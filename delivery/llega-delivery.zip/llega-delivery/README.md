# Llega · plataforma de delivery

**Español** · [English](README.en.md)

Plataforma de pedidos a domicilio para restaurantes locales, con rastreo en vivo del repartidor. Una sola app se puede vender de tres formas:

1. **Tienda propia (marca blanca):** cada restaurante tiene su página de pedidos (`/r/su-restaurante`) con su color, menú, QR y un **asistente de IA** que toma pedidos por chat. Sin comisión por pedido.
2. **Marketplace:** la página principal lista a los restaurantes que quieran aparecer, como Rappi o Uber Eats.
3. **Solo rastreo (como Pinkbot):** el restaurante ya recibe pedidos por teléfono, WhatsApp o su sistema de caja. Los captura en el panel (o por **API**) y el cliente recibe un link para ver a su repartidor en el mapa.

<p>
  <img src="docs/screenshots/marketplace.png" width="200" alt="Marketplace en el celular">
  <img src="docs/screenshots/tienda.png" width="200" alt="Tienda del restaurante">
  <img src="docs/screenshots/rastreo.png" width="200" alt="Rastreo en vivo con mapa, hora estimada y código de entrega">
  <img src="docs/screenshots/repartidor.png" width="200" alt="App del repartidor">
</p>
<p>
  <img src="docs/screenshots/panel.png" width="560" alt="Panel del restaurante">
  <img src="docs/screenshots/chat.png" width="200" alt="Pedido por chat con el asistente">
</p>

> **Para empezar rápido en Windows lee [INSTRUCCIONES.txt](INSTRUCCIONES.txt).** Para entender cada parte, [COMO-FUNCIONA.txt](COMO-FUNCIONA.txt).

---

## Estado honesto

| Función | Estado | Cómo se probó |
|---|---|---|
| Marketplace, tienda por restaurante, carrito, checkout con pin en el mapa, propina | ✅ Funciona | E2E en Chromium |
| Precios, radio de entrega, pedido mínimo y abierto/cerrado validados **en el servidor** | ✅ | Unitarias + E2E (un producto inventado se rechaza) |
| Pago en **efectivo** contra entrega | ✅ Real | E2E |
| Pago con **tarjeta** | ⚠️ **Simulado**: no pide datos ni cobra. Mercado Pago/Stripe es el siguiente paso | — |
| Panel del restaurante: tablero en vivo con sonido, aceptar con tiempo, listo, asignar repartidor, rechazar con motivo, chat | ✅ | E2E |
| App del repartidor (web): disponible, GPS en vivo, tomar/soltar pedidos, Google Maps/Waze, **código de entrega** anti-fraude | ✅ | E2E con GPS simulado del navegador |
| Rastreo del cliente: mapa, hora estimada con el GPS del repartidor, pasos, chat, llamar, ayuda, calificar, cancelar mientras está pendiente | ✅ | E2E |
| Simulador de repartidor (para demos) | ✅ Solo en desarrollo o con `DEMO_TOOLS=1` | E2E |
| **Asistente de IA** que toma pedidos por chat y crea el pedido real | ✅ Con Groq/OpenAI/Anthropic. **Necesita tu clave** | E2E contra un servidor que imita la API de Groq. **No probado con Groq real** |
| Asistente sin IA (reglas: cantidades, platillos, "sin cebolla", datos, "es todo", "sí") | ✅ Funciona sin claves | Unitarias + E2E |
| WhatsApp (Meta Cloud API o Twilio): webhook que conecta al asistente + avisos con plantillas | ✅ Código listo, firmas verificadas. **Requiere cuenta de WhatsApp Business y plantillas aprobadas** | Unitarias con respuestas simuladas. **No probado con Meta/Twilio reales** |
| SMS con Twilio | ✅ Código listo. **Requiere cuenta Twilio** (≈US$0.18 por SMS a México) | Unitarias con API simulada |
| Sin proveedor de mensajes | ✅ Los mensajes se guardan en *Panel → Mensajes* | E2E |
| API pública para "solo rastreo" (`/api/v1`) con claves por restaurante | ✅ | E2E |
| Registro de restaurantes, invitación de repartidores, editor de menú, ajustes, QR, administración | ✅ | E2E |
| Seguridad: contraseñas con scrypt, sesiones firmadas, protección CSRF, límites de intentos, roles | ✅ | E2E (401/403) |
| Base de datos: PostgreSQL (Neon en producción, PGlite integrado en local) | ✅ | Todas las pruebas corren sobre Postgres real |
| Tiempo real | ✅ Por consulta cada 4–5 s (funciona en Vercel). No usa WebSockets | E2E |
| Facturación (CFDI), cobros a restaurantes, pagos a repartidores | ❌ No incluido | — |
| App nativa en tiendas (iOS/Android) | ❌ Es web adaptable al celular | — |

**Pruebas:** `npm test` (27 unitarias e integración sobre Postgres en memoria) y `npm run test:e2e` (6 escenarios y 44 verificaciones en Chromium con cliente, restaurante y repartidor en navegadores separados y GPS simulado).

---

## Cómo funciona

```
 Cliente (web)                 Restaurante (panel)             Repartidor (web en su celular)
 marketplace / tienda / chat   tablero · menú · ajustes         disponible · GPS · entregar con código
        │                              │                                  │
        └──────────── Next.js (API + páginas) ─────────────────────────────┘
                         │           │             │
                   PostgreSQL   Agente de IA    SMS / WhatsApp
                   (Neon)       (Groq…)         (Twilio / Meta)
```

- **Estados del pedido:** `pending → preparing → ready → on_the_way → delivered` (o `cancelled`). Quién puede hacer cada cambio está en una sola tabla: `src/lib/order-flow.ts`.
- **Hora estimada:** tiempo de preparación + distancia (con factor de calles) y, cuando el repartidor va en camino, su GPS real (`src/lib/eta.ts`).
- **Agente de pedidos:** la IA solo *propone* acciones (agregar, quitar, datos del cliente, pedir). El código las valida contra el menú real y **el pedido solo se crea cuando el cliente responde "sí" a un resumen que genera el código**, no la IA (`src/server/agent`).
- **Privacidad:** el teléfono del cliente solo lo ve el repartidor asignado; la ubicación del repartidor solo se comparte mientras lleva tu pedido.

## Ejecutarlo

```bash
npm install
cp .env.example .env.local      # Windows: Copy-Item .env.example .env.local
npm run dev                     # http://localhost:3000
```

Sin configurar nada usa una base PostgreSQL integrada (PGlite) en `.data/` y crea 3 restaurantes de ejemplo en Tepotzotlán. Cuentas demo (contraseña `demo1234`): `dueno@llega.demo` (restaurante), `repartidor@llega.demo` (repartidor), `admin@llega.demo`.

## Producción

1. **Base de datos:** crea un proyecto en [Neon](https://neon.tech) y pon la cadena *pooled* en `DATABASE_URL`. Las tablas se crean solas al primer uso (migraciones en `src/server/db/migrations.ts`).
2. **Hosting:** Vercel (recuerda que el plan Hobby es solo para uso no comercial), Render, Railway o un VPS con `npm run build && npm start`.
3. **Variables obligatorias:** `DATABASE_URL`, `AUTH_SECRET`, `APP_URL`. Recomendadas: `ADMIN_EMAILS`, `GROQ_API_KEY`. Todas están explicadas en [.env.example](.env.example).
4. **Mensajes:** Twilio y/o WhatsApp ([docs/WHATSAPP.md](docs/WHATSAPP.md)).
5. **Mapas:** para uso comercial con volumen cambia `NEXT_PUBLIC_MAP_TILE_URL` a MapTiler, Stadia o Mapbox (las reglas de OpenStreetMap no permiten uso intensivo de sus servidores).

## Costos por pedido (aprox., septiembre 2026; verifícalos)

| Concepto | Costo |
|---|---|
| Agente de IA con Groq (`gpt-oss-20b`) | < US$0.01 por conversación |
| SMS Twilio a México | ≈ US$0.18 por mensaje (hasta 4 por pedido) |
| WhatsApp (Meta) | Plantillas de utilidad: centavos por mensaje; gratis dentro de la ventana de 24 h cuando el cliente escribió primero |
| Neon, Vercel | Planes gratis para empezar; Vercel Pro ≈ US$20/mes para uso comercial |

Recomendación: usa WhatsApp o manda un solo SMS (el link de rastreo). El cliente ya ve su pedido en vivo al terminar de pedir.

## Limitaciones conocidas

- Los límites de intentos (login, pedidos por IP) viven en memoria de cada servidor; en serverless son aproximados. Para volumen, muévelos a Redis.
- El GPS del repartidor se envía mientras la página está abierta. Con la pantalla bloqueada, iOS y Android pausan la ubicación en el navegador; la app mantiene la pantalla encendida donde el navegador lo permite (Wake Lock). Una app nativa resolvería esto.
- La búsqueda de direcciones con Nominatim es gratuita pero limitada (≈1 consulta/segundo). Para volumen usa `GEOCODER=mapbox`.
- Un número de WhatsApp atiende a un restaurante (`WHATSAPP_DEFAULT_RESTAURANT`) o se asigna por restaurante en la columna `whatsapp_phone_number_id`.
- Los precios y modelos de los proveedores cambian: revisa antes de lanzar.

## Estructura

```
src/app/                  páginas (marketplace, tienda, checkout, rastreo, panel, repartidor, admin) y API
src/server/orders.ts      pedidos: checkout, estados, asignación, rastreo, simulador
src/server/agent/         asistente de pedidos: IA, reglas, WhatsApp
src/server/notify/        SMS / WhatsApp (Twilio, Meta) y modo demo
src/server/db/            PostgreSQL (Neon o PGlite), migraciones, datos demo
src/lib/                  lógica compartida: estados, hora estimada, dinero, teléfonos
tests/unit, tests/e2e     pruebas
docs/                     negocio, API, WhatsApp
```

Licencia: define la tuya antes de publicar.
