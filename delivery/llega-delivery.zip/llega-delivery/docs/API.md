# API pública (modo "solo rastreo")

Para que el sistema de caja, la página web o el bot de WhatsApp de un restaurante cree pedidos y obtenga un link de rastreo en vivo.

## Autenticación

El dueño crea una clave en **Panel → Ajustes → API**. Se muestra una sola vez. Envíala así:

```
Authorization: Bearer llk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## Crear un pedido

`POST /api/v1/orders`

```json
{
  "customer": { "name": "Ana López", "phone": "55 1234 5678" },
  "address": { "text": "Calle Hidalgo 12, Centro", "notes": "portón negro", "lat": 19.7188, "lng": -99.2168 },
  "items": [{ "name": "Orden de tacos", "qty": 2, "unitPriceCents": 9000 }],
  "totalCents": 18000,
  "paymentMethod": "cash",
  "prepMinutes": 20,
  "notify": true
}
```

- `lat`/`lng` son opcionales, pero sin ellos no hay mapa ni hora estimada precisa.
- `paymentMethod`: `cash` (cobrar al entregar) o `prepaid` (ya pagó).
- `notify`: manda al cliente el SMS/WhatsApp con el link.

Respuesta `201`:

```json
{
  "id": "5b0c…",
  "code": "K7QM",
  "status": "preparing",
  "tracking_url": "https://tu-dominio/t/AbC…",
  "delivery_pin": "4821",
  "eta": "2026-09-27T20:05:00.000Z"
}
```

## Consultar un pedido

`GET /api/v1/orders/{id}` → `{ id, code, status, courier, eta, delivered_at, tracking_url }`

## Cambiar el estado

`POST /api/v1/orders/{id}/status` con `{ "status": "ready" }` o `{ "status": "cancelled", "reason": "…" }`.

El repartidor marca "en camino" y "entregado" desde su app.

## Ejemplo con curl

```bash
curl -X POST https://tu-dominio/api/v1/orders \
  -H "Authorization: Bearer llk_..." -H "Content-Type: application/json" \
  -d '{"customer":{"name":"Ana","phone":"5512345678"},"address":{"text":"Calle 1"},"totalCents":15000}'
```

Errores: `400` datos inválidos, `401` clave faltante o revocada, `404` pedido de otro restaurante, `409` cambio de estado no permitido, `429` demasiadas solicitudes (120 por minuto por restaurante).
