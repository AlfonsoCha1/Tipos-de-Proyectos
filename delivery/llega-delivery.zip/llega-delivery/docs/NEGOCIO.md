# Llega: cómo validarlo y convertirlo en negocio

Propuesta de trabajo. Los precios y cifras son hipótesis para validar con restaurantes reales; verifica comisiones y costos actuales antes de decidir.

## 1. La apuesta

**Cliente que paga:** restaurantes independientes de zona conurbada (empezando por Tepotzotlán, Cuautitlán, Cuautitlán Izcalli, Huehuetoca, Teoloyucan) que:
- ya reparten con su propia gente o motos, y reciben pedidos por teléfono o WhatsApp, o
- están en Rappi / Uber Eats / DiDi Food y les duele la comisión por pedido.

**Problema:** tomar pedidos por WhatsApp es caótico (errores, "¿ya viene?", clientes que no encuentran la casa) y las apps grandes se quedan con una parte grande de cada venta y con el cliente.

**Propuesta:** "tu propio delivery, con tu nombre": página de pedidos + asistente que toma pedidos por chat + rastreo en vivo para tus clientes + app para tus repartidores. Precio fijo mensual en lugar de comisión.

**Por qué tú:** vives en la zona, conoces tecnología y soporte, y puedes dar de alta a cada restaurante en persona (capturar el menú, imprimir el QR, capacitar al repartidor). Eso es difícil de copiar para una app grande.

## 2. Qué vender primero

No lances los tres modelos a la vez. Orden recomendado:

1. **Tienda propia + rastreo (plan "Tienda propia")** a restaurantes con repartidores propios. Es donde el valor es más claro y no necesitas conseguir repartidores ni clientes finales.
2. **Solo rastreo** para restaurantes que no quieren cambiar cómo reciben pedidos. Es la venta más fácil ("tus clientes dejan de preguntar ¿ya viene?").
3. **Marketplace** solo cuando tengas 20–30 restaurantes activos en una zona. Antes de eso, la página principal se ve vacía y no atrae clientes.

## 3. Plan de validación (6 semanas)

**Semana 1–2: entrevistas (sin vender).** Visita 20 restaurantes. Pregunta:
- ¿Cuántos pedidos a domicilio tienen por semana y por dónde llegan?
- ¿Tienen repartidores propios? ¿Cuántos?
- ¿Están en apps? ¿Qué comisión pagan? ¿Qué les molesta?
- ¿Qué pasa cuando un cliente pregunta "¿ya viene mi pedido?"

Señal para seguir: al menos 8 de 20 tienen repartidor propio y más de 30 pedidos a domicilio por semana.

**Semana 3–6: piloto con 3 restaurantes, gratis por 30 días.**
- Tú capturas su menú, imprimes el QR (mesas, bolsas, volantes) y das de alta a sus repartidores.
- Ellos mandan el link de su tienda a sus clientes de WhatsApp.
- Mide cada semana (el panel ya guarda los datos):
  - pedidos por la tienda propia vs. por teléfono/WhatsApp,
  - % de pedidos entregados sin problema y tiempo promedio,
  - % de clientes que repiten,
  - llamadas de "¿ya viene?" (pregúntale al restaurante antes y después).

**Decisión al día 30:** pide que paguen el segundo mes. Si 2 de 3 pagan, sigues. Si ninguno paga, entrevista por qué antes de construir más.

## 4. Precios propuestos (hipótesis)

| Plan | Precio | Para quién |
|---|---|---|
| Solo rastreo | $499 MXN/mes | Ya tienen pedidos y repartidores; quieren rastreo y avisos |
| Tienda propia | $899 MXN/mes | Quieren su página, asistente por chat y rastreo, sin comisión |
| Marketplace | 8% por pedido | Más adelante, cuando haya clientes que buscan en la página principal |

**Comparación que convence:** un restaurante con 300 pedidos al mes y ticket de $250 vende $75,000. Si una app le cobra entre 20% y 30% (confírmalo en tus entrevistas), paga entre $15,000 y $22,500 al mes. Con la tienda propia paga $899 más el costo de sus repartidores, que ya tiene.

**Tus costos por restaurante (aprox.):** hosting y base de datos se reparten entre todos (Vercel Pro ~US$20/mes + Neon), IA menos de 1 centavo de dólar por conversación. El costo variable importante son los **SMS (~US$0.18 cada uno en México)**: usa WhatsApp o limita a 1 SMS por pedido, o cobra los SMS aparte.

## 5. Antes de cobrar en serio

- **Pagos con tarjeta:** integrar Mercado Pago (Checkout Pro o Split para marketplace). Hoy el pago con tarjeta es de prueba.
- **Facturas (CFDI)** para cobrar la mensualidad a restaurantes.
- **Aviso de privacidad y términos** (plantillas en `/privacidad` y `/terminos`), revisados por un abogado.
- **Repartidores:** si son del restaurante, la relación laboral es del restaurante. Si en el marketplace los pones tú, revisa con un abogado las reglas para trabajadores de plataformas digitales vigentes desde 2025.
- **WhatsApp Business** verificado y plantillas aprobadas (ver `docs/WHATSAPP.md`).
- Borrar las cuentas de demo y poner `DEMO_TOOLS=0`.

## 6. Métricas para seguir cada semana

- Restaurantes activos (al menos 10 pedidos en la semana).
- Pedidos por restaurante y % que llegan por la tienda propia.
- Tiempo de entrega promedio y % entregados a tiempo (vs. hora estimada).
- Calificación promedio y solicitudes de ayuda por cada 100 pedidos.
- Restaurantes que cancelan (churn) y por qué.

## 7. Riesgos

| Riesgo | Cómo reducirlo |
|---|---|
| El restaurante no tiene repartidores | Empieza solo con los que sí tienen; más adelante, red de repartidores compartida |
| Los clientes siguen pidiendo por WhatsApp | Conecta el asistente al WhatsApp del restaurante: el cliente escribe igual, pero el pedido entra al sistema |
| Costos de SMS | WhatsApp con plantillas, o un solo SMS con el link |
| Competencia de apps grandes | No compitas por clientes finales; vende control y ahorro al restaurante |
| Pagos en efectivo | El repartidor cobra; el panel marca pagado al entregar. Tarjeta real después |
