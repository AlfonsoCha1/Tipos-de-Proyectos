# WhatsApp: avisos y pedidos por chat

Hay dos usos:

1. **Avisos** (pedido recibido, aceptado, en camino, entregado). El negocio escribe primero, así que WhatsApp **exige plantillas aprobadas**.
2. **Pedidos por chat.** El cliente escribe al número del restaurante y el asistente responde. Dentro de las 24 h después de que el cliente escribe, se permite texto libre y Meta no cobra esos mensajes.

Puedes usar **Meta WhatsApp Cloud API** (directo) o **Twilio**.

## Opción A: Meta WhatsApp Cloud API

1. En [developers.facebook.com](https://developers.facebook.com) crea una app de tipo *Business* y agrega el producto **WhatsApp**.
2. Conecta y verifica un número (no puede estar usándose en la app normal de WhatsApp).
3. Copia a tus variables:
   - `META_WHATSAPP_TOKEN` (token permanente de un *System User*)
   - `META_WHATSAPP_PHONE_NUMBER_ID`
   - `META_APP_SECRET` (Configuración de la app → Básica)
   - `META_WEBHOOK_VERIFY_TOKEN` (inventa un texto)
4. Webhook: URL `https://TU-DOMINIO/api/webhooks/whatsapp`, token de verificación = `META_WEBHOOK_VERIFY_TOKEN`, suscríbete a `messages`.
5. Qué restaurante contesta: `WHATSAPP_DEFAULT_RESTAURANT=slug-del-restaurante`. Con varios números, pon el Phone Number ID en la columna `whatsapp_phone_number_id` de cada restaurante.
6. Plantillas: crea en WhatsApp Manager estas plantillas de categoría **Utilidad**, idioma **Español (MEX) `es_MX`**, y activa `META_USE_TEMPLATES=1`:

| Nombre | Texto sugerido |
|---|---|
| `llega_created` | Recibimos tu pedido #{{1}} de {{2}} por {{3}}. Síguelo en vivo: {{4}} |
| `llega_tracking_only_created` | {{1}} está preparando tu pedido #{{2}}. Síguelo en vivo: {{3}} |
| `llega_accepted` | {{1}} aceptó tu pedido #{{2}}. Llegada estimada: {{3}}. {{4}} |
| `llega_on_the_way` | {{1}} va en camino con tu pedido de {{2}}. Tu código de entrega es {{3}}. Síguelo aquí: {{4}} |
| `llega_delivered` | Tu pedido de {{1}} fue entregado. ¿Qué tal estuvo? Califícalo aquí: {{2}} |
| `llega_cancelled` | Tu pedido #{{1}} de {{2}} fue cancelado. Motivo: {{3}} |

El orden de las variables importa (lo llena `templateParams` en `src/server/notify/index.ts`). Si cambias el prefijo usa `META_TEMPLATE_PREFIX`.

## Opción B: Twilio

1. Activa WhatsApp en Twilio (sandbox para pruebas o un sender aprobado).
2. Variables: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM`.
3. Webhook "When a message comes in": `https://TU-DOMINIO/api/webhooks/twilio`. La firma `X-Twilio-Signature` se verifica con tu `APP_URL`; debe coincidir exactamente con la URL configurada.
4. Plantillas: crea *Content Templates* con los mismos textos de la tabla y pon su SID en `TWILIO_CONTENT_SID_CREATED`, `TWILIO_CONTENT_SID_ON_THE_WAY`, etc.

## Canal por restaurante

En **Panel → Ajustes → Avisos al cliente** cada restaurante elige SMS, WhatsApp o no enviar.

## Costos

Meta cobra por plantilla entregada (tarifas por país y categoría en su tabla de precios); los mensajes dentro de la ventana de atención de 24 h son gratis. Twilio agrega su tarifa por mensaje. Revisa las tarifas vigentes antes de lanzar.
