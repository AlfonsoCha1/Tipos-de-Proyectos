"use client";
import Link from "next/link";
import { useState } from "react";
import { api, ApiError } from "@/lib/client/api";

interface Row {
  id: string;
  slug: string;
  name: string;
  active: boolean;
  inMarketplace: boolean;
  isOpen: boolean;
  orders7d: number;
  sales7d: string;
  couriers: number;
}

export default function AdminTable({ restaurants }: { restaurants: Row[] }) {
  const [rows, setRows] = useState(restaurants);
  const [error, setError] = useState<string | null>(null);

  async function toggle(id: string, field: "active" | "inMarketplace", value: boolean) {
    setError(null);
    try {
      await api("/api/admin/restaurants", { method: "PATCH", body: { id, [field]: value } });
      setRows((rs) => rs.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "No se pudo guardar.");
    }
  }

  return (
    <div className="stack">
      {error && <p className="alert">{error}</p>}
      <div style={{ overflowX: "auto" }}>
        <table className="table">
          <thead>
            <tr>
              <th>Restaurante</th>
              <th>Pedidos 7 d</th>
              <th>Ventas 7 d</th>
              <th>Repartidores</th>
              <th>Activo</th>
              <th>Marketplace</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>
                  <Link href={`/r/${r.slug}`}>{r.name}</Link>
                  <div className="faint">{r.isOpen ? "Abierto" : "Cerrado"} · /r/{r.slug}</div>
                </td>
                <td>{r.orders7d}</td>
                <td>{r.sales7d}</td>
                <td>{r.couriers}</td>
                <td>
                  <input type="checkbox" aria-label={`Activo: ${r.name}`} checked={r.active} onChange={(e) => toggle(r.id, "active", e.target.checked)} />
                </td>
                <td>
                  <input type="checkbox" aria-label={`En marketplace: ${r.name}`} checked={r.inMarketplace} onChange={(e) => toggle(r.id, "inMarketplace", e.target.checked)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
