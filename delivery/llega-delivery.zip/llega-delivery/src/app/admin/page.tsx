import { redirect } from "next/navigation";
import { Topbar } from "@/components/Chrome";
import { mxn } from "@/lib/money";
import { currentUser, isAdmin } from "@/server/auth";
import { sql } from "@/server/db";
import AdminTable from "./AdminTable";

export const dynamic = "force-dynamic";
export const metadata = { title: "Administración" };

export default async function AdminPage() {
  const u = await currentUser();
  if (!isAdmin(u)) redirect("/panel/login");
  const rows = await sql<{
    id: string;
    slug: string;
    name: string;
    active: boolean;
    in_marketplace: boolean;
    is_open: boolean;
    orders_7d: number;
    sales_7d: number;
    couriers: number;
    created_at: Date;
  }>(
    `select r.id, r.slug, r.name, r.active, r.in_marketplace, r.is_open, r.created_at,
       (select count(*)::int from orders o where o.restaurant_id = r.id and o.created_at > now() - interval '7 days') as orders_7d,
       (select coalesce(sum(total_cents), 0)::int from orders o where o.restaurant_id = r.id and o.status = 'delivered' and o.created_at > now() - interval '7 days') as sales_7d,
       (select count(*)::int from users u where u.restaurant_id = r.id and u.role = 'courier') as couriers
     from restaurants r order by r.created_at desc`,
  );
  const [totals] = await sql<{ orders: number; delivered: number; active: number }>(
    `select count(*)::int as orders, count(*) filter (where status = 'delivered')::int as delivered,
       count(*) filter (where status in ('pending','preparing','ready','on_the_way'))::int as active
     from orders where created_at > now() - interval '7 days'`,
  );
  return (
    <>
      <Topbar />
      <main className="wrap stack-l" style={{ padding: "24px 16px 60px" }}>
        <div className="stack">
          <h1 className="display">Administración</h1>
          <p className="muted">Últimos 7 días en toda la plataforma.</p>
        </div>
        <div className="stat-row">
          <div className="stat">
            <b>{totals.orders}</b>
            <span>pedidos</span>
          </div>
          <div className="stat">
            <b>{totals.delivered}</b>
            <span>entregados</span>
          </div>
          <div className="stat">
            <b>{totals.active}</b>
            <span>en curso ahora</span>
          </div>
          <div className="stat">
            <b>{rows.length}</b>
            <span>restaurantes</span>
          </div>
        </div>
        <AdminTable
          restaurants={rows.map((r) => ({
            id: r.id,
            slug: r.slug,
            name: r.name,
            active: r.active,
            inMarketplace: r.in_marketplace,
            isOpen: r.is_open,
            orders7d: r.orders_7d,
            sales7d: mxn(r.sales_7d),
            couriers: r.couriers,
          }))}
        />
      </main>
    </>
  );
}
