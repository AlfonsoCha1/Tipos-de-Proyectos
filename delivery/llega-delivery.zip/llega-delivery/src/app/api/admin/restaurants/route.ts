import { z } from "zod";
import { currentUser, isAdmin } from "@/server/auth";
import { sql } from "@/server/db";
import { body, HttpError, json, route } from "@/server/http";

export const PATCH = route(async (req) => {
  if (!isAdmin(await currentUser())) throw new HttpError(403, "Solo administradores.");
  const { id, active, inMarketplace } = await body(req, z.object({ id: z.string().uuid(), active: z.boolean().optional(), inMarketplace: z.boolean().optional() }));
  if (active !== undefined) await sql("update restaurants set active = $2 where id = $1", [id, active]);
  if (inMarketplace !== undefined) await sql("update restaurants set in_marketplace = $2 where id = $1", [id, inMarketplace]);
  return json({ ok: true });
});
