import { z } from "zod";
import { agentSnapshot, handleAgentTurn } from "@/server/agent";
import { appUrl, body, clientIp, HttpError, json, rateLimit, route } from "@/server/http";
import { getRestaurantBySlug } from "@/server/repo/restaurants";

const Schema = z.object({
  sessionId: z.string().max(64).nullable().optional(),
  text: z.string().max(500).default(""),
  location: z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }).nullable().optional(),
});

export const maxDuration = 30;

export const POST = route<{ params: Promise<{ slug: string }> }>(async (req, { params }) => {
  const { slug } = await params;
  const r = await getRestaurantBySlug(slug);
  if (!r) throw new HttpError(404, "Restaurante no encontrado.");
  rateLimit(`agent:${clientIp(req)}`, 60, 10 * 60_000);
  const input = await body(req, Schema);
  if (!input.text.trim() && !input.location) throw new HttpError(400, "Escribe un mensaje.");
  const out = await handleAgentTurn({ restaurant: r, channel: "web", sessionId: input.sessionId, text: input.text, location: input.location }, appUrl(req));
  return json(out);
});

export const GET = route<{ params: Promise<{ slug: string }> }>(async (req, { params }) => {
  const { slug } = await params;
  const r = await getRestaurantBySlug(slug);
  if (!r) throw new HttpError(404, "Restaurante no encontrado.");
  const sessionId = new URL(req.url).searchParams.get("session") ?? "";
  const snap = await agentSnapshot(r, sessionId, appUrl(req));
  if (!snap) throw new HttpError(404, "Conversación no encontrada.", "no_session");
  return json(snap);
});
