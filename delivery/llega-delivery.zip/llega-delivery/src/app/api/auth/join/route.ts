import { z } from "zod";
import { normalizePhone } from "@/lib/phone";
import { hashPassword, setSessionCookie } from "@/server/auth";
import { getDb } from "@/server/db";
import { body, clientIp, HttpError, json, rateLimit, route } from "@/server/http";

const Schema = z.object({
  code: z.string().min(4).max(20),
  name: z.string().min(2).max(80),
  email: z.string().email().max(120),
  password: z.string().min(8, "La contraseña debe tener al menos 8 caracteres.").max(200),
  phone: z.string().min(8).max(25),
  vehicle: z.enum(["moto", "bici", "auto", "pie"]).default("moto"),
});

/** A courier joins a restaurant's team with the invite code the restaurant shares. */
export const POST = route(async (req) => {
  rateLimit(`join:${clientIp(req)}`, 8, 60 * 60_000);
  const input = await body(req, Schema);
  const phone = normalizePhone(input.phone);
  if (!phone) throw new HttpError(400, "Teléfono inválido: usa 10 dígitos.");
  const pw = await hashPassword(input.password);
  const db = await getDb();
  const user = await db.tx(async (q) => {
    const [r] = await q.query<{ id: string }>("select id from restaurants where courier_invite_code = $1 and active", [input.code.trim().toUpperCase()]);
    if (!r) throw new HttpError(404, "Código de invitación inválido. Pídeselo de nuevo al restaurante.", "bad_code");
    if ((await q.query("select 1 from users where lower(email) = lower($1)", [input.email])).length) {
      throw new HttpError(409, "Ya hay una cuenta con ese correo. Inicia sesión.", "email_taken");
    }
    const [u] = await q.query<{ id: string; password_hash: string }>(
      "insert into users (email, name, phone, password_hash, role, restaurant_id, vehicle) values ($1,$2,$3,$4,'courier',$5,$6) returning id, password_hash",
      [input.email.toLowerCase(), input.name.trim(), phone, pw, r.id, input.vehicle],
    );
    await q.query("insert into courier_status (user_id) values ($1)", [u.id]);
    return u;
  });
  await setSessionCookie(user.id, user.password_hash);
  return json({ ok: true, redirect: "/repartidor" }, { status: 201 });
});
