import { z } from "zod";
import { setSessionCookie, verifyPassword } from "@/server/auth";
import { one } from "@/server/db";
import { body, clientIp, HttpError, json, rateLimit, route } from "@/server/http";

export const POST = route(async (req) => {
  const { email, password } = await body(req, z.object({ email: z.string().email().max(120), password: z.string().min(1).max(200) }));
  rateLimit(`login:${clientIp(req)}:${email.toLowerCase()}`, 8, 15 * 60_000);
  const u = await one<{ id: string; role: string; password_hash: string }>("select id, role, password_hash from users where lower(email) = lower($1)", [email]);
  if (!u || !(await verifyPassword(password, u.password_hash))) throw new HttpError(401, "Correo o contraseña incorrectos.", "bad_credentials");
  await setSessionCookie(u.id, u.password_hash);
  const redirect = u.role === "courier" ? "/repartidor" : u.role === "admin" ? "/admin" : "/panel";
  return json({ ok: true, role: u.role, redirect });
});
