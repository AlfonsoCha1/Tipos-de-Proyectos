import { z } from "zod";
import { normalizePhone } from "@/lib/phone";
import { slugify } from "@/lib/text";
import { hashPassword, setSessionCookie } from "@/server/auth";
import { getDb } from "@/server/db";
import { body, clientIp, HttpError, json, rateLimit, route } from "@/server/http";
import { randomCode } from "@/server/random";

const Schema = z.object({
  restaurantName: z.string().min(2).max(80),
  cuisine: z.string().max(40).default(""),
  ownerName: z.string().min(2).max(80),
  email: z.string().email().max(120),
  password: z.string().min(8, "La contraseña debe tener al menos 8 caracteres.").max(200),
  phone: z.string().min(8).max(25),
  address: z.string().min(5).max(200),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
});

/** Restaurant self-signup: creates the restaurant, its owner account and signs in. */
export const POST = route(async (req) => {
  rateLimit(`register:${clientIp(req)}`, 5, 60 * 60_000);
  if (process.env.ALLOW_SIGNUP === "0") throw new HttpError(403, "El registro está cerrado. Contáctanos para darte de alta.");
  const input = await body(req, Schema);
  const phone = normalizePhone(input.phone);
  if (!phone) throw new HttpError(400, "Teléfono inválido: usa 10 dígitos.");
  const pw = await hashPassword(input.password);
  const db = await getDb();
  const user = await db.tx(async (q) => {
    const exists = await q.query("select 1 from users where lower(email) = lower($1)", [input.email]);
    if (exists.length) throw new HttpError(409, "Ya hay una cuenta con ese correo. Inicia sesión.", "email_taken");
    let slug = slugify(input.restaurantName) || "restaurante";
    if ((await q.query("select 1 from restaurants where slug = $1", [slug])).length) slug = `${slug}-${randomCode(4, "abcdefghjkmnpqrstuvwxyz23456789")}`;
    const [r] = await q.query<{ id: string }>(
      `insert into restaurants (slug, name, cuisine, phone, address, lat, lng, courier_invite_code, in_marketplace)
       values ($1,$2,$3,$4,$5,$6,$7,$8,false) returning id`,
      [slug, input.restaurantName.trim(), input.cuisine.trim(), phone, input.address.trim(), input.lat, input.lng, randomCode(8)],
    );
    const [u] = await q.query<{ id: string; password_hash: string }>(
      "insert into users (email, name, phone, password_hash, role, restaurant_id) values ($1,$2,$3,$4,'owner',$5) returning id, password_hash",
      [input.email.toLowerCase(), input.ownerName.trim(), phone, pw, r.id],
    );
    return u;
  });
  await setSessionCookie(user.id, user.password_hash);
  return json({ ok: true, redirect: "/panel/ajustes?nuevo=1" }, { status: 201 });
});
