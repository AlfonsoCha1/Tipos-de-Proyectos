import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { body, json, route } from "@/server/http";

export const POST = route(async (req) => {
  const u = await requireApiUser(["courier"]);
  const { available } = await body(req, z.object({ available: z.boolean() }));
  await sql(
    "insert into courier_status (user_id, available) values ($1,$2) on conflict (user_id) do update set available = excluded.available",
    [u.id, available],
  );
  return json({ ok: true, available });
});
