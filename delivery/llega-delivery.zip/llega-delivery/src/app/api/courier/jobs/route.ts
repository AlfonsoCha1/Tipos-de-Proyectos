import { requireApiUser } from "@/server/auth";
import { one } from "@/server/db";
import { json, route } from "@/server/http";
import { courierJobs } from "@/server/orders";

export const GET = route(async () => {
  const u = await requireApiUser(["courier"]);
  const status = await one<{ available: boolean; lat: number | null; lng: number | null; updated_at: Date | null }>(
    "select available, lat, lng, updated_at from courier_status where user_id = $1",
    [u.id],
  );
  return json({
    me: { id: u.id, name: u.name, available: !!status?.available, lastFix: status?.updated_at ?? null },
    jobs: await courierJobs(u.id, u.restaurantId),
  });
});
