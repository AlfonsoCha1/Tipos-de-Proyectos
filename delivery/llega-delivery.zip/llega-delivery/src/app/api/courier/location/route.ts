import { requireApiUser } from "@/server/auth";
import { LocationSchema } from "@/server/api/schemas";
import { sql } from "@/server/db";
import { body, json, rateLimit, route } from "@/server/http";
import { refreshCourierEtas } from "@/server/orders";

/** GPS ping from the courier's phone (every few seconds while working). */
export const POST = route(async (req) => {
  const u = await requireApiUser(["courier"]);
  rateLimit(`loc:${u.id}`, 40, 60_000);
  const p = await body(req, LocationSchema);
  await sql(
    `insert into courier_status (user_id, lat, lng, accuracy, heading, updated_at) values ($1,$2,$3,$4,$5, now())
     on conflict (user_id) do update set lat = excluded.lat, lng = excluded.lng, accuracy = excluded.accuracy, heading = excluded.heading, updated_at = now()`,
    [u.id, p.lat, p.lng, p.accuracy ?? null, p.heading ?? null],
  );
  await refreshCourierEtas(u.id);
  return json({ ok: true });
});
