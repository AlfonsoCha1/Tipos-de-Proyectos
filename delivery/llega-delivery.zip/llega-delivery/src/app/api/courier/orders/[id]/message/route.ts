import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { one } from "@/server/db";
import { body, HttpError, json, rateLimit, route } from "@/server/http";
import { addMessage } from "@/server/orders";

export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["courier"]);
  const { id } = await params;
  const o = await one("select id from orders where id = $1 and courier_id = $2 and status in ('preparing','ready','on_the_way')", [id, u.id]);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  rateLimit(`cmsg:${u.id}`, 40, 10 * 60_000);
  const { text } = await body(req, z.object({ text: z.string().min(1).max(500) }));
  await addMessage(id, "courier", text);
  return json({ ok: true });
});
