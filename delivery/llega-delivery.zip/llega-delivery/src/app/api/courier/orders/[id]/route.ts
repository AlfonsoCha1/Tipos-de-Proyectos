import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { getDb } from "@/server/db";
import { appUrl, body, HttpError, json, route } from "@/server/http";
import { transitionOrder } from "@/server/orders";

/**
 * take    — claim an unassigned order of my restaurant
 * release — give it back (only before pickup)
 * pickup  — I have the food: order goes "on the way"
 * deliver — handed to the customer (PIN if the restaurant requires it)
 */
export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["courier"]);
  const { id } = await params;
  const { action, pin } = await body(req, z.object({ action: z.enum(["take", "release", "pickup", "deliver"]), pin: z.string().max(8).optional() }));
  const base = appUrl(req);
  if (action === "take" || action === "release") {
    const db = await getDb();
    await db.tx(async (q) => {
      const [o] = await q.query<{ id: string; courier_id: string | null; status: string; restaurant_id: string }>(
        "select id, courier_id, status, restaurant_id from orders where id = $1 for update",
        [id],
      );
      if (!o || o.restaurant_id !== u.restaurantId) throw new HttpError(404, "Pedido no encontrado.");
      if (!["preparing", "ready"].includes(o.status)) throw new HttpError(409, "Este pedido ya no se puede tomar ni soltar.");
      if (action === "take") {
        if (o.courier_id && o.courier_id !== u.id) throw new HttpError(409, "Otro repartidor ya lo tomó.", "taken");
        await q.query("update orders set courier_id = $2 where id = $1", [id, u.id]);
        await q.query("insert into order_events (order_id, type, message, actor) values ($1,'assigned',$2,'courier')", [id, `${u.name} tomó el pedido`]);
      } else {
        if (o.courier_id !== u.id) throw new HttpError(409, "Este pedido no es tuyo.");
        await q.query("update orders set courier_id = null where id = $1", [id]);
        await q.query("insert into order_events (order_id, type, message, actor) values ($1,'unassigned',$2,'courier')", [id, `${u.name} soltó el pedido`]);
      }
    });
    return json({ ok: true });
  }
  const to = action === "pickup" ? "on_the_way" : "delivered";
  const o = await transitionOrder(id, to, { actor: "courier", courierId: u.id, pin }, base);
  return json({ ok: true, status: o.status });
});
