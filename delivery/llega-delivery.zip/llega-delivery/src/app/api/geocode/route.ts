import { clientIp, HttpError, json, rateLimit, route } from "@/server/http";

/**
 * Address search for the checkout map.
 * GEOCODER=nominatim (default, free OpenStreetMap service; max ~1 request/second, light use only)
 * GEOCODER=mapbox with MAPBOX_TOKEN for production volume. GEOCODER=off hides the search box.
 */
export const GET = route(async (req) => {
  const q = new URL(req.url).searchParams.get("q")?.trim() ?? "";
  if (q.length < 4) return json({ results: [] });
  rateLimit(`geo:${clientIp(req)}`, 20, 60_000);
  const provider = (process.env.GEOCODER ?? "nominatim").toLowerCase();
  const near = process.env.GEOCODER_COUNTRY ?? "mx";
  try {
    if (provider === "mapbox" && process.env.MAPBOX_TOKEN) {
      const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(q)}.json?country=${near}&language=es&limit=5&access_token=${process.env.MAPBOX_TOKEN}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
      const data = (await res.json()) as { features?: { place_name: string; center: [number, number] }[] };
      return json({ results: (data.features ?? []).map((f) => ({ label: f.place_name, lat: f.center[1], lng: f.center[0] })) });
    }
    if (provider === "nominatim") {
      const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=${near}&accept-language=es&q=${encodeURIComponent(q)}`;
      const res = await fetch(url, {
        headers: { "User-Agent": `${process.env.NEXT_PUBLIC_BRAND_NAME ?? "Llega"} delivery (${process.env.APP_URL ?? "localhost"})` },
        signal: AbortSignal.timeout(6000),
      });
      const data = (await res.json()) as { display_name: string; lat: string; lon: string }[];
      return json({ results: data.map((d) => ({ label: d.display_name, lat: Number(d.lat), lng: Number(d.lon) })) });
    }
    return json({ results: [], disabled: true });
  } catch {
    throw new HttpError(502, "No pudimos buscar la dirección. Mueve el pin en el mapa.");
  }
});
