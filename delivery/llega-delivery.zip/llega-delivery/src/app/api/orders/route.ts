import { CheckoutSchema } from "@/server/api/schemas";
import { appUrl, body, clientIp, HttpError, json, rateLimit, route } from "@/server/http";
import { placeOrder } from "@/server/orders";
import { getRestaurantBySlug } from "@/server/repo/restaurants";

export const POST = route(async (req) => {
  rateLimit(`order:${clientIp(req)}`, 12, 60 * 60_000);
  const input = await body(req, CheckoutSchema);
  const r = await getRestaurantBySlug(input.slug);
  if (!r) throw new HttpError(404, "Restaurante no encontrado.");
  const o = await placeOrder({ ...input, restaurantId: r.id }, appUrl(req));
  return json({ id: o.id, code: o.code, trackingUrl: `/t/${o.trackingToken}`, trackingToken: o.trackingToken }, { status: 201 });
});
