import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { body, HttpError, json, route } from "@/server/http";

export const GET = route(async () => {
  const u = await requireApiUser(["owner"]);
  const keys = await sql<{ id: string; name: string; prefix: string; created_at: Date }>(
    "select id, name, prefix, created_at from api_keys where restaurant_id = $1 and revoked_at is null order by created_at desc",
    [u.restaurantId],
  );
  return json({ keys });
});

/** The full key is shown only once; we store a SHA-256 hash. */
export const POST = route(async (req) => {
  const u = await requireApiUser(["owner"]);
  const { name } = await body(req, z.object({ name: z.string().min(1).max(60) }));
  const [{ n }] = await sql<{ n: number }>("select count(*)::int as n from api_keys where restaurant_id = $1 and revoked_at is null", [u.restaurantId]);
  if (n >= 10) throw new HttpError(400, "Máximo 10 claves activas.");
  const key = `llk_${randomBytes(24).toString("base64url")}`;
  const hash = createHash("sha256").update(key).digest("hex");
  await sql("insert into api_keys (restaurant_id, name, prefix, key_hash) values ($1,$2,$3,$4)", [u.restaurantId, name.trim(), key.slice(0, 10), hash]);
  return json({ key }, { status: 201 });
});

export const DELETE = route(async (req) => {
  const u = await requireApiUser(["owner"]);
  const id = new URL(req.url).searchParams.get("id") ?? "";
  if (!/^[0-9a-f-]{36}$/.test(id)) throw new HttpError(400, "Clave inválida.");
  await sql("update api_keys set revoked_at = now() where id = $1 and restaurant_id = $2", [id, u.restaurantId]);
  return json({ ok: true });
});
