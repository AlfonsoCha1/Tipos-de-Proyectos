import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { json, route } from "@/server/http";

export const GET = route(async () => {
  const u = await requireApiUser(["owner", "staff"]);
  const rows = await sql<{ id: string; name: string; phone: string; vehicle: string; email: string; available: boolean | null; lat: number | null; lng: number | null; updated_at: Date | null; active_orders: number }>(
    `select u.id, u.name, u.phone, u.vehicle, u.email, s.available, s.lat, s.lng, s.updated_at,
       (select count(*)::int from orders o where o.courier_id = u.id and o.status in ('preparing','ready','on_the_way')) as active_orders
     from users u left join courier_status s on s.user_id = u.id
     where u.role = 'courier' and u.restaurant_id = $1 order by s.available desc nulls last, u.name`,
    [u.restaurantId],
  );
  return json({
    couriers: rows.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      vehicle: c.vehicle,
      simulated: c.email.startsWith("simulado@"),
      available: !!c.available,
      lat: c.lat,
      lng: c.lng,
      updatedAt: c.updated_at ? new Date(c.updated_at).toISOString() : null,
      activeOrders: c.active_orders,
    })),
  });
});
