import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { body, json, route } from "@/server/http";

export const GET = route(async () => {
  const u = await requireApiUser(["owner", "staff"]);
  const rows = await sql(
    `select h.id, h.reason, h.message, h.status, h.created_at, o.code, o.customer_name, o.customer_phone, o.id as order_id
     from help_requests h join orders o on o.id = h.order_id where o.restaurant_id = $1 order by h.status, h.created_at desc limit 50`,
    [u.restaurantId],
  );
  return json({ requests: rows });
});

export const POST = route(async (req) => {
  const u = await requireApiUser(["owner", "staff"]);
  const { id } = await body(req, z.object({ id: z.string().uuid() }));
  await sql("update help_requests h set status = 'resolved' from orders o where h.id = $1 and o.id = h.order_id and o.restaurant_id = $2", [id, u.restaurantId]);
  return json({ ok: true });
});
