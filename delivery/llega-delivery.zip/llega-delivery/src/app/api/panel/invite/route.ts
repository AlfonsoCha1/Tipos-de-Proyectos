import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { json, route } from "@/server/http";
import { randomCode } from "@/server/random";

/** New courier invite code (the old one stops working). */
export const POST = route(async () => {
  const u = await requireApiUser(["owner"]);
  const code = randomCode(8);
  await sql("update restaurants set courier_invite_code = $2 where id = $1", [u.restaurantId, code]);
  return json({ code });
});
