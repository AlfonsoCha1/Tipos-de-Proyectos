import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { one, sql } from "@/server/db";
import { body, HttpError, json, route } from "@/server/http";
import { getMenu } from "@/server/repo/restaurants";

const Op = z.discriminatedUnion("op", [
  z.object({ op: z.literal("add_category"), name: z.string().min(1).max(60) }),
  z.object({ op: z.literal("rename_category"), id: z.string().uuid(), name: z.string().min(1).max(60) }),
  z.object({ op: z.literal("delete_category"), id: z.string().uuid() }),
  z.object({
    op: z.literal("save_item"),
    id: z.string().uuid().optional(),
    categoryId: z.string().uuid().nullable(),
    name: z.string().min(1).max(80),
    description: z.string().max(240).default(""),
    priceCents: z.number().int().min(0).max(10_000_000),
    emoji: z.string().max(8).default(""),
    available: z.boolean().default(true),
  }),
  z.object({ op: z.literal("toggle_item"), id: z.string().uuid(), available: z.boolean() }),
  z.object({ op: z.literal("delete_item"), id: z.string().uuid() }),
]);

export const GET = route(async () => {
  const u = await requireApiUser(["owner", "staff"]);
  return json({ menu: await getMenu(u.restaurantId) });
});

export const POST = route(async (req) => {
  const u = await requireApiUser(["owner", "staff"]);
  const input = await body(req, Op);
  const rid = u.restaurantId;
  const own = async (table: "menu_items" | "menu_categories", id: string) => {
    if (!(await one(`select 1 from ${table} where id = $1 and restaurant_id = $2`, [id, rid]))) throw new HttpError(404, "No encontrado.");
  };
  switch (input.op) {
    case "add_category": {
      const [{ n }] = await sql<{ n: number }>("select coalesce(max(sort), -1)::int + 1 as n from menu_categories where restaurant_id = $1", [rid]);
      await sql("insert into menu_categories (restaurant_id, name, sort) values ($1,$2,$3)", [rid, input.name.trim(), n]);
      break;
    }
    case "rename_category":
      await own("menu_categories", input.id);
      await sql("update menu_categories set name = $2 where id = $1", [input.id, input.name.trim()]);
      break;
    case "delete_category":
      await own("menu_categories", input.id);
      await sql("delete from menu_categories where id = $1", [input.id]);
      break;
    case "save_item": {
      if (input.categoryId) await own("menu_categories", input.categoryId);
      if (input.id) {
        await own("menu_items", input.id);
        await sql("update menu_items set category_id=$2, name=$3, description=$4, price_cents=$5, emoji=$6, available=$7 where id=$1", [
          input.id, input.categoryId, input.name.trim(), input.description.trim(), input.priceCents, input.emoji.trim(), input.available,
        ]);
      } else {
        const [{ n }] = await sql<{ n: number }>("select coalesce(max(sort), -1)::int + 1 as n from menu_items where restaurant_id = $1", [rid]);
        await sql("insert into menu_items (restaurant_id, category_id, name, description, price_cents, emoji, available, sort) values ($1,$2,$3,$4,$5,$6,$7,$8)", [
          rid, input.categoryId, input.name.trim(), input.description.trim(), input.priceCents, input.emoji.trim(), input.available, n,
        ]);
      }
      break;
    }
    case "toggle_item":
      await own("menu_items", input.id);
      await sql("update menu_items set available = $2 where id = $1", [input.id, input.available]);
      break;
    case "delete_item":
      await own("menu_items", input.id);
      await sql("delete from menu_items where id = $1", [input.id]);
      break;
  }
  return json({ ok: true, menu: await getMenu(rid) });
});
