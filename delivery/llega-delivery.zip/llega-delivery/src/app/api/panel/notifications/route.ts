import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { json, route } from "@/server/http";

export const GET = route(async () => {
  const u = await requireApiUser(["owner", "staff"]);
  const rows = await sql<{ id: string; channel: string; to_phone: string; body: string; status: string; provider: string; error: string; created_at: Date; code: string | null }>(
    `select n.id, n.channel, n.to_phone, n.body, n.status, n.provider, n.error, n.created_at, o.code
     from notifications n left join orders o on o.id = n.order_id where n.restaurant_id = $1 order by n.created_at desc limit 100`,
    [u.restaurantId],
  );
  return json({ notifications: rows });
});
