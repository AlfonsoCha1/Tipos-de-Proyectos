import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { body, json, route } from "@/server/http";
import { assignCourier } from "@/server/orders";

export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["owner", "staff"]);
  const { id } = await params;
  const { courierId } = await body(req, z.object({ courierId: z.string().uuid().nullable() }));
  await assignCourier(id, u.restaurantId, courierId);
  return json({ ok: true });
});
