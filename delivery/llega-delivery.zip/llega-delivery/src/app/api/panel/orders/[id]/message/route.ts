import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { one } from "@/server/db";
import { body, HttpError, json, route } from "@/server/http";
import { addMessage } from "@/server/orders";

export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["owner", "staff"]);
  const { id } = await params;
  const o = await one("select id from orders where id = $1 and restaurant_id = $2", [id, u.restaurantId]);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  const { text } = await body(req, z.object({ text: z.string().min(1).max(500) }));
  await addMessage(id, "restaurant", text);
  return json({ ok: true });
});
