import { requireApiUser } from "@/server/auth";
import { appUrl, json, route } from "@/server/http";
import { startSimulation } from "@/server/orders";

/** Demo only: a simulated courier drives the order to the customer so you can see live tracking. */
export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["owner", "staff"]);
  const { id } = await params;
  await startSimulation(id, u.restaurantId, appUrl(req));
  return json({ ok: true });
});
