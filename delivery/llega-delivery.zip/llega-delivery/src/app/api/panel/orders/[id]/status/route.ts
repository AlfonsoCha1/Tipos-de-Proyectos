import { z } from "zod";
import { requireApiUser } from "@/server/auth";
import { appUrl, body, json, route } from "@/server/http";
import { transitionOrder } from "@/server/orders";

export const POST = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const u = await requireApiUser(["owner", "staff"]);
  const { id } = await params;
  const input = await body(
    req,
    z.object({
      to: z.enum(["preparing", "ready", "on_the_way", "delivered", "cancelled"]),
      prepMinutes: z.number().int().min(1).max(180).optional(),
      reason: z.string().max(200).optional(),
    }),
  );
  const o = await transitionOrder(id, input.to, { actor: "restaurant", restaurantId: u.restaurantId, prepMinutes: input.prepMinutes, reason: input.reason }, appUrl(req));
  return json({ ok: true, status: o.status });
});
