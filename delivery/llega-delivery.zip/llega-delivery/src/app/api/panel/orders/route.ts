import { requireApiUser } from "@/server/auth";
import { ManualOrderSchema } from "@/server/api/schemas";
import { appUrl, body, json, route } from "@/server/http";
import { createManualOrder, listPanelOrders } from "@/server/orders";

export const GET = route(async () => {
  const u = await requireApiUser(["owner", "staff"]);
  return json({ orders: await listPanelOrders(u.restaurantId), now: new Date().toISOString() });
});

/** Tracking-only: the restaurant already has the order (phone, WhatsApp, its own POS) and just wants live tracking + SMS. */
export const POST = route(async (req) => {
  const u = await requireApiUser(["owner", "staff"]);
  const input = await body(req, ManualOrderSchema);
  const o = await createManualOrder({ ...input, restaurantId: u.restaurantId, source: "manual" }, appUrl(req));
  return json({ id: o.id, code: o.code, trackingUrl: `/t/${o.tracking_token}` }, { status: 201 });
});
