import { z } from "zod";
import { normalizePhone } from "@/lib/phone";
import { requireApiUser } from "@/server/auth";
import { sql } from "@/server/db";
import { body, HttpError, json, route } from "@/server/http";

const Schema = z
  .object({
    name: z.string().min(2).max(80),
    tagline: z.string().max(120),
    cuisine: z.string().max(40),
    phone: z.string().max(25),
    address: z.string().min(3).max(200),
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180),
    brandColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    logoEmoji: z.string().min(1).max(8),
    isOpen: z.boolean(),
    prepMinutes: z.number().int().min(1).max(180),
    deliveryFeeCents: z.number().int().min(0).max(100_000),
    minOrderCents: z.number().int().min(0).max(1_000_000),
    deliveryRadiusKm: z.number().min(0.5).max(50),
    inMarketplace: z.boolean(),
    acceptsCash: z.boolean(),
    acceptsCardSim: z.boolean(),
    requireDeliveryPin: z.boolean(),
    notifyChannel: z.enum(["sms", "whatsapp", "none"]),
  })
  .partial();

const COLS: Record<string, string> = {
  name: "name", tagline: "tagline", cuisine: "cuisine", phone: "phone", address: "address", lat: "lat", lng: "lng",
  brandColor: "brand_color", logoEmoji: "logo_emoji", isOpen: "is_open", prepMinutes: "prep_minutes",
  deliveryFeeCents: "delivery_fee_cents", minOrderCents: "min_order_cents", deliveryRadiusKm: "delivery_radius_km",
  inMarketplace: "in_marketplace", acceptsCash: "accepts_cash", acceptsCardSim: "accepts_card_sim",
  requireDeliveryPin: "require_delivery_pin", notifyChannel: "notify_channel",
};

export const PATCH = route(async (req) => {
  const u = await requireApiUser(["owner", "staff"]);
  const input = await body(req, Schema);
  if (u.role !== "owner" && Object.keys(input).some((k) => k !== "isOpen")) throw new HttpError(403, "Solo el dueño puede cambiar la configuración.");
  if (input.phone !== undefined && input.phone !== "") {
    const p = normalizePhone(input.phone);
    if (!p) throw new HttpError(400, "Teléfono inválido.");
    input.phone = p;
  }
  if (input.acceptsCash === false && input.acceptsCardSim === false) throw new HttpError(400, "Activa al menos una forma de pago.");
  const sets: string[] = [];
  const params: unknown[] = [u.restaurantId];
  for (const [k, v] of Object.entries(input)) {
    if (v === undefined || !COLS[k]) continue;
    params.push(typeof v === "string" ? v.trim() : v);
    sets.push(`${COLS[k]} = $${params.length}`);
  }
  if (sets.length) await sql(`update restaurants set ${sets.join(", ")} where id = $1`, params);
  return json({ ok: true });
});
