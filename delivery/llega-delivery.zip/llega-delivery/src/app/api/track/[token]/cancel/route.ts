import { appUrl, HttpError, json, route } from "@/server/http";
import { getOrderByToken, transitionOrder } from "@/server/orders";

/** Customers can cancel only while the restaurant hasn't accepted the order yet. */
export const POST = route<{ params: Promise<{ token: string }> }>(async (req, { params }) => {
  const { token } = await params;
  const o = await getOrderByToken(token);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  if (o.status !== "pending") throw new HttpError(409, "El restaurante ya empezó tu pedido. Usa «Obtener ayuda» para hablar con ellos.");
  await transitionOrder(o.id, "cancelled", { actor: "customer", reason: "Cancelado por el cliente" }, appUrl(req));
  return json({ ok: true });
});
