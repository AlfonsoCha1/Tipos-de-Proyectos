import { z } from "zod";
import { sql } from "@/server/db";
import { getOrderByToken } from "@/server/orders";
import { body, HttpError, json, rateLimit, route } from "@/server/http";

const REASONS = ["late", "wrong_item", "missing_item", "courier", "payment", "cancel", "other"] as const;
const LABEL: Record<(typeof REASONS)[number], string> = {
  late: "Se está tardando",
  wrong_item: "Llegó algo equivocado",
  missing_item: "Falta algo",
  courier: "Problema con el repartidor",
  payment: "Problema con el pago",
  cancel: "Quiero cancelar",
  other: "Otro",
};

export const POST = route<{ params: Promise<{ token: string }> }>(async (req, { params }) => {
  const { token } = await params;
  const o = await getOrderByToken(token);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  rateLimit(`help:${o.id}`, 5, 60 * 60_000);
  const { reason, message } = await body(req, z.object({ reason: z.enum(REASONS), message: z.string().max(500).default("") }));
  await sql("insert into help_requests (order_id, reason, message) values ($1,$2,$3)", [o.id, reason, message.trim()]);
  await sql("insert into order_events (order_id, type, message, actor) values ($1,'help',$2,'customer')", [o.id, `Ayuda solicitada: ${LABEL[reason]}`]);
  return json({ ok: true, messageEs: "Listo. El restaurante ya vio tu solicitud y te contactará." });
});
