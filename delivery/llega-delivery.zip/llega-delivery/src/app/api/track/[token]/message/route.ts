import { z } from "zod";
import { addMessage, getOrderByToken } from "@/server/orders";
import { body, HttpError, json, rateLimit, route } from "@/server/http";

export const POST = route<{ params: Promise<{ token: string }> }>(async (req, { params }) => {
  const { token } = await params;
  const o = await getOrderByToken(token);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  if (o.status === "delivered" || o.status === "cancelled") throw new HttpError(409, "El chat se cierra cuando el pedido termina.");
  rateLimit(`msg:${o.id}`, 30, 10 * 60_000);
  const { text } = await body(req, z.object({ text: z.string().min(1).max(500) }));
  await addMessage(o.id, "customer", text);
  return json({ ok: true });
});
