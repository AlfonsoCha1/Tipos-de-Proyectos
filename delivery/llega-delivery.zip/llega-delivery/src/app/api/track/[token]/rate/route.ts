import { z } from "zod";
import { sql } from "@/server/db";
import { getOrderByToken } from "@/server/orders";
import { body, HttpError, json, route } from "@/server/http";

export const POST = route<{ params: Promise<{ token: string }> }>(async (req, { params }) => {
  const { token } = await params;
  const o = await getOrderByToken(token);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  if (o.status !== "delivered") throw new HttpError(409, "Podrás calificar cuando recibas tu pedido.");
  if (o.rating) throw new HttpError(409, "Ya calificaste este pedido. ¡Gracias!");
  const { rating, comment } = await body(req, z.object({ rating: z.number().int().min(1).max(5), comment: z.string().max(400).default("") }));
  await sql("update orders set rating = $2, rating_comment = $3 where id = $1", [o.id, rating, comment.trim()]);
  return json({ ok: true });
});
