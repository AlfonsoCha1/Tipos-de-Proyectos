import { appUrl, HttpError, json, route } from "@/server/http";
import { trackView } from "@/server/orders";

export const GET = route<{ params: Promise<{ token: string }> }>(async (req, { params }) => {
  const { token } = await params;
  const view = await trackView(token, appUrl(req));
  if (!view) throw new HttpError(404, "No encontramos ese pedido.");
  return json(view);
});
