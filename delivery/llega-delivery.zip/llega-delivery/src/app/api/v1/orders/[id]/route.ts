import { restaurantFromApiKey } from "@/server/api/apikey";
import { one } from "@/server/db";
import { appUrl, HttpError, json, route } from "@/server/http";

export const GET = route<{ params: Promise<{ id: string }> }>(async (req, { params }) => {
  const rid = await restaurantFromApiKey(req);
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/.test(id)) throw new HttpError(404, "Pedido no encontrado.");
  const o = await one<{ id: string; code: string; status: string; tracking_token: string; eta_at: Date | null; delivered_at: Date | null; courier_name: string | null }>(
    `select o.id, o.code, o.status, o.tracking_token, o.eta_at, o.delivered_at, u.name as courier_name
     from orders o left join users u on u.id = o.courier_id where o.id = $1 and o.restaurant_id = $2`,
    [id, rid],
  );
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  return json({ id: o.id, code: o.code, status: o.status, courier: o.courier_name, eta: o.eta_at, delivered_at: o.delivered_at, tracking_url: `${appUrl(req)}/t/${o.tracking_token}` });
});
