import { z } from "zod";
import { restaurantFromApiKey } from "@/server/api/apikey";
import { appUrl, body, json, route } from "@/server/http";
import { transitionOrder } from "@/server/orders";

export const POST = route<{ params: Promise<{ id: string }> }>(
  async (req, { params }) => {
    const rid = await restaurantFromApiKey(req);
    const { id } = await params;
    const { status, reason } = await body(req, z.object({ status: z.enum(["ready", "cancelled"]), reason: z.string().max(200).optional() }));
    const o = await transitionOrder(id, status, { actor: "restaurant", restaurantId: rid, reason }, appUrl(req));
    return json({ id: o.id, status: o.status });
  },
  { checkOrigin: false },
);
