import { restaurantFromApiKey } from "@/server/api/apikey";
import { ManualOrderSchema } from "@/server/api/schemas";
import { appUrl, body, json, rateLimit, route } from "@/server/http";
import { createManualOrder } from "@/server/orders";

/**
 * Tracking as a service: a restaurant's own system (POS, website, WhatsApp bot) creates an
 * order here and gets a live tracking link; the customer receives it by SMS/WhatsApp.
 */
export const POST = route(
  async (req) => {
    const rid = await restaurantFromApiKey(req);
    rateLimit(`v1:${rid}`, 120, 60_000);
    const input = await body(req, ManualOrderSchema);
    const base = appUrl(req);
    const o = await createManualOrder({ ...input, restaurantId: rid, source: "api" }, base);
    return json(
      { id: o.id, code: o.code, status: o.status, tracking_url: `${base}/t/${o.tracking_token}`, delivery_pin: o.delivery_pin, eta: o.eta_at },
      { status: 201 },
    );
  },
  { checkOrigin: false },
);
