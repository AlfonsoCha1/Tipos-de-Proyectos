import { handleAgentTurn } from "@/server/agent";
import { restaurantForWhatsApp, verifyTwilioSignature } from "@/server/agent/whatsapp";
import { appUrl } from "@/server/http";

/**
 * Twilio WhatsApp (or SMS) incoming webhook -> ordering agent. Replies with TwiML.
 * Set this URL in Twilio as "When a message comes in": {APP_URL}/api/webhooks/twilio
 */
function twiml(text: string): Response {
  const esc = text.replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c]!);
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response><Message>${esc}</Message></Response>`, {
    headers: { "Content-Type": "text/xml" },
  });
}

export async function POST(req: Request) {
  const form = await req.formData();
  const params: Record<string, string> = {};
  for (const [k, v] of form.entries()) params[k] = String(v);
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  if (authToken) {
    const url = `${appUrl(req)}${new URL(req.url).pathname}`;
    if (!verifyTwilioSignature(url, params, req.headers.get("x-twilio-signature"), authToken)) return new Response("bad signature", { status: 401 });
  } else if (process.env.NODE_ENV === "production") {
    return new Response("TWILIO_AUTH_TOKEN not configured", { status: 503 });
  }
  const r = await restaurantForWhatsApp(null);
  if (!r) return twiml("Este número todavía no está conectado a un restaurante.");
  const from = (params.From ?? "").replace(/^whatsapp:/, "");
  const lat = Number(params.Latitude);
  const lng = Number(params.Longitude);
  const location = Number.isFinite(lat) && Number.isFinite(lng) && params.Latitude ? { lat, lng } : null;
  try {
    const out = await handleAgentTurn(
      { restaurant: r, channel: "whatsapp", externalId: from, senderPhone: from, text: params.Body ?? "", location, source: "whatsapp" },
      appUrl(req),
    );
    return twiml(out.reply);
  } catch (e) {
    console.error("[twilio] agent error:", e);
    return twiml("Tuvimos un problema. Intenta de nuevo en un momento.");
  }
}
