import { handleAgentTurn } from "@/server/agent";
import { restaurantForWhatsApp, verifyMetaSignature } from "@/server/agent/whatsapp";
import { appUrl } from "@/server/http";
import { MetaWhatsAppProvider } from "@/server/notify/providers";

/**
 * WhatsApp Cloud API (Meta) webhook.
 * GET: subscription check. POST: incoming customer messages -> ordering agent -> reply.
 * Needs META_WHATSAPP_TOKEN, META_WHATSAPP_PHONE_NUMBER_ID, META_WEBHOOK_VERIFY_TOKEN and META_APP_SECRET.
 */
export async function GET(req: Request) {
  const u = new URL(req.url);
  const ok = u.searchParams.get("hub.mode") === "subscribe" && !!process.env.META_WEBHOOK_VERIFY_TOKEN && u.searchParams.get("hub.verify_token") === process.env.META_WEBHOOK_VERIFY_TOKEN;
  return ok ? new Response(u.searchParams.get("hub.challenge") ?? "", { status: 200 }) : new Response("forbidden", { status: 403 });
}

interface MetaMessage {
  from: string;
  type: string;
  text?: { body: string };
  location?: { latitude: number; longitude: number; address?: string; name?: string };
}

export async function POST(req: Request) {
  const raw = await req.text();
  const secret = process.env.META_APP_SECRET;
  if (secret) {
    if (!verifyMetaSignature(raw, req.headers.get("x-hub-signature-256"), secret)) return new Response("bad signature", { status: 401 });
  } else if (process.env.NODE_ENV === "production") {
    return new Response("META_APP_SECRET not configured", { status: 503 });
  }
  let payload: { entry?: { changes?: { value?: { metadata?: { phone_number_id?: string }; messages?: MetaMessage[] } }[] }[] };
  try {
    payload = JSON.parse(raw);
  } catch {
    return new Response("bad json", { status: 400 });
  }
  const token = process.env.META_WHATSAPP_TOKEN;
  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      const value = change.value;
      const phoneNumberId = value?.metadata?.phone_number_id;
      for (const m of value?.messages ?? []) {
        const r = await restaurantForWhatsApp(phoneNumberId);
        if (!r) continue;
        const text = m.type === "text" ? (m.text?.body ?? "") : m.type === "location" && m.location?.address ? m.location.address : "";
        const location = m.type === "location" && m.location ? { lat: m.location.latitude, lng: m.location.longitude } : null;
        if (!text && !location) continue;
        try {
          const out = await handleAgentTurn(
            { restaurant: r, channel: "whatsapp", externalId: m.from, senderPhone: `+${m.from}`, text, location, source: "whatsapp" },
            appUrl(req),
          );
          if (token && phoneNumberId) await new MetaWhatsAppProvider(token, phoneNumberId, process.env.META_GRAPH_BASE).send(`+${m.from}`, out.reply);
        } catch (e) {
          console.error("[whatsapp] agent error:", e);
        }
      }
    }
  }
  // Always 200 so Meta doesn't retry the same message.
  return new Response("ok", { status: 200 });
}
