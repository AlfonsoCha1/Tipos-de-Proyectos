import Link from "next/link";
import { Footer, Topbar } from "@/components/Chrome";
import { PLANS } from "@/lib/plans";

export const metadata = { title: "Para restaurantes" };

const STEPS = [
  ["Registra tu restaurante", "Nombre, dirección y teléfono. Toma 3 minutos."],
  ["Sube tu menú", "Categorías, platillos y precios. Marca agotado con un toque."],
  ["Invita a tus repartidores", "Les compartes un código; usan la app desde su celular."],
  ["Comparte tu link o QR", "Tus clientes piden y siguen su pedido en el mapa."],
];

export default function Negocios() {
  return (
    <>
      <Topbar>
        <Link href="/panel/login">Entrar</Link>
        <Link href="/panel/registro" className="btn btn-primary btn-small">
          Registrar mi restaurante
        </Link>
      </Topbar>
      <main className="wrap stack-l">
        <section className="hero">
          <h1 className="display" style={{ maxWidth: "16ch" }}>
            Tus pedidos a domicilio, con tu nombre y sin comisiones.
          </h1>
          <p className="muted" style={{ marginTop: 12, maxWidth: "52ch" }}>
            Recibe pedidos en tu propia página, avísale a tus clientes por WhatsApp o SMS y deja que vean a tu repartidor en el mapa. Un asistente de IA puede tomar pedidos por chat mientras
            tú cocinas.
          </p>
          <div className="row wrap-row" style={{ marginTop: 16 }}>
            <Link href="/panel/registro" className="btn btn-primary">
              Empezar gratis
            </Link>
            <Link href="/" className="btn">
              Ver cómo lo ve el cliente
            </Link>
          </div>
        </section>

        <section className="stack" aria-labelledby="modos">
          <h2 id="modos">Elige cómo usarlo</h2>
          <div className="grid-cards">
            {PLANS.map((p) => (
              <article key={p.id} className="card stack" style={p.featured ? { borderColor: "var(--primary)", borderWidth: 2 } : undefined}>
                <div className="spread">
                  <h3>{p.name}</h3>
                  {p.featured && <span className="chip open">Más elegido</span>}
                </div>
                <p className="display" style={{ fontSize: 30 }}>
                  {p.price}
                </p>
                <p className="muted">{p.for}</p>
                <ul style={{ margin: 0, paddingLeft: 18 }}>
                  {p.features.map((f) => (
                    <li key={f}>{f}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
          <p className="faint">Precios en pesos mexicanos más IVA. El primer mes es de prueba.</p>
        </section>

        <section className="stack" aria-labelledby="pasos">
          <h2 id="pasos">Así empiezas</h2>
          <ol className="legs">
            {STEPS.map(([t, d], i) => (
              <li key={t}>
                <span className="n">{i + 1}</span>
                <div>
                  <strong>{t}</strong>
                  <p className="muted">{d}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      </main>
      <Footer />
    </>
  );
}
