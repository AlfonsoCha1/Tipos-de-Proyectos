import Link from "next/link";
import { Footer, Topbar } from "@/components/Chrome";
import { mxn } from "@/lib/money";
import { listMarketplace } from "@/server/repo/restaurants";

export const dynamic = "force-dynamic";

export default async function Home({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const restaurants = await listMarketplace(q);
  return (
    <>
      <Topbar>
        <Link href="/negocios">Tengo un restaurante</Link>
        <Link href="/panel/login">Entrar</Link>
      </Topbar>
      <main className="wrap">
        <section className="hero">
          <h1 className="display">¿Qué se te antoja hoy?</h1>
          <p className="muted" style={{ marginTop: 10, maxWidth: "46ch" }}>
            Pide a los restaurantes de tu zona y sigue a tu repartidor en el mapa, minuto a minuto.
          </p>
          <form className="search" action="/" role="search">
            <label htmlFor="q" className="sr-only">
              Buscar restaurante o platillo
            </label>
            <input id="q" name="q" defaultValue={q ?? ""} placeholder="Tacos, pizza, café…" autoComplete="off" />
            <button className="btn btn-primary" type="submit">
              Buscar
            </button>
          </form>
        </section>

        <section aria-labelledby="list" className="stack">
          <h2 id="list">{q ? `Resultados para «${q}»` : "Restaurantes cerca de ti"}</h2>
          {restaurants.length === 0 && (
            <div className="card">
              <p>No encontramos restaurantes{q ? " con esa búsqueda" : ""}.</p>
              {q && (
                <Link className="btn btn-small" href="/" style={{ marginTop: 10 }}>
                  Ver todos
                </Link>
              )}
            </div>
          )}
          <div className="grid-cards">
            {restaurants.map((r) => (
              <Link key={r.id} href={`/r/${r.slug}?via=m`} className="rest-card" style={{ ["--c" as string]: r.brand_color }}>
                <div className="rest-logo" aria-hidden="true">
                  {r.logo_emoji}
                </div>
                <div>
                  <h3>{r.name}</h3>
                  <p className="faint">{r.tagline || r.cuisine}</p>
                  <div className="meta">
                    <span className={`chip ${r.is_open ? "open" : "closed"}`}>{r.is_open ? "Abierto" : "Cerrado"}</span>
                    <span>{r.prep_minutes + 10}–{r.prep_minutes + 25} min</span>
                    <span>Envío {mxn(r.delivery_fee_cents)}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="band">
          <h2 className="display" style={{ fontSize: 30 }}>
            ¿Tienes restaurante? Vende con tu propia página, sin comisiones por pedido.
          </h2>
          <p style={{ marginTop: 8, opacity: 0.85 }}>Pedidos en línea, repartidores con GPS, avisos por WhatsApp y un asistente de IA que toma pedidos por ti.</p>
          <Link className="btn btn-primary" href="/negocios">
            Ver cómo funciona
          </Link>
        </section>
      </main>
      <Footer />
    </>
  );
}
