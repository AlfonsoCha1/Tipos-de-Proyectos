"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/lib/client/api";
import { usePoll } from "@/lib/client/usePoll";
import { mxn } from "@/lib/money";
import { STATUS_LABEL_ES, type OrderStatus } from "@/lib/order-flow";
import { prettyPhone } from "@/lib/phone";
import type { PanelOrder } from "@/lib/types";

interface Courier {
  id: string;
  name: string;
  available: boolean;
  simulated: boolean;
  activeOrders: number;
  updatedAt: string | null;
}

const COLUMNS: { status: OrderStatus; title: string }[] = [
  { status: "pending", title: "Nuevos" },
  { status: "preparing", title: "En cocina" },
  { status: "ready", title: "Listos" },
  { status: "on_the_way", title: "En camino" },
];

const SOURCE: Record<string, string> = { web: "Tienda", marketplace: "Marketplace", agent: "Chat IA", whatsapp: "WhatsApp", manual: "Manual", api: "API" };
const REJECT = ["Se nos acabó un producto", "Estamos por cerrar", "Fuera de la zona de entrega", "Otro motivo"];
const hm = (iso: string) => new Intl.DateTimeFormat("es-MX", { hour: "numeric", minute: "2-digit" }).format(new Date(iso));
const ago = (iso: string, now: number) => {
  const m = Math.max(0, Math.round((now - new Date(iso).getTime()) / 60000));
  return m < 1 ? "ahora" : m < 60 ? `hace ${m} min` : `hace ${Math.floor(m / 60)} h ${m % 60} min`;
};

function beep() {
  try {
    const ctx = new AudioContext();
    [0, 0.22].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.18);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.2);
    });
  } catch {
    /* audio not available */
  }
}

export default function Board({ demoTools }: { demoTools: boolean }) {
  const { data, refresh, error } = usePoll<{ orders: PanelOrder[]; now: string }>("/api/panel/orders", 4000);
  const couriers = usePoll<{ couriers: Courier[] }>("/api/panel/couriers", 10000);
  const [tab, setTab] = useState<OrderStatus>("pending");
  const [sound, setSound] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const seen = useRef<Set<string> | null>(null);
  const orders = useMemo(() => data?.orders ?? [], [data]);
  const now = data ? new Date(data.now).getTime() : Date.now();

  // Alert on new orders (after the first load).
  useEffect(() => {
    if (!data) return;
    const pending = orders.filter((o) => o.status === "pending").map((o) => o.id);
    if (seen.current) {
      const fresh = pending.filter((id) => !seen.current!.has(id));
      if (fresh.length) {
        if (sound) beep();
        setTab("pending");
      }
    }
    seen.current = new Set(orders.map((o) => o.id));
    const n = pending.length;
    document.title = n ? `(${n}) Pedidos nuevos` : "Pedidos";
  }, [data, orders, sound]);

  const act = async (fn: () => Promise<unknown>, ok?: string) => {
    setMsg(null);
    try {
      await fn();
      if (ok) setMsg(ok);
      refresh();
      couriers.refresh();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "No se pudo.");
    }
  };

  const status = (id: string, to: OrderStatus, extra: Record<string, unknown> = {}) => act(() => api(`/api/panel/orders/${id}/status`, { body: { to, ...extra } }));

  const today = orders.filter((o) => new Date(o.createdAt).toDateString() === new Date(now).toDateString());
  const sales = today.filter((o) => o.status !== "cancelled").reduce((n, o) => n + o.totalCents, 0);
  const done = today.filter((o) => o.status === "delivered" && o.deliveredAt);
  const avg = done.length ? Math.round(done.reduce((n, o) => n + (new Date(o.deliveredAt!).getTime() - new Date(o.createdAt).getTime()), 0) / done.length / 60000) : null;
  const finished = orders.filter((o) => o.status === "delivered" || o.status === "cancelled");

  return (
    <div className="stack-l">
      <div className="spread" style={{ flexWrap: "wrap" }}>
        <h1 className="display" style={{ fontSize: 34 }}>
          Pedidos
        </h1>
        {!sound ? (
          <button
            type="button"
            className="btn btn-small"
            onClick={() => {
              setSound(true);
              beep();
            }}
          >
            🔔 Activar sonido de pedidos nuevos
          </button>
        ) : (
          <span className="chip open">🔔 Sonido activado</span>
        )}
      </div>

      <div className="stat-row">
        <div className="stat">
          <b>{today.length}</b>
          <span className="faint">pedidos hoy</span>
        </div>
        <div className="stat">
          <b className="money">{mxn(sales)}</b>
          <span className="faint">vendido hoy</span>
        </div>
        <div className="stat">
          <b>{orders.filter((o) => ["pending", "preparing", "ready", "on_the_way"].includes(o.status)).length}</b>
          <span className="faint">en curso</span>
        </div>
        <div className="stat">
          <b>{avg != null ? `${avg} min` : "—"}</b>
          <span className="faint">entrega promedio</span>
        </div>
      </div>

      {error && <p className="alert">{error.message}</p>}
      {msg && (
        <p className="notice" role="status">
          {msg}
        </p>
      )}

      <div className="board-tabs segmented" role="tablist" aria-label="Estado">
        {COLUMNS.map((c) => (
          <button key={c.status} type="button" role="tab" aria-selected={tab === c.status} aria-pressed={tab === c.status} onClick={() => setTab(c.status)}>
            {c.title} ({orders.filter((o) => o.status === c.status).length})
          </button>
        ))}
      </div>

      <div className="board">
        {COLUMNS.map((c) => {
          const list = orders.filter((o) => o.status === c.status).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
          return (
            <section key={c.status} className={`board-col ${tab === c.status ? "active" : ""}`} aria-label={c.title}>
              <h2>
                {c.title} <span className="count">{list.length}</span>
              </h2>
              {list.length === 0 && <p className="faint">Nada por aquí.</p>}
              {list.map((o) => (
                <OrderCard key={o.id} o={o} now={now} couriers={couriers.data?.couriers ?? []} demoTools={demoTools} onStatus={status} act={act} />
              ))}
            </section>
          );
        })}
      </div>

      {finished.length > 0 && (
        <section className="stack">
          <h2>Terminados (últimas 12 h)</h2>
          <div className="card" style={{ overflowX: "auto" }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Pedido</th>
                  <th>Cliente</th>
                  <th>Total</th>
                  <th>Estado</th>
                  <th>Hora</th>
                </tr>
              </thead>
              <tbody>
                {finished.map((o) => (
                  <tr key={o.id}>
                    <td>
                      <a href={`/t/${o.trackingToken}`} target="_blank" rel="noreferrer">
                        #{o.code}
                      </a>
                    </td>
                    <td>{o.customerName}</td>
                    <td className="money">{mxn(o.totalCents)}</td>
                    <td>{STATUS_LABEL_ES[o.status]}</td>
                    <td>{hm(o.deliveredAt ?? o.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

function OrderCard({
  o,
  now,
  couriers,
  demoTools,
  onStatus,
  act,
}: {
  o: PanelOrder;
  now: number;
  couriers: Courier[];
  demoTools: boolean;
  onStatus: (id: string, to: OrderStatus, extra?: Record<string, unknown>) => Promise<void>;
  act: (fn: () => Promise<unknown>, ok?: string) => Promise<void>;
}) {
  const [prep, setPrep] = useState(o.prepMinutes || 20);
  const [rejecting, setRejecting] = useState(false);
  const canAssign = o.status === "preparing" || o.status === "ready" || o.status === "pending";
  return (
    <article className={`order-card ${o.status === "pending" ? "new" : ""}`} data-testid="order-card" data-code={o.code}>
      <div className="spread">
        <span className="code">#{o.code}</span>
        <span className="faint">{ago(o.createdAt, now)}</span>
      </div>
      <div className="row wrap-row">
        <span className="chip">{SOURCE[o.source] ?? o.source}</span>
        <span className="chip">{o.paymentMethod === "cash" ? "💵 Efectivo" : o.paymentMethod === "card_sim" ? "💳 Prueba" : "Pagado"}</span>
        {o.unreadHelp > 0 && <span className="chip closed">Pidió ayuda</span>}
      </div>
      <div>
        <strong>{o.customerName}</strong>{" "}
        <a href={`tel:${o.customerPhone}`} className="faint">
          {prettyPhone(o.customerPhone)}
        </a>
        <p className="faint">
          {o.addressText}
          {o.addressNotes ? ` · ${o.addressNotes}` : ""}
        </p>
      </div>
      {o.items.length > 0 && (
        <ul>
          {o.items.map((it, i) => (
            <li key={i}>
              {it.qty}× {it.name}
              {it.notes ? <em className="faint"> — {it.notes}</em> : null}
            </li>
          ))}
        </ul>
      )}
      {o.notes && <p className="notice">Nota: {o.notes}</p>}
      <p className="money" style={{ fontWeight: 800 }}>
        {mxn(o.totalCents)}
      </p>

      {canAssign && (
        <label className="field">
          <span>Repartidor</span>
          <select
            value={o.courier?.id ?? ""}
            onChange={(e) => act(() => api(`/api/panel/orders/${o.id}/assign`, { body: { courierId: e.target.value || null } }))}
          >
            <option value="">Sin asignar (cualquiera del equipo puede tomarlo)</option>
            {couriers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
                {c.simulated ? " (simulado)" : ""} · {c.available ? "disponible" : "no disponible"}
                {c.activeOrders ? ` · ${c.activeOrders} en curso` : ""}
              </option>
            ))}
          </select>
        </label>
      )}
      {o.status === "on_the_way" && o.courier && <p className="faint">🛵 {o.courier.name} va en camino</p>}

      <div className="actions">
        {o.status === "pending" && !rejecting && (
          <>
            <label className="sr-only" htmlFor={`prep-${o.id}`}>
              Minutos de preparación
            </label>
            <select id={`prep-${o.id}`} className="input" style={{ width: "auto", minHeight: 34 }} value={prep} onChange={(e) => setPrep(Number(e.target.value))}>
              {[10, 15, 20, 25, 30, 45, 60].map((m) => (
                <option key={m} value={m}>
                  {m} min
                </option>
              ))}
            </select>
            <button type="button" className="btn btn-primary btn-small" onClick={() => onStatus(o.id, "preparing", { prepMinutes: prep })}>
              Aceptar
            </button>
            <button type="button" className="btn btn-danger btn-small" onClick={() => setRejecting(true)}>
              Rechazar
            </button>
          </>
        )}
        {rejecting && (
          <div className="stack" style={{ width: "100%" }}>
            <p className="faint">¿Por qué lo rechazas? Se le avisa al cliente.</p>
            {REJECT.map((r) => (
              <button key={r} type="button" className="btn btn-small btn-danger" onClick={() => onStatus(o.id, "cancelled", { reason: r })}>
                {r}
              </button>
            ))}
            <button type="button" className="btn btn-small btn-ghost" onClick={() => setRejecting(false)}>
              Volver
            </button>
          </div>
        )}
        {o.status === "preparing" && (
          <button type="button" className="btn btn-primary btn-small" onClick={() => onStatus(o.id, "ready")}>
            Listo para recoger
          </button>
        )}
        {(o.status === "preparing" || o.status === "ready") && o.courier && (
          <button type="button" className="btn btn-small" onClick={() => onStatus(o.id, "on_the_way")}>
            Salió a entregar
          </button>
        )}
        {o.status === "on_the_way" && (
          <button type="button" className="btn btn-small" onClick={() => onStatus(o.id, "delivered")}>
            Marcar entregado
          </button>
        )}
        {demoTools && (o.status === "preparing" || o.status === "ready" || o.status === "pending") && o.lat != null && (
          <button
            type="button"
            className="btn btn-small btn-ghost"
            title="Solo para demostraciones: un repartidor simulado lleva el pedido"
            onClick={() => act(() => api(`/api/panel/orders/${o.id}/simulate`, { body: {} }), `Simulación iniciada: abre el rastreo de #${o.code} para ver al repartidor moverse.`)}
          >
            ▶ Simular entrega (demo)
          </button>
        )}
        <a className="btn btn-small btn-ghost" href={`/t/${o.trackingToken}`} target="_blank" rel="noreferrer">
          Ver rastreo ↗
        </a>
      </div>
    </article>
  );
}
