"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { BRAND } from "@/lib/brand";
import { api } from "@/lib/client/api";

const TABS = [
  ["/panel", "Pedidos"],
  ["/panel/nuevo", "Pedido manual"],
  ["/panel/menu", "Menú"],
  ["/panel/equipo", "Repartidores"],
  ["/panel/mensajes", "Mensajes"],
  ["/panel/ajustes", "Ajustes"],
] as const;

export default function PanelChrome({
  restaurant,
  userName,
  role,
  children,
}: {
  restaurant: { name: string; slug: string; isOpen: boolean; emoji: string };
  userName: string;
  role: string;
  children: React.ReactNode;
}) {
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(restaurant.isOpen);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <header className="topbar">
        <div className="wrap">
          <Link href="/panel" className="wordmark" aria-label={`${BRAND} panel`}>
            {BRAND}
            <span className="dot" aria-hidden="true" />
          </Link>
          <strong style={{ fontSize: 15, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {restaurant.emoji} {restaurant.name}
          </strong>
          <nav>
            <label className="switch" title="Recibir pedidos">
              <input
                type="checkbox"
                checked={open}
                disabled={busy}
                aria-label="Restaurante abierto"
                onChange={async (e) => {
                  const v = e.target.checked;
                  setBusy(true);
                  try {
                    await api("/api/panel/settings", { method: "PATCH", body: { isOpen: v } });
                    setOpen(v);
                  } finally {
                    setBusy(false);
                  }
                }}
              />
              <span style={{ fontSize: 14 }}>{open ? "Abierto" : "Cerrado"}</span>
            </label>
            <button
              type="button"
              className="btn btn-ghost btn-small"
              onClick={async () => {
                await api("/api/auth/logout", { body: {} });
                router.push("/panel/login");
                router.refresh();
              }}
              title={`Sesión de ${userName} (${role === "owner" ? "dueño" : "equipo"})`}
            >
              Salir
            </button>
          </nav>
        </div>
      </header>
      <div className="wrap">
        <nav className="panel-nav" aria-label="Panel">
          {TABS.map(([href, label]) => (
            <Link key={href} href={href} aria-current={path === href ? "page" : undefined}>
              {label}
            </Link>
          ))}
          <a href={`/r/${restaurant.slug}`} target="_blank" rel="noreferrer">
            Mi tienda ↗
          </a>
        </nav>
      </div>
      <main className="wrap" style={{ paddingTop: 16, paddingBottom: 48 }}>
        {children}
      </main>
    </>
  );
}
