"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import LocationPicker from "@/components/LocationPicker";
import { api } from "@/lib/client/api";
import { parsePesos } from "@/lib/money";
import type { RestaurantPublic } from "@/lib/types";

interface Props {
  isOwner: boolean;
  isNew: boolean;
  restaurant: RestaurantPublic;
  extra: { requireDeliveryPin: boolean; notifyChannel: "sms" | "whatsapp" | "none" };
  storeUrl: string;
  baseUrl: string;
  qrSvg: string;
  keys: { id: string; name: string; prefix: string; createdAt: string }[];
  providers: { sms: string; whatsapp: string; agent: string | null };
}

export default function Settings({ isOwner, isNew, restaurant: r, extra, storeUrl, baseUrl, qrSvg, keys: initialKeys, providers }: Props) {
  const router = useRouter();
  const [f, setF] = useState({
    name: r.name,
    tagline: r.tagline,
    cuisine: r.cuisine,
    phone: r.phone,
    address: r.address,
    brandColor: r.brandColor,
    logoEmoji: r.logoEmoji,
    prepMinutes: String(r.prepMinutes),
    fee: (r.deliveryFeeCents / 100).toFixed(2),
    min: (r.minOrderCents / 100).toFixed(2),
    radius: String(r.deliveryRadiusKm),
    inMarketplace: r.inMarketplace,
    acceptsCash: r.acceptsCash,
    acceptsCardSim: r.acceptsCardSim,
    requireDeliveryPin: extra.requireDeliveryPin,
    notifyChannel: extra.notifyChannel,
  });
  const [pos, setPos] = useState({ lat: r.lat, lng: r.lng });
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [keys, setKeys] = useState(initialKeys);
  const [newKey, setNewKey] = useState<string | null>(null);
  const [keyName, setKeyName] = useState("Mi sistema");
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF({ ...f, [k]: v });

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const fee = parsePesos(f.fee);
    const min = parsePesos(f.min);
    if (fee == null || min == null) return setMsg({ ok: false, text: "Revisa el costo de envío y el pedido mínimo." });
    setBusy(true);
    setMsg(null);
    try {
      await api("/api/panel/settings", {
        method: "PATCH",
        body: {
          name: f.name,
          tagline: f.tagline,
          cuisine: f.cuisine,
          phone: f.phone,
          address: f.address,
          lat: pos.lat,
          lng: pos.lng,
          brandColor: f.brandColor,
          logoEmoji: f.logoEmoji,
          prepMinutes: Number(f.prepMinutes),
          deliveryFeeCents: fee,
          minOrderCents: min,
          deliveryRadiusKm: Number(f.radius),
          inMarketplace: f.inMarketplace,
          acceptsCash: f.acceptsCash,
          acceptsCardSim: f.acceptsCardSim,
          requireDeliveryPin: f.requireDeliveryPin,
          notifyChannel: f.notifyChannel,
        },
      });
      setMsg({ ok: true, text: "Cambios guardados." });
      router.refresh();
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : "No se guardó." });
    } finally {
      setBusy(false);
    }
  };

  const demoMsg = (id: string) => (id === "log" ? "Modo demo: los mensajes se guardan en «Mensajes» pero no se envían." : `Conectado (${id}).`);

  return (
    <div className="stack-l">
      <h1 className="display" style={{ fontSize: 34 }}>
        Ajustes
      </h1>
      {isNew && (
        <div className="ok-box stack">
          <strong>¡Tu restaurante está creado!</strong>
          <p>Siguientes pasos: 1) revisa estos datos, 2) sube tu menú en «Menú», 3) invita a tus repartidores en «Repartidores», 4) comparte el link o QR de tu tienda.</p>
        </div>
      )}

      <section className="card stack" aria-labelledby="s-store">
        <h2 id="s-store">Tu tienda en línea</h2>
        <div className="row wrap-row" style={{ gap: 20, alignItems: "flex-start" }}>
          <div className="qr" dangerouslySetInnerHTML={{ __html: qrSvg }} role="img" aria-label="QR de tu tienda" />
          <div className="stack" style={{ flex: 1, minWidth: 220 }}>
            <p className="muted">Imprime el QR para tus mesas y empaques, o comparte el link en WhatsApp e Instagram.</p>
            <input className="input" readOnly value={storeUrl} onFocus={(e) => e.currentTarget.select()} aria-label="Link de tu tienda" />
            <div className="row wrap-row">
              <button type="button" className="btn btn-small" onClick={() => navigator.clipboard?.writeText(storeUrl)}>
                Copiar link
              </button>
              <a className="btn btn-small" href={storeUrl} target="_blank" rel="noreferrer">
                Abrir tienda ↗
              </a>
            </div>
          </div>
        </div>
      </section>

      <form className="stack-l" onSubmit={save}>
        <fieldset disabled={!isOwner} style={{ border: "none", padding: 0, margin: 0 }} className="stack-l">
          {!isOwner && <p className="notice">Solo el dueño puede cambiar la configuración.</p>}
          <section className="card stack" aria-labelledby="s-biz">
            <h2 id="s-biz">Datos del negocio</h2>
            <div className="form-grid">
              <label className="field">
                <span>Nombre</span>
                <input required value={f.name} onChange={(e) => set("name", e.target.value)} maxLength={80} />
              </label>
              <label className="field">
                <span>Tipo de comida</span>
                <input value={f.cuisine} onChange={(e) => set("cuisine", e.target.value)} maxLength={40} />
              </label>
              <label className="field full">
                <span>Frase corta</span>
                <input value={f.tagline} onChange={(e) => set("tagline", e.target.value)} maxLength={120} placeholder="Pastor al carbón desde 1998" />
              </label>
              <label className="field">
                <span>Teléfono</span>
                <input value={f.phone} onChange={(e) => set("phone", e.target.value)} inputMode="tel" />
              </label>
              <label className="field">
                <span>Dirección</span>
                <input required value={f.address} onChange={(e) => set("address", e.target.value)} maxLength={200} />
              </label>
              <label className="field">
                <span>Color de tu marca</span>
                <input type="color" value={f.brandColor} onChange={(e) => set("brandColor", e.target.value)} style={{ padding: 4 }} />
              </label>
              <label className="field">
                <span>Logo (emoji)</span>
                <input value={f.logoEmoji} onChange={(e) => set("logoEmoji", e.target.value)} maxLength={8} />
              </label>
            </div>
            <p className="faint">Ubicación del restaurante (de aquí sale el repartidor):</p>
            <LocationPicker value={pos} fallbackCenter={pos} onChange={(p) => setPos(p)} height={220} />
          </section>

          <section className="card stack" aria-labelledby="s-del">
            <h2 id="s-del">Entregas</h2>
            <div className="form-grid">
              <label className="field">
                <span>Tiempo de preparación (min)</span>
                <input type="number" min={1} max={180} value={f.prepMinutes} onChange={(e) => set("prepMinutes", e.target.value)} />
              </label>
              <label className="field">
                <span>Costo de envío (MXN)</span>
                <input inputMode="decimal" value={f.fee} onChange={(e) => set("fee", e.target.value)} />
              </label>
              <label className="field">
                <span>Pedido mínimo (MXN)</span>
                <input inputMode="decimal" value={f.min} onChange={(e) => set("min", e.target.value)} />
              </label>
              <label className="field">
                <span>Radio de entrega (km)</span>
                <input type="number" step="0.5" min={0.5} max={50} value={f.radius} onChange={(e) => set("radius", e.target.value)} />
              </label>
            </div>
            <label className="check">
              <input type="checkbox" checked={f.requireDeliveryPin} onChange={(e) => set("requireDeliveryPin", e.target.checked)} />
              <span>
                Pedir código de entrega de 4 dígitos
                <small>El repartidor solo puede marcar «entregado» con el código que ve el cliente. Evita entregas falsas.</small>
              </span>
            </label>
            <label className="check">
              <input type="checkbox" checked={f.inMarketplace} onChange={(e) => set("inMarketplace", e.target.checked)} />
              <span>
                Aparecer en el marketplace
                <small>Tu restaurante sale en la página principal para clientes nuevos.</small>
              </span>
            </label>
          </section>

          <section className="card stack" aria-labelledby="s-pay">
            <h2 id="s-pay">Pagos</h2>
            <label className="check">
              <input type="checkbox" checked={f.acceptsCash} onChange={(e) => set("acceptsCash", e.target.checked)} />
              <span>Efectivo al recibir</span>
            </label>
            <label className="check">
              <input type="checkbox" checked={f.acceptsCardSim} onChange={(e) => set("acceptsCardSim", e.target.checked)} />
              <span>
                Tarjeta (modo prueba)
                <small>Todavía no cobra dinero real. Los cobros con Mercado Pago o Stripe se conectan más adelante.</small>
              </span>
            </label>
          </section>

          <section className="card stack" aria-labelledby="s-notif">
            <h2 id="s-notif">Avisos al cliente</h2>
            <div className="segmented" role="group" aria-label="Canal de avisos">
              {(["sms", "whatsapp", "none"] as const).map((c) => (
                <button key={c} type="button" aria-pressed={f.notifyChannel === c} onClick={() => set("notifyChannel", c)}>
                  {c === "sms" ? "SMS" : c === "whatsapp" ? "WhatsApp" : "No enviar"}
                </button>
              ))}
            </div>
            <p className="faint">
              {f.notifyChannel === "sms" ? demoMsg(providers.sms) : f.notifyChannel === "whatsapp" ? demoMsg(providers.whatsapp) : "No se envían mensajes; el cliente usa el link de la pantalla de confirmación."}
            </p>
          </section>
        </fieldset>
        {msg && (
          <p className={msg.ok ? "ok-box" : "alert"} role="status">
            {msg.text}
          </p>
        )}
        {isOwner && (
          <button className="btn btn-primary btn-block" disabled={busy}>
            {busy ? "Guardando…" : "Guardar cambios"}
          </button>
        )}
      </form>

      <section className="card stack" aria-labelledby="s-agent">
        <h2 id="s-agent">Asistente que toma pedidos</h2>
        <p className="muted">
          {providers.agent
            ? `Agente de IA activo (${providers.agent}). Entiende lenguaje natural y responde dudas del menú.`
            : "Sin clave de IA: el asistente funciona con reglas (entiende cantidades, platillos, datos y «es todo»). Agrega GROQ_API_KEY para activar el agente de IA."}
        </p>
        <p className="faint">
          En tu tienda aparece como «Pedir por chat». Para WhatsApp, conecta tu número en Meta (WhatsApp Cloud API) o Twilio con este webhook:
        </p>
        <div className="code-block">{`Meta:   ${baseUrl}/api/webhooks/whatsapp\nTwilio: ${baseUrl}/api/webhooks/twilio`}</div>
      </section>

      {isOwner && (
        <section className="card stack" aria-labelledby="s-api">
          <h2 id="s-api">API para tu sistema (modo «solo rastreo»)</h2>
          <p className="muted">Si ya tienes caja o sistema de pedidos, crea el pedido por API y tu cliente recibe el link de rastreo.</p>
          {newKey && (
            <div className="notice stack">
              <strong>Copia tu clave ahora; no se volverá a mostrar:</strong>
              <div className="code-block" data-testid="new-api-key">
                {newKey}
              </div>
            </div>
          )}
          {keys.length > 0 && (
            <table className="table">
              <tbody>
                {keys.map((k) => (
                  <tr key={k.id}>
                    <td>{k.name}</td>
                    <td className="faint">{k.prefix}…</td>
                    <td style={{ textAlign: "right" }}>
                      <button
                        type="button"
                        className="btn btn-small btn-ghost"
                        onClick={async () => {
                          await api(`/api/panel/api-keys?id=${k.id}`, { method: "DELETE" });
                          setKeys(keys.filter((x) => x.id !== k.id));
                        }}
                      >
                        Revocar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <form
            className="row"
            onSubmit={async (e) => {
              e.preventDefault();
              const r = await api<{ key: string }>("/api/panel/api-keys", { body: { name: keyName } });
              setNewKey(r.key);
              router.refresh();
              const list = await api<{ keys: { id: string; name: string; prefix: string; created_at: string }[] }>("/api/panel/api-keys");
              setKeys(list.keys.map((k) => ({ id: k.id, name: k.name, prefix: k.prefix, createdAt: k.created_at })));
            }}
          >
            <input className="input" aria-label="Nombre de la clave" value={keyName} onChange={(e) => setKeyName(e.target.value)} maxLength={60} />
            <button className="btn">Crear clave</button>
          </form>
          <div className="code-block">{`curl -X POST ${baseUrl}/api/v1/orders \\
  -H "Authorization: Bearer llk_TU_CLAVE" \\
  -H "Content-Type: application/json" \\
  -d '{"customer":{"name":"Ana","phone":"5512345678"},
       "address":{"text":"Calle Hidalgo 12","lat":19.72,"lng":-99.21},
       "totalCents":18000,"paymentMethod":"cash","notify":true}'`}</div>
        </section>
      )}
    </div>
  );
}
