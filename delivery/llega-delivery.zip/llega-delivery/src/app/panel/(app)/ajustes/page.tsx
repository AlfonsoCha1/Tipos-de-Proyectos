import { headers } from "next/headers";
import QRCode from "qrcode";
import { requirePageUser } from "@/server/auth";
import { agentLlm } from "@/server/agent/llm";
import { sql } from "@/server/db";
import { smsProvider, whatsappProvider } from "@/server/notify/providers";
import { getRestaurantById, toPublic } from "@/server/repo/restaurants";
import Settings from "./Settings";

export const metadata = { title: "Ajustes" };

export default async function AjustesPage({ searchParams }: { searchParams: Promise<{ nuevo?: string }> }) {
  const u = await requirePageUser(["owner", "staff"], "/panel/login");
  const { nuevo } = await searchParams;
  const r = (await getRestaurantById(u.restaurantId))!;
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const base = process.env.APP_URL ?? `${host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https"}://${host}`;
  const storeUrl = `${base}/r/${r.slug}`;
  const qr = await QRCode.toString(storeUrl, { type: "svg", margin: 1, width: 160 });
  const keys = u.role === "owner"
    ? await sql<{ id: string; name: string; prefix: string; created_at: Date }>("select id, name, prefix, created_at from api_keys where restaurant_id = $1 and revoked_at is null order by created_at desc", [r.id])
    : [];
  const llm = agentLlm();
  return (
    <Settings
      isOwner={u.role === "owner"}
      isNew={nuevo === "1"}
      restaurant={toPublic(r)}
      extra={{ requireDeliveryPin: r.require_delivery_pin, notifyChannel: r.notify_channel }}
      storeUrl={storeUrl}
      baseUrl={base}
      qrSvg={qr}
      keys={keys.map((k) => ({ id: k.id, name: k.name, prefix: k.prefix, createdAt: new Date(k.created_at).toISOString() }))}
      providers={{ sms: smsProvider().id, whatsapp: whatsappProvider().id, agent: llm ? `${llm.vendor} · ${llm.model}` : null }}
    />
  );
}
