"use client";
import dynamic from "next/dynamic";
import { useState } from "react";
import type { MapMarker } from "@/components/MapView";
import { api } from "@/lib/client/api";
import { usePoll } from "@/lib/client/usePoll";
import { prettyPhone } from "@/lib/phone";

const MapView = dynamic(() => import("@/components/MapView"), { ssr: false, loading: () => <div className="map" /> });

interface Courier {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  simulated: boolean;
  available: boolean;
  lat: number | null;
  lng: number | null;
  updatedAt: string | null;
  activeOrders: number;
}

const VEHICLE: Record<string, string> = { moto: "🛵", bici: "🚲", auto: "🚗", pie: "🚶" };

function lastSeen(iso: string | null): string {
  if (!iso) return "sin ubicación todavía";
  const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  return m < 1 ? "ubicación hace segundos" : m < 60 ? `ubicación hace ${m} min` : "ubicación hace más de 1 h";
}

export default function Team({ code, joinUrl, qrSvg, isOwner, restaurant }: { code: string; joinUrl: string; qrSvg: string; isOwner: boolean; restaurant: { lat: number; lng: number; emoji: string; name: string } }) {
  const { data } = usePoll<{ couriers: Courier[] }>("/api/panel/couriers", 8000);
  const [inv, setInv] = useState({ code, url: joinUrl, qr: qrSvg });
  const couriers = data?.couriers ?? [];
  const markers: MapMarker[] = [
    { id: "r", lat: restaurant.lat, lng: restaurant.lng, kind: "restaurant", emoji: restaurant.emoji, label: restaurant.name },
    ...couriers.filter((c) => c.lat != null && c.lng != null && c.updatedAt && Date.now() - new Date(c.updatedAt).getTime() < 30 * 60000).map((c) => ({ id: c.id, lat: c.lat!, lng: c.lng!, kind: "courier" as const, emoji: VEHICLE[c.vehicle], label: c.name })),
  ];

  return (
    <div className="stack-l">
      <h1 className="display" style={{ fontSize: 34 }}>
        Repartidores
      </h1>

      <section className="card stack" aria-labelledby="inv">
        <h2 id="inv">Invitar a un repartidor</h2>
        <div className="row wrap-row" style={{ gap: 20, alignItems: "flex-start" }}>
          <div className="qr" dangerouslySetInnerHTML={{ __html: inv.qr }} aria-label="Código QR para unirse" role="img" />
          <div className="stack" style={{ flex: 1, minWidth: 220 }}>
            <p className="muted">Que escanee el QR o abra el link desde su celular y cree su cuenta. Código:</p>
            <p className="display" style={{ fontSize: 34, letterSpacing: "0.08em" }} data-testid="invite-code">
              {inv.code}
            </p>
            <input className="input" readOnly value={inv.url} onFocus={(e) => e.currentTarget.select()} aria-label="Link de invitación" />
            <div className="row wrap-row">
              <button type="button" className="btn btn-small" onClick={() => navigator.clipboard?.writeText(inv.url)}>
                Copiar link
              </button>
              <a className="btn btn-small" href={`https://wa.me/?text=${encodeURIComponent(`Únete como repartidor de ${restaurant.name}: ${inv.url}`)}`} target="_blank" rel="noreferrer">
                Enviar por WhatsApp
              </a>
              {isOwner && (
                <button
                  type="button"
                  className="btn btn-small btn-ghost"
                  onClick={async () => {
                    if (!window.confirm("¿Generar un código nuevo? El anterior dejará de funcionar.")) return;
                    const r = await api<{ code: string }>("/api/panel/invite", { body: {} });
                    const url = inv.url.replace(/code=[^&]+/, `code=${r.code}`);
                    const QR = (await import("qrcode")).default;
                    setInv({ code: r.code, url, qr: await QR.toString(url, { type: "svg", margin: 1, width: 160 }) });
                  }}
                >
                  Cambiar código
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="stack" aria-labelledby="team">
        <h2 id="team">Tu equipo ({couriers.length})</h2>
        <div style={{ height: 280, borderRadius: 14, overflow: "hidden", border: "1px solid var(--line)" }}>
          <MapView markers={markers} fitKey={String(markers.length)} label="Ubicación de tus repartidores" />
        </div>
        {couriers.length === 0 && <p className="faint">Todavía no tienes repartidores. Comparte el código de arriba.</p>}
        <div className="grid-cards">
          {couriers.map((c) => (
            <div key={c.id} className="person">
              <div className="avatar" aria-hidden="true">
                {VEHICLE[c.vehicle] ?? "🛵"}
              </div>
              <div>
                <strong>
                  {c.name}
                  {c.simulated ? " (demo)" : ""}
                </strong>
                <p className="faint">
                  <span className={`chip ${c.available ? "open" : ""}`}>{c.available ? "Disponible" : "No disponible"}</span> {c.activeOrders ? `· ${c.activeOrders} en curso` : ""}
                </p>
                <p className="faint">{lastSeen(c.updatedAt)}</p>
              </div>
              {c.phone && (
                <a className="icon-btn" href={`tel:${c.phone}`} aria-label={`Llamar a ${c.name} (${prettyPhone(c.phone)})`}>
                  📞
                </a>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
