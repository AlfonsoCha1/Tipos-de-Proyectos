import { headers } from "next/headers";
import QRCode from "qrcode";
import { requirePageUser } from "@/server/auth";
import { getRestaurantById } from "@/server/repo/restaurants";
import Team from "./Team";

export const metadata = { title: "Repartidores" };

export default async function EquipoPage() {
  const u = await requirePageUser(["owner", "staff"], "/panel/login");
  const r = (await getRestaurantById(u.restaurantId))!;
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const base = process.env.APP_URL ?? `${host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https"}://${host}`;
  const joinUrl = `${base}/repartidor/unirse?code=${r.courier_invite_code}`;
  const qr = await QRCode.toString(joinUrl, { type: "svg", margin: 1, width: 160 });
  return <Team code={r.courier_invite_code} joinUrl={joinUrl} qrSvg={qr} isOwner={u.role === "owner"} restaurant={{ lat: r.lat, lng: r.lng, emoji: r.logo_emoji, name: r.name }} />;
}
