import { redirect } from "next/navigation";
import { requirePageUser } from "@/server/auth";
import { getRestaurantById } from "@/server/repo/restaurants";
import PanelChrome from "./PanelChrome";

export const dynamic = "force-dynamic";

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const u = await requirePageUser(["owner", "staff", "admin"], "/panel/login");
  if (!u.restaurantId) redirect("/admin");
  const r = await getRestaurantById(u.restaurantId);
  if (!r) redirect("/panel/login");
  return (
    <PanelChrome restaurant={{ name: r.name, slug: r.slug, isOpen: r.is_open, emoji: r.logo_emoji }} userName={u.name} role={u.role}>
      {children}
    </PanelChrome>
  );
}
