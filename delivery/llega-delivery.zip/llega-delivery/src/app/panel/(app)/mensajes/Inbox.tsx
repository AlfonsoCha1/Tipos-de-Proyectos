"use client";
import { api } from "@/lib/client/api";
import { usePoll } from "@/lib/client/usePoll";
import { prettyPhone } from "@/lib/phone";

interface Notification {
  id: string;
  channel: string;
  to_phone: string;
  body: string;
  status: "sent" | "logged" | "failed";
  provider: string;
  error: string;
  created_at: string;
  code: string | null;
}

interface Help {
  id: string;
  reason: string;
  message: string;
  status: "open" | "resolved";
  created_at: string;
  code: string;
  customer_name: string;
  customer_phone: string;
}

const REASON: Record<string, string> = {
  late: "Se está tardando",
  wrong_item: "Llegó algo equivocado",
  missing_item: "Falta algo",
  courier: "Problema con el repartidor",
  payment: "Problema con el pago",
  cancel: "Quiere cancelar",
  other: "Otro",
};

const when = (iso: string) => new Intl.DateTimeFormat("es-MX", { dateStyle: "short", timeStyle: "short" }).format(new Date(iso));

export default function Inbox() {
  const n = usePoll<{ notifications: Notification[] }>("/api/panel/notifications", 8000);
  const h = usePoll<{ requests: Help[] }>("/api/panel/help", 8000);
  const help = h.data?.requests ?? [];
  const list = n.data?.notifications ?? [];
  return (
    <div className="stack-l">
      <h1 className="display" style={{ fontSize: 34 }}>
        Mensajes
      </h1>

      <section className="stack" aria-labelledby="h-help">
        <h2 id="h-help">Clientes que pidieron ayuda</h2>
        {help.length === 0 && <p className="faint">Nadie ha pedido ayuda.</p>}
        {help.map((r) => (
          <div key={r.id} className="card spread" style={{ alignItems: "flex-start", opacity: r.status === "resolved" ? 0.6 : 1 }}>
            <div className="stack" style={{ gap: 4 }}>
              <strong>
                #{r.code} · {REASON[r.reason] ?? r.reason}
              </strong>
              {r.message && <p>{r.message}</p>}
              <p className="faint">
                {r.customer_name} · <a href={`tel:${r.customer_phone}`}>{prettyPhone(r.customer_phone)}</a> · {when(r.created_at)}
              </p>
            </div>
            {r.status === "open" ? (
              <button
                type="button"
                className="btn btn-small"
                onClick={async () => {
                  await api("/api/panel/help", { body: { id: r.id } });
                  h.refresh();
                }}
              >
                Marcar resuelto
              </button>
            ) : (
              <span className="chip open">Resuelto</span>
            )}
          </div>
        ))}
      </section>

      <section className="stack" aria-labelledby="h-sent">
        <h2 id="h-sent">SMS y WhatsApp a clientes</h2>
        {list.some((x) => x.status === "logged") && (
          <p className="notice">
            Los mensajes marcados «Demo» no se enviaron: todavía no conectas Twilio o WhatsApp. Aquí ves exactamente lo que recibiría tu cliente.
          </p>
        )}
        {list.length === 0 && <p className="faint">Aún no hay mensajes.</p>}
        {list.map((x) => (
          <article key={x.id} className="card stack" data-testid="notification">
            <div className="spread">
              <span className="faint">
                {x.channel === "whatsapp" ? "WhatsApp" : "SMS"} a {prettyPhone(x.to_phone)}
                {x.code ? ` · #${x.code}` : ""} · {when(x.created_at)}
              </span>
              <span className={`chip ${x.status === "sent" ? "open" : x.status === "failed" ? "closed" : ""}`}>
                {x.status === "sent" ? "Enviado" : x.status === "failed" ? "Falló" : "Demo"}
              </span>
            </div>
            <p className="bubble" style={{ maxWidth: "100%" }}>
              {x.body}
            </p>
            {x.error && <p className="faint">Error: {x.error}</p>}
          </article>
        ))}
      </section>
    </div>
  );
}
