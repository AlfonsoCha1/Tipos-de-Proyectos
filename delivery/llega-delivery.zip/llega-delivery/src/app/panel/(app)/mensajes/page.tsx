import Inbox from "./Inbox";

export const metadata = { title: "Mensajes" };

export default function MensajesPage() {
  return <Inbox />;
}
