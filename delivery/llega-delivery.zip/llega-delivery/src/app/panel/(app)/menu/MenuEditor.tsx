"use client";
import { useState } from "react";
import { api } from "@/lib/client/api";
import { mxn, parsePesos } from "@/lib/money";
import type { MenuCategory, MenuItem } from "@/lib/types";

interface Draft {
  id?: string;
  categoryId: string | null;
  name: string;
  description: string;
  price: string;
  emoji: string;
  available: boolean;
}

const empty = (categoryId: string | null): Draft => ({ categoryId, name: "", description: "", price: "", emoji: "", available: true });

export default function MenuEditor({ initial }: { initial: MenuCategory[] }) {
  const [menu, setMenu] = useState(initial);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [newCat, setNewCat] = useState("");
  const [error, setError] = useState<string | null>(null);
  const cats = menu.filter((c) => c.id !== "none");

  const run = async (body: Record<string, unknown>) => {
    setError(null);
    try {
      const r = await api<{ menu: MenuCategory[] }>("/api/panel/menu", { body });
      setMenu(r.menu);
      return true;
    } catch (e) {
      setError(e instanceof Error ? e.message : "No se pudo guardar.");
      return false;
    }
  };

  const edit = (it: MenuItem) =>
    setDraft({ id: it.id, categoryId: it.categoryId, name: it.name, description: it.description, price: (it.priceCents / 100).toFixed(2), emoji: it.emoji, available: it.available });

  return (
    <div className="stack-l">
      <div className="spread" style={{ flexWrap: "wrap" }}>
        <h1 className="display" style={{ fontSize: 34 }}>
          Menú
        </h1>
        <button type="button" className="btn btn-primary" onClick={() => setDraft(empty(cats[0]?.id ?? null))}>
          + Agregar platillo
        </button>
      </div>
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}

      {draft && (
        <form
          className="card stack"
          onSubmit={async (e) => {
            e.preventDefault();
            const cents = parsePesos(draft.price);
            if (cents == null) return setError("Escribe un precio válido, por ejemplo 45 o 45.50.");
            const ok = await run({ op: "save_item", id: draft.id, categoryId: draft.categoryId, name: draft.name, description: draft.description, priceCents: cents, emoji: draft.emoji, available: draft.available });
            if (ok) setDraft(null);
          }}
        >
          <h2>{draft.id ? "Editar platillo" : "Nuevo platillo"}</h2>
          <div className="form-grid">
            <label className="field">
              <span>Nombre</span>
              <input required value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} maxLength={80} />
            </label>
            <label className="field">
              <span>Precio (MXN)</span>
              <input required inputMode="decimal" value={draft.price} onChange={(e) => setDraft({ ...draft, price: e.target.value })} placeholder="45.00" />
            </label>
            <label className="field">
              <span>Categoría</span>
              <select value={draft.categoryId ?? ""} onChange={(e) => setDraft({ ...draft, categoryId: e.target.value || null })}>
                <option value="">Sin categoría</option>
                {cats.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              <span>Emoji (opcional)</span>
              <input value={draft.emoji} onChange={(e) => setDraft({ ...draft, emoji: e.target.value })} maxLength={8} placeholder="🌮" />
            </label>
            <label className="field full">
              <span>Descripción</span>
              <input value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} maxLength={240} placeholder="Ingredientes, tamaño…" />
            </label>
          </div>
          <label className="check">
            <input type="checkbox" checked={draft.available} onChange={(e) => setDraft({ ...draft, available: e.target.checked })} />
            <span>Disponible</span>
          </label>
          <div className="row">
            <button className="btn btn-primary">Guardar</button>
            <button type="button" className="btn btn-ghost" onClick={() => setDraft(null)}>
              Cancelar
            </button>
          </div>
        </form>
      )}

      {menu.map((c) => (
        <section key={c.id} className="card stack" aria-label={c.name}>
          <div className="spread">
            <h2>{c.name}</h2>
            {c.id !== "none" && (
              <div className="row">
                <button
                  type="button"
                  className="btn btn-small btn-ghost"
                  onClick={() => {
                    const name = window.prompt("Nuevo nombre de la categoría", c.name);
                    if (name && name.trim()) run({ op: "rename_category", id: c.id, name });
                  }}
                >
                  Renombrar
                </button>
                <button
                  type="button"
                  className="btn btn-small btn-ghost"
                  onClick={() => {
                    if (window.confirm(`¿Borrar la categoría «${c.name}»? Los platillos quedan sin categoría.`)) run({ op: "delete_category", id: c.id });
                  }}
                >
                  Borrar
                </button>
              </div>
            )}
          </div>
          {c.items.length === 0 && <p className="faint">Sin platillos.</p>}
          {c.items.map((it) => (
            <div key={it.id} className={`menu-item ${it.available ? "" : "off"}`}>
              <div className="emoji" aria-hidden="true">
                {it.emoji || "🍽️"}
              </div>
              <div style={{ minWidth: 0 }}>
                <h3>{it.name}</h3>
                <p className="faint money">
                  {mxn(it.priceCents)}
                  {it.description ? ` · ${it.description}` : ""}
                </p>
              </div>
              <div className="row">
                <label className="switch" title={it.available ? "Disponible" : "Agotado"}>
                  <input type="checkbox" checked={it.available} aria-label={`${it.name} disponible`} onChange={(e) => run({ op: "toggle_item", id: it.id, available: e.target.checked })} />
                </label>
                <button type="button" className="btn btn-small" onClick={() => edit(it)}>
                  Editar
                </button>
                <button
                  type="button"
                  className="btn btn-small btn-ghost"
                  aria-label={`Borrar ${it.name}`}
                  onClick={() => {
                    if (window.confirm(`¿Borrar «${it.name}»?`)) run({ op: "delete_item", id: it.id });
                  }}
                >
                  ✕
                </button>
              </div>
            </div>
          ))}
        </section>
      ))}

      <form
        className="card row"
        onSubmit={async (e) => {
          e.preventDefault();
          if (newCat.trim() && (await run({ op: "add_category", name: newCat }))) setNewCat("");
        }}
      >
        <label htmlFor="newcat" className="sr-only">
          Nueva categoría
        </label>
        <input id="newcat" className="input" value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="Nueva categoría (ej. Postres)" maxLength={60} />
        <button className="btn">Agregar categoría</button>
      </form>
    </div>
  );
}
