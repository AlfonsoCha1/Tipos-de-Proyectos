import { requirePageUser } from "@/server/auth";
import { getMenu } from "@/server/repo/restaurants";
import MenuEditor from "./MenuEditor";

export const metadata = { title: "Menú" };

export default async function MenuPage() {
  const u = await requirePageUser(["owner", "staff"], "/panel/login");
  const menu = await getMenu(u.restaurantId);
  return <MenuEditor initial={menu} />;
}
