"use client";
import { useState } from "react";
import LocationPicker from "@/components/LocationPicker";
import { api } from "@/lib/client/api";
import { mxn, parsePesos } from "@/lib/money";
import { normalizePhone } from "@/lib/phone";

interface Line {
  name: string;
  qty: string;
  price: string;
}

export default function ManualOrder({ restaurant }: { restaurant: { lat: number; lng: number; emoji: string; name: string; prep: number; channel: string } }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [lines, setLines] = useState<Line[]>([{ name: "", qty: "1", price: "" }]);
  const [total, setTotal] = useState("");
  const [pay, setPay] = useState<"cash" | "prepaid">("cash");
  const [prep, setPrep] = useState(restaurant.prep);
  const [notify, setNotify] = useState(restaurant.channel !== "none");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ code: string; url: string } | null>(null);

  const items = lines
    .filter((l) => l.name.trim())
    .map((l) => ({ name: l.name.trim(), qty: Math.max(1, parseInt(l.qty || "1", 10) || 1), unitPriceCents: parsePesos(l.price || "0") ?? 0 }));
  const computed = items.reduce((n, i) => n + i.qty * i.unitPriceCents, 0);
  const totalCents = total ? parsePesos(total) : computed;

  if (done) {
    const e164 = normalizePhone(phone);
    const waText = encodeURIComponent(`Hola ${name || ""}, ${restaurant.name} está preparando tu pedido #${done.code}. Síguelo en vivo aquí: ${done.url}`);
    return (
      <div className="card stack" data-testid="manual-done">
        <h2>Pedido #{done.code} creado</h2>
        <p className="muted">
          {notify ? "Le enviamos el link de rastreo a tu cliente." : "No se envió mensaje automático."} También puedes mandárselo tú:
        </p>
        <input className="input" readOnly value={done.url} onFocus={(e) => e.currentTarget.select()} aria-label="Link de rastreo" />
        <div className="row wrap-row">
          <button type="button" className="btn btn-small" onClick={() => navigator.clipboard?.writeText(done.url)}>
            Copiar link
          </button>
          {e164 && (
            <a className="btn btn-small" href={`https://wa.me/${e164.replace("+", "")}?text=${waText}`} target="_blank" rel="noreferrer">
              Enviar por mi WhatsApp
            </a>
          )}
          <a className="btn btn-small" href={done.url} target="_blank" rel="noreferrer">
            Abrir rastreo ↗
          </a>
          <button
            type="button"
            className="btn btn-primary btn-small"
            onClick={() => {
              setDone(null);
              setName("");
              setPhone("");
              setAddress("");
              setNotes("");
              setPos(null);
              setLines([{ name: "", qty: "1", price: "" }]);
              setTotal("");
            }}
          >
            Otro pedido
          </button>
        </div>
      </div>
    );
  }

  return (
    <form
      className="stack-l"
      onSubmit={async (e) => {
        e.preventDefault();
        setError(null);
        if (totalCents == null) return setError("Revisa el total.");
        setBusy(true);
        try {
          const r = await api<{ code: string; trackingUrl: string }>("/api/panel/orders", {
            body: {
              customer: { name: name || "Cliente", phone },
              address: { text: address, notes, lat: pos?.lat ?? null, lng: pos?.lng ?? null },
              items,
              totalCents,
              paymentMethod: pay,
              prepMinutes: prep,
              notify,
            },
          });
          setDone({ code: r.code, url: `${window.location.origin}${r.trackingUrl}` });
        } catch (err) {
          setError(err instanceof Error ? err.message : "No se pudo crear.");
        } finally {
          setBusy(false);
        }
      }}
    >
      <section className="card stack">
        <h2>Cliente</h2>
        <div className="form-grid">
          <label className="field">
            <span>Nombre</span>
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="field">
            <span>Celular</span>
            <input required inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="55 1234 5678" />
          </label>
          <label className="field full">
            <span>Dirección</span>
            <input required minLength={3} value={address} onChange={(e) => setAddress(e.target.value)} />
          </label>
          <label className="field full">
            <span>Referencias</span>
            <input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </label>
        </div>
        <details>
          <summary style={{ cursor: "pointer", fontWeight: 600 }}>Marcar en el mapa (recomendado para el rastreo y la hora estimada)</summary>
          <div style={{ marginTop: 10 }}>
            <LocationPicker value={pos} fallbackCenter={{ lat: restaurant.lat, lng: restaurant.lng }} restaurant={restaurant} onChange={(p) => setPos(p)} height={220} />
          </div>
        </details>
      </section>

      <section className="card stack">
        <h2>Pedido</h2>
        {lines.map((l, i) => (
          <div key={i} className="row">
            <input className="input" aria-label="Producto" placeholder="Producto" value={l.name} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            <input className="input" aria-label="Cantidad" style={{ width: 64 }} inputMode="numeric" value={l.qty} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, qty: e.target.value } : x)))} />
            <input className="input" aria-label="Precio unitario" style={{ width: 96 }} inputMode="decimal" placeholder="$" value={l.price} onChange={(e) => setLines(lines.map((x, j) => (j === i ? { ...x, price: e.target.value } : x)))} />
          </div>
        ))}
        <button type="button" className="btn btn-small" onClick={() => setLines([...lines, { name: "", qty: "1", price: "" }])}>
          + Otro producto
        </button>
        <label className="field">
          <span>Total a cobrar</span>
          <input inputMode="decimal" value={total} onChange={(e) => setTotal(e.target.value)} placeholder={computed ? mxn(computed) : "$0.00"} />
          <small>Déjalo vacío para usar la suma de los productos.</small>
        </label>
        <div className="segmented" role="group" aria-label="Pago">
          <button type="button" aria-pressed={pay === "cash"} onClick={() => setPay("cash")}>
            Cobrar en efectivo
          </button>
          <button type="button" aria-pressed={pay === "prepaid"} onClick={() => setPay("prepaid")}>
            Ya pagó
          </button>
        </div>
        <label className="field">
          <span>Listo en (minutos)</span>
          <input type="number" min={1} max={180} value={prep} onChange={(e) => setPrep(Number(e.target.value) || 1)} />
        </label>
        <label className="check">
          <input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} />
          <span>
            Enviar el link de rastreo automáticamente
            <small>Por {restaurant.channel === "whatsapp" ? "WhatsApp" : "SMS"} (configúralo en Ajustes).</small>
          </span>
        </label>
      </section>
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}
      <button className="btn btn-primary btn-block" disabled={busy}>
        {busy ? "Creando…" : `Crear pedido${totalCents ? ` · ${mxn(totalCents)}` : ""}`}
      </button>
    </form>
  );
}
