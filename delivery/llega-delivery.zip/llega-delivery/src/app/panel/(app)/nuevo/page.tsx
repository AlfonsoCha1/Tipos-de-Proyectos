import { requirePageUser } from "@/server/auth";
import { getRestaurantById } from "@/server/repo/restaurants";
import ManualOrder from "./ManualOrder";

export const metadata = { title: "Pedido manual" };

export default async function NuevoPage() {
  const u = await requirePageUser(["owner", "staff"], "/panel/login");
  const r = (await getRestaurantById(u.restaurantId))!;
  return (
    <div className="narrow stack-l" style={{ padding: 0 }}>
      <div className="stack">
        <h1 className="display" style={{ fontSize: 34 }}>
          Pedido manual
        </h1>
        <p className="muted">
          Para pedidos que te llegan por teléfono o WhatsApp. Tu cliente recibe un link para seguir al repartidor en vivo (modo «solo rastreo»).
        </p>
      </div>
      <ManualOrder restaurant={{ lat: r.lat, lng: r.lng, emoji: r.logo_emoji, name: r.name, prep: r.prep_minutes, channel: r.notify_channel }} />
    </div>
  );
}
