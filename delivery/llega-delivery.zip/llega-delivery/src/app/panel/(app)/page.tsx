import { demoToolsEnabled } from "@/server/orders";
import Board from "./Board";

export const metadata = { title: "Pedidos" };

export default function PanelHome() {
  return <Board demoTools={demoToolsEnabled()} />;
}
