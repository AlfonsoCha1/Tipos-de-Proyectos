import { Topbar } from "@/components/Chrome";
import LoginForm from "@/components/LoginForm";

export const metadata = { title: "Entrar al panel" };

export default function PanelLogin() {
  return (
    <>
      <Topbar />
      <LoginForm
        title="Panel del restaurante"
        subtitle="Recibe pedidos, asigna repartidores y edita tu menú."
        alt={{ href: "/panel/registro", label: "¿No tienes cuenta? Registra tu restaurante" }}
      />
    </>
  );
}
