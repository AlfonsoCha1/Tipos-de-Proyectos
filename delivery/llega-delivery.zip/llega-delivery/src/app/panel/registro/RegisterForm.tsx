"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import LocationPicker from "@/components/LocationPicker";
import { api } from "@/lib/client/api";

const CENTER = { lat: 19.7137, lng: -99.2233 };

export default function RegisterForm() {
  const router = useRouter();
  const [f, setF] = useState({ restaurantName: "", cuisine: "", ownerName: "", email: "", password: "", phone: "", address: "" });
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  return (
    <form
      className="stack-l"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!pos) return setError("Marca en el mapa dónde está tu restaurante.");
        setBusy(true);
        setError(null);
        try {
          const r = await api<{ redirect: string }>("/api/auth/register", { body: { ...f, lat: pos.lat, lng: pos.lng } });
          router.push(r.redirect);
          router.refresh();
        } catch (err) {
          setError(err instanceof Error ? err.message : "No se pudo registrar.");
          setBusy(false);
        }
      }}
    >
      <section className="card stack">
        <h2>Tu restaurante</h2>
        <div className="form-grid">
          <label className="field">
            <span>Nombre</span>
            <input required minLength={2} value={f.restaurantName} onChange={set("restaurantName")} placeholder="Tacos El Güero" />
          </label>
          <label className="field">
            <span>Tipo de comida</span>
            <input value={f.cuisine} onChange={set("cuisine")} placeholder="Tacos, pizza, café…" />
          </label>
          <label className="field full">
            <span>Dirección</span>
            <input required minLength={5} value={f.address} onChange={set("address")} placeholder="Calle, número y colonia" />
          </label>
        </div>
        <LocationPicker value={pos} fallbackCenter={CENTER} onChange={(p) => setPos(p)} />
      </section>
      <section className="card stack">
        <h2>Tu cuenta</h2>
        <div className="form-grid">
          <label className="field">
            <span>Tu nombre</span>
            <input required minLength={2} value={f.ownerName} onChange={set("ownerName")} autoComplete="name" />
          </label>
          <label className="field">
            <span>Celular</span>
            <input required inputMode="tel" value={f.phone} onChange={set("phone")} placeholder="55 1234 5678" autoComplete="tel" />
          </label>
          <label className="field">
            <span>Correo</span>
            <input required type="email" value={f.email} onChange={set("email")} autoComplete="email" />
          </label>
          <label className="field">
            <span>Contraseña</span>
            <input required type="password" minLength={8} value={f.password} onChange={set("password")} autoComplete="new-password" />
            <small>Mínimo 8 caracteres.</small>
          </label>
        </div>
      </section>
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}
      <button className="btn btn-primary btn-block" disabled={busy}>
        {busy ? "Creando…" : "Crear mi restaurante"}
      </button>
      <p className="faint">Al registrarte aceptas los términos y el aviso de privacidad.</p>
    </form>
  );
}
