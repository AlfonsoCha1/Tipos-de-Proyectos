import Link from "next/link";
import { Topbar } from "@/components/Chrome";
import RegisterForm from "./RegisterForm";

export const metadata = { title: "Registrar restaurante" };

export default function Registro() {
  return (
    <>
      <Topbar>
        <Link href="/panel/login">Ya tengo cuenta</Link>
      </Topbar>
      <main className="narrow stack-l" style={{ paddingTop: 32, paddingBottom: 48 }}>
        <div className="stack">
          <h1 className="display">Registra tu restaurante</h1>
          <p className="muted">Después subes tu menú e invitas a tus repartidores. Tu tienda no aparece en el marketplace hasta que tú lo actives.</p>
        </div>
        <RegisterForm />
      </main>
    </>
  );
}
