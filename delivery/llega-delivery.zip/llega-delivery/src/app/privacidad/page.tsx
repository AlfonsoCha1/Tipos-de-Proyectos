import { Footer, Topbar } from "@/components/Chrome";
import { BRAND } from "@/lib/brand";

export const metadata = { title: "Aviso de privacidad" };

/** TEMPLATE. Review with a lawyer before launch (LFPDPPP, México). */
export default function PrivacyPage() {
  return (
    <>
      <Topbar />
      <main className="narrow stack" style={{ padding: "24px 16px 60px" }}>
        <h1 className="display">Aviso de privacidad</h1>
        <p className="notice">
          Plantilla de trabajo. Antes de lanzar, complétala con los datos del responsable (razón social, domicilio, contacto) y revísala con un abogado conforme a
          la Ley Federal de Protección de Datos Personales en Posesión de los Particulares.
        </p>
        <h2>Qué datos usamos</h2>
        <p>
          Para entregar tu pedido, {BRAND} y el restaurante usan tu nombre, teléfono, dirección, la ubicación que marques en el mapa y el detalle del pedido. Si eres
          repartidor, usamos tu nombre, teléfono, correo y tu ubicación GPS solo mientras estás disponible o tienes un pedido en curso.
        </p>
        <h2>Para qué</h2>
        <p>
          Preparar y entregar pedidos, avisarte por SMS o WhatsApp del estado de tu pedido, mostrar al cliente dónde viene su repartidor, atender aclaraciones y
          prevenir fraudes (código de entrega).
        </p>
        <h2>Con quién se comparte</h2>
        <p>
          Con el restaurante que elegiste y con el repartidor asignado. Con proveedores que nos ayudan a operar: hospedaje y base de datos, envío de SMS o WhatsApp y,
          si usas el chat, el servicio de inteligencia artificial que interpreta tus mensajes. No vendemos tus datos.
        </p>
        <h2>Tus derechos (ARCO)</h2>
        <p>Puedes pedir acceso, rectificación, cancelación u oposición al uso de tus datos escribiendo a: [correo de privacidad].</p>
        <h2>Conservación</h2>
        <p>Guardamos los datos del pedido el tiempo necesario para cumplir obligaciones fiscales y de aclaraciones: [plazo].</p>
        <p className="faint">Última actualización: [fecha].</p>
      </main>
      <Footer />
    </>
  );
}
