"use client";
import Link from "next/link";
import { BRAND } from "@/lib/brand";
import { useCart } from "@/lib/client/cart";
import { mxn } from "@/lib/money";
import type { MenuCategory, RestaurantPublic } from "@/lib/types";

export default function Storefront({ restaurant: r, menu, via }: { restaurant: RestaurantPublic; menu: MenuCategory[]; via: string }) {
  const cart = useCart(r.slug);
  const qtyOf = (id: string) => cart.lines.filter((l) => l.itemId === id).reduce((n, l) => n + l.qty, 0);
  const q = via ? `?via=${via}` : "";

  return (
    <div style={{ ["--brand" as string]: r.brandColor }}>
      <header className="topbar">
        <div className="wrap">
          {via ? (
            <Link href="/" className="btn btn-ghost btn-small" aria-label="Volver a restaurantes">
              ←
            </Link>
          ) : null}
          <strong style={{ fontSize: 17 }}>
            {r.logoEmoji} {r.name}
          </strong>
          <nav>
            <Link href={`/r/${r.slug}/chat${q}`} className="btn btn-small">
              💬 Pedir por chat
            </Link>
          </nav>
        </div>
      </header>

      <section className="store-head">
        <div className="wrap row" style={{ gap: 16, alignItems: "center" }}>
          <div className="rest-logo" aria-hidden="true">
            {r.logoEmoji}
          </div>
          <div className="stack" style={{ minWidth: 0 }}>
            <h1 style={{ fontSize: "clamp(30px, 8vw, 44px)" }}>{r.name}</h1>
            {r.tagline && <p style={{ opacity: 0.9 }}>{r.tagline}</p>}
            <div className="row wrap-row">
              <span className="chip">{r.isOpen ? "Abierto ahora" : "Cerrado"}</span>
              <span className="chip">
                {r.prepMinutes + 10}–{r.prepMinutes + 25} min
              </span>
              <span className="chip">Envío {mxn(r.deliveryFeeCents)}</span>
              {r.minOrderCents > 0 && <span className="chip">Mínimo {mxn(r.minOrderCents)}</span>}
            </div>
          </div>
        </div>
      </section>

      {menu.length > 1 && (
        <nav className="cat-nav" aria-label="Categorías del menú">
          <div className="wrap">
            {menu.map((c) => (
              <a key={c.id} href={`#cat-${c.id}`}>
                {c.name}
              </a>
            ))}
          </div>
        </nav>
      )}

      <main className="wrap pad-bottom">
        {!r.isOpen && (
          <p className="notice" style={{ marginTop: 16 }}>
            {r.name} está cerrado en este momento. Puedes ver el menú; los pedidos se reciben cuando abra.
          </p>
        )}
        {menu.length === 0 && <p className="muted" style={{ marginTop: 24 }}>Este restaurante todavía no publica su menú.</p>}
        {menu.map((c) => (
          <section key={c.id} id={`cat-${c.id}`} className="menu-section" aria-labelledby={`h-${c.id}`}>
            <h2 id={`h-${c.id}`}>{c.name}</h2>
            <div>
              {c.items.map((it) => {
                const n = qtyOf(it.id);
                return (
                  <div key={it.id} className={`menu-item ${it.available ? "" : "off"}`} data-testid="menu-item">
                    <div className="emoji" aria-hidden="true">
                      {it.emoji || "🍽️"}
                    </div>
                    <div style={{ minWidth: 0 }}>
                      <h3>{it.name}</h3>
                      {it.description && <p className="faint">{it.description}</p>}
                      <p className="money" style={{ fontWeight: 700, marginTop: 2 }}>
                        {mxn(it.priceCents)}
                        {!it.available && <span className="chip closed" style={{ marginLeft: 8 }}>Agotado</span>}
                      </p>
                    </div>
                    {it.available &&
                      (n === 0 ? (
                        <button
                          type="button"
                          className="add-btn"
                          aria-label={`Agregar ${it.name}`}
                          onClick={() => cart.add({ itemId: it.id, name: it.name, priceCents: it.priceCents, emoji: it.emoji })}
                        >
                          Agregar
                        </button>
                      ) : (
                        <div className="qty" role="group" aria-label={`Cantidad de ${it.name}`}>
                          <button type="button" aria-label="Quitar uno" onClick={() => cart.add({ itemId: it.id, name: it.name, priceCents: it.priceCents, emoji: it.emoji }, -1)}>
                            −
                          </button>
                          <output aria-live="polite">{n}</output>
                          <button type="button" aria-label="Agregar uno" onClick={() => cart.add({ itemId: it.id, name: it.name, priceCents: it.priceCents, emoji: it.emoji })}>
                            +
                          </button>
                        </div>
                      ))}
                  </div>
                );
              })}
            </div>
          </section>
        ))}
        <p className="faint" style={{ marginTop: 32 }}>
          {r.address} · Tienda en línea con {BRAND}
        </p>
      </main>

      {cart.count > 0 && (
        <div className="cart-bar">
          <Link href={`/r/${r.slug}/pedir${q}`} className="btn btn-primary" data-testid="go-checkout">
            <span>
              Ver pedido · {cart.count} {cart.count === 1 ? "producto" : "productos"}
            </span>
            <span className="money">{mxn(cart.subtotal)}</span>
          </Link>
        </div>
      )}
    </div>
  );
}
