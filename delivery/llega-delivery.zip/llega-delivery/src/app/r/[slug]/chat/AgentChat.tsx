"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { api, ApiError } from "@/lib/client/api";
import { mxn } from "@/lib/money";
import type { RestaurantPublic } from "@/lib/types";

interface AgentView {
  sessionId: string;
  reply?: string;
  mode: "ai" | "rules";
  fallback?: boolean;
  cart: { lines: { itemId: string; name: string; emoji: string; qty: number; unitPriceCents: number; notes?: string }[]; subtotalCents: number; deliveryFeeCents: number; totalCents: number };
  customer: { name?: string; phone?: string; address?: string; hasLocation: boolean; payment: "cash" | "card_sim" };
  missing: string[];
  awaitingConfirmation: boolean;
  order?: { code: string; trackingUrl: string };
  suggestions: string[];
  messages: { role: "user" | "assistant"; content: string }[];
}

const AI_NAMES: Record<string, string> = { groq: "Groq", openai: "OpenAI", anthropic: "Claude" };

/** Turn URLs in the assistant's text into links (tracking links point to this same site). */
function Linkified({ text }: { text: string }) {
  const parts = text.split(/(https?:\/\/[^\s]+)/g);
  return (
    <>
      {parts.map((p, i) => {
        if (!/^https?:\/\//.test(p)) return <span key={i}>{p}</span>;
        let href = p;
        try {
          const u = new URL(p);
          if (u.host === window.location.host) href = u.pathname + u.search;
        } catch {}
        return (
          <a key={i} href={href}>
            {href.startsWith("/t/") ? "Ver mi pedido en vivo" : p}
          </a>
        );
      })}
    </>
  );
}

export default function AgentChat({ restaurant: r, greeting, ai, via }: { restaurant: RestaurantPublic; greeting: string; ai: string | null; via: string }) {
  const key = `llega.agent.${r.slug}`;
  const [view, setView] = useState<AgentView | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const q = via ? `?via=${via}` : "";

  // Restore an ongoing conversation after a reload.
  useEffect(() => {
    let sid: string | null = null;
    try {
      sid = localStorage.getItem(key);
    } catch {}
    if (!sid) return;
    api<AgentView>(`/api/agent/${r.slug}?session=${encodeURIComponent(sid)}`)
      .then(setView)
      .catch(() => {
        try {
          localStorage.removeItem(key);
        } catch {}
      });
  }, [key, r.slug]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [view?.messages.length, busy]);

  async function send(message: string, location?: { lat: number; lng: number }) {
    if (busy || (!message.trim() && !location)) return;
    setBusy(true);
    setError(null);
    // Optimistic bubble.
    if (message.trim()) setView((v) => (v ? { ...v, messages: [...v.messages, { role: "user", content: message.trim() }] } : v));
    try {
      const out = await api<AgentView>(`/api/agent/${r.slug}`, { body: { sessionId: view?.sessionId ?? null, text: message, location: location ?? null } });
      setView(out);
      setText("");
      try {
        localStorage.setItem(key, out.sessionId);
      } catch {}
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "No se pudo enviar. Revisa tu conexión.");
      setView((v) => (v ? { ...v, messages: v.messages.slice(0, -1) } : v));
    } finally {
      setBusy(false);
    }
  }

  function shareLocation() {
    if (!("geolocation" in navigator)) {
      setError("Tu navegador no permite compartir ubicación. Escribe «sin ubicación».");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        void send("", { lat: pos.coords.latitude, lng: pos.coords.longitude });
      },
      () => {
        setLocating(false);
        setError("No pudimos leer tu ubicación. Revisa el permiso o escribe «sin ubicación».");
      },
      { enableHighAccuracy: true, timeout: 12000 },
    );
  }

  function restart() {
    try {
      localStorage.removeItem(key);
    } catch {}
    setView(null);
    setError(null);
  }

  const messages = view?.messages ?? [];
  const suggestions = view?.suggestions ?? ["Ver menú"];
  // Offer the location button whenever there is something to deliver and no pin yet.
  const needsLocation = !!view && !view.order && !view.customer.hasLocation && view.cart.lines.length > 0;
  const trackPath = view?.order ? (() => {
    try {
      return new URL(view.order!.trackingUrl).pathname;
    } catch {
      return view.order!.trackingUrl;
    }
  })() : null;

  return (
    <div className="agent-page" style={{ ["--brand" as string]: r.brandColor }}>
      <header className="topbar">
        <div className="wrap">
          <Link href={`/r/${r.slug}${q}`} className="btn btn-ghost btn-small" aria-label={`Volver al menú de ${r.name}`}>
            ←
          </Link>
          <strong style={{ fontSize: 16 }}>
            {r.logoEmoji} {r.name}
          </strong>
          <span className={`chip ${ai ? "live" : ""}`} title={ai ? "Un modelo de IA entiende tu mensaje; el sistema valida cada cambio." : "Sin clave de IA: entiende pedidos simples con reglas."}>
            {ai ? `IA · ${AI_NAMES[ai] ?? ai}` : "Sin IA"}
          </span>
        </div>
      </header>

      <main className="agent-scroll">
        <div className="narrow agent-feed" aria-live="polite" data-testid="agent-feed">
          <div className="bubble">
            <span className="who">Asistente</span>
            {greeting}
          </div>
          {messages.map((m, i) => (
            <div key={i} className={`bubble ${m.role === "user" ? "me" : ""}`}>
              <span className="who">{m.role === "user" ? "Tú" : "Asistente"}</span>
              {m.role === "assistant" ? <Linkified text={m.content} /> : m.content}
            </div>
          ))}
          {busy && (
            <div className="bubble" aria-label="El asistente está escribiendo">
              <span className="who">Asistente</span>…
            </div>
          )}
          {view?.fallback && <p className="faint">La IA no respondió a tiempo; este mensaje lo resolvió el asistente de respaldo.</p>}
          <div ref={endRef} />
        </div>
      </main>

      <div className="agent-dock">
        <div className="narrow stack">
          {view?.order && trackPath ? (
            <div className="ok-box stack">
              <strong>Pedido #{view.order.code} enviado a la cocina.</strong>
              <div className="row wrap-row">
                <Link href={trackPath} className="btn btn-primary" data-testid="agent-track">
                  Ver mi pedido en vivo
                </Link>
                <button type="button" className="btn btn-small" onClick={restart}>
                  Empezar otro chat
                </button>
              </div>
            </div>
          ) : (
            view &&
            view.cart.lines.length > 0 && (
              <div className="mini-cart spread" data-testid="agent-cart">
                <span>
                  {view.cart.lines.map((l) => `${l.qty}× ${l.name}`).join(", ")}
                </span>
                <strong className="money">{mxn(view.cart.totalCents)}</strong>
              </div>
            )
          )}
          {error && (
            <p className="alert" role="alert">
              {error}
            </p>
          )}
          {!r.isOpen && <p className="notice">{r.name} está cerrado ahora. Puedes preguntar, pero no se envían pedidos.</p>}
          <div className="suggestions">
            {needsLocation && (
              <button type="button" className="btn btn-small btn-dark" onClick={shareLocation} disabled={busy || locating}>
                {locating ? "Buscando…" : "📍 Compartir ubicación"}
              </button>
            )}
            {suggestions.map((s) => (
              <button key={s} type="button" className="btn btn-small" onClick={() => send(s === "Cambiar algo" ? "quiero cambiar algo" : s)} disabled={busy}>
                {s}
              </button>
            ))}
          </div>
          <form
            className="composer"
            onSubmit={(e) => {
              e.preventDefault();
              void send(text);
            }}
          >
            <label htmlFor="agent-input" className="sr-only">
              Escribe tu pedido
            </label>
            <input
              id="agent-input"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ej. 2 tacos al pastor y una horchata"
              autoComplete="off"
              maxLength={500}
              enterKeyHint="send"
            />
            <button type="submit" className="btn btn-primary" disabled={busy || !text.trim()}>
              Enviar
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
