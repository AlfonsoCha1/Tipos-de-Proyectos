import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { agentGreeting } from "@/server/agent";
import { agentLlm } from "@/server/agent/llm";
import { getRestaurantBySlug, toPublic } from "@/server/repo/restaurants";
import AgentChat from "./AgentChat";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const r = await getRestaurantBySlug(slug);
  return { title: r ? `Pide por chat — ${r.name}` : "No encontrado" };
}

export default async function ChatPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ via?: string }> }) {
  const { slug } = await params;
  const { via } = await searchParams;
  const r = await getRestaurantBySlug(slug);
  if (!r) notFound();
  const llm = agentLlm();
  return <AgentChat restaurant={toPublic(r)} greeting={await agentGreeting(r)} ai={llm ? llm.vendor : null} via={via === "m" ? "m" : ""} />;
}
