import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getMenu, getRestaurantBySlug, toPublic } from "@/server/repo/restaurants";
import Storefront from "./Storefront";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const r = await getRestaurantBySlug(slug);
  return r ? { title: `${r.name} — pide a domicilio`, description: r.tagline || `Pide en línea a ${r.name}` } : { title: "No encontrado" };
}

export default async function StorePage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ via?: string }> }) {
  const { slug } = await params;
  const { via } = await searchParams;
  const r = await getRestaurantBySlug(slug);
  if (!r) notFound();
  const menu = await getMenu(r.id);
  return <Storefront restaurant={toPublic(r)} menu={menu} via={via === "m" ? "m" : ""} />;
}
