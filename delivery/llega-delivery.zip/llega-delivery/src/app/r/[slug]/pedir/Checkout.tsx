"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import LocationPicker from "@/components/LocationPicker";
import { api } from "@/lib/client/api";
import { loadCustomer, saveCustomer, useCart } from "@/lib/client/cart";
import { distanceKm } from "@/lib/geo";
import { mxn } from "@/lib/money";
import type { RestaurantPublic } from "@/lib/types";

const TIPS = [0, 1000, 2000, 3000];

export default function Checkout({ restaurant: r, source }: { restaurant: RestaurantPublic; source: "web" | "marketplace" }) {
  const router = useRouter();
  const cart = useCart(r.slug);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [pay, setPay] = useState<"cash" | "card_sim">(r.acceptsCash ? "cash" : "card_sim");
  const [tip, setTip] = useState(0);
  const [orderNotes, setOrderNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const c = loadCustomer();
    if (!c) return;
    setName(c.name);
    setPhone(c.phone);
    setAddress(c.address);
    setNotes(c.notes);
    if (typeof c.lat === "number" && typeof c.lng === "number") setPos({ lat: c.lat, lng: c.lng });
  }, []);

  const dist = pos ? distanceKm({ lat: r.lat, lng: r.lng }, pos) : null;
  const tooFar = dist != null && dist > r.deliveryRadiusKm;
  const belowMin = cart.subtotal < r.minOrderCents;
  const total = cart.subtotal + (cart.count ? r.deliveryFeeCents : 0) + tip;
  const back = `/r/${r.slug}${source === "marketplace" ? "?via=m" : ""}`;

  if (cart.count === 0 && !busy) {
    return (
      <main className="narrow stack" style={{ paddingTop: 48 }}>
        <h1 className="display">Tu carrito está vacío</h1>
        <Link className="btn btn-primary" href={back}>
          Ver el menú de {r.name}
        </Link>
      </main>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!pos) return setError("Marca tu ubicación en el mapa para que el repartidor llegue directo.");
    setBusy(true);
    try {
      const res = await api<{ trackingUrl: string }>("/api/orders", {
        body: {
          slug: r.slug,
          source,
          items: cart.lines.map((l) => ({ itemId: l.itemId, qty: l.qty, notes: l.notes || undefined })),
          customer: { name, phone },
          address: { text: address, notes, lat: pos.lat, lng: pos.lng },
          paymentMethod: pay,
          tipCents: tip,
          notes: orderNotes || undefined,
        },
      });
      saveCustomer({ name, phone, address, notes, lat: pos.lat, lng: pos.lng });
      cart.clear();
      router.push(res.trackingUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo enviar el pedido.");
      setBusy(false);
    }
  };

  return (
    <div style={{ ["--brand" as string]: r.brandColor }}>
      <header className="topbar">
        <div className="wrap">
          <Link href={back} className="btn btn-ghost btn-small" aria-label="Volver al menú">
            ←
          </Link>
          <strong>Tu pedido en {r.name}</strong>
        </div>
      </header>
      <form className="narrow stack-l pad-bottom" style={{ paddingTop: 20 }} onSubmit={submit}>
        <section className="card stack" aria-labelledby="h-items">
          <h2 id="h-items">Productos</h2>
          {cart.lines.map((l) => (
            <div key={`${l.itemId}${l.notes ?? ""}`} className="stack" style={{ borderBottom: "1px solid var(--line)", paddingBottom: 10 }}>
              <div className="spread">
                <div>
                  <strong>
                    {l.emoji} {l.name}
                  </strong>
                  <div className="faint money">{mxn(l.priceCents)} c/u</div>
                </div>
                <div className="qty" role="group" aria-label={`Cantidad de ${l.name}`}>
                  <button type="button" aria-label="Quitar uno" onClick={() => cart.add(l, -1)}>
                    −
                  </button>
                  <output>{l.qty}</output>
                  <button type="button" aria-label="Agregar uno" onClick={() => cart.add(l, 1)}>
                    +
                  </button>
                </div>
              </div>
              <input
                className="input"
                aria-label={`Indicaciones para ${l.name}`}
                placeholder="Indicaciones (ej. sin cebolla)"
                maxLength={140}
                value={l.notes ?? ""}
                onChange={(e) => cart.setNotes(l.itemId, e.target.value)}
              />
            </div>
          ))}
          <Link href={back} className="faint">
            + Agregar más
          </Link>
        </section>

        <section className="card stack" aria-labelledby="h-you">
          <h2 id="h-you">Tus datos</h2>
          <div className="form-grid">
            <label className="field">
              <span>Nombre</span>
              <input required minLength={2} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
            </label>
            <label className="field">
              <span>Celular</span>
              <input required inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" placeholder="55 1234 5678" />
              <small>Te avisamos por mensaje cuando vaya en camino.</small>
            </label>
          </div>
        </section>

        <section className="card stack" aria-labelledby="h-where">
          <h2 id="h-where">¿A dónde lo llevamos?</h2>
          <label className="field">
            <span>Dirección</span>
            <input required minLength={5} value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="street-address" placeholder="Calle, número, colonia" />
          </label>
          <label className="field">
            <span>Referencias (opcional)</span>
            <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Portón negro, tocar el timbre 2" maxLength={200} />
          </label>
          <LocationPicker
            value={pos}
            fallbackCenter={{ lat: r.lat, lng: r.lng }}
            restaurant={{ lat: r.lat, lng: r.lng, emoji: r.logoEmoji, name: r.name }}
            onChange={(p, label) => {
              setPos(p);
              if (label && !address) setAddress(label.split(",").slice(0, 3).join(","));
            }}
          />
          {dist != null && (
            <p className={tooFar ? "alert" : "faint"}>
              {tooFar
                ? `Estás a ${dist.toFixed(1)} km; ${r.name} entrega hasta ${r.deliveryRadiusKm} km.`
                : `A ${dist.toFixed(1)} km del restaurante.`}
            </p>
          )}
        </section>

        <section className="card stack" aria-labelledby="h-pay">
          <h2 id="h-pay">Pago</h2>
          <div className="segmented" role="group" aria-label="Forma de pago">
            {r.acceptsCash && (
              <button type="button" aria-pressed={pay === "cash"} onClick={() => setPay("cash")}>
                💵 Efectivo al recibir
              </button>
            )}
            {r.acceptsCardSim && (
              <button type="button" aria-pressed={pay === "card_sim"} onClick={() => setPay("card_sim")}>
                💳 Tarjeta (prueba)
              </button>
            )}
          </div>
          {pay === "card_sim" && (
            <p className="notice">Pago de prueba: se aprueba sin pedir datos de tarjeta y no se cobra dinero real. Los cobros reales se activan más adelante.</p>
          )}
          <div className="stack">
            <span style={{ fontWeight: 600, fontSize: 14 }}>Propina para el repartidor</span>
            <div className="segmented" role="group" aria-label="Propina">
              {TIPS.map((t) => (
                <button key={t} type="button" aria-pressed={tip === t} onClick={() => setTip(t)}>
                  {t === 0 ? "Sin propina" : mxn(t)}
                </button>
              ))}
            </div>
          </div>
          <label className="field">
            <span>Nota para el restaurante (opcional)</span>
            <input value={orderNotes} onChange={(e) => setOrderNotes(e.target.value)} maxLength={300} placeholder="Cubiertos, salsas aparte…" />
          </label>
        </section>

        <section className="card receipt" aria-label="Resumen">
          <div className="line">
            <span>Productos</span>
            <span className="money">{mxn(cart.subtotal)}</span>
          </div>
          <div className="line">
            <span>Envío</span>
            <span className="money">{mxn(r.deliveryFeeCents)}</span>
          </div>
          {tip > 0 && (
            <div className="line">
              <span>Propina</span>
              <span className="money">{mxn(tip)}</span>
            </div>
          )}
          <div className="line total">
            <span>Total</span>
            <span className="money">{mxn(total)}</span>
          </div>
        </section>

        {belowMin && <p className="alert">El pedido mínimo es de {mxn(r.minOrderCents)}.</p>}
        {!r.isOpen && <p className="alert">{r.name} está cerrado ahora.</p>}
        {error && (
          <p className="alert" role="alert">
            {error}
          </p>
        )}
        <div className="cart-bar">
          <button className="btn btn-primary" disabled={busy || tooFar || belowMin || !r.isOpen} data-testid="place-order">
            <span>{busy ? "Enviando…" : "Hacer pedido"}</span>
            <span className="money">{mxn(total)}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
