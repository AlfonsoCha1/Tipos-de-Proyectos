import { notFound } from "next/navigation";
import { getRestaurantBySlug, toPublic } from "@/server/repo/restaurants";
import Checkout from "./Checkout";

export const dynamic = "force-dynamic";
export const metadata = { title: "Tu pedido" };

export default async function CheckoutPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ via?: string }> }) {
  const { slug } = await params;
  const { via } = await searchParams;
  const r = await getRestaurantBySlug(slug);
  if (!r) notFound();
  return <Checkout restaurant={toPublic(r)} source={via === "m" ? "marketplace" : "web"} />;
}
