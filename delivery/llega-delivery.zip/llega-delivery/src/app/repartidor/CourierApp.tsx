"use client";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import type { MapMarker } from "@/components/MapView";
import { api } from "@/lib/client/api";
import { usePoll } from "@/lib/client/usePoll";
import { distanceKm, googleMapsUrl, wazeUrl } from "@/lib/geo";
import { mxn } from "@/lib/money";
import { prettyPhone } from "@/lib/phone";
import type { CourierJob } from "@/lib/types";

const MapView = dynamic(() => import("@/components/MapView"), { ssr: false, loading: () => <div className="map" /> });

interface State {
  me: { id: string; name: string; available: boolean };
  jobs: CourierJob[];
}

type Gps = { state: "off" } | { state: "waiting" } | { state: "on"; accuracy: number; sentAt: number | null } | { state: "error"; message: string };

const MIN_SEND_MS = 5000;

export default function CourierApp({ name }: { name: string }) {
  const router = useRouter();
  const { data, refresh } = usePoll<State>("/api/courier/jobs", 5000);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [gps, setGps] = useState<Gps>({ state: "off" });
  const [me, setMe] = useState<{ lat: number; lng: number } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const lastSent = useRef<{ t: number; lat: number; lng: number } | null>(null);

  useEffect(() => {
    if (data && available === null) setAvailable(data.me.available);
  }, [data, available]);

  const jobs = data?.jobs ?? [];
  const mine = jobs.filter((j) => j.mine);
  const offers = jobs.filter((j) => !j.mine);
  const working = !!available || mine.length > 0;

  // Share GPS while available or carrying an order.
  useEffect(() => {
    if (!working) {
      setGps({ state: "off" });
      return;
    }
    if (!("geolocation" in navigator)) {
      setGps({ state: "error", message: "Este teléfono no permite compartir ubicación desde el navegador." });
      return;
    }
    setGps({ state: "waiting" });
    const id = navigator.geolocation.watchPosition(
      async (p) => {
        const pos = { lat: p.coords.latitude, lng: p.coords.longitude };
        setMe(pos);
        const prev = lastSent.current;
        const moved = prev ? distanceKm(prev, pos) * 1000 : Infinity;
        const due = !prev || Date.now() - prev.t > MIN_SEND_MS || moved > 40;
        setGps((g) => ({ state: "on", accuracy: Math.round(p.coords.accuracy), sentAt: g.state === "on" ? g.sentAt : null }));
        if (!due) return;
        lastSent.current = { t: Date.now(), ...pos };
        try {
          await api("/api/courier/location", {
            body: { ...pos, accuracy: p.coords.accuracy, heading: Number.isFinite(p.coords.heading ?? NaN) ? p.coords.heading : null },
          });
          setGps({ state: "on", accuracy: Math.round(p.coords.accuracy), sentAt: Date.now() });
        } catch {
          /* next fix retries */
        }
      },
      (err) =>
        setGps({
          state: "error",
          message: err.code === 1 ? "Diste «no permitir» a la ubicación. Actívala en los ajustes del navegador para este sitio." : "No hay señal de GPS. Sal a un lugar abierto.",
        }),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 20000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [working]);

  // Keep the screen on while working (where supported).
  useEffect(() => {
    if (!working || !("wakeLock" in navigator)) return;
    let lock: WakeLockSentinel | null = null;
    const get = async () => {
      try {
        lock = await navigator.wakeLock.request("screen");
      } catch {
        /* not allowed */
      }
    };
    get();
    const onVis = () => document.visibilityState === "visible" && get();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      lock?.release().catch(() => {});
    };
  }, [working]);

  const act = async (id: string, action: "take" | "release" | "pickup" | "deliver", pin?: string) => {
    setMsg(null);
    try {
      await api(`/api/courier/orders/${id}`, { body: { action, pin } });
      if (action === "deliver") setMsg("¡Entregado! Buen trabajo.");
      refresh();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "No se pudo.");
    }
  };

  const secondsAgo = gps.state === "on" && gps.sentAt ? Math.round((Date.now() - gps.sentAt) / 1000) : null;

  return (
    <main className="narrow stack-l" style={{ paddingTop: 16, paddingBottom: 48 }}>
      <div className="courier-top">
        <div>
          <strong style={{ fontSize: 18 }}>Hola, {name.split(" ")[0]}</strong>
          <div className="gps" aria-live="polite" data-testid="gps">
            {gps.state === "off" && "📍 Ubicación apagada"}
            {gps.state === "waiting" && "📍 Buscando GPS…"}
            {gps.state === "on" && `📍 GPS activo ±${gps.accuracy} m${secondsAgo != null ? ` · enviado hace ${secondsAgo} s` : ""}`}
            {gps.state === "error" && `⚠️ ${gps.message}`}
          </div>
        </div>
        <label className="switch">
          <input
            type="checkbox"
            checked={!!available}
            aria-label="Disponible para pedidos"
            onChange={async (e) => {
              const v = e.target.checked;
              setAvailable(v);
              try {
                await api("/api/courier/availability", { body: { available: v } });
              } catch {
                setAvailable(!v);
              }
            }}
          />
          <span>{available ? "Disponible" : "Descansando"}</span>
        </label>
      </div>

      {msg && (
        <p className={msg.startsWith("¡") ? "ok-box" : "alert"} role="status">
          {msg}
        </p>
      )}

      {mine.length > 0 && (
        <section className="stack" aria-labelledby="h-mine">
          <h2 id="h-mine">{mine.length === 1 ? "Tu entrega" : `Tus entregas (${mine.length})`}</h2>
          {mine.map((j) => (
            <JobCard key={j.id} job={j} me={me} onAct={act} onMessage={refresh} />
          ))}
        </section>
      )}

      <section className="stack" aria-labelledby="h-offers">
        <h2 id="h-offers">Pedidos por tomar</h2>
        {!available && mine.length === 0 && <p className="faint">Activa «Disponible» para ver y tomar pedidos.</p>}
        {available && offers.length === 0 && <p className="faint">No hay pedidos esperando. Te avisaremos aquí; mantén esta pantalla abierta.</p>}
        {available &&
          offers.map((j) => (
            <div key={j.id} className="card stack" data-testid="offer">
              <div className="spread">
                <strong className="display" style={{ fontSize: 22 }}>
                  #{j.code}
                </strong>
                <span className="chip">{j.status === "ready" ? "Listo para recoger" : "En cocina"}</span>
              </div>
              <p className="muted">
                {j.restaurant.name} → {j.addressText}
              </p>
              <p className="faint">
                {j.items.reduce((n, i) => n + i.qty, 0)} productos · {mxn(j.totalCents)}
                {j.lat != null ? ` · ${distanceKm(j.restaurant, { lat: j.lat, lng: j.lng! }).toFixed(1)} km` : ""}
              </p>
              <button type="button" className="btn btn-primary" onClick={() => act(j.id, "take")}>
                Tomar pedido
              </button>
            </div>
          ))}
      </section>

      <button
        type="button"
        className="btn btn-ghost"
        onClick={async () => {
          await api("/api/courier/availability", { body: { available: false } }).catch(() => {});
          await api("/api/auth/logout", { body: {} });
          router.push("/repartidor/login");
        }}
      >
        Cerrar sesión
      </button>
    </main>
  );
}

function JobCard({
  job: j,
  me,
  onAct,
  onMessage,
}: {
  job: CourierJob;
  me: { lat: number; lng: number } | null;
  onAct: (id: string, a: "take" | "release" | "pickup" | "deliver", pin?: string) => Promise<void>;
  onMessage: () => void;
}) {
  const [pin, setPin] = useState("");
  const [text, setText] = useState("");
  const [chat, setChat] = useState(false);
  const pickedUp = j.status === "on_the_way";
  const dest = j.lat != null && j.lng != null ? { lat: j.lat, lng: j.lng } : null;
  const target = pickedUp ? dest : j.restaurant;
  const markers: MapMarker[] = [{ id: "r", lat: j.restaurant.lat, lng: j.restaurant.lng, kind: "restaurant", label: j.restaurant.name }];
  if (dest) markers.push({ id: "h", ...dest, kind: "home", label: j.customerName });
  if (me) markers.push({ id: "me", ...me, kind: "courier", label: "Tú" });
  const cash = j.paymentMethod === "cash" && j.paymentStatus !== "paid";

  return (
    <article className="job" data-testid="my-job">
      <div className="job-map">
        <MapView markers={markers} path={me && target ? [me, target] : undefined} fitKey={`${j.status}:${me ? 1 : 0}`} label={`Ruta del pedido ${j.code}`} />
      </div>
      <div className="job-body stack">
        <div className="spread">
          <strong className="display" style={{ fontSize: 26 }}>
            #{j.code}
          </strong>
          <span className="chip live">{pickedUp ? "Rumbo al cliente" : j.status === "ready" ? "Listo para recoger" : "En cocina"}</span>
        </div>
        <ol className="legs">
          <li style={{ opacity: pickedUp ? 0.5 : 1 }}>
            <span className="n">1</span>
            <div>
              <strong>Recoger en {j.restaurant.name}</strong>
              <p className="faint">{j.restaurant.address}</p>
              {!pickedUp && (
                <div className="row wrap-row" style={{ marginTop: 6 }}>
                  <a className="btn btn-small" href={googleMapsUrl(j.restaurant)} target="_blank" rel="noreferrer">
                    Google Maps
                  </a>
                  <a className="btn btn-small" href={wazeUrl(j.restaurant)} target="_blank" rel="noreferrer">
                    Waze
                  </a>
                  {j.restaurant.phone && (
                    <a className="btn btn-small" href={`tel:${j.restaurant.phone}`}>
                      Llamar
                    </a>
                  )}
                </div>
              )}
            </div>
          </li>
          <li>
            <span className="n">2</span>
            <div>
              <strong>Entregar a {j.customerName}</strong>
              <p className="faint">
                {j.addressText}
                {j.addressNotes ? ` · ${j.addressNotes}` : ""}
              </p>
              <div className="row wrap-row" style={{ marginTop: 6 }}>
                <a className="btn btn-small" href={googleMapsUrl(dest, j.addressText)} target="_blank" rel="noreferrer">
                  Google Maps
                </a>
                <a className="btn btn-small" href={wazeUrl(dest, j.addressText)} target="_blank" rel="noreferrer">
                  Waze
                </a>
                {j.customerPhone && (
                  <a className="btn btn-small" href={`tel:${j.customerPhone}`} aria-label={`Llamar a ${prettyPhone(j.customerPhone)}`}>
                    Llamar
                  </a>
                )}
                <button type="button" className="btn btn-small" onClick={() => setChat((c) => !c)}>
                  Chat{j.messages.length ? ` (${j.messages.length})` : ""}
                </button>
              </div>
            </div>
          </li>
        </ol>

        <ul style={{ margin: 0, paddingLeft: 18 }}>
          {j.items.map((it, i) => (
            <li key={i}>
              {it.qty}× {it.name}
              {it.notes ? <em className="faint"> — {it.notes}</em> : null}
            </li>
          ))}
        </ul>
        <p className={cash ? "notice" : "faint"}>{cash ? `💵 Cobrar ${mxn(j.totalCents)} en efectivo` : `Pagado · ${mxn(j.totalCents)}`}</p>

        {chat && (
          <div className="card stack">
            <div className="chat">
              {j.messages.length === 0 && <p className="faint">Sin mensajes.</p>}
              {j.messages.map((m) => (
                <div key={m.id} className={`bubble ${m.sender === "courier" ? "me" : ""}`}>
                  <span className="who">{m.sender === "courier" ? "Tú" : m.sender === "customer" ? j.customerName : "Restaurante"}</span>
                  {m.body}
                </div>
              ))}
            </div>
            <form
              className="composer"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!text.trim()) return;
                await api(`/api/courier/orders/${j.id}/message`, { body: { text } });
                setText("");
                onMessage();
              }}
            >
              <input aria-label="Mensaje al cliente" value={text} onChange={(e) => setText(e.target.value)} placeholder="Ya voy llegando…" />
              <button className="btn btn-dark btn-small">Enviar</button>
            </form>
          </div>
        )}

        {!pickedUp ? (
          <div className="stack">
            <button type="button" className="btn btn-primary big-action" onClick={() => onAct(j.id, "pickup")}>
              Recogí el pedido
            </button>
            <button type="button" className="btn btn-ghost btn-small" onClick={() => onAct(j.id, "release")}>
              Soltar pedido
            </button>
          </div>
        ) : (
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              onAct(j.id, "deliver", pin);
            }}
          >
            {j.requirePin && (
              <label className="field">
                <span>Código de entrega que te da el cliente</span>
                <input
                  inputMode="numeric"
                  pattern="[0-9]{4}"
                  maxLength={4}
                  required
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                  style={{ fontSize: 28, letterSpacing: "0.4em", textAlign: "center" }}
                  data-testid="pin-input"
                />
              </label>
            )}
            <button className="btn btn-primary big-action">Entregado</button>
          </form>
        )}
      </div>
    </article>
  );
}
