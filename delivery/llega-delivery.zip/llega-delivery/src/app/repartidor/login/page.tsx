import { Topbar } from "@/components/Chrome";
import LoginForm from "@/components/LoginForm";

export const metadata = { title: "Repartidores" };

export default function CourierLogin() {
  return (
    <>
      <Topbar />
      <LoginForm
        title="App del repartidor"
        subtitle="Toma pedidos, comparte tu ubicación y entrega."
        alt={{ href: "/repartidor/unirse", label: "¿Tienes un código de invitación? Crea tu cuenta" }}
      />
    </>
  );
}
