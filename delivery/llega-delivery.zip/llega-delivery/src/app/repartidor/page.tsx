import { Topbar } from "@/components/Chrome";
import { requirePageUser } from "@/server/auth";
import CourierApp from "./CourierApp";

export const dynamic = "force-dynamic";
export const metadata = { title: "Repartidor" };

export default async function CourierPage() {
  const u = await requirePageUser(["courier"], "/repartidor/login");
  return (
    <>
      <Topbar />
      <CourierApp name={u.name} />
    </>
  );
}
