"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client/api";

export default function JoinForm({ initialCode }: { initialCode: string }) {
  const router = useRouter();
  const [f, setF] = useState({ code: initialCode, name: "", phone: "", email: "", password: "", vehicle: "moto" });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <form
      className="card stack"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setError(null);
        try {
          const r = await api<{ redirect: string }>("/api/auth/join", { body: f });
          router.push(r.redirect);
          router.refresh();
        } catch (err) {
          setError(err instanceof Error ? err.message : "No se pudo crear la cuenta.");
          setBusy(false);
        }
      }}
    >
      <label className="field">
        <span>Código de invitación</span>
        <input required value={f.code} onChange={set("code")} style={{ textTransform: "uppercase", letterSpacing: "0.1em" }} />
        <small>Te lo da el restaurante.</small>
      </label>
      <div className="form-grid">
        <label className="field">
          <span>Nombre</span>
          <input required minLength={2} value={f.name} onChange={set("name")} autoComplete="name" />
        </label>
        <label className="field">
          <span>Celular</span>
          <input required inputMode="tel" value={f.phone} onChange={set("phone")} autoComplete="tel" />
        </label>
        <label className="field">
          <span>Correo</span>
          <input required type="email" value={f.email} onChange={set("email")} autoComplete="email" />
        </label>
        <label className="field">
          <span>Contraseña</span>
          <input required type="password" minLength={8} value={f.password} onChange={set("password")} autoComplete="new-password" />
        </label>
        <label className="field full">
          <span>Vehículo</span>
          <select value={f.vehicle} onChange={set("vehicle")}>
            <option value="moto">Moto</option>
            <option value="bici">Bicicleta</option>
            <option value="auto">Auto</option>
            <option value="pie">A pie</option>
          </select>
        </label>
      </div>
      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}
      <button className="btn btn-primary btn-block" disabled={busy}>
        {busy ? "Creando…" : "Crear cuenta de repartidor"}
      </button>
    </form>
  );
}
