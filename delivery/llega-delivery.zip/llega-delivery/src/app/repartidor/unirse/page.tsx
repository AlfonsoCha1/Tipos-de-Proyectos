import { Topbar } from "@/components/Chrome";
import JoinForm from "./JoinForm";

export const metadata = { title: "Unirme como repartidor" };

export default async function Unirse({ searchParams }: { searchParams: Promise<{ code?: string }> }) {
  const { code } = await searchParams;
  return (
    <>
      <Topbar />
      <main className="narrow stack-l" style={{ paddingTop: 32, paddingBottom: 48 }}>
        <div className="stack">
          <h1 className="display">Únete como repartidor</h1>
          <p className="muted">Usarás esta página desde tu celular para tomar pedidos y compartir tu ubicación mientras entregas.</p>
        </div>
        <JoinForm initialCode={(code ?? "").toUpperCase().slice(0, 20)} />
      </main>
    </>
  );
}
