"use client";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import type { MapMarker } from "@/components/MapView";
import { api } from "@/lib/client/api";
import { usePoll } from "@/lib/client/usePoll";
import { mxn } from "@/lib/money";
import { CUSTOMER_STEPS } from "@/lib/order-flow";
import type { TrackView } from "@/lib/types";

const MapView = dynamic(() => import("@/components/MapView"), { ssr: false, loading: () => <div className="map" /> });

const VEHICLE: Record<string, string> = { moto: "🛵", bici: "🚲", auto: "🚗", pie: "🚶" };
const clock = (iso: string | null) => (iso ? new Intl.DateTimeFormat("es-MX", { hour: "numeric", minute: "2-digit" }).format(new Date(iso)) : "—");

const HELP = [
  ["late", "Se está tardando"],
  ["missing_item", "Falta algo"],
  ["wrong_item", "Llegó algo equivocado"],
  ["courier", "Problema con el repartidor"],
  ["payment", "Problema con el pago"],
  ["other", "Otro"],
] as const;

export default function Tracker({ token, initial }: { token: string; initial: TrackView }) {
  const { data, refresh } = usePoll<TrackView>(`/api/track/${token}`, 4000);
  const v = data ?? initial;
  const [chatOpen, setChatOpen] = useState(false);
  const [text, setText] = useState("");
  const [helpMsg, setHelpMsg] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [rated, setRated] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const helpRef = useRef<HTMLDialogElement>(null);
  const chatEnd = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.title = `${v.headline} · #${v.code}`;
  }, [v.headline, v.code]);
  useEffect(() => {
    chatEnd.current?.scrollIntoView({ block: "nearest" });
  }, [v.messages.length, chatOpen]);

  const markers = useMemo<MapMarker[]>(() => {
    const m: MapMarker[] = [{ id: "r", lat: v.restaurant.lat, lng: v.restaurant.lng, kind: "restaurant", emoji: v.restaurant.logoEmoji, label: v.restaurant.name }];
    if (v.destination) m.push({ id: "h", ...v.destination, kind: "home", label: "Tu dirección" });
    if (v.courier?.lat != null && v.courier.lng != null && v.status !== "delivered") {
      m.push({ id: "c", lat: v.courier.lat, lng: v.courier.lng, kind: "courier", emoji: VEHICLE[v.courier.vehicle] ?? "🛵", label: v.courier.name });
    }
    return m;
  }, [v]);
  const path = v.status === "on_the_way" && v.courier?.lat != null && v.destination ? [{ lat: v.courier.lat, lng: v.courier.lng! }, v.destination] : undefined;
  const fitKey = `${v.status}:${markers.length}`;
  const active = v.status !== "delivered" && v.status !== "cancelled";
  const step = v.stepIndex;

  const send = async () => {
    if (!text.trim()) return;
    try {
      await api(`/api/track/${token}/message`, { body: { text } });
      setText("");
      refresh();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "No se envió.");
    }
  };

  return (
    <div className="track" style={{ ["--brand" as string]: v.restaurant.brandColor }}>
      <div className="track-map">
        <MapView markers={markers} path={path} fitKey={fitKey} label={`Mapa del pedido: ${v.headline}`} />
      </div>

      <section className="track-sheet" aria-live="polite">
        <div className="inner stack-l">
          <div className="stack">
            <div className="spread">
              <p className="eta-label">
                {v.status === "delivered" ? "Entregado a las" : v.status === "cancelled" ? "Pedido cancelado" : "Llegada estimada"}
              </p>
              {active && v.etaBasis === "live" && (
                <span className="chip live" data-testid="live">
                  <span className="live-dot" /> En vivo
                </span>
              )}
            </div>
            {v.status !== "cancelled" && (
              <p className="eta" data-testid="eta">
                {clock(v.status === "delivered" ? (v.events.findLast((e) => e.type === "delivered")?.at ?? v.etaAt) : v.etaAt)}
              </p>
            )}
            <p style={{ fontSize: 18 }} data-testid="headline">
              {v.headline}
            </p>
            {v.status === "cancelled" && v.cancelReason && <p className="muted">Motivo: {v.cancelReason}</p>}
          </div>

          {v.status !== "cancelled" && (
            <ol className="steps" aria-label="Progreso del pedido">
              {CUSTOMER_STEPS.map((s, i) => (
                <li key={s.key} className={i < step ? "done" : i === step ? (step === 3 ? "done" : "current") : ""} aria-current={i === step ? "step" : undefined}>
                  <div className="bar" />
                  {s.label}
                </li>
              ))}
            </ol>
          )}

          {v.courier && active && (
            <div className="stack">
              <div className="person">
                <div className="avatar" aria-hidden="true">
                  {VEHICLE[v.courier.vehicle] ?? "🛵"}
                </div>
                <div>
                  <strong style={{ fontSize: 18 }}>{v.courier.name}</strong>
                  <p className="faint">Tu repartidor{v.simulated ? " (simulación de demostración)" : ""}</p>
                </div>
                <div className="row">
                  <button type="button" className="icon-btn" aria-label={`Chatear con ${v.courier.name}`} onClick={() => setChatOpen((o) => !o)}>
                    💬
                  </button>
                  {v.courier.phone && (
                    <a className="icon-btn" href={`tel:${v.courier.phone}`} aria-label={`Llamar a ${v.courier.name}`}>
                      📞
                    </a>
                  )}
                </div>
              </div>
              {chatOpen && (
                <div className="card stack">
                  <div className="chat" aria-label="Mensajes">
                    {v.messages.length === 0 && <p className="faint">Escríbele a tu repartidor o al restaurante.</p>}
                    {v.messages.map((m) => (
                      <div key={m.id} className={`bubble ${m.sender === "customer" ? "me" : ""}`}>
                        <span className="who">{m.sender === "customer" ? "Tú" : m.sender === "courier" ? v.courier?.name : m.sender === "restaurant" ? v.restaurant.name : "Aviso"}</span>
                        {m.body}
                      </div>
                    ))}
                    <div ref={chatEnd} />
                  </div>
                  <form
                    className="composer"
                    onSubmit={(e) => {
                      e.preventDefault();
                      send();
                    }}
                  >
                    <label htmlFor="msg" className="sr-only">
                      Mensaje
                    </label>
                    <input id="msg" value={text} onChange={(e) => setText(e.target.value)} placeholder="Escribe un mensaje" maxLength={500} />
                    <button className="btn btn-dark btn-small">Enviar</button>
                  </form>
                </div>
              )}
            </div>
          )}

          {v.requirePin && active && (
            <div className="pin-box" data-testid="pin">
              <div>
                <strong>Código de entrega</strong>
                <p className="faint">Dáselo al repartidor solo cuando tengas tu pedido en la mano.</p>
              </div>
              <span className="digits">{v.deliveryPin}</span>
            </div>
          )}

          {v.status === "delivered" && !v.rating && !rated && (
            <form
              className="card stack"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!rating) return;
                try {
                  await api(`/api/track/${token}/rate`, { body: { rating, comment } });
                  setRated(true);
                } catch (x) {
                  setErr(x instanceof Error ? x.message : "No se guardó.");
                }
              }}
            >
              <h2>¿Qué tal estuvo?</h2>
              <div className="stars" role="group" aria-label="Calificación">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} type="button" aria-pressed={n <= rating} aria-label={`${n} estrellas`} onClick={() => setRating(n)}>
                    ★
                  </button>
                ))}
              </div>
              <input className="input" placeholder="Comentario (opcional)" value={comment} onChange={(e) => setComment(e.target.value)} maxLength={400} />
              <button className="btn btn-primary" disabled={!rating}>
                Enviar calificación
              </button>
            </form>
          )}
          {(rated || (v.status === "delivered" && v.rating)) && <p className="ok-box">¡Gracias por tu calificación!</p>}

          {err && (
            <p className="alert" role="alert">
              {err}
            </p>
          )}

          <details className="card">
            <summary style={{ cursor: "pointer", fontWeight: 700 }}>
              Pedido #{v.code} · {v.restaurant.name}
            </summary>
            <div className="receipt stack" style={{ marginTop: 12 }}>
              {v.items.map((it, i) => (
                <div className="line" key={i}>
                  <span>
                    {it.qty}× {it.name}
                    {it.notes ? <span className="faint"> · {it.notes}</span> : null}
                  </span>
                  <span className="money">{mxn(it.qty * it.unitPriceCents)}</span>
                </div>
              ))}
              {v.deliveryFeeCents > 0 && (
                <div className="line">
                  <span>Envío</span>
                  <span className="money">{mxn(v.deliveryFeeCents)}</span>
                </div>
              )}
              {v.tipCents > 0 && (
                <div className="line">
                  <span>Propina</span>
                  <span className="money">{mxn(v.tipCents)}</span>
                </div>
              )}
              <div className="line total">
                <span>Total</span>
                <span className="money">{mxn(v.totalCents)}</span>
              </div>
              <p className="faint">
                {v.paymentMethod === "cash" ? "Pagas en efectivo al recibir." : v.paymentMethod === "card_sim" ? "Pago de prueba (no se cobró dinero real)." : "Pagado."} Entrega en: {v.addressText}
              </p>
              <ol className="timeline" aria-label="Historial">
                {v.events.map((e, i) => (
                  <li key={i}>
                    <time>{clock(e.at)}</time>
                    <span>{e.message}</span>
                  </li>
                ))}
              </ol>
            </div>
          </details>

          <div className="stack">
            <button type="button" className="btn btn-block" onClick={() => helpRef.current?.showModal()}>
              ❓ Obtener ayuda con este pedido
            </button>
            {v.status === "pending" && (
              <button
                type="button"
                className="btn btn-block btn-danger"
                onClick={async () => {
                  try {
                    await api(`/api/track/${token}/cancel`, { body: {} });
                    refresh();
                  } catch (x) {
                    setErr(x instanceof Error ? x.message : "No se pudo cancelar.");
                  }
                }}
              >
                Cancelar pedido
              </button>
            )}
            <p className="faint" style={{ textAlign: "center" }}>
              {v.restaurant.phone && (
                <>
                  ¿Dudas? Llama a <a href={`tel:${v.restaurant.phone}`}>{v.restaurant.name}</a> ·{" "}
                </>
              )}
              <Link href={`/r/${v.restaurant.slug}`}>Pedir otra vez</Link>
            </p>
          </div>
        </div>
      </section>

      <dialog ref={helpRef} className="sheet" aria-labelledby="help-title">
        <form
          method="dialog"
          className="stack"
          onSubmit={async (e) => {
            e.preventDefault();
            const reason = (new FormData(e.currentTarget).get("reason") as string) || "other";
            const message = (new FormData(e.currentTarget).get("message") as string) || "";
            try {
              const r = await api<{ messageEs: string }>(`/api/track/${token}/help`, { body: { reason, message } });
              setHelpMsg(r.messageEs);
            } catch (x) {
              setHelpMsg(x instanceof Error ? x.message : "No se pudo enviar.");
            }
          }}
        >
          <h2 id="help-title">¿Qué pasó?</h2>
          {helpMsg ? (
            <>
              <p className="ok-box">{helpMsg}</p>
              <button type="button" className="btn" onClick={() => helpRef.current?.close()}>
                Cerrar
              </button>
            </>
          ) : (
            <>
              {HELP.map(([k, label], i) => (
                <label key={k} className="check">
                  <input type="radio" name="reason" value={k} defaultChecked={i === 0} />
                  <span>{label}</span>
                </label>
              ))}
              <label className="field">
                <span>Cuéntanos más (opcional)</span>
                <textarea name="message" maxLength={500} />
              </label>
              <div className="row">
                <button className="btn btn-primary">Enviar al restaurante</button>
                <button type="button" className="btn btn-ghost" onClick={() => helpRef.current?.close()}>
                  Cancelar
                </button>
              </div>
            </>
          )}
        </form>
      </dialog>
    </div>
  );
}
