import { notFound } from "next/navigation";
import { headers } from "next/headers";
import { trackView } from "@/server/orders";
import Tracker from "./Tracker";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sigue tu pedido", robots: { index: false } };

export default async function TrackPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? (host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https");
  const view = await trackView(token, process.env.APP_URL ?? `${proto}://${host}`);
  if (!view) notFound();
  return <Tracker token={token} initial={view} />;
}
