import { Footer, Topbar } from "@/components/Chrome";
import { BRAND } from "@/lib/brand";

export const metadata = { title: "Términos y condiciones" };

/** TEMPLATE. Review with a lawyer before launch. */
export default function TermsPage() {
  return (
    <>
      <Topbar />
      <main className="narrow stack" style={{ padding: "24px 16px 60px" }}>
        <h1 className="display">Términos y condiciones</h1>
        <p className="notice">Plantilla de trabajo: complétala y revísala con un abogado antes de lanzar.</p>
        <h2>Qué es {BRAND}</h2>
        <p>
          {BRAND} es una plataforma tecnológica que conecta a clientes con restaurantes y sus repartidores. Cada restaurante es responsable de sus productos, precios,
          tiempos de preparación y, cuando usa repartidores propios, de la entrega.
        </p>
        <h2>Pedidos y pagos</h2>
        <p>
          El precio final se confirma antes de enviar el pedido. En esta versión el pago con tarjeta es de prueba y no se cobra dinero real; el pago real es en efectivo al
          recibir, salvo que el restaurante indique otra cosa.
        </p>
        <h2>Cancelaciones</h2>
        <p>Puedes cancelar mientras el restaurante no haya aceptado tu pedido. Después, usa «Obtener ayuda» para hablar con el restaurante.</p>
        <h2>Entrega</h2>
        <p>Los tiempos son estimados. Si el restaurante lo pide, el repartidor solicitará tu código de entrega de 4 dígitos.</p>
        <h2>Contacto</h2>
        <p>[correo y teléfono de soporte]</p>
      </main>
      <Footer />
    </>
  );
}
