import Link from "next/link";
import { BRAND } from "@/lib/brand";

export function Topbar({ children }: { children?: React.ReactNode }) {
  return (
    <header className="topbar">
      <div className="wrap">
        <Link href="/" className="wordmark" aria-label={`${BRAND}, inicio`}>
          {BRAND}
          <span className="dot" aria-hidden="true" />
        </Link>
        <nav aria-label="Principal">{children}</nav>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="wrap stack">
        <div>
          <Link href="/negocios">Para restaurantes</Link>
          <Link href="/repartidor/login">Repartidores</Link>
          <Link href="/privacidad">Privacidad</Link>
          <Link href="/terminos">Términos</Link>
        </div>
        <p>
          {BRAND} · Hecho en Tepotzotlán, México. Los pagos con tarjeta de esta versión son de prueba: no se cobra dinero real.
        </p>
      </div>
    </footer>
  );
}
