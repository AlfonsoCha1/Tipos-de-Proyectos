"use client";
import dynamic from "next/dynamic";
import { useState } from "react";
import { api } from "@/lib/client/api";

const MapView = dynamic(() => import("./MapView"), { ssr: false, loading: () => <div className="map" /> });

interface Props {
  value: { lat: number; lng: number } | null;
  fallbackCenter: { lat: number; lng: number };
  onChange: (p: { lat: number; lng: number }, label?: string) => void;
  /** Extra markers, e.g. the restaurant. */
  restaurant?: { lat: number; lng: number; emoji: string; name: string };
  height?: number;
}

/** Search an address, use GPS, or drag the pin. The pin is what the courier navigates to. */
export default function LocationPicker({ value, fallbackCenter, onChange, restaurant, height = 240 }: Props) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ label: string; lat: number; lng: number }[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const pos = value ?? fallbackCenter;

  const search = async () => {
    if (q.trim().length < 4) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await api<{ results: { label: string; lat: number; lng: number }[]; disabled?: boolean }>(`/api/geocode?q=${encodeURIComponent(q)}`);
      setResults(r.results);
      if (r.disabled) setMsg("La búsqueda está desactivada: mueve el pin en el mapa.");
      else if (!r.results.length) setMsg("No encontramos esa dirección. Mueve el pin en el mapa.");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "No se pudo buscar.");
    } finally {
      setBusy(false);
    }
  };

  const gps = () => {
    if (!navigator.geolocation) return setMsg("Tu navegador no permite ubicación. Mueve el pin.");
    setMsg("Buscando tu ubicación…");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        onChange({ lat: p.coords.latitude, lng: p.coords.longitude });
        setMsg(p.coords.accuracy > 150 ? `Ubicación aproximada (±${Math.round(p.coords.accuracy)} m). Ajusta el pin si hace falta.` : null);
      },
      (err) => setMsg(err.code === 1 ? "No diste permiso de ubicación. Busca tu dirección o mueve el pin." : "No pudimos obtener tu ubicación. Mueve el pin."),
      { enableHighAccuracy: true, timeout: 12000 },
    );
  };

  return (
    <div className="stack">
      <div className="row">
        <label htmlFor="addr-search" className="sr-only">
          Buscar dirección en el mapa
        </label>
        <input
          id="addr-search"
          className="input"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              search();
            }
          }}
          placeholder="Buscar calle y colonia"
        />
        <button type="button" className="btn btn-small" onClick={search} disabled={busy}>
          Buscar
        </button>
        <button type="button" className="btn btn-small" onClick={gps} title="Usar mi ubicación actual">
          📍 Yo
        </button>
      </div>
      {results.length > 0 && (
        <ul className="card" style={{ listStyle: "none", margin: 0, padding: 6 }}>
          {results.map((r) => (
            <li key={`${r.lat},${r.lng}`}>
              <button
                type="button"
                className="btn btn-ghost btn-small"
                style={{ width: "100%", justifyContent: "flex-start", textAlign: "left", borderRadius: 8 }}
                onClick={() => {
                  onChange({ lat: r.lat, lng: r.lng }, r.label);
                  setResults([]);
                }}
              >
                {r.label}
              </button>
            </li>
          ))}
        </ul>
      )}
      {msg && <p className="faint">{msg}</p>}
      <div style={{ height, borderRadius: 14, overflow: "hidden", border: "1px solid var(--line)" }}>
        <MapView
          label="Mapa para elegir la ubicación de entrega"
          markers={restaurant ? [{ id: "r", lat: restaurant.lat, lng: restaurant.lng, kind: "restaurant", emoji: restaurant.emoji, label: restaurant.name }] : []}
          pin={{ lat: pos.lat, lng: pos.lng, onChange: (p) => onChange(p) }}
          fitKey={value ? "set" : "unset"}
        />
      </div>
      <p className="faint">{value ? "Arrastra el pin 🏠 a tu puerta exacta." : "Toca el mapa o arrastra el pin 🏠 hasta tu puerta."}</p>
    </div>
  );
}
