"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client/api";

export default function LoginForm({ title, subtitle, alt }: { title: string; subtitle: string; alt: { href: string; label: string } }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  return (
    <main className="narrow stack-l" style={{ paddingTop: 40, paddingBottom: 40 }}>
      <div className="stack">
        <h1 className="display">{title}</h1>
        <p className="muted">{subtitle}</p>
      </div>
      <form
        className="card stack"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setError(null);
          try {
            const r = await api<{ redirect: string }>("/api/auth/login", { body: { email, password } });
            router.push(r.redirect);
            router.refresh();
          } catch (err) {
            setError(err instanceof Error ? err.message : "No se pudo iniciar sesión.");
            setBusy(false);
          }
        }}
      >
        <label className="field">
          <span>Correo</span>
          <input type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="field">
          <span>Contraseña</span>
          <input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        {error && (
          <p className="alert" role="alert">
            {error}
          </p>
        )}
        <button className="btn btn-primary btn-block" disabled={busy}>
          {busy ? "Entrando…" : "Entrar"}
        </button>
      </form>
      <p className="muted">
        <Link href={alt.href}>{alt.label}</Link>
      </p>
    </main>
  );
}
