"use client";
import "leaflet/dist/leaflet.css";
import type * as Leaflet from "leaflet";
import { useEffect, useRef } from "react";

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  kind: "restaurant" | "courier" | "home" | "pin";
  emoji?: string;
  label?: string;
}

interface Props {
  markers: MapMarker[];
  /** Dashed line through these points (e.g. courier -> customer). */
  path?: { lat: number; lng: number }[];
  /** Checkout: a draggable pin that reports its position. */
  pin?: { lat: number; lng: number; onChange: (p: { lat: number; lng: number }) => void };
  /** Refit the view when this key changes. */
  fitKey?: string;
  className?: string;
  label: string;
  zoom?: number;
}

const TILE_URL = process.env.NEXT_PUBLIC_MAP_TILE_URL ?? "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
const TILE_ATTRIBUTION = process.env.NEXT_PUBLIC_MAP_ATTRIBUTION ?? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>';

const DEFAULT_EMOJI: Record<MapMarker["kind"], string> = { restaurant: "🍽️", courier: "🛵", home: "🏠", pin: "📍" };

function icon(L: typeof Leaflet, m: MapMarker) {
  const e = (m.emoji ?? DEFAULT_EMOJI[m.kind]).replace(/[<>&"]/g, "");
  return L.divIcon({
    className: "",
    html: `<div class="map-pin ${m.kind}" title="${(m.label ?? "").replace(/[<>&"]/g, "")}"><span>${e}</span></div>`,
    iconSize: [40, 40],
    iconAnchor: m.kind === "courier" ? [20, 20] : [20, 40],
  });
}

export default function MapView({ markers, path, pin, fitKey, className, label, zoom = 15 }: Props) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<Leaflet.Map | null>(null);
  const lib = useRef<typeof Leaflet | null>(null);
  const layers = useRef(new Map<string, Leaflet.Marker>());
  const line = useRef<Leaflet.Polyline | null>(null);
  const pinMarker = useRef<Leaflet.Marker | null>(null);
  const pinCb = useRef(pin?.onChange);
  const lastFit = useRef<string | undefined>(undefined);
  const anim = useRef(new Map<string, number>());
  const refit = useRef<(() => void) | null>(null);
  pinCb.current = pin?.onChange;

  // Create the map once.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !el.current || map.current) return;
      lib.current = L;
      const first = pin ?? markers[0] ?? { lat: 19.4326, lng: -99.1332 };
      const m = L.map(el.current, { zoomControl: false, attributionControl: true }).setView([first.lat, first.lng], zoom);
      L.control.zoom({ position: "bottomright" }).addTo(m);
      L.tileLayer(TILE_URL, { maxZoom: 19, attribution: TILE_ATTRIBUTION }).addTo(m);
      map.current = m;
      if (pin) {
        m.on("click", (ev: Leaflet.LeafletMouseEvent) => {
          pinMarker.current?.setLatLng(ev.latlng);
          pinCb.current?.({ lat: ev.latlng.lat, lng: ev.latlng.lng });
        });
      }
      // Leaflet measures its container once; cards and sheets often change size after mount.
      const ro = new ResizeObserver(() => {
        if (!el.current || el.current.clientWidth === 0 || el.current.clientHeight === 0) return;
        m.invalidateSize();
        refit.current?.();
      });
      ro.observe(el.current);
      m.once("unload", () => ro.disconnect());
      // Trigger the sync effect now that the map exists.
      el.current.dispatchEvent(new Event("mapready"));
    })();
    return () => {
      cancelled = true;
      map.current?.remove();
      map.current = null;
      layers.current.clear();
      pinMarker.current = null;
      line.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep markers, path and pin in sync with props.
  useEffect(() => {
    const node = el.current;
    const sync = () => {
      const L = lib.current;
      const m = map.current;
      if (!L || !m) return;
      const seen = new Set<string>();
      for (const mk of markers) {
        seen.add(mk.id);
        const existing = layers.current.get(mk.id);
        if (!existing) {
          layers.current.set(mk.id, L.marker([mk.lat, mk.lng], { icon: icon(L, mk), keyboard: false, alt: mk.label }).addTo(m));
          continue;
        }
        const from = existing.getLatLng();
        if (from.lat === mk.lat && from.lng === mk.lng) continue;
        // Glide moving markers (the courier) instead of jumping.
        const prev = anim.current.get(mk.id);
        if (prev) cancelAnimationFrame(prev);
        const start = performance.now();
        const dur = 900;
        const step = (t: number) => {
          const k = Math.min(1, (t - start) / dur);
          existing.setLatLng([from.lat + (mk.lat - from.lat) * k, from.lng + (mk.lng - from.lng) * k]);
          if (k < 1) anim.current.set(mk.id, requestAnimationFrame(step));
        };
        anim.current.set(mk.id, requestAnimationFrame(step));
      }
      for (const [id, layer] of layers.current) {
        if (!seen.has(id)) {
          layer.remove();
          layers.current.delete(id);
        }
      }
      if (path && path.length >= 2) {
        const pts = path.map((p) => [p.lat, p.lng] as [number, number]);
        if (line.current) line.current.setLatLngs(pts);
        else line.current = L.polyline(pts, { color: "#1d6fd6", weight: 4, dashArray: "2 10", lineCap: "round", opacity: 0.8 }).addTo(m);
      } else if (line.current) {
        line.current.remove();
        line.current = null;
      }
      if (pin) {
        if (!pinMarker.current) {
          pinMarker.current = L.marker([pin.lat, pin.lng], { icon: icon(L, { id: "pin", lat: pin.lat, lng: pin.lng, kind: "home" }), draggable: true, autoPan: true }).addTo(m);
          pinMarker.current.on("dragend", () => {
            const p = pinMarker.current!.getLatLng();
            pinCb.current?.({ lat: p.lat, lng: p.lng });
          });
        } else {
          const cur = pinMarker.current.getLatLng();
          if (Math.abs(cur.lat - pin.lat) > 1e-7 || Math.abs(cur.lng - pin.lng) > 1e-7) {
            pinMarker.current.setLatLng([pin.lat, pin.lng]);
            m.panTo([pin.lat, pin.lng]);
          }
        }
      }
      const fit = () => {
        // A hidden or not-yet-laid-out container has no size; fitting now would break the view.
        if (!el.current || el.current.clientWidth === 0 || el.current.clientHeight === 0) return;
        const pts: [number, number][] = markers.map((mk) => [mk.lat, mk.lng]);
        if (pin) pts.push([pin.lat, pin.lng]);
        if (pts.length >= 2) m.fitBounds(L.latLngBounds(pts), { padding: [56, 56], maxZoom: 16 });
        else if (pts.length === 1) m.setView(pts[0], zoom);
      };
      if (fitKey !== undefined && fitKey !== lastFit.current) {
        lastFit.current = fitKey;
        fit();
        // Refit once more if the container resizes right after (e.g. a sheet opening).
        refit.current = fit;
        setTimeout(() => {
          if (refit.current === fit) refit.current = null;
        }, 1500);
      }
    };
    sync();
    node?.addEventListener("mapready", sync);
    return () => node?.removeEventListener("mapready", sync);
  }, [markers, path, pin, fitKey, zoom]);

  return <div ref={el} className={`map ${className ?? ""}`} role="img" aria-label={label} />;
}
