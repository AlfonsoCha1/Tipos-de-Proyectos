export const BRAND = process.env.NEXT_PUBLIC_BRAND_NAME ?? "Llega";
export const BRAND_TAGLINE = "Pide, rastrea y recibe. Del restaurante de tu barrio a tu puerta.";
