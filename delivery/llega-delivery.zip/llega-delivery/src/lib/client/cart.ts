"use client";
import { useCallback, useEffect, useState } from "react";

/** Cart kept in the browser, per restaurant. Prices shown here are only a preview; the server recalculates. */
export interface CartLine {
  itemId: string;
  name: string;
  priceCents: number;
  emoji: string;
  qty: number;
  notes?: string;
}

const key = (slug: string) => `llega.cart.${slug}`;

// Fallback when localStorage is unavailable (private mode, blocked storage).
const memory = new Map<string, CartLine[]>();

function read(slug: string): CartLine[] {
  try {
    const raw = localStorage.getItem(key(slug));
    const v = raw ? (JSON.parse(raw) as CartLine[]) : [];
    return Array.isArray(v) ? v.filter((l) => l && typeof l.itemId === "string" && l.qty > 0) : [];
  } catch {
    return memory.get(slug) ?? [];
  }
}

function write(slug: string, lines: CartLine[]) {
  memory.set(slug, lines);
  try {
    localStorage.setItem(key(slug), JSON.stringify(lines));
  } catch {
    /* storage unavailable: the in-memory copy is used */
  }
  window.dispatchEvent(new CustomEvent("llega-cart", { detail: slug }));
}

export function useCart(slug: string) {
  const [lines, setLines] = useState<CartLine[]>([]);
  useEffect(() => {
    setLines(read(slug));
    const sync = (e: Event) => {
      if ((e as CustomEvent).detail === slug) setLines(read(slug));
    };
    window.addEventListener("llega-cart", sync);
    return () => window.removeEventListener("llega-cart", sync);
  }, [slug]);

  // Read-modify-write against storage (the source of truth), outside React's state updater.
  const update = useCallback(
    (fn: (prev: CartLine[]) => CartLine[]) => {
      const next = fn(read(slug)).filter((l) => l.qty > 0);
      write(slug, next);
      setLines(next);
    },
    [slug],
  );

  const add = useCallback(
    (item: Omit<CartLine, "qty">, delta = 1) =>
      update((prev) => {
        const i = prev.findIndex((l) => l.itemId === item.itemId && (l.notes ?? "") === (item.notes ?? ""));
        if (i < 0) return delta > 0 ? [...prev, { ...item, qty: Math.min(50, delta) }] : prev;
        const copy = [...prev];
        copy[i] = { ...copy[i], qty: Math.max(0, Math.min(50, copy[i].qty + delta)) };
        return copy;
      }),
    [update],
  );

  const setNotes = useCallback((itemId: string, notes: string) => update((prev) => prev.map((l) => (l.itemId === itemId ? { ...l, notes } : l))), [update]);
  const clear = useCallback(() => update(() => []), [update]);
  const count = lines.reduce((n, l) => n + l.qty, 0);
  const subtotal = lines.reduce((n, l) => n + l.qty * l.priceCents, 0);
  return { lines, add, setNotes, clear, count, subtotal };
}

// Customer details remembered for next time (only in this browser).
export interface SavedCustomer {
  name: string;
  phone: string;
  address: string;
  notes: string;
  lat?: number;
  lng?: number;
}

export function loadCustomer(): SavedCustomer | null {
  try {
    const raw = localStorage.getItem("llega.customer");
    return raw ? (JSON.parse(raw) as SavedCustomer) : null;
  } catch {
    return null;
  }
}

export function saveCustomer(c: SavedCustomer) {
  try {
    localStorage.setItem("llega.customer", JSON.stringify(c));
  } catch {
    /* ignore */
  }
}
