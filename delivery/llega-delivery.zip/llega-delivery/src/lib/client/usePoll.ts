"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiError } from "./api";

/**
 * Poll a JSON endpoint. Pauses while the tab is hidden and backs off on errors.
 * Polling (instead of websockets) works everywhere, including serverless hosting.
 */
export function usePoll<T>(url: string | null, intervalMs: number) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fails = useRef(0);
  const alive = useRef(true);

  const load = useCallback(async () => {
    if (!url) return;
    try {
      const d = await api<T>(url);
      if (!alive.current) return;
      setData(d);
      setError(null);
      fails.current = 0;
    } catch (e) {
      if (!alive.current) return;
      fails.current++;
      setError(e instanceof ApiError ? e : new ApiError(0, "Sin conexión. Reintentando…"));
    }
  }, [url]);

  useEffect(() => {
    alive.current = true;
    let stopped = false;
    const tick = async () => {
      if (stopped) return;
      if (document.visibilityState === "visible") await load();
      const wait = intervalMs * Math.min(8, 2 ** Math.min(fails.current, 3));
      timer.current = setTimeout(tick, wait);
    };
    tick();
    const onVis = () => document.visibilityState === "visible" && load();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      stopped = true;
      alive.current = false;
      if (timer.current) clearTimeout(timer.current);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [load, intervalMs]);

  return { data, error, refresh: load, setData };
}
