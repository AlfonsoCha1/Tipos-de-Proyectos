import { travelMinutes, type LatLng } from "./geo";
import type { OrderStatus } from "./order-flow";

export interface EtaInput {
  status: OrderStatus;
  now: number;
  createdAt: number;
  acceptedAt?: number | null;
  deliveredAt?: number | null;
  prepMinutes: number;
  restaurant: LatLng;
  destination: LatLng | null;
  courier?: { pos: LatLng; updatedAt: number; vehicle: string } | null;
  previousEta?: number | null;
}

export interface Eta {
  etaAt: number | null;
  /** "live": based on the courier's current GPS. "estimate": based on prep time and distance. */
  basis: "live" | "estimate" | "done";
}

const MIN = 60_000;
/** Minutes to hand over the food at the restaurant. */
const PICKUP_BUFFER = 3;
/** Typical wait for the restaurant to accept. */
const ACCEPT_BUFFER = 3;
/** Used when the customer gave no map pin. */
const DEFAULT_TRAVEL = 15;
/** GPS older than this is not trusted for a live ETA. */
const FRESH_GPS_MS = 2 * MIN;

export function estimateEta(i: EtaInput): Eta {
  if (i.status === "delivered") return { etaAt: i.deliveredAt ?? i.now, basis: "done" };
  if (i.status === "cancelled") return { etaAt: null, basis: "done" };

  const vehicle = i.courier?.vehicle ?? "moto";
  const leg = i.destination ? travelMinutes(i.restaurant, i.destination, vehicle) : DEFAULT_TRAVEL;
  const fresh = i.courier && i.now - i.courier.updatedAt < FRESH_GPS_MS ? i.courier : null;

  if (i.status === "on_the_way") {
    if (fresh && i.destination) {
      return { etaAt: i.now + travelMinutes(fresh.pos, i.destination, vehicle) * MIN, basis: "live" };
    }
    // No fresh GPS: keep the previous promise if it's still in the future, otherwise a short estimate.
    if (i.previousEta && i.previousEta > i.now) return { etaAt: i.previousEta, basis: "estimate" };
    return { etaAt: i.now + Math.ceil(leg / 2) * MIN, basis: "estimate" };
  }

  let foodReady: number;
  if (i.status === "pending") foodReady = i.now + (ACCEPT_BUFFER + i.prepMinutes) * MIN;
  else if (i.status === "preparing") foodReady = Math.max(i.now, (i.acceptedAt ?? i.createdAt) + i.prepMinutes * MIN);
  else foodReady = i.now; // ready

  // When will the courier be at the restaurant?
  let courierAtRestaurant = i.now + 8 * MIN; // unassigned: typical time to find one
  if (fresh) courierAtRestaurant = i.now + travelMinutes(fresh.pos, i.restaurant, vehicle) * MIN;
  const pickup = Math.max(foodReady, courierAtRestaurant) + PICKUP_BUFFER * MIN;
  return { etaAt: pickup + leg * MIN, basis: fresh ? "live" : "estimate" };
}

export function minutesUntil(etaAt: number | null, now: number): number | null {
  if (etaAt == null) return null;
  return Math.max(0, Math.round((etaAt - now) / MIN));
}
