export interface LatLng {
  lat: number;
  lng: number;
}

const R = 6371; // km

export function distanceKm(a: LatLng, b: LatLng): number {
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Streets are not straight lines. 1.35 is a common urban detour factor. */
export const ROAD_FACTOR = 1.35;

export const SPEED_KMH: Record<string, number> = { moto: 22, bici: 13, auto: 20, pie: 5 };

export function travelMinutes(a: LatLng, b: LatLng, vehicle = "moto"): number {
  const km = distanceKm(a, b) * ROAD_FACTOR;
  const speed = SPEED_KMH[vehicle] ?? SPEED_KMH.moto;
  return Math.max(1, Math.round((km / speed) * 60));
}

export function isValidLatLng(p: Partial<LatLng> | null | undefined): p is LatLng {
  return (
    !!p &&
    typeof p.lat === "number" &&
    typeof p.lng === "number" &&
    Number.isFinite(p.lat) &&
    Number.isFinite(p.lng) &&
    Math.abs(p.lat) <= 90 &&
    Math.abs(p.lng) <= 180 &&
    !(p.lat === 0 && p.lng === 0)
  );
}

/** Point a fraction t (0..1) of the way from a to b, with a slight curve so the demo route looks like streets. */
export function interpolate(a: LatLng, b: LatLng, t: number): LatLng {
  const k = Math.min(1, Math.max(0, t));
  // Manhattan-ish path: first move mostly in latitude, then longitude.
  const bend = { lat: b.lat, lng: a.lng + (b.lng - a.lng) * 0.25 };
  if (k < 0.5) {
    const u = k / 0.5;
    return { lat: a.lat + (bend.lat - a.lat) * u, lng: a.lng + (bend.lng - a.lng) * u };
  }
  const u = (k - 0.5) / 0.5;
  return { lat: bend.lat + (b.lat - bend.lat) * u, lng: bend.lng + (b.lng - bend.lng) * u };
}

export function googleMapsUrl(p: LatLng | null, addressText?: string): string {
  if (p) return `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}&travelmode=driving`;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressText ?? "")}`;
}

export function wazeUrl(p: LatLng | null, addressText?: string): string {
  if (p) return `https://waze.com/ul?ll=${p.lat},${p.lng}&navigate=yes`;
  return `https://waze.com/ul?q=${encodeURIComponent(addressText ?? "")}&navigate=yes`;
}
