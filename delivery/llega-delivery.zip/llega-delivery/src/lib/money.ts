const fmt = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN", minimumFractionDigits: 2 });

/** 12350 -> "$123.50" */
export function mxn(cents: number): string {
  return fmt.format(cents / 100);
}

/** "123.5" | "123" | "$1,234.50" -> cents, or null when not a valid amount. */
export function parsePesos(input: string | number): number | null {
  if (typeof input === "number") return Number.isFinite(input) && input >= 0 ? Math.round(input * 100) : null;
  const clean = input.replace(/[$,\s]/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(clean)) return null;
  return Math.round(parseFloat(clean) * 100);
}
