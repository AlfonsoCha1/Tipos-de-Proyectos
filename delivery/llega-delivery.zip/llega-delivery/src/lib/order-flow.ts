export const ORDER_STATUSES = ["pending", "preparing", "ready", "on_the_way", "delivered", "cancelled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export type Actor = "restaurant" | "courier" | "customer" | "system";

/** Allowed transitions and who can make them. The single source of truth for the order lifecycle. */
const TRANSITIONS: Record<OrderStatus, Partial<Record<OrderStatus, Actor[]>>> = {
  pending: { preparing: ["restaurant"], cancelled: ["restaurant", "customer", "system"] },
  preparing: { ready: ["restaurant"], on_the_way: ["courier", "restaurant"], cancelled: ["restaurant", "system"] },
  ready: { on_the_way: ["courier", "restaurant"], cancelled: ["restaurant", "system"] },
  on_the_way: { delivered: ["courier", "restaurant", "system"] },
  delivered: {},
  cancelled: {},
};

export function canTransition(from: OrderStatus, to: OrderStatus, actor: Actor): boolean {
  return TRANSITIONS[from]?.[to]?.includes(actor) ?? false;
}

export const ACTIVE_STATUSES: OrderStatus[] = ["pending", "preparing", "ready", "on_the_way"];

export function isActive(status: OrderStatus): boolean {
  return ACTIVE_STATUSES.includes(status);
}

/** The 4 steps the customer sees, like any delivery app. */
export const CUSTOMER_STEPS = [
  { key: "ordered", label: "Pedido" },
  { key: "preparing", label: "Preparando" },
  { key: "on_the_way", label: "En camino" },
  { key: "delivered", label: "Entregado" },
] as const;

export function customerStepIndex(status: OrderStatus): number {
  switch (status) {
    case "pending":
      return 0;
    case "preparing":
    case "ready":
      return 1;
    case "on_the_way":
      return 2;
    case "delivered":
      return 3;
    default:
      return -1;
  }
}

export const STATUS_LABEL_ES: Record<OrderStatus, string> = {
  pending: "Nuevo",
  preparing: "Preparando",
  ready: "Listo para recoger",
  on_the_way: "En camino",
  delivered: "Entregado",
  cancelled: "Cancelado",
};

export function customerHeadline(status: OrderStatus, restaurantName: string, courierName?: string | null): string {
  switch (status) {
    case "pending":
      return `Esperando que ${restaurantName} confirme tu pedido…`;
    case "preparing":
      return `${restaurantName} está preparando tu pedido`;
    case "ready":
      return courierName ? `Tu pedido está listo; ${courierName} va por él` : "Tu pedido está listo; asignando repartidor";
    case "on_the_way":
      return courierName ? `${courierName} va en camino` : "Tu repartidor va en camino";
    case "delivered":
      return "¡Entregado! Buen provecho";
    case "cancelled":
      return "Pedido cancelado";
  }
}
