/**
 * Normalize Mexican phone numbers to E.164 (+52XXXXXXXXXX). Accepts 10-digit local
 * numbers, +52, 52, the legacy +521 mobile prefix, spaces, dashes and parentheses.
 * Numbers that already have another country code (+1, +34...) are kept.
 */
export function normalizePhone(input: string): string | null {
  const raw = input.trim();
  const digits = raw.replace(/\D/g, "");
  if (raw.startsWith("+") && !raw.startsWith("+52")) {
    return digits.length >= 8 && digits.length <= 15 ? `+${digits}` : null;
  }
  let d = digits;
  if (d.startsWith("521") && d.length === 13) d = d.slice(3);
  else if (d.startsWith("52") && d.length === 12) d = d.slice(2);
  if (d.length !== 10) return null;
  return `+52${d}`;
}

/** "+525512345678" -> "55 1234 5678" */
export function prettyPhone(e164: string): string {
  const m = e164.match(/^\+52(\d{2})(\d{4})(\d{4})$/);
  return m ? `${m[1]} ${m[2]} ${m[3]}` : e164;
}

/** Show only the last 4 digits. */
export function maskPhone(e164: string): string {
  return e164.length > 4 ? `•••• ${e164.slice(-4)}` : e164;
}
