/**
 * Plans shown on /negocios. These are launch PROPOSALS to validate with restaurants
 * (see docs/NEGOCIO.md). Edit freely; nothing here charges money.
 */
export const PLANS = [
  {
    id: "tracking",
    name: "Solo rastreo",
    price: "$499 al mes",
    for: "Ya recibes pedidos por teléfono o WhatsApp y tienes tus repartidores.",
    features: ["Link de rastreo en vivo por SMS o WhatsApp", "App para tus repartidores con GPS", "Código de entrega anti-fraude", "API para tu sistema de caja"],
  },
  {
    id: "store",
    name: "Tienda propia",
    price: "$899 al mes",
    for: "Quieres tu propia página de pedidos, sin pagar comisión por pedido.",
    features: ["Todo lo de Solo rastreo", "Tu página con tu color, menú y QR", "Asistente de IA que toma pedidos por chat", "Panel de cocina en tiempo real"],
    featured: true,
  },
  {
    id: "marketplace",
    name: "Marketplace",
    price: "8% por pedido",
    for: "Quieres que te encuentren clientes nuevos de tu zona.",
    features: ["Apareces en la página principal", "Sin mensualidad", "Puedes combinarlo con Tienda propia", "Tú controlas horarios y zona de entrega"],
  },
];
