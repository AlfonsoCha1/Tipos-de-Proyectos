/** Lowercase, strip accents and punctuation. "¡Quiero 2 Tacos al Pastor!" -> "quiero 2 tacos al pastor" */
export function norm(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9ñ\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Spanish plural -> singular, good enough for menu matching ("tacos" -> "taco", "tortas" -> "torta"). */
export function singular(word: string): string {
  if (word.length > 4 && word.endsWith("es") && !/[aeiou]es$/.test(word)) return word.slice(0, -2);
  if (word.length > 3 && word.endsWith("s")) return word.slice(0, -1);
  return word;
}

export function slugify(s: string): string {
  return norm(s).replace(/ñ/g, "n").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 48);
}
