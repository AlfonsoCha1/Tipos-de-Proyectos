import type { OrderStatus } from "./order-flow";

/** Shapes shared by server responses and client components. No secrets here. */

export interface RestaurantPublic {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  cuisine: string;
  logoEmoji: string;
  brandColor: string;
  isOpen: boolean;
  prepMinutes: number;
  deliveryFeeCents: number;
  minOrderCents: number;
  deliveryRadiusKm: number;
  lat: number;
  lng: number;
  address: string;
  phone: string;
  acceptsCash: boolean;
  acceptsCardSim: boolean;
  inMarketplace: boolean;
}

export interface MenuItem {
  id: string;
  categoryId: string | null;
  name: string;
  description: string;
  priceCents: number;
  emoji: string;
  available: boolean;
  sort: number;
}

export interface MenuCategory {
  id: string;
  name: string;
  sort: number;
  items: MenuItem[];
}

export interface OrderItemView {
  name: string;
  qty: number;
  unitPriceCents: number;
  notes: string;
}

export interface OrderEventView {
  type: string;
  message: string;
  at: string;
}

export interface ChatMessageView {
  id: string;
  sender: "customer" | "courier" | "restaurant" | "system";
  body: string;
  at: string;
}

export interface CourierView {
  id: string;
  name: string;
  vehicle: string;
  phone: string;
  lat: number | null;
  lng: number | null;
  updatedAt: string | null;
}

export type PaymentMethod = "cash" | "card_sim" | "prepaid";
export type OrderSource = "web" | "marketplace" | "agent" | "whatsapp" | "manual" | "api";

export interface TrackView {
  code: string;
  status: OrderStatus;
  headline: string;
  stepIndex: number;
  createdAt: string;
  etaAt: string | null;
  etaBasis: "live" | "estimate" | "done";
  restaurant: { name: string; slug: string; phone: string; lat: number; lng: number; logoEmoji: string; brandColor: string };
  destination: { lat: number; lng: number } | null;
  addressText: string;
  courier: CourierView | null;
  items: OrderItemView[];
  subtotalCents: number;
  deliveryFeeCents: number;
  tipCents: number;
  totalCents: number;
  paymentMethod: PaymentMethod;
  paymentStatus: "pending" | "paid" | "simulated";
  deliveryPin: string;
  requirePin: boolean;
  events: OrderEventView[];
  messages: ChatMessageView[];
  rating: number | null;
  simulated: boolean;
  cancelReason: string;
  now: string;
}

export interface PanelOrder {
  id: string;
  code: string;
  status: OrderStatus;
  source: OrderSource;
  customerName: string;
  customerPhone: string;
  addressText: string;
  addressNotes: string;
  lat: number | null;
  lng: number | null;
  items: OrderItemView[];
  totalCents: number;
  paymentMethod: PaymentMethod;
  paymentStatus: string;
  notes: string;
  courier: CourierView | null;
  trackingToken: string;
  prepMinutes: number;
  etaAt: string | null;
  createdAt: string;
  acceptedAt: string | null;
  deliveredAt: string | null;
  unreadHelp: number;
}

export interface CourierJob {
  id: string;
  code: string;
  status: OrderStatus;
  restaurant: { name: string; address: string; phone: string; lat: number; lng: number };
  customerName: string;
  customerPhone: string;
  addressText: string;
  addressNotes: string;
  lat: number | null;
  lng: number | null;
  totalCents: number;
  paymentMethod: PaymentMethod;
  paymentStatus: string;
  requirePin: boolean;
  items: OrderItemView[];
  messages: ChatMessageView[];
  mine: boolean;
}

export interface CartLine {
  itemId: string;
  qty: number;
  notes?: string;
}
