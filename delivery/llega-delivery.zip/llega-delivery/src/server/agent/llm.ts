import "server-only";

/**
 * Chat model transport for the ordering agent. Any OpenAI-compatible API (Groq, OpenAI,
 * OpenRouter, a local server) or Anthropic. JSON mode keeps the output machine-checkable.
 */
export interface LlmMessage {
  role: "user" | "assistant";
  content: string;
}

export interface LlmClient {
  vendor: string;
  model: string;
  complete(system: string, messages: LlmMessage[], opts?: { maxTokens?: number; temperature?: number }): Promise<string>;
}

function env(n: string) {
  const v = process.env[n];
  return v && v.trim() ? v.trim() : undefined;
}

/** Many providers reject two user messages in a row; merge them and make sure we start with a user turn. */
export function normalizeTurns(messages: LlmMessage[]): LlmMessage[] {
  const out: LlmMessage[] = [];
  for (const m of messages) {
    const last = out.at(-1);
    if (last && last.role === m.role) last.content += `\n${m.content}`;
    else out.push({ ...m });
  }
  if (out[0]?.role !== "user") out.unshift({ role: "user", content: "(inicio de la conversación)" });
  return out;
}

class OpenAICompatible implements LlmClient {
  constructor(
    public vendor: string,
    private baseUrl: string,
    private key: string,
    public model: string,
  ) {}
  async complete(system: string, messages: LlmMessage[], opts: { maxTokens?: number; temperature?: number } = {}) {
    const body: Record<string, unknown> = {
      model: this.model,
      messages: [{ role: "system", content: system }, ...normalizeTurns(messages)],
      temperature: opts.temperature ?? 0.3,
      max_completion_tokens: opts.maxTokens ?? 700,
      response_format: { type: "json_object" },
    };
    if (this.vendor === "groq" && this.model.includes("gpt-oss")) body.reasoning_effort = "low";
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.key}` },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(20000),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`${this.vendor} HTTP ${res.status}: ${text.slice(0, 200)}`);
    const content = (JSON.parse(text) as { choices?: { message?: { content?: string } }[] }).choices?.[0]?.message?.content;
    if (!content) throw new Error(`${this.vendor}: empty completion`);
    return content;
  }
}

class Anthropic implements LlmClient {
  vendor = "anthropic";
  constructor(
    private key: string,
    public model: string,
    private baseUrl = "https://api.anthropic.com/v1",
  ) {}
  async complete(system: string, messages: LlmMessage[], opts: { maxTokens?: number; temperature?: number } = {}) {
    const res = await fetch(`${this.baseUrl}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": this.key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: this.model,
        max_tokens: opts.maxTokens ?? 700,
        temperature: opts.temperature ?? 0.3,
        system: `${system}\nResponde solo con un objeto JSON.`,
        messages: normalizeTurns(messages),
      }),
      signal: AbortSignal.timeout(20000),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`anthropic HTTP ${res.status}: ${text.slice(0, 200)}`);
    const content = (JSON.parse(text) as { content?: { type: string; text?: string }[] }).content?.find((c) => c.type === "text")?.text;
    if (!content) throw new Error("anthropic: empty completion");
    return content;
  }
}

export function agentLlm(): LlmClient | null {
  const wanted = (env("AGENT_PROVIDER") ?? "auto").toLowerCase();
  if (wanted === "off" || wanted === "rules") return null;
  const groq = env("GROQ_API_KEY");
  const openai = env("OPENAI_API_KEY");
  const anthropic = env("ANTHROPIC_API_KEY");
  const pickGroq = () => new OpenAICompatible("groq", env("GROQ_BASE_URL") ?? "https://api.groq.com/openai/v1", groq!, env("GROQ_MODEL") ?? "openai/gpt-oss-20b");
  const pickOpenAI = () => new OpenAICompatible("openai", env("OPENAI_BASE_URL") ?? "https://api.openai.com/v1", openai!, env("OPENAI_MODEL") ?? "gpt-4.1-mini");
  const pickAnthropic = () => new Anthropic(anthropic!, env("ANTHROPIC_MODEL") ?? "claude-haiku-4-5-20251001", env("ANTHROPIC_BASE_URL"));
  if (wanted === "groq") return groq ? pickGroq() : null;
  if (wanted === "openai") return openai ? pickOpenAI() : null;
  if (wanted === "anthropic") return anthropic ? pickAnthropic() : null;
  if (groq) return pickGroq();
  if (openai) return pickOpenAI();
  if (anthropic) return pickAnthropic();
  return null;
}

export function extractJson(raw: string): unknown {
  const t = raw.trim();
  try {
    return JSON.parse(t);
  } catch {
    const a = t.indexOf("{");
    const b = t.lastIndexOf("}");
    if (a >= 0 && b > a) return JSON.parse(t.slice(a, b + 1));
    throw new Error("no JSON in model output");
  }
}
