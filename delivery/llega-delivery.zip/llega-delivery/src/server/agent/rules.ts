import { normalizePhone } from "@/lib/phone";
import { norm, singular } from "@/lib/text";
import type { MenuItem } from "@/lib/types";

/** What the agent (AI or rules) wants to do. The engine validates every action before applying it. */
export type AgentAction =
  | { type: "add"; itemId: string; qty: number; notes?: string }
  | { type: "remove"; itemId: string; qty?: number }
  | { type: "clear_cart" }
  | { type: "set_name"; value: string }
  | { type: "set_phone"; value: string }
  | { type: "set_address"; value: string; notes?: string }
  | { type: "set_payment"; value: "cash" | "card_sim" }
  | { type: "checkout" }
  | { type: "show_menu" }
  | { type: "show_cart" }
  | { type: "new_order" };

export interface RulesResult {
  actions: AgentAction[];
  /** Items the customer mentioned ambiguously, e.g. "2 tacos" when there are 4 kinds. */
  ambiguous: { mention: string; options: MenuItem[] }[];
  greeting: boolean;
  understood: boolean;
}

const NUMBER_WORDS: Record<string, number> = {
  un: 1, una: 1, uno: 1, dos: 2, tres: 3, cuatro: 4, cinco: 5, seis: 6, siete: 7, ocho: 8, nueve: 9, diez: 10,
  once: 11, doce: 12, docena: 12, quince: 15, veinte: 20,
};
const STOP = new Set(["de", "del", "la", "el", "al", "con", "y", "en", "a", "los", "las", "orden", "ordenes", "para", "mi", "por", "favor", "quiero", "me", "das", "da", "dame", "regalas", "manda", "mandame", "porfa", "tambien", "mas", "otra", "otro", "pon", "agrega", "agregame", "ponme", "queria", "quisiera", "seria", "sin"]);

const AFFIRMATIVE = /^(s[ií]+|claro|dale|va|ok(ay)?|correcto|confirm(o|ar|a|ado)|de acuerdo|perfecto|as[ií] es|adelante|sale|[eé]chale|por favor|s[ií],? (confirmo|por favor|gracias))\b/;

export function isAffirmative(text: string): boolean {
  return AFFIRMATIVE.test(norm(text)) || /^(s[ií]|yes)[.!]*$/i.test(text.trim());
}

interface Indexed {
  item: MenuItem;
  tokens: string[];
  key: string; // most specific token
}

function tokensOf(s: string): string[] {
  return norm(s)
    .split(" ")
    .map(singular)
    .filter((t) => t && !STOP.has(t) && !/^\d+$/.test(t));
}

function index(menu: MenuItem[]): Indexed[] {
  const df = new Map<string, number>();
  const list = menu.map((item) => ({ item, tokens: [...new Set(tokensOf(item.name))] }));
  for (const { tokens } of list) for (const t of tokens) df.set(t, (df.get(t) ?? 0) + 1);
  return list.map(({ item, tokens }) => {
    const key = [...tokens].sort((a, b) => (df.get(a) ?? 0) - (df.get(b) ?? 0) || b.length - a.length)[0] ?? "";
    return { item, tokens, key };
  });
}

function qtyOf(seg: string[]): number {
  for (const w of seg) {
    if (/^\d{1,2}$/.test(w)) return Math.max(1, Math.min(20, parseInt(w, 10)));
    if (NUMBER_WORDS[w]) return NUMBER_WORDS[w];
    if (w === "media") return 6; // "media docena"
  }
  return 1;
}

/** Split "2 tacos al pastor, una gringa y 2 horchatas" into item mentions. */
function segments(text: string): string[] {
  return norm(text)
    .split(/\s*(?:,|;|\by\b|\bmas\b|\btambien\b|\bademas\b|\bplus\b)\s*/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function matchItems(text: string, menu: MenuItem[]): { found: { item: MenuItem; qty: number; notes?: string; remove: boolean }[]; ambiguous: RulesResult["ambiguous"] } {
  const idx = index(menu);
  const found: { item: MenuItem; qty: number; notes?: string; remove: boolean }[] = [];
  const ambiguous: RulesResult["ambiguous"] = [];
  let removing = false;
  for (const seg of segments(text)) {
    const words = seg.split(" ");
    if (/^(quita|quitale|quitar|elimina|borra|ya no quiero|cancela|saca)\b/.test(seg)) removing = true;
    const toks = new Set(words.map(singular));
    // Notes like "sin cebolla" / "con todo" stay attached to the item in this segment.
    const noteMatch = seg.match(/\b(sin [a-zñ ]{3,30}|con todo|bien dorad[oa]s?|extra [a-zñ ]{3,20})$/);
    const strong = idx.filter((x) => x.key && toks.has(x.key));
    let pick: Indexed | null = null;
    if (strong.length === 1) pick = strong[0];
    else if (strong.length > 1) {
      const scored = strong.map((x) => ({ x, s: x.tokens.filter((t) => toks.has(t)).length }));
      scored.sort((a, b) => b.s - a.s);
      if (scored[0].s > scored[1].s) pick = scored[0].x;
      else ambiguous.push({ mention: seg, options: scored.filter((s) => s.s === scored[0].s).map((s) => s.x.item) });
    } else {
      const weak = idx.filter((x) => x.tokens.some((t) => toks.has(t)));
      if (weak.length === 1) pick = weak[0];
      else if (weak.length > 1 && weak.length <= 6) ambiguous.push({ mention: seg, options: weak.map((w) => w.item) });
    }
    if (pick) {
      found.push({
        item: pick.item,
        qty: qtyOf(words),
        notes: noteMatch && !removing ? noteMatch[1] : undefined,
        remove: removing,
      });
    }
  }
  return { found, ambiguous };
}

export function parseRules(text: string, menu: MenuItem[]): RulesResult {
  const t = norm(text);
  const actions: AgentAction[] = [];
  const greeting = /^(hola|buenas|buen dia|buenos dias|buenas tardes|buenas noches|que tal|hey|holi)\b/.test(t);

  if (/\b(nuevo pedido|otro pedido|empezar de nuevo|pedir otra vez)\b/.test(t)) actions.push({ type: "new_order" });
  if (/\b(menu|carta|que (tienen|hay|venden|me recomiendas)|opciones|precios)\b/.test(t)) actions.push({ type: "show_menu" });
  if (/\b(carrito|mi pedido|cuanto (es|va|llevo|seria)|el total|que llevo)\b/.test(t)) actions.push({ type: "show_cart" });
  if (/\b(vacia|borra todo|cancela todo|empieza de cero)\b/.test(t)) actions.push({ type: "clear_cart" });

  const name = text.match(/\b(?:me llamo|mi nombre es|a nombre de|soy)\s+([A-Za-zÁÉÍÓÚÑáéíóúñ]+(?:\s+[A-Za-zÁÉÍÓÚÑáéíóúñ]+){0,2})/i);
  if (name && !/^(de|alergic|vegetarian|el|la)/i.test(name[1])) {
    const clean = name[1].replace(/\s+(y|mi|con|por)\b.*$/i, "").trim();
    if (clean.length >= 2) actions.push({ type: "set_name", value: clean });
  }
  const phone = text.match(/(\+?\d[\d\s().-]{8,17}\d)/);
  if (phone && normalizePhone(phone[1])) actions.push({ type: "set_phone", value: phone[1] });

  const addr = text.match(/(?:mi direcci[oó]n es|direcci[oó]n:?|vivo en|entr[eé]galo en|ll[eé]valo a|env[ií]alo a|a la direcci[oó]n)\s+(.{5,200})/i);
  if (addr) actions.push({ type: "set_address", value: addr[1].trim().replace(/[.]+$/, "") });

  if (/\befectivo\b/.test(t)) actions.push({ type: "set_payment", value: "cash" });
  else if (/\btarjeta\b/.test(t)) actions.push({ type: "set_payment", value: "card_sim" });

  // Only look for dishes in the part of the message that isn't name/phone/address.
  let itemText = text;
  if (addr) itemText = itemText.replace(addr[0], " ");
  if (name) itemText = itemText.replace(name[0], " ");
  if (phone) itemText = itemText.replace(phone[1], " ");
  const { found, ambiguous } = matchItems(itemText, menu);
  for (const f of found) {
    if (f.remove) actions.push({ type: "remove", itemId: f.item.id, qty: /\b(\d+|un|una|dos|tres)\b/.test(norm(itemText)) ? f.qty : undefined });
    else actions.push({ type: "add", itemId: f.item.id, qty: f.qty, notes: f.notes });
  }

  // "es todo" can come in the same message as the dishes ("2 tacos y una horchata, es todo").
  const done = /\b(es todo|eso es todo|seria todo|ya es todo|nada mas|y ya|confirmar|confirmo|hacer (el )?pedido|pedirlo|finalizar|terminar (el )?pedido|mandalo|envialo)\b/.test(t);
  // Bare words that only mean "checkout" when no dish was mentioned ("listo", "ya", "ordenar").
  const doneAlone = /^(listo|ya|ordenar|ordena|pide|pidelo|va|sale)$/.test(t);
  if (done || (doneAlone && !found.length)) actions.push({ type: "checkout" });
  return { actions, ambiguous, greeting, understood: actions.length > 0 || ambiguous.length > 0 || greeting };
}
