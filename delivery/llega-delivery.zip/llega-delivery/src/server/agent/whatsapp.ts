import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { one } from "../db";
import { getRestaurantBySlug, type RestaurantRow } from "../repo/restaurants";

/** Which restaurant answers a WhatsApp number. */
export async function restaurantForWhatsApp(phoneNumberId?: string | null): Promise<RestaurantRow | null> {
  if (phoneNumberId) {
    const r = await one<RestaurantRow>("select * from restaurants where whatsapp_phone_number_id = $1 and active", [phoneNumberId]);
    if (r) return r;
  }
  const slug = process.env.WHATSAPP_DEFAULT_RESTAURANT?.trim();
  return slug ? getRestaurantBySlug(slug) : null;
}

/** Meta signs webhook bodies with the app secret (X-Hub-Signature-256). */
export function verifyMetaSignature(raw: string, header: string | null, appSecret: string): boolean {
  if (!header?.startsWith("sha256=")) return false;
  const expected = Buffer.from(`sha256=${createHmac("sha256", appSecret).update(raw).digest("hex")}`);
  const given = Buffer.from(header);
  return expected.length === given.length && timingSafeEqual(expected, given);
}

/** Twilio signs requests: base64(HMAC-SHA1(authToken, fullUrl + sorted key/value pairs)). */
export function verifyTwilioSignature(url: string, params: Record<string, string>, header: string | null, authToken: string): boolean {
  if (!header) return false;
  const data = url + Object.keys(params).sort().map((k) => k + params[k]).join("");
  const expected = Buffer.from(createHmac("sha1", authToken).update(data).digest("base64"));
  const given = Buffer.from(header);
  return expected.length === given.length && timingSafeEqual(expected, given);
}
