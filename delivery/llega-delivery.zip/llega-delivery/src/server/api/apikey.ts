import "server-only";
import { createHash } from "node:crypto";
import { one } from "../db";
import { HttpError } from "../http";

/** Public API auth: "Authorization: Bearer llk_…". Returns the restaurant id. */
export async function restaurantFromApiKey(req: Request): Promise<string> {
  const h = req.headers.get("authorization") ?? "";
  const key = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  if (!key.startsWith("llk_")) throw new HttpError(401, "Falta la clave de API (Authorization: Bearer llk_…).", "no_api_key");
  const hash = createHash("sha256").update(key).digest("hex");
  const row = await one<{ restaurant_id: string }>("select restaurant_id from api_keys where key_hash = $1 and revoked_at is null", [hash]);
  if (!row) throw new HttpError(401, "Clave de API inválida o revocada.", "bad_api_key");
  return row.restaurant_id;
}
