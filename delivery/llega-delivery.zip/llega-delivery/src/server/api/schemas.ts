import "server-only";
import { z } from "zod";

const lat = z.number().min(-90).max(90);
const lng = z.number().min(-180).max(180);

export const CheckoutSchema = z.object({
  slug: z.string().min(1).max(60),
  source: z.enum(["web", "marketplace"]).default("web"),
  items: z
    .array(z.object({ itemId: z.string().uuid(), qty: z.number().int().min(1).max(50), notes: z.string().max(140).optional() }))
    .min(1)
    .max(60),
  customer: z.object({ name: z.string().min(2).max(80), phone: z.string().min(8).max(25) }),
  address: z.object({
    text: z.string().min(5).max(300),
    notes: z.string().max(200).optional(),
    lat: lat.nullable().optional(),
    lng: lng.nullable().optional(),
  }),
  paymentMethod: z.enum(["cash", "card_sim"]),
  tipCents: z.number().int().min(0).max(100000).default(0),
  notes: z.string().max(300).optional(),
});

export const ManualOrderSchema = z.object({
  customer: z.object({ name: z.string().max(80).default("Cliente"), phone: z.string().min(8).max(25) }),
  address: z.object({ text: z.string().min(3).max(300), notes: z.string().max(200).optional(), lat: lat.nullable().optional(), lng: lng.nullable().optional() }),
  items: z.array(z.object({ name: z.string().min(1).max(120), qty: z.number().int().min(1).max(99), unitPriceCents: z.number().int().min(0).max(10_000_000) })).max(50).default([]),
  totalCents: z.number().int().min(0).max(10_000_000).optional(),
  paymentMethod: z.enum(["cash", "prepaid"]).default("cash"),
  notes: z.string().max(300).optional(),
  prepMinutes: z.number().int().min(1).max(180).optional(),
  notify: z.boolean().default(true),
});

export const LocationSchema = z.object({
  lat,
  lng,
  accuracy: z.number().min(0).max(100000).nullable().optional(),
  heading: z.number().min(0).max(360).nullable().optional(),
});
