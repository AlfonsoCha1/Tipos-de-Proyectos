import "server-only";
import { createHmac, randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { one } from "./db";
import { HttpError } from "./http";

const scrypt = promisify(scryptCb) as (pw: string, salt: Buffer, keylen: number) => Promise<Buffer>;

export type Role = "owner" | "staff" | "courier" | "admin";

export interface SessionUser {
  id: string;
  role: Role;
  restaurantId: string | null;
  name: string;
  email: string;
}

const COOKIE = "llega_session";
const MAX_AGE_S = 60 * 60 * 24 * 30; // 30 days

// ---------- passwords ----------

export async function hashPassword(pw: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await scrypt(pw, salt, 64);
  return `scrypt$${salt.toString("base64url")}$${hash.toString("base64url")}`;
}

export async function verifyPassword(pw: string, stored: string): Promise<boolean> {
  const [alg, saltB64, hashB64] = stored.split("$");
  if (alg !== "scrypt" || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, "base64url");
  const actual = await scrypt(pw, Buffer.from(saltB64, "base64url"), expected.length);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

// ---------- signed session cookie ----------

const g = globalThis as unknown as { __llegaAuthSecret?: string };

function secret(): string {
  const s = process.env.AUTH_SECRET?.trim();
  if (s && s.length >= 16) return s;
  if (process.env.NODE_ENV === "production" && process.env.ALLOW_EPHEMERAL_SECRET !== "1") {
    throw new Error("AUTH_SECRET is required in production (at least 16 characters).");
  }
  g.__llegaAuthSecret ??= randomBytes(32).toString("hex");
  return g.__llegaAuthSecret;
}

function sign(body: string): string {
  return createHmac("sha256", secret()).update(body).digest("base64url");
}

interface CookiePayload {
  uid: string;
  exp: number;
  /** Changes when the password changes, so old cookies stop working (last 8 chars of the hash). */
  v: string;
}

export function encodeSession(uid: string, passwordHash: string): string {
  const payload: CookiePayload = { uid, exp: Date.now() + MAX_AGE_S * 1000, v: passwordHash.slice(-8) };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}

function decodeSession(token: string | undefined): CookiePayload | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const a = Buffer.from(sign(body));
  const b = Buffer.from(sig);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString()) as CookiePayload;
    return p.exp > Date.now() ? p : null;
  } catch {
    return null;
  }
}

export async function setSessionCookie(uid: string, passwordHash: string): Promise<void> {
  (await cookies()).set(COOKIE, encodeSession(uid, passwordHash), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE_S,
  });
}

export async function clearSessionCookie(): Promise<void> {
  (await cookies()).delete(COOKIE);
}

export async function currentUser(): Promise<SessionUser | null> {
  const p = decodeSession((await cookies()).get(COOKIE)?.value);
  if (!p) return null;
  const u = await one<{ id: string; role: Role; restaurant_id: string | null; name: string; email: string; password_hash: string }>(
    "select id, role, restaurant_id, name, email, password_hash from users where id = $1",
    [p.uid],
  );
  if (!u || u.password_hash.slice(-8) !== p.v) return null;
  return { id: u.id, role: u.role, restaurantId: u.restaurant_id, name: u.name, email: u.email };
}

function isAdminEmail(email: string): boolean {
  const list = (process.env.ADMIN_EMAILS ?? "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  return list.includes(email.toLowerCase());
}

export function isAdmin(u: SessionUser | null): boolean {
  return !!u && (u.role === "admin" || isAdminEmail(u.email));
}

/** For API routes: returns the user or throws 401/403. */
export async function requireApiUser(roles: Role[]): Promise<SessionUser & { restaurantId: string }> {
  const u = await currentUser();
  if (!u) throw new HttpError(401, "Inicia sesión para continuar.");
  if (!roles.includes(u.role)) throw new HttpError(403, "No tienes permiso para esto.");
  if (!u.restaurantId && u.role !== "admin") throw new HttpError(403, "Tu cuenta no está ligada a un restaurante.");
  return u as SessionUser & { restaurantId: string };
}

/** For pages: returns the user or redirects to the right login. */
export async function requirePageUser(roles: Role[], loginPath: string): Promise<SessionUser & { restaurantId: string }> {
  const u = await currentUser();
  if (!u || !roles.includes(u.role) || (!u.restaurantId && u.role !== "admin")) redirect(loginPath);
  return u as SessionUser & { restaurantId: string };
}

export { randomCode, randomPin, randomToken } from "./random";
