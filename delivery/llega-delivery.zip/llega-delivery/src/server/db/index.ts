import "server-only";
import { MIGRATIONS } from "./migrations";

/**
 * Thin database layer over plain SQL.
 * - Production: set DATABASE_URL (Neon, Supabase, RDS, any Postgres) -> node-postgres pool.
 * - Local / demo: no DATABASE_URL -> PGlite, a real Postgres compiled to WASM, stored in ./.data/pglite.
 * Both use the same SQL ($1 placeholders), so code and tests run identically.
 */
export interface Queryable {
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<T[]>;
}

export interface Db extends Queryable {
  tx<T>(fn: (q: Queryable) => Promise<T>): Promise<T>;
  kind: "postgres" | "pglite";
}

async function createPg(url: string): Promise<Db> {
  const { Pool } = await import("pg");
  const pool = new Pool({ connectionString: url, max: Number(process.env.DATABASE_POOL_MAX ?? 5), idleTimeoutMillis: 20_000 });
  return {
    kind: "postgres",
    async query<T>(sql: string, params: unknown[] = []) {
      const r = await pool.query(sql, params as unknown[]);
      return r.rows as T[];
    },
    async tx<T>(fn: (q: Queryable) => Promise<T>) {
      const client = await pool.connect();
      try {
        await client.query("begin");
        const out = await fn({
          async query<R>(sql: string, params: unknown[] = []) {
            return (await client.query(sql, params as unknown[])).rows as R[];
          },
        });
        await client.query("commit");
        return out;
      } catch (err) {
        await client.query("rollback").catch(() => {});
        throw err;
      } finally {
        client.release();
      }
    },
  };
}

async function createPglite(dir: string): Promise<Db> {
  const { PGlite } = await import("@electric-sql/pglite");
  if (dir !== "memory") {
    // PGlite does not create parent folders (e.g. a fresh clone has no .data/).
    const { mkdirSync } = await import("node:fs");
    const { dirname, resolve } = await import("node:path");
    mkdirSync(dirname(resolve(dir)), { recursive: true });
  }
  const db = dir === "memory" ? await PGlite.create() : await PGlite.create(dir);
  // PGlite has one connection; serialize work so a transaction never interleaves with other queries.
  let chain: Promise<unknown> = Promise.resolve();
  const serial = <T>(fn: () => Promise<T>): Promise<T> => {
    const next = chain.then(fn, fn);
    chain = next.catch(() => {});
    return next;
  };
  return {
    kind: "pglite",
    query<T>(sql: string, params: unknown[] = []) {
      return serial(async () => (await db.query(sql, params as unknown[])).rows as T[]);
    },
    tx<T>(fn: (q: Queryable) => Promise<T>) {
      return serial(() =>
        db.transaction(async (t) =>
          fn({
            async query<R>(sql: string, params: unknown[] = []) {
              return (await t.query(sql, params as unknown[])).rows as R[];
            },
          }),
        ),
      );
    },
  };
}

async function migrate(db: Db): Promise<void> {
  await db.query(`create table if not exists schema_migrations (id text primary key, applied_at timestamptz not null default now())`);
  await db.tx(async (q) => {
    // Serverless cold starts can race; the advisory lock makes migrations run once.
    await q.query("select pg_advisory_xact_lock(424242)");
    const done = new Set((await q.query<{ id: string }>("select id from schema_migrations")).map((r) => r.id));
    for (const m of MIGRATIONS) {
      if (done.has(m.id)) continue;
      for (const stmt of splitSql(m.sql)) await q.query(stmt);
      await q.query("insert into schema_migrations (id) values ($1)", [m.id]);
    }
  });
}

/** Split a migration into statements (no semicolons inside our DDL strings). */
export function splitSql(sql: string): string[] {
  return sql
    .split(/;\s*\n/)
    .map((s) => s.trim())
    .filter(Boolean);
}

const g = globalThis as unknown as { __llegaDb?: Promise<Db> };

export function getDb(): Promise<Db> {
  if (!g.__llegaDb) {
    g.__llegaDb = (async () => {
      const url = process.env.DATABASE_URL?.trim();
      const db = url ? await createPg(url) : await createPglite(process.env.PGLITE_DIR?.trim() || ".data/pglite");
      await migrate(db);
      const shouldSeed = process.env.SEED_DEMO === "1" || (process.env.SEED_DEMO !== "0" && process.env.NODE_ENV !== "production");
      if (shouldSeed) {
        const { seedDemoIfEmpty } = await import("./seed");
        await seedDemoIfEmpty(db);
      }
      return db;
    })().catch((err) => {
      g.__llegaDb = undefined;
      throw err;
    });
  }
  return g.__llegaDb;
}

/** Shorthand: run one query. */
export async function sql<T = Record<string, unknown>>(text: string, params: unknown[] = []): Promise<T[]> {
  return (await getDb()).query<T>(text, params);
}

export async function one<T = Record<string, unknown>>(text: string, params: unknown[] = []): Promise<T | null> {
  const rows = await sql<T>(text, params);
  return rows[0] ?? null;
}
