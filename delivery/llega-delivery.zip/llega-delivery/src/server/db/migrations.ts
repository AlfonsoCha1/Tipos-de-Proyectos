/**
 * SQL migrations, embedded as strings so they ship inside the serverless bundle.
 * Append new migrations; never edit one that already ran in production.
 */
export const MIGRATIONS: { id: string; sql: string }[] = [
  {
    id: "001_init",
    sql: `
create table restaurants (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  tagline text not null default '',
  cuisine text not null default '',
  phone text not null default '',
  address text not null default '',
  lat double precision not null,
  lng double precision not null,
  brand_color text not null default '#0e5e4a',
  logo_emoji text not null default '🍽️',
  is_open boolean not null default true,
  prep_minutes int not null default 20 check (prep_minutes between 1 and 180),
  delivery_fee_cents int not null default 3500 check (delivery_fee_cents >= 0),
  min_order_cents int not null default 0 check (min_order_cents >= 0),
  delivery_radius_km double precision not null default 5 check (delivery_radius_km > 0),
  in_marketplace boolean not null default true,
  accepts_cash boolean not null default true,
  accepts_card_sim boolean not null default true,
  require_delivery_pin boolean not null default true,
  notify_channel text not null default 'sms' check (notify_channel in ('sms', 'whatsapp', 'none')),
  courier_invite_code text not null unique,
  whatsapp_phone_number_id text unique,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  name text not null,
  phone text not null default '',
  password_hash text not null,
  role text not null check (role in ('owner', 'staff', 'courier', 'admin')),
  restaurant_id uuid references restaurants(id) on delete cascade,
  vehicle text not null default 'moto' check (vehicle in ('moto', 'bici', 'auto', 'pie')),
  created_at timestamptz not null default now()
);
create index users_restaurant_idx on users (restaurant_id);

create table courier_status (
  user_id uuid primary key references users(id) on delete cascade,
  available boolean not null default false,
  lat double precision,
  lng double precision,
  accuracy double precision,
  heading double precision,
  updated_at timestamptz
);

create table menu_categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  name text not null,
  sort int not null default 0
);
create index menu_categories_restaurant_idx on menu_categories (restaurant_id, sort);

create table menu_items (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  category_id uuid references menu_categories(id) on delete set null,
  name text not null,
  description text not null default '',
  price_cents int not null check (price_cents >= 0),
  emoji text not null default '',
  available boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
create index menu_items_restaurant_idx on menu_items (restaurant_id, sort);

create table orders (
  id uuid primary key default gen_random_uuid(),
  code text not null,
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  source text not null check (source in ('web', 'marketplace', 'agent', 'whatsapp', 'manual', 'api')),
  status text not null check (status in ('pending', 'preparing', 'ready', 'on_the_way', 'delivered', 'cancelled')),
  customer_name text not null,
  customer_phone text not null,
  address_text text not null,
  address_notes text not null default '',
  lat double precision,
  lng double precision,
  subtotal_cents int not null default 0,
  delivery_fee_cents int not null default 0,
  tip_cents int not null default 0,
  total_cents int not null default 0,
  payment_method text not null check (payment_method in ('cash', 'card_sim', 'prepaid')),
  payment_status text not null check (payment_status in ('pending', 'paid', 'simulated')),
  courier_id uuid references users(id) on delete set null,
  tracking_token text not null unique,
  delivery_pin text not null,
  prep_minutes int not null default 20,
  eta_at timestamptz,
  notes text not null default '',
  rating int check (rating between 1 and 5),
  rating_comment text not null default '',
  sim_started_at timestamptz,
  created_at timestamptz not null default now(),
  accepted_at timestamptz,
  ready_at timestamptz,
  picked_up_at timestamptz,
  delivered_at timestamptz,
  cancelled_at timestamptz,
  cancel_reason text not null default ''
);
create index orders_restaurant_created_idx on orders (restaurant_id, created_at desc);
create index orders_courier_idx on orders (courier_id) where status in ('preparing', 'ready', 'on_the_way');
create index orders_open_idx on orders (status) where status in ('pending', 'preparing', 'ready', 'on_the_way');

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  menu_item_id uuid references menu_items(id) on delete set null,
  name text not null,
  unit_price_cents int not null check (unit_price_cents >= 0),
  qty int not null check (qty between 1 and 99),
  notes text not null default ''
);
create index order_items_order_idx on order_items (order_id);

create table order_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  type text not null,
  message text not null default '',
  actor text not null default 'system',
  created_at timestamptz not null default now()
);
create index order_events_order_idx on order_events (order_id, created_at);

create table order_messages (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  sender text not null check (sender in ('customer', 'courier', 'restaurant', 'system')),
  body text not null,
  created_at timestamptz not null default now()
);
create index order_messages_order_idx on order_messages (order_id, created_at);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  restaurant_id uuid references restaurants(id) on delete cascade,
  channel text not null,
  to_phone text not null,
  body text not null,
  status text not null check (status in ('sent', 'logged', 'failed')),
  provider text not null,
  provider_ref text not null default '',
  error text not null default '',
  created_at timestamptz not null default now()
);
create index notifications_restaurant_idx on notifications (restaurant_id, created_at desc);

create table help_requests (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  reason text not null,
  message text not null default '',
  status text not null default 'open' check (status in ('open', 'resolved')),
  created_at timestamptz not null default now()
);

create table api_keys (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  name text not null,
  prefix text not null,
  key_hash text not null unique,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);

create table agent_sessions (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references restaurants(id) on delete cascade,
  channel text not null check (channel in ('web', 'whatsapp')),
  external_id text,
  state jsonb not null default '{}'::jsonb,
  messages jsonb not null default '[]'::jsonb,
  order_id uuid references orders(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index agent_sessions_external_idx on agent_sessions (restaurant_id, channel, external_id) where external_id is not null;
`,
  },
];
