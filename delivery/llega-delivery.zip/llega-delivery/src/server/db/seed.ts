import "server-only";
import { randomBytes, scryptSync } from "node:crypto";
import type { Db } from "./index";

/**
 * Demo data so the app is usable right after `npm run dev`.
 * Runs only when the database has no restaurants, and never in production unless SEED_DEMO=1.
 * All demo accounts use the password "demo1234" — change or delete them before launch.
 */

export const DEMO_PASSWORD = "demo1234";

function hash(pw: string): string {
  const salt = randomBytes(16);
  return `scrypt$${salt.toString("base64url")}$${scryptSync(pw, salt, 64).toString("base64url")}`;
}

function code(): string {
  return randomBytes(4).toString("hex").toUpperCase();
}

interface SeedRestaurant {
  slug: string;
  name: string;
  tagline: string;
  cuisine: string;
  emoji: string;
  color: string;
  lat: number;
  lng: number;
  address: string;
  phone: string;
  prep: number;
  fee: number;
  menu: { category: string; items: [name: string, price: number, emoji: string, description: string][] }[];
}

const RESTAURANTS: SeedRestaurant[] = [
  {
    slug: "tacos-don-chava",
    name: "Tacos Don Chava",
    tagline: "Pastor al carbón desde 1998",
    cuisine: "Tacos",
    emoji: "🌮",
    color: "#b3261e",
    lat: 19.7142,
    lng: -99.2219,
    address: "Av. Insurgentes 12, Centro, Tepotzotlán",
    phone: "+525512340001",
    prep: 15,
    fee: 3000,
    menu: [
      {
        category: "Tacos",
        items: [
          ["Taco al pastor", 22, "🌮", "Con piña, cebolla y cilantro."],
          ["Taco de suadero", 22, "🌮", "Suadero dorado en su jugo."],
          ["Taco de bistec", 24, "🌮", "Bistec de res a la plancha."],
          ["Taco campechano", 25, "🌮", "Bistec con longaniza."],
        ],
      },
      {
        category: "Especiales",
        items: [
          ["Gringa de pastor", 55, "🧀", "Tortilla de harina, queso y pastor."],
          ["Quesadilla de queso", 40, "🫓", "Tortilla de maíz hecha a mano."],
          ["Orden de cebollitas", 30, "🧅", "Cebollitas cambray asadas."],
        ],
      },
      {
        category: "Bebidas",
        items: [
          ["Agua de horchata", 30, "🥛", "Medio litro."],
          ["Agua de jamaica", 30, "🥤", "Medio litro."],
          ["Refresco", 28, "🥤", "Lata 355 ml."],
        ],
      },
    ],
  },
  {
    slug: "cafe-arcos",
    name: "Café Arcos",
    tagline: "Desayunos y café de especialidad",
    cuisine: "Café y desayunos",
    emoji: "☕",
    color: "#6b4226",
    lat: 19.7128,
    lng: -99.2247,
    address: "Plaza Virreinal 5, Centro, Tepotzotlán",
    phone: "+525512340002",
    prep: 12,
    fee: 2500,
    menu: [
      {
        category: "Café",
        items: [
          ["Americano", 35, "☕", "Grano de Veracruz."],
          ["Latte", 48, "☕", "Leche entera o de avena."],
          ["Capuchino", 48, "☕", "Espuma firme, canela opcional."],
        ],
      },
      {
        category: "Desayunos",
        items: [
          ["Chilaquiles verdes", 95, "🍳", "Con pollo o huevo, crema y queso."],
          ["Molletes", 75, "🥖", "Frijoles, queso gratinado y pico de gallo."],
          ["Concha", 22, "🍞", "Vainilla o chocolate."],
        ],
      },
    ],
  },
  {
    slug: "pizzas-del-convento",
    name: "Pizzas del Convento",
    tagline: "Horno de piedra, masa madre",
    cuisine: "Pizza",
    emoji: "🍕",
    color: "#1f5f3a",
    lat: 19.7155,
    lng: -99.2261,
    address: "Calle Virreinato 30, Tepotzotlán",
    phone: "+525512340003",
    prep: 25,
    fee: 3500,
    menu: [
      {
        category: "Pizzas",
        items: [
          ["Pizza pepperoni", 159, "🍕", "Mediana, 8 rebanadas."],
          ["Pizza hawaiana", 169, "🍍", "Jamón y piña."],
          ["Pizza mexicana", 179, "🌶️", "Chorizo, jalapeño y cebolla."],
        ],
      },
      {
        category: "Para acompañar",
        items: [
          ["Alitas BBQ", 139, "🍗", "10 piezas."],
          ["Refresco 2 L", 45, "🥤", "Cola o naranja."],
        ],
      },
    ],
  },
];

export async function seedDemoIfEmpty(db: Db): Promise<void> {
  const [{ n }] = await db.query<{ n: number }>("select count(*)::int as n from restaurants");
  if (n > 0) return;
  const pw = hash(DEMO_PASSWORD);
  await db.tx(async (q) => {
    const ids: Record<string, string> = {};
    for (const r of RESTAURANTS) {
      const [row] = await q.query<{ id: string }>(
        `insert into restaurants (slug, name, tagline, cuisine, logo_emoji, brand_color, lat, lng, address, phone, prep_minutes, delivery_fee_cents, courier_invite_code, delivery_radius_km)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) returning id`,
        [r.slug, r.name, r.tagline, r.cuisine, r.emoji, r.color, r.lat, r.lng, r.address, r.phone, r.prep, r.fee, code(), 6],
      );
      ids[r.slug] = row.id;
      let sort = 0;
      for (const [ci, cat] of r.menu.entries()) {
        const [c] = await q.query<{ id: string }>("insert into menu_categories (restaurant_id, name, sort) values ($1,$2,$3) returning id", [row.id, cat.category, ci]);
        for (const [name, price, emoji, description] of cat.items) {
          await q.query(
            "insert into menu_items (restaurant_id, category_id, name, price_cents, emoji, description, sort) values ($1,$2,$3,$4,$5,$6,$7)",
            [row.id, c.id, name, price * 100, emoji, description, sort++],
          );
        }
      }
    }
    const users: [email: string, name: string, role: string, slug: string | null, phone: string, vehicle: string][] = [
      ["dueno@llega.demo", "Chava (dueño)", "owner", "tacos-don-chava", "+525512340001", "moto"],
      ["cafe@llega.demo", "Lucía (Café Arcos)", "owner", "cafe-arcos", "+525512340002", "moto"],
      ["pizzas@llega.demo", "Marco (Pizzas)", "owner", "pizzas-del-convento", "+525512340003", "moto"],
      ["repartidor@llega.demo", "Luis", "courier", "tacos-don-chava", "+525512349001", "moto"],
      ["ana@llega.demo", "Ana", "courier", "cafe-arcos", "+525512349002", "bici"],
      ["simulado@llega.demo", "Repartidor demo", "courier", "tacos-don-chava", "+525512349009", "moto"],
      ["admin@llega.demo", "Admin", "admin", null, "", "moto"],
    ];
    for (const [email, name, role, slug, phone, vehicle] of users) {
      const [u] = await q.query<{ id: string }>(
        "insert into users (email, name, role, restaurant_id, phone, password_hash, vehicle) values ($1,$2,$3,$4,$5,$6,$7) returning id",
        [email, name, role, slug ? ids[slug] : null, phone, pw, vehicle],
      );
      if (role === "courier") await q.query("insert into courier_status (user_id) values ($1)", [u.id]);
    }
  });
  console.log(`[seed] Demo data created. Accounts use the password "${DEMO_PASSWORD}".`);
}
