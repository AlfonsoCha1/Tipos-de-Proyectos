import "server-only";
import { z } from "zod";

export class HttpError extends Error {
  constructor(
    public status: number,
    public messageEs: string,
    public code = "error",
  ) {
    super(messageEs);
  }
}

export function json(data: unknown, init: ResponseInit = {}): Response {
  return Response.json(data, { ...init, headers: { "Cache-Control": "no-store", ...(init.headers ?? {}) } });
}

/**
 * Wrap a route handler: consistent JSON errors, origin check on mutations,
 * never leaks stack traces or provider details.
 */
export function route<C = unknown>(
  fn: (req: Request, ctx: C) => Promise<Response>,
  opts: { checkOrigin?: boolean } = {},
): (req: Request, ctx: C) => Promise<Response> {
  return async (req, ctx) => {
    try {
      if (opts.checkOrigin !== false && req.method !== "GET" && req.method !== "HEAD") assertSameOrigin(req);
      return await fn(req, ctx);
    } catch (err) {
      if (err instanceof HttpError) return json({ error: err.messageEs, code: err.code }, { status: err.status });
      if (err instanceof z.ZodError) {
        return json({ error: "Revisa los datos enviados.", code: "invalid", issues: err.issues.slice(0, 5).map((i) => i.path.join(".") + ": " + i.message) }, { status: 400 });
      }
      console.error(`[api] ${req.method} ${new URL(req.url).pathname}:`, err);
      return json({ error: "Algo falló de nuestro lado. Intenta de nuevo.", code: "server_error" }, { status: 500 });
    }
  };
}

/** Blocks cross-site form posts (CSRF) for cookie-authenticated endpoints. */
export function assertSameOrigin(req: Request): void {
  const origin = req.headers.get("origin");
  if (!origin) return; // same-origin fetches from older browsers, server-to-server
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  try {
    if (new URL(origin).host !== host) throw new HttpError(403, "Origen no permitido.", "bad_origin");
  } catch (e) {
    if (e instanceof HttpError) throw e;
    throw new HttpError(403, "Origen no permitido.", "bad_origin");
  }
}

export async function body<T extends z.ZodType>(req: Request, schema: T): Promise<z.infer<T>> {
  let data: unknown;
  try {
    data = await req.json();
  } catch {
    throw new HttpError(400, "El cuerpo de la solicitud no es JSON válido.", "bad_json");
  }
  return schema.parse(data);
}

/** Public base URL used in SMS / WhatsApp links. */
export function appUrl(req?: Request): string {
  const env = process.env.APP_URL?.trim().replace(/\/$/, "");
  if (env) return env;
  if (!req) return "http://localhost:3000";
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "localhost:3000";
  const proto = req.headers.get("x-forwarded-proto") ?? (host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https");
  return `${proto}://${host}`;
}

export function clientIp(req: Request): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? req.headers.get("x-real-ip") ?? "local";
}

// ---------- simple in-memory rate limiting (per server instance) ----------

const g = globalThis as unknown as { __llegaRate?: Map<string, { n: number; reset: number }> };
const buckets = (g.__llegaRate ??= new Map());

/** Allow `max` hits per `windowMs` for a key. Throws 429 when exceeded. */
export function rateLimit(key: string, max: number, windowMs: number): void {
  const now = Date.now();
  if (buckets.size > 5000) for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
  const b = buckets.get(key);
  if (!b || b.reset < now) {
    buckets.set(key, { n: 1, reset: now + windowMs });
    return;
  }
  b.n++;
  if (b.n > max) throw new HttpError(429, "Demasiadas solicitudes. Espera un momento.", "rate_limited");
}
