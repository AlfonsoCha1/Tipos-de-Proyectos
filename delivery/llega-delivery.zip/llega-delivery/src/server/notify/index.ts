import "server-only";
import { mxn } from "@/lib/money";
import { sql } from "../db";
import { providerFor, type Channel } from "./providers";

export type NotifyEvent = "created" | "tracking_only_created" | "accepted" | "on_the_way" | "delivered" | "cancelled";

export interface NotifyOrder {
  id: string;
  code: string;
  restaurantId: string;
  restaurantName: string;
  notifyChannel: "sms" | "whatsapp" | "none";
  customerPhone: string;
  trackingToken: string;
  deliveryPin: string;
  requirePin: boolean;
  totalCents: number;
  etaAt: Date | null;
  courierName?: string | null;
  cancelReason?: string;
}

function hhmm(d: Date | null): string {
  if (!d) return "";
  return new Intl.DateTimeFormat("es-MX", { hour: "2-digit", minute: "2-digit", timeZone: process.env.APP_TIMEZONE ?? "America/Mexico_City" }).format(d);
}

export function composeMessage(ev: NotifyEvent, o: NotifyOrder, baseUrl: string): string {
  const brand = process.env.NEXT_PUBLIC_BRAND_NAME ?? "Llega";
  const link = `${baseUrl}/t/${o.trackingToken}`;
  switch (ev) {
    case "created":
      return `${brand}: Recibimos tu pedido #${o.code} de ${o.restaurantName} (${mxn(o.totalCents)}). Síguelo en vivo: ${link}`;
    case "tracking_only_created":
      return `${brand}: ${o.restaurantName} está preparando tu pedido #${o.code}. Síguelo en vivo: ${link}`;
    case "accepted":
      return `${brand}: ${o.restaurantName} aceptó tu pedido #${o.code}.${o.etaAt ? ` Llegada estimada: ${hhmm(o.etaAt)}.` : ""} ${link}`;
    case "on_the_way":
      return `${brand}: ${o.restaurantName} terminó tu pedido y ${o.courierName ?? "tu repartidor"} va en camino.${o.requirePin ? ` Tu código de entrega es ${o.deliveryPin}.` : ""} ${link}`;
    case "delivered":
      return `${brand}: ¡Tu pedido fue entregado! ¿Qué tal estuvo? Califícalo aquí: ${link}`;
    case "cancelled":
      return `${brand}: Tu pedido #${o.code} de ${o.restaurantName} fue cancelado.${o.cancelReason ? ` Motivo: ${o.cancelReason}.` : ""}`;
  }
}

/**
 * Values for the WhatsApp templates (see docs/WHATSAPP.md for the exact template texts).
 * Order matters: they fill {{1}}, {{2}}, … in the approved template.
 */
export function templateParams(ev: NotifyEvent, o: NotifyOrder, baseUrl: string): string[] {
  const link = `${baseUrl}/t/${o.trackingToken}`;
  switch (ev) {
    case "created":
      return [o.code, o.restaurantName, mxn(o.totalCents), link];
    case "tracking_only_created":
      return [o.restaurantName, o.code, link];
    case "accepted":
      return [o.restaurantName, o.code, o.etaAt ? hhmm(o.etaAt) : "en unos minutos", link];
    case "on_the_way":
      return [o.courierName ?? "Tu repartidor", o.restaurantName, o.requirePin ? o.deliveryPin : "no se requiere", link];
    case "delivered":
      return [o.restaurantName, link];
    case "cancelled":
      return [o.code, o.restaurantName, o.cancelReason || "sin motivo indicado"];
  }
}

/** Send and record. Never throws: a failed SMS must not break the order flow. */
export async function notifyCustomer(ev: NotifyEvent, o: NotifyOrder, baseUrl: string): Promise<void> {
  if (o.notifyChannel === "none" || !o.customerPhone) return;
  const channel: Channel = o.notifyChannel;
  const body = composeMessage(ev, o, baseUrl);
  const provider = providerFor(channel);
  const result = await provider.send(o.customerPhone, body, { event: ev, params: templateParams(ev, o, baseUrl) }).catch((e: unknown) => ({
    status: "failed" as const,
    provider: provider.id,
    ref: undefined,
    error: e instanceof Error ? e.message : String(e),
  }));
  try {
    await sql(
      `insert into notifications (order_id, restaurant_id, channel, to_phone, body, status, provider, provider_ref, error)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [o.id, o.restaurantId, channel, o.customerPhone, body, result.status, result.provider, result.ref ?? "", result.error ?? ""],
    );
    await sql("insert into order_events (order_id, type, message, actor) values ($1,'notified',$2,'system')", [
      o.id,
      `${channel === "sms" ? "SMS" : "WhatsApp"} ${result.status === "failed" ? "falló" : result.status === "logged" ? "registrado (demo)" : "enviado"}: ${ev}`,
    ]);
  } catch (e) {
    console.error("[notify] could not record notification:", e);
  }
  if (result.status === "failed") console.error(`[notify] ${provider.id} failed for order ${o.code}:`, result.error);
}
