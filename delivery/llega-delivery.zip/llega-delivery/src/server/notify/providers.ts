import "server-only";

/**
 * Message providers. Each one sends a plain text message to a phone number.
 * - twilio-sms / twilio-whatsapp: Twilio REST API (needs an account and a sender number).
 * - meta-whatsapp: WhatsApp Cloud API from Meta (needs a Business account and phone number ID).
 *   Note: outside the 24 h customer-service window WhatsApp only allows pre-approved templates.
 * - log: does not send anything; stores the message so you can see it in the panel (demo).
 */
export type Channel = "sms" | "whatsapp";

export interface SendResult {
  status: "sent" | "logged" | "failed";
  provider: string;
  ref?: string;
  error?: string;
}

/**
 * WhatsApp only lets a business start a conversation with a pre-approved template.
 * `event` picks the template; `params` fill {{1}}, {{2}}… in order. SMS ignores it.
 */
export interface TemplateRef {
  event: string;
  params: string[];
}

export interface MessageProvider {
  id: string;
  send(to: string, body: string, template?: TemplateRef): Promise<SendResult>;
}

function env(n: string) {
  const v = process.env[n];
  return v && v.trim() ? v.trim() : undefined;
}

export class LogProvider implements MessageProvider {
  constructor(public id = "log") {}
  async send(): Promise<SendResult> {
    return { status: "logged", provider: this.id };
  }
}

export class TwilioProvider implements MessageProvider {
  constructor(
    public id: string,
    private sid: string,
    private token: string,
    private from: string,
    private whatsapp: boolean,
    private baseUrl = "https://api.twilio.com",
  ) {}

  async send(to: string, body: string, template?: TemplateRef): Promise<SendResult> {
    const form = new URLSearchParams({
      To: this.whatsapp ? `whatsapp:${to}` : to,
      From: this.whatsapp && !this.from.startsWith("whatsapp:") ? `whatsapp:${this.from}` : this.from,
    });
    // WhatsApp through Twilio: business-initiated messages need an approved Content Template.
    const contentSid = this.whatsapp && template ? env(`TWILIO_CONTENT_SID_${template.event.toUpperCase()}`) : undefined;
    if (contentSid && template) {
      form.set("ContentSid", contentSid);
      form.set("ContentVariables", JSON.stringify(Object.fromEntries(template.params.map((p, i) => [String(i + 1), p]))));
    } else {
      form.set("Body", body);
    }
    try {
      const res = await fetch(`${this.baseUrl}/2010-04-01/Accounts/${this.sid}/Messages.json`, {
        method: "POST",
        headers: {
          Authorization: `Basic ${Buffer.from(`${this.sid}:${this.token}`).toString("base64")}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: form,
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json().catch(() => ({}))) as { sid?: string; message?: string };
      if (!res.ok) return { status: "failed", provider: this.id, error: `HTTP ${res.status}: ${data.message ?? ""}`.slice(0, 300) };
      return { status: "sent", provider: this.id, ref: data.sid };
    } catch (e) {
      return { status: "failed", provider: this.id, error: e instanceof Error ? e.message : String(e) };
    }
  }
}

export class MetaWhatsAppProvider implements MessageProvider {
  readonly id = "meta-whatsapp";
  constructor(
    private token: string,
    private phoneNumberId: string,
    private baseUrl = "https://graph.facebook.com/v21.0",
  ) {}

  async send(to: string, body: string, template?: TemplateRef): Promise<SendResult> {
    const useTemplate = !!template && env("META_USE_TEMPLATES") === "1";
    const payload = useTemplate
      ? {
          messaging_product: "whatsapp",
          to: to.replace(/^\+/, ""),
          type: "template",
          template: {
            name: `${env("META_TEMPLATE_PREFIX") ?? "llega_"}${template!.event}`,
            language: { code: env("META_TEMPLATE_LANG") ?? "es_MX" },
            components: [{ type: "body", parameters: template!.params.map((text) => ({ type: "text", text })) }],
          },
        }
      : { messaging_product: "whatsapp", to: to.replace(/^\+/, ""), type: "text", text: { body, preview_url: true } };
    try {
      const res = await fetch(`${this.baseUrl}/${this.phoneNumberId}/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${this.token}`, "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(10000),
      });
      const data = (await res.json().catch(() => ({}))) as { messages?: { id: string }[]; error?: { message?: string } };
      if (!res.ok) return { status: "failed", provider: this.id, error: `HTTP ${res.status}: ${data.error?.message ?? ""}`.slice(0, 300) };
      return { status: "sent", provider: this.id, ref: data.messages?.[0]?.id };
    } catch (e) {
      return { status: "failed", provider: this.id, error: e instanceof Error ? e.message : String(e) };
    }
  }
}

export function smsProvider(): MessageProvider {
  const wanted = env("SMS_PROVIDER") ?? "auto";
  const sid = env("TWILIO_ACCOUNT_SID");
  const token = env("TWILIO_AUTH_TOKEN");
  const from = env("TWILIO_SMS_FROM");
  if ((wanted === "twilio" || wanted === "auto") && sid && token && from) {
    return new TwilioProvider("twilio-sms", sid, token, from, false, env("TWILIO_API_BASE"));
  }
  return new LogProvider("log");
}

export function whatsappProvider(): MessageProvider {
  const wanted = env("WHATSAPP_PROVIDER") ?? "auto";
  const metaToken = env("META_WHATSAPP_TOKEN");
  const metaPhone = env("META_WHATSAPP_PHONE_NUMBER_ID");
  if ((wanted === "meta" || wanted === "auto") && metaToken && metaPhone) {
    return new MetaWhatsAppProvider(metaToken, metaPhone, env("META_GRAPH_BASE"));
  }
  const sid = env("TWILIO_ACCOUNT_SID");
  const token = env("TWILIO_AUTH_TOKEN");
  const from = env("TWILIO_WHATSAPP_FROM");
  if ((wanted === "twilio" || wanted === "auto") && sid && token && from) {
    return new TwilioProvider("twilio-whatsapp", sid, token, from, true, env("TWILIO_API_BASE"));
  }
  return new LogProvider("log");
}

export function providerFor(channel: Channel): MessageProvider {
  return channel === "whatsapp" ? whatsappProvider() : smsProvider();
}
