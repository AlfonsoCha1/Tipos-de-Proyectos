import "server-only";
import { estimateEta } from "@/lib/eta";
import { distanceKm, interpolate, isValidLatLng, travelMinutes, type LatLng } from "@/lib/geo";
import { canTransition, customerHeadline, customerStepIndex, type Actor, type OrderStatus } from "@/lib/order-flow";
import { normalizePhone } from "@/lib/phone";
import type {
  ChatMessageView,
  CourierJob,
  CourierView,
  OrderItemView,
  OrderSource,
  PanelOrder,
  PaymentMethod,
  TrackView,
} from "@/lib/types";
import { randomCode, randomPin, randomToken } from "./random";
import { getDb, one, sql, type Queryable } from "./db";
import { HttpError } from "./http";
import { notifyCustomer, type NotifyEvent, type NotifyOrder } from "./notify";
import { getMenuItemsByIds, getRestaurantById, type RestaurantRow } from "./repo/restaurants";

// ------------------------------------------------------------------ rows

export interface OrderRow {
  id: string;
  code: string;
  restaurant_id: string;
  source: OrderSource;
  status: OrderStatus;
  customer_name: string;
  customer_phone: string;
  address_text: string;
  address_notes: string;
  lat: number | null;
  lng: number | null;
  subtotal_cents: number;
  delivery_fee_cents: number;
  tip_cents: number;
  total_cents: number;
  payment_method: PaymentMethod;
  payment_status: "pending" | "paid" | "simulated";
  courier_id: string | null;
  tracking_token: string;
  delivery_pin: string;
  prep_minutes: number;
  eta_at: Date | null;
  notes: string;
  rating: number | null;
  rating_comment: string;
  sim_started_at: Date | null;
  created_at: Date;
  accepted_at: Date | null;
  ready_at: Date | null;
  picked_up_at: Date | null;
  delivered_at: Date | null;
  cancelled_at: Date | null;
  cancel_reason: string;
}

interface CourierRow {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  restaurant_id: string | null;
  email: string;
  available: boolean | null;
  lat: number | null;
  lng: number | null;
  updated_at: Date | null;
}

const ms = (d: Date | null | undefined) => (d ? new Date(d).getTime() : null);
const iso = (d: Date | null | undefined) => (d ? new Date(d).toISOString() : null);

async function getCourier(q: Queryable, id: string | null): Promise<CourierRow | null> {
  if (!id) return null;
  const rows = await q.query<CourierRow>(
    `select u.id, u.name, u.phone, u.vehicle, u.restaurant_id, u.email, s.available, s.lat, s.lng, s.updated_at
     from users u left join courier_status s on s.user_id = u.id where u.id = $1 and u.role = 'courier'`,
    [id],
  );
  return rows[0] ?? null;
}

function courierView(c: CourierRow | null): CourierView | null {
  if (!c) return null;
  return { id: c.id, name: c.name, vehicle: c.vehicle, phone: c.phone, lat: c.lat, lng: c.lng, updatedAt: iso(c.updated_at) };
}

function computeEta(o: OrderRow, r: RestaurantRow, c: CourierRow | null, now = Date.now()) {
  return estimateEta({
    status: o.status,
    now,
    createdAt: ms(o.created_at)!,
    acceptedAt: ms(o.accepted_at),
    deliveredAt: ms(o.delivered_at),
    prepMinutes: o.prep_minutes,
    restaurant: { lat: r.lat, lng: r.lng },
    destination: o.lat != null && o.lng != null ? { lat: o.lat, lng: o.lng } : null,
    courier: c && c.lat != null && c.lng != null && c.updated_at ? { pos: { lat: c.lat, lng: c.lng }, updatedAt: ms(c.updated_at)!, vehicle: c.vehicle } : null,
    previousEta: ms(o.eta_at),
  });
}

function notifyPayload(o: OrderRow, r: RestaurantRow, courierName?: string | null): NotifyOrder {
  return {
    id: o.id,
    code: o.code,
    restaurantId: r.id,
    restaurantName: r.name,
    notifyChannel: r.notify_channel,
    customerPhone: o.customer_phone,
    trackingToken: o.tracking_token,
    deliveryPin: o.delivery_pin,
    requirePin: r.require_delivery_pin,
    totalCents: o.total_cents,
    etaAt: o.eta_at ? new Date(o.eta_at) : null,
    courierName,
    cancelReason: o.cancel_reason,
  };
}

async function addEvent(q: Queryable, orderId: string, type: string, message: string, actor: string) {
  await q.query("insert into order_events (order_id, type, message, actor) values ($1,$2,$3,$4)", [orderId, type, message, actor]);
}

// ------------------------------------------------------------------ checkout

export interface CheckoutInput {
  restaurantId: string;
  source: OrderSource;
  items: { itemId: string; qty: number; notes?: string }[];
  customer: { name: string; phone: string };
  address: { text: string; notes?: string; lat?: number | null; lng?: number | null };
  paymentMethod: "cash" | "card_sim";
  tipCents?: number;
  notes?: string;
}

export interface CheckoutQuote {
  subtotalCents: number;
  deliveryFeeCents: number;
  tipCents: number;
  totalCents: number;
  lines: { itemId: string; name: string; qty: number; unitPriceCents: number; notes: string }[];
  distanceKm: number | null;
}

/** Prices always come from the database, never from the client. */
export async function quote(r: RestaurantRow, input: Pick<CheckoutInput, "items" | "address" | "tipCents">, q?: Queryable): Promise<CheckoutQuote> {
  const merged = new Map<string, { qty: number; notes: string }>();
  for (const line of input.items) {
    if (!Number.isInteger(line.qty) || line.qty < 1 || line.qty > 50) throw new HttpError(400, "Cantidad inválida.");
    const key = `${line.itemId}|${(line.notes ?? "").trim()}`;
    const prev = merged.get(key);
    merged.set(key, { qty: (prev?.qty ?? 0) + line.qty, notes: (line.notes ?? "").trim().slice(0, 140) });
  }
  if (merged.size === 0) throw new HttpError(400, "Tu carrito está vacío.");
  const ids = [...new Set(input.items.map((i) => i.itemId))];
  const menu = await getMenuItemsByIds(r.id, ids, q);
  const lines: CheckoutQuote["lines"] = [];
  for (const [key, v] of merged) {
    const itemId = key.split("|")[0];
    const item = menu.find((m) => m.id === itemId);
    if (!item) throw new HttpError(400, "Uno de los productos ya no existe. Actualiza tu carrito.", "item_missing");
    if (!item.available) throw new HttpError(409, `"${item.name}" ya no está disponible.`, "item_unavailable");
    lines.push({ itemId, name: item.name, qty: v.qty, unitPriceCents: item.priceCents, notes: v.notes });
  }
  const subtotal = lines.reduce((n, l) => n + l.qty * l.unitPriceCents, 0);
  const tip = Math.max(0, Math.min(100_000, Math.round(input.tipCents ?? 0)));
  const dest = { lat: input.address.lat ?? NaN, lng: input.address.lng ?? NaN };
  const dist = isValidLatLng(dest) ? distanceKm({ lat: r.lat, lng: r.lng }, dest) : null;
  return {
    subtotalCents: subtotal,
    deliveryFeeCents: r.delivery_fee_cents,
    tipCents: tip,
    totalCents: subtotal + r.delivery_fee_cents + tip,
    lines,
    distanceKm: dist,
  };
}

export async function placeOrder(input: CheckoutInput, baseUrl: string): Promise<{ id: string; code: string; trackingToken: string }> {
  const r = await getRestaurantById(input.restaurantId);
  if (!r || !r.active) throw new HttpError(404, "Restaurante no encontrado.");
  if (!r.is_open) throw new HttpError(409, `${r.name} está cerrado en este momento.`, "closed");
  const phone = normalizePhone(input.customer.phone);
  if (!phone) throw new HttpError(400, "Escribe un teléfono de 10 dígitos.", "bad_phone");
  const name = input.customer.name.trim().slice(0, 80);
  if (name.length < 2) throw new HttpError(400, "Escribe tu nombre.");
  const addressText = input.address.text.trim().slice(0, 300);
  if (addressText.length < 5) throw new HttpError(400, "Escribe tu dirección.");
  if (input.paymentMethod === "cash" && !r.accepts_cash) throw new HttpError(400, "Este restaurante no acepta efectivo.");
  if (input.paymentMethod === "card_sim" && !r.accepts_card_sim) throw new HttpError(400, "Este restaurante no acepta pago con tarjeta.");

  const qt = await quote(r, input);
  if (qt.subtotalCents < r.min_order_cents) throw new HttpError(400, `El pedido mínimo es de $${(r.min_order_cents / 100).toFixed(0)}.`, "min_order");
  if (qt.distanceKm != null && qt.distanceKm > r.delivery_radius_km) {
    throw new HttpError(400, `Tu dirección está a ${qt.distanceKm.toFixed(1)} km. ${r.name} entrega hasta ${r.delivery_radius_km} km.`, "out_of_range");
  }
  const lat = qt.distanceKm != null ? input.address.lat! : null;
  const lng = qt.distanceKm != null ? input.address.lng! : null;

  const db = await getDb();
  const order = await db.tx(async (q) => {
    const eta = estimateEta({
      status: "pending",
      now: Date.now(),
      createdAt: Date.now(),
      prepMinutes: r.prep_minutes,
      restaurant: { lat: r.lat, lng: r.lng },
      destination: lat != null && lng != null ? { lat, lng } : null,
    });
    const [o] = await q.query<OrderRow>(
      `insert into orders (code, restaurant_id, source, status, customer_name, customer_phone, address_text, address_notes, lat, lng,
         subtotal_cents, delivery_fee_cents, tip_cents, total_cents, payment_method, payment_status, tracking_token, delivery_pin, prep_minutes, eta_at, notes)
       values ($1,$2,$3,'pending',$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20) returning *`,
      [
        randomCode(4),
        r.id,
        input.source,
        name,
        phone,
        addressText,
        (input.address.notes ?? "").trim().slice(0, 200),
        lat,
        lng,
        qt.subtotalCents,
        qt.deliveryFeeCents,
        qt.tipCents,
        qt.totalCents,
        input.paymentMethod,
        input.paymentMethod === "card_sim" ? "simulated" : "pending",
        randomToken(16),
        randomPin(),
        r.prep_minutes,
        eta.etaAt ? new Date(eta.etaAt) : null,
        (input.notes ?? "").trim().slice(0, 300),
      ],
    );
    for (const l of qt.lines) {
      await q.query("insert into order_items (order_id, menu_item_id, name, unit_price_cents, qty, notes) values ($1,$2,$3,$4,$5,$6)", [
        o.id,
        l.itemId,
        l.name,
        l.unitPriceCents,
        l.qty,
        l.notes,
      ]);
    }
    const via = { web: "tienda en línea", marketplace: "marketplace", agent: "chat con IA", whatsapp: "WhatsApp", manual: "panel", api: "API" }[input.source];
    await addEvent(q, o.id, "created", `Pedido recibido por ${via}`, "customer");
    if (input.paymentMethod === "card_sim") await addEvent(q, o.id, "payment", "Pago de prueba aprobado (no se cobró dinero real)", "system");
    return o;
  });
  await notifyCustomer("created", notifyPayload(order, r), baseUrl);
  return { id: order.id, code: order.code, trackingToken: order.tracking_token };
}

// ------------------------------------------------------------------ tracking-only (manual / API)

export interface ManualOrderInput {
  restaurantId: string;
  source: "manual" | "api";
  customer: { name: string; phone: string };
  address: { text: string; notes?: string; lat?: number | null; lng?: number | null };
  items: { name: string; qty: number; unitPriceCents: number }[];
  totalCents?: number;
  paymentMethod: "cash" | "prepaid";
  notes?: string;
  prepMinutes?: number;
  notify: boolean;
}

export async function createManualOrder(input: ManualOrderInput, baseUrl: string) {
  const r = await getRestaurantById(input.restaurantId);
  if (!r) throw new HttpError(404, "Restaurante no encontrado.");
  const phone = normalizePhone(input.customer.phone);
  if (!phone) throw new HttpError(400, "Teléfono inválido: usa 10 dígitos.", "bad_phone");
  const dest = { lat: input.address.lat ?? NaN, lng: input.address.lng ?? NaN };
  const hasPin = isValidLatLng(dest);
  const items = input.items.filter((i) => i.name.trim() && i.qty > 0);
  const subtotal = items.reduce((n, i) => n + i.qty * i.unitPriceCents, 0);
  const total = input.totalCents ?? subtotal;
  const prep = Math.max(1, Math.min(180, Math.round(input.prepMinutes ?? r.prep_minutes)));
  const db = await getDb();
  const order = await db.tx(async (q) => {
    const now = Date.now();
    const eta = estimateEta({
      status: "preparing",
      now,
      createdAt: now,
      acceptedAt: now,
      prepMinutes: prep,
      restaurant: { lat: r.lat, lng: r.lng },
      destination: hasPin ? dest : null,
    });
    const [o] = await q.query<OrderRow>(
      `insert into orders (code, restaurant_id, source, status, customer_name, customer_phone, address_text, address_notes, lat, lng,
         subtotal_cents, delivery_fee_cents, tip_cents, total_cents, payment_method, payment_status, tracking_token, delivery_pin, prep_minutes, eta_at, notes, accepted_at)
       values ($1,$2,$3,'preparing',$4,$5,$6,$7,$8,$9,$10,0,0,$11,$12,$13,$14,$15,$16,$17,$18, now()) returning *`,
      [
        randomCode(4),
        r.id,
        input.source,
        input.customer.name.trim().slice(0, 80) || "Cliente",
        phone,
        input.address.text.trim().slice(0, 300),
        (input.address.notes ?? "").trim().slice(0, 200),
        hasPin ? dest.lat : null,
        hasPin ? dest.lng : null,
        subtotal,
        total,
        input.paymentMethod,
        input.paymentMethod === "prepaid" ? "paid" : "pending",
        randomToken(16),
        randomPin(),
        prep,
        eta.etaAt ? new Date(eta.etaAt) : null,
        (input.notes ?? "").trim().slice(0, 300),
      ],
    );
    for (const it of items) {
      await q.query("insert into order_items (order_id, name, unit_price_cents, qty) values ($1,$2,$3,$4)", [o.id, it.name.trim().slice(0, 120), it.unitPriceCents, it.qty]);
    }
    await addEvent(q, o.id, "created", input.source === "api" ? "Pedido creado por API (solo rastreo)" : "Pedido capturado en el panel (solo rastreo)", "restaurant");
    return o;
  });
  if (input.notify) await notifyCustomer("tracking_only_created", notifyPayload(order, r), baseUrl);
  return order;
}

// ------------------------------------------------------------------ status changes

export interface TransitionOpts {
  actor: Actor;
  /** Restaurant performing the change (checked against the order). */
  restaurantId?: string;
  /** Courier performing the change. */
  courierId?: string;
  prepMinutes?: number;
  reason?: string;
  pin?: string;
  /** Skip the delivery PIN (demo simulator only). */
  skipPin?: boolean;
}

const NOTIFY_ON: Partial<Record<OrderStatus, NotifyEvent>> = {
  preparing: "accepted",
  on_the_way: "on_the_way",
  delivered: "delivered",
  cancelled: "cancelled",
};

export async function transitionOrder(orderId: string, to: OrderStatus, opts: TransitionOpts, baseUrl: string): Promise<OrderRow> {
  const db = await getDb();
  const { order, restaurant, courier, changed } = await db.tx(async (q) => {
    const [o] = await q.query<OrderRow>("select * from orders where id = $1 for update", [orderId]);
    if (!o) throw new HttpError(404, "Pedido no encontrado.");
    if (opts.restaurantId && o.restaurant_id !== opts.restaurantId) throw new HttpError(404, "Pedido no encontrado.");
    const r = (await getRestaurantById(o.restaurant_id, q))!;

    let courierId = o.courier_id;
    if (opts.actor === "courier") {
      const me = await getCourier(q, opts.courierId ?? null);
      if (!me || me.restaurant_id !== o.restaurant_id) throw new HttpError(403, "Este pedido no es de tu restaurante.");
      if (o.courier_id && o.courier_id !== me.id) throw new HttpError(409, "Otro repartidor ya tomó este pedido.", "taken");
      if (!o.courier_id) courierId = me.id;
    }
    if (o.status === to) return { order: o, restaurant: r, courier: await getCourier(q, courierId), changed: false };
    if (!canTransition(o.status, to, opts.actor)) {
      throw new HttpError(409, `No se puede pasar de "${o.status}" a "${to}".`, "bad_transition");
    }
    if (to === "on_the_way" && !courierId) throw new HttpError(409, "Asigna un repartidor antes de marcar en camino.", "no_courier");
    if (to === "delivered" && opts.actor === "courier" && r.require_delivery_pin && !opts.skipPin) {
      if ((opts.pin ?? "").trim() !== o.delivery_pin) throw new HttpError(400, "El código de entrega no coincide. Pídeselo al cliente.", "bad_pin");
    }

    const sets: string[] = ["status = $2", "courier_id = $3"];
    const params: unknown[] = [o.id, to, courierId];
    const push = (col: string, val: unknown) => {
      params.push(val);
      sets.push(`${col} = $${params.length}`);
    };
    let event = "";
    switch (to) {
      case "preparing": {
        const prep = Math.max(1, Math.min(180, Math.round(opts.prepMinutes ?? r.prep_minutes)));
        push("prep_minutes", prep);
        sets.push("accepted_at = now()");
        event = `Aceptado; listo en ~${prep} min`;
        break;
      }
      case "ready":
        sets.push("ready_at = now()");
        event = "Listo para recoger";
        break;
      case "on_the_way":
        sets.push("picked_up_at = now()");
        if (!o.ready_at) sets.push("ready_at = now()");
        event = "El repartidor recogió el pedido";
        break;
      case "delivered":
        sets.push("delivered_at = now()");
        if (o.payment_method === "cash") push("payment_status", "paid");
        event = opts.skipPin ? "Entregado (simulación)" : "Entregado";
        break;
      case "cancelled":
        sets.push("cancelled_at = now()");
        push("cancel_reason", (opts.reason ?? "").trim().slice(0, 200));
        event = `Cancelado${opts.reason ? `: ${opts.reason}` : ""}`;
        break;
    }
    const [updated] = await q.query<OrderRow>(`update orders set ${sets.join(", ")} where id = $1 returning *`, params);
    if (courierId && courierId !== o.courier_id) {
      const c = await getCourier(q, courierId);
      await addEvent(q, o.id, "assigned", `Repartidor asignado: ${c?.name ?? ""}`, opts.actor);
    }
    await addEvent(q, o.id, to, event, opts.actor);
    const c = await getCourier(q, courierId);
    const eta = computeEta(updated, r, c);
    const [withEta] = await q.query<OrderRow>("update orders set eta_at = $2 where id = $1 returning *", [o.id, eta.etaAt ? new Date(eta.etaAt) : null]);
    return { order: withEta, restaurant: r, courier: c, changed: true };
  });
  const ev = NOTIFY_ON[order.status];
  if (ev && changed) await notifyCustomer(ev, notifyPayload(order, restaurant, courier?.name), baseUrl);
  return order;
}

export async function assignCourier(orderId: string, restaurantId: string, courierId: string | null): Promise<void> {
  const db = await getDb();
  await db.tx(async (q) => {
    const [o] = await q.query<OrderRow>("select * from orders where id = $1 and restaurant_id = $2 for update", [orderId, restaurantId]);
    if (!o) throw new HttpError(404, "Pedido no encontrado.");
    if (o.status === "delivered" || o.status === "cancelled") throw new HttpError(409, "El pedido ya terminó.");
    if (o.status === "on_the_way" && courierId !== o.courier_id) throw new HttpError(409, "El pedido ya va en camino; no se puede cambiar de repartidor.");
    if (courierId) {
      const c = await getCourier(q, courierId);
      if (!c || c.restaurant_id !== restaurantId) throw new HttpError(400, "Ese repartidor no es de tu equipo.");
      await q.query("update orders set courier_id = $2 where id = $1", [orderId, courierId]);
      await addEvent(q, orderId, "assigned", `Repartidor asignado: ${c.name}`, "restaurant");
    } else {
      await q.query("update orders set courier_id = null where id = $1", [orderId]);
      await addEvent(q, orderId, "unassigned", "Repartidor removido", "restaurant");
    }
  });
}

/** Called on every courier GPS update: refresh ETAs of the orders they carry. */
export async function refreshCourierEtas(courierId: string): Promise<void> {
  const db = await getDb();
  const orders = await db.query<OrderRow>("select * from orders where courier_id = $1 and status in ('preparing','ready','on_the_way')", [courierId]);
  if (orders.length === 0) return;
  const c = await getCourier(db, courierId);
  for (const o of orders) {
    const r = (await getRestaurantById(o.restaurant_id))!;
    const eta = computeEta(o, r, c);
    await db.query("update orders set eta_at = $2 where id = $1", [o.id, eta.etaAt ? new Date(eta.etaAt) : null]);
  }
}

// ------------------------------------------------------------------ demo simulator

export const SIM_SECONDS = Number(process.env.SIM_SECONDS ?? 75);

export function demoToolsEnabled(): boolean {
  return process.env.DEMO_TOOLS === "1" || (process.env.DEMO_TOOLS !== "0" && process.env.NODE_ENV !== "production");
}

/** Start a simulated delivery: a demo courier drives from the restaurant to the customer. */
export async function startSimulation(orderId: string, restaurantId: string, baseUrl: string): Promise<void> {
  if (!demoToolsEnabled()) throw new HttpError(403, "El simulador está desactivado en producción.");
  let o = await one<OrderRow>("select * from orders where id = $1 and restaurant_id = $2", [orderId, restaurantId]);
  if (!o) throw new HttpError(404, "Pedido no encontrado.");
  if (o.lat == null || o.lng == null) throw new HttpError(400, "El pedido no tiene ubicación en el mapa; no se puede simular la ruta.");
  const sim =
    (await one<{ id: string }>("select id from users where role = 'courier' and restaurant_id = $1 and email like 'simulado@%' limit 1", [restaurantId])) ??
    (await one<{ id: string }>("select id from users where role = 'courier' and restaurant_id = $1 order by created_at limit 1", [restaurantId]));
  if (!sim) throw new HttpError(400, "Agrega al menos un repartidor para simular.");
  if (o.status === "pending") o = await transitionOrder(o.id, "preparing", { actor: "restaurant", restaurantId }, baseUrl);
  if (!o.courier_id) await assignCourier(o.id, restaurantId, sim.id);
  const r = (await getRestaurantById(restaurantId))!;
  await sql("update courier_status set lat = $2, lng = $3, updated_at = now(), available = true where user_id = $1", [o.courier_id ?? sim.id, r.lat, r.lng]);
  await sql("update orders set sim_started_at = now() where id = $1", [o.id]);
  if (o.status !== "on_the_way") await transitionOrder(o.id, "on_the_way", { actor: "restaurant", restaurantId }, baseUrl);
}

async function advanceSimulation(o: OrderRow, r: RestaurantRow, baseUrl: string): Promise<void> {
  if (!o.sim_started_at || o.status !== "on_the_way" || !o.courier_id || o.lat == null || o.lng == null) return;
  const t = (Date.now() - new Date(o.sim_started_at).getTime()) / (SIM_SECONDS * 1000);
  if (t >= 1) {
    await sql("update courier_status set lat = $2, lng = $3, updated_at = now() where user_id = $1", [o.courier_id, o.lat, o.lng]);
    await transitionOrder(o.id, "delivered", { actor: "system", skipPin: true }, baseUrl).catch(() => {});
    return;
  }
  const p = interpolate({ lat: r.lat, lng: r.lng }, { lat: o.lat, lng: o.lng }, t);
  await sql("update courier_status set lat = $2, lng = $3, updated_at = now() where user_id = $1", [o.courier_id, p.lat, p.lng]);
  await refreshCourierEtas(o.courier_id);
}

// ------------------------------------------------------------------ views

async function itemsOf(orderIds: string[]): Promise<Map<string, OrderItemView[]>> {
  const map = new Map<string, OrderItemView[]>();
  if (orderIds.length === 0) return map;
  const rows = await sql<{ order_id: string; name: string; qty: number; unit_price_cents: number; notes: string }>(
    "select order_id, name, qty, unit_price_cents, notes from order_items where order_id = any($1::uuid[]) order by name",
    [orderIds],
  );
  for (const r of rows) {
    const list = map.get(r.order_id) ?? [];
    list.push({ name: r.name, qty: r.qty, unitPriceCents: r.unit_price_cents, notes: r.notes });
    map.set(r.order_id, list);
  }
  return map;
}

async function messagesOf(orderId: string): Promise<ChatMessageView[]> {
  const rows = await sql<{ id: string; sender: ChatMessageView["sender"]; body: string; created_at: Date }>(
    "select id, sender, body, created_at from order_messages where order_id = $1 order by created_at limit 200",
    [orderId],
  );
  return rows.map((m) => ({ id: m.id, sender: m.sender, body: m.body, at: iso(m.created_at)! }));
}

export async function getOrderByToken(token: string): Promise<OrderRow | null> {
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(token)) return null;
  return one<OrderRow>("select * from orders where tracking_token = $1", [token]);
}

export async function trackView(token: string, baseUrl: string): Promise<TrackView | null> {
  let o = await getOrderByToken(token);
  if (!o) return null;
  const r = (await getRestaurantById(o.restaurant_id))!;
  if (o.sim_started_at && o.status === "on_the_way") {
    await advanceSimulation(o, r, baseUrl);
    o = (await getOrderByToken(token))!;
  }
  const db = await getDb();
  const courier = await getCourier(db, o.courier_id);
  const items = (await itemsOf([o.id])).get(o.id) ?? [];
  const events = await sql<{ type: string; message: string; created_at: Date }>(
    "select type, message, created_at from order_events where order_id = $1 and type <> 'notified' order by created_at",
    [o.id],
  );
  const eta = computeEta(o, r, courier);
  // Only share the courier's live position while they are on the way to you (privacy).
  const showCourierPos = o.status === "on_the_way" || o.status === "ready";
  return {
    code: o.code,
    status: o.status,
    headline: customerHeadline(o.status, r.name, courier?.name),
    stepIndex: customerStepIndex(o.status),
    createdAt: iso(o.created_at)!,
    etaAt: eta.etaAt ? new Date(eta.etaAt).toISOString() : iso(o.eta_at),
    etaBasis: eta.basis,
    restaurant: { name: r.name, slug: r.slug, phone: r.phone, lat: r.lat, lng: r.lng, logoEmoji: r.logo_emoji, brandColor: r.brand_color },
    destination: o.lat != null && o.lng != null ? { lat: o.lat, lng: o.lng } : null,
    addressText: o.address_text,
    courier: courier
      ? {
          ...courierView(courier)!,
          lat: showCourierPos ? courier.lat : null,
          lng: showCourierPos ? courier.lng : null,
          phone: o.status === "on_the_way" ? courier.phone : "",
        }
      : null,
    items,
    subtotalCents: o.subtotal_cents,
    deliveryFeeCents: o.delivery_fee_cents,
    tipCents: o.tip_cents,
    totalCents: o.total_cents,
    paymentMethod: o.payment_method,
    paymentStatus: o.payment_status,
    deliveryPin: o.delivery_pin,
    requirePin: r.require_delivery_pin,
    events: events.map((e) => ({ type: e.type, message: e.message, at: iso(e.created_at)! })),
    messages: await messagesOf(o.id),
    rating: o.rating,
    simulated: !!o.sim_started_at,
    cancelReason: o.cancel_reason,
    now: new Date().toISOString(),
  };
}

export async function listPanelOrders(restaurantId: string): Promise<PanelOrder[]> {
  const rows = await sql<OrderRow & { help_open: number }>(
    `select o.*, (select count(*)::int from help_requests h where h.order_id = o.id and h.status = 'open') as help_open
     from orders o where o.restaurant_id = $1
       and (o.status in ('pending','preparing','ready','on_the_way') or o.created_at > now() - interval '12 hours')
     order by o.created_at desc limit 200`,
    [restaurantId],
  );
  const items = await itemsOf(rows.map((r) => r.id));
  const db = await getDb();
  const courierCache = new Map<string, CourierRow | null>();
  const out: PanelOrder[] = [];
  for (const o of rows) {
    if (o.courier_id && !courierCache.has(o.courier_id)) courierCache.set(o.courier_id, await getCourier(db, o.courier_id));
    out.push({
      id: o.id,
      code: o.code,
      status: o.status,
      source: o.source,
      customerName: o.customer_name,
      customerPhone: o.customer_phone,
      addressText: o.address_text,
      addressNotes: o.address_notes,
      lat: o.lat,
      lng: o.lng,
      items: items.get(o.id) ?? [],
      totalCents: o.total_cents,
      paymentMethod: o.payment_method,
      paymentStatus: o.payment_status,
      notes: o.notes,
      courier: courierView(o.courier_id ? (courierCache.get(o.courier_id) ?? null) : null),
      trackingToken: o.tracking_token,
      prepMinutes: o.prep_minutes,
      etaAt: iso(o.eta_at),
      createdAt: iso(o.created_at)!,
      acceptedAt: iso(o.accepted_at),
      deliveredAt: iso(o.delivered_at),
      unreadHelp: o.help_open,
    });
  }
  return out;
}

export async function courierJobs(courierId: string, restaurantId: string): Promise<CourierJob[]> {
  const rows = await sql<OrderRow>(
    `select * from orders where restaurant_id = $2 and status in ('preparing','ready','on_the_way')
       and (courier_id = $1 or courier_id is null)
     order by (courier_id = $1) desc nulls last, created_at limit 30`,
    [courierId, restaurantId],
  );
  if (rows.length === 0) return [];
  const r = (await getRestaurantById(restaurantId))!;
  const items = await itemsOf(rows.map((o) => o.id));
  const out: CourierJob[] = [];
  for (const o of rows) {
    const mine = o.courier_id === courierId;
    out.push({
      id: o.id,
      code: o.code,
      status: o.status,
      restaurant: { name: r.name, address: r.address, phone: r.phone, lat: r.lat, lng: r.lng },
      customerName: o.customer_name,
      // The customer's phone is only shared with the assigned courier.
      customerPhone: mine ? o.customer_phone : "",
      addressText: o.address_text,
      addressNotes: mine ? o.address_notes : "",
      lat: o.lat,
      lng: o.lng,
      totalCents: o.total_cents,
      paymentMethod: o.payment_method,
      paymentStatus: o.payment_status,
      requirePin: r.require_delivery_pin,
      items: items.get(o.id) ?? [],
      messages: mine ? await messagesOf(o.id) : [],
      mine,
    });
  }
  return out;
}

export async function addMessage(orderId: string, sender: ChatMessageView["sender"], text: string): Promise<void> {
  const clean = text.trim().slice(0, 500);
  if (!clean) throw new HttpError(400, "Escribe un mensaje.");
  const [{ n }] = await sql<{ n: number }>("select count(*)::int as n from order_messages where order_id = $1", [orderId]);
  if (n >= 200) throw new HttpError(429, "Se alcanzó el límite de mensajes de este pedido.");
  await sql("insert into order_messages (order_id, sender, body) values ($1,$2,$3)", [orderId, sender, clean]);
}

export function etaMinutesFrom(pos: LatLng, dest: LatLng, vehicle: string): number {
  return travelMinutes(pos, dest, vehicle);
}
