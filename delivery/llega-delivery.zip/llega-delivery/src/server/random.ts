import { randomBytes } from "node:crypto";

export function randomToken(bytes = 16): string {
  return randomBytes(bytes).toString("base64url");
}

export function randomCode(len: number, alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"): string {
  const bytes = randomBytes(len);
  let out = "";
  for (let i = 0; i < len; i++) out += alphabet[bytes[i] % alphabet.length];
  return out;
}

export function randomPin(): string {
  return String(randomBytes(2).readUInt16BE(0) % 10000).padStart(4, "0");
}
