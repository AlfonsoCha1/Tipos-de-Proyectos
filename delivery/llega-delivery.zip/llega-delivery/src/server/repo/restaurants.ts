import "server-only";
import type { MenuCategory, MenuItem, RestaurantPublic } from "@/lib/types";
import { one, sql, type Queryable } from "../db";

export interface RestaurantRow {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  cuisine: string;
  phone: string;
  address: string;
  lat: number;
  lng: number;
  brand_color: string;
  logo_emoji: string;
  is_open: boolean;
  prep_minutes: number;
  delivery_fee_cents: number;
  min_order_cents: number;
  delivery_radius_km: number;
  in_marketplace: boolean;
  accepts_cash: boolean;
  accepts_card_sim: boolean;
  require_delivery_pin: boolean;
  notify_channel: "sms" | "whatsapp" | "none";
  courier_invite_code: string;
  whatsapp_phone_number_id: string | null;
  active: boolean;
  created_at: Date;
}

export function toPublic(r: RestaurantRow): RestaurantPublic {
  return {
    id: r.id,
    slug: r.slug,
    name: r.name,
    tagline: r.tagline,
    cuisine: r.cuisine,
    logoEmoji: r.logo_emoji,
    brandColor: r.brand_color,
    isOpen: r.is_open,
    prepMinutes: r.prep_minutes,
    deliveryFeeCents: r.delivery_fee_cents,
    minOrderCents: r.min_order_cents,
    deliveryRadiusKm: r.delivery_radius_km,
    lat: r.lat,
    lng: r.lng,
    address: r.address,
    phone: r.phone,
    acceptsCash: r.accepts_cash,
    acceptsCardSim: r.accepts_card_sim,
    inMarketplace: r.in_marketplace,
  };
}

export async function getRestaurantBySlug(slug: string): Promise<RestaurantRow | null> {
  return one<RestaurantRow>("select * from restaurants where slug = $1 and active", [slug]);
}

export async function getRestaurantById(id: string, q?: Queryable): Promise<RestaurantRow | null> {
  const rows = q ? await q.query<RestaurantRow>("select * from restaurants where id = $1", [id]) : await sql<RestaurantRow>("select * from restaurants where id = $1", [id]);
  return rows[0] ?? null;
}

export async function listMarketplace(search?: string): Promise<RestaurantRow[]> {
  const term = search?.trim();
  if (term) {
    return sql<RestaurantRow>(
      `select distinct r.* from restaurants r left join menu_items m on m.restaurant_id = r.id and m.available
       where r.active and r.in_marketplace and (r.name ilike $1 or r.cuisine ilike $1 or m.name ilike $1)
       order by r.is_open desc, r.name`,
      [`%${term}%`],
    );
  }
  return sql<RestaurantRow>("select * from restaurants where active and in_marketplace order by is_open desc, name");
}

interface ItemRow {
  id: string;
  category_id: string | null;
  name: string;
  description: string;
  price_cents: number;
  emoji: string;
  available: boolean;
  sort: number;
}

function toItem(r: ItemRow): MenuItem {
  return {
    id: r.id,
    categoryId: r.category_id,
    name: r.name,
    description: r.description,
    priceCents: r.price_cents,
    emoji: r.emoji,
    available: r.available,
    sort: r.sort,
  };
}

/** Menu grouped by category. Items without a category go into "Otros". */
export async function getMenu(restaurantId: string, opts: { onlyAvailable?: boolean } = {}): Promise<MenuCategory[]> {
  const cats = await sql<{ id: string; name: string; sort: number }>(
    "select id, name, sort from menu_categories where restaurant_id = $1 order by sort, name",
    [restaurantId],
  );
  const items = (
    await sql<ItemRow>(
      `select id, category_id, name, description, price_cents, emoji, available, sort from menu_items
       where restaurant_id = $1 ${opts.onlyAvailable ? "and available" : ""} order by sort, name`,
      [restaurantId],
    )
  ).map(toItem);
  const out: MenuCategory[] = cats.map((c) => ({ ...c, items: items.filter((i) => i.categoryId === c.id) }));
  const loose = items.filter((i) => !i.categoryId || !cats.some((c) => c.id === i.categoryId));
  if (loose.length) out.push({ id: "none", name: "Otros", sort: 999, items: loose });
  return out;
}

export async function getMenuItemsByIds(restaurantId: string, ids: string[], q?: Queryable): Promise<MenuItem[]> {
  if (ids.length === 0) return [];
  const text = "select id, category_id, name, description, price_cents, emoji, available, sort from menu_items where restaurant_id = $1 and id = any($2::uuid[])";
  const rows = q ? await q.query<ItemRow>(text, [restaurantId, ids]) : await sql<ItemRow>(text, [restaurantId, ids]);
  return rows.map(toItem);
}
