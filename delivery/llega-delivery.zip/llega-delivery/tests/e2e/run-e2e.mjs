// End-to-end test in real Chromium: customer, restaurant and courier in separate browsers,
// with fake GPS, against a production build (`npm run build` first).
// Usage: npm run build && npm run test:e2e   (optionally: node tests/e2e/run-e2e.mjs ACF)
import { spawn } from "node:child_process";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const out = path.join(here, "output");
fs.mkdirSync(out, { recursive: true });
const executablePath =
  process.env.CHROMIUM_PATH ?? (fs.existsSync("/opt/pw-browsers/chromium-1194/chrome-linux/chrome") ? "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" : undefined);

let failures = 0;
function check(cond, msg) {
  console.log(`  ${cond ? "✓" : "✗"} ${msg}`);
  if (!cond) failures++;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Tepotzotlán demo data (see src/server/db/seed.ts)
const RESTAURANT = { latitude: 19.7142, longitude: -99.2219 };
const CUSTOMER = { latitude: 19.7188, longitude: -99.2168 };
const HALFWAY = { latitude: 19.7166, longitude: -99.2192 };

// ------------------------------------------------------------ mock Groq (OpenAI-compatible) for the AI agent
const aiLog = [];
function startMockAi(port) {
  const server = http.createServer((req, res) => {
    let raw = "";
    req.on("data", (c) => (raw += c));
    req.on("end", () => {
      const body = JSON.parse(raw || "{}");
      const system = body.messages?.[0]?.content ?? "";
      const last = [...(body.messages ?? [])].reverse().find((m) => m.role === "user")?.content ?? "";
      aiLog.push({ json: body.response_format?.type, last });
      const idOf = (name) => (system.match(new RegExp(`(m\\d+) \\| ${name} \\|`)) ?? [])[1];
      let reply = { reply: "¿Qué se te antoja? Tenemos tacos, gringas y aguas frescas.", actions: [] };
      if (/pastor/i.test(last)) {
        reply = {
          reply: "¡Va! Anoté 3 tacos al pastor y una jamaica. ¿Algo más?",
          actions: [
            { type: "add", item: idOf("Taco al pastor"), qty: 3, notes: "con todo" },
            { type: "add", item: idOf("Agua de jamaica"), qty: 1 },
            { type: "add", item: "m999", qty: 5 }, // invented: must be ignored
          ],
        };
      } else if (/nombre|soy/i.test(last)) {
        reply = {
          reply: "Gracias, Pedro. ¿Ya es todo?",
          actions: [
            { type: "set_name", value: "Pedro Gómez" },
            { type: "set_phone", value: "55 7777 8888" },
            { type: "set_address", value: "Calle Juárez 20, Centro", notes: "casa azul" },
          ],
        };
      } else if (/todo/i.test(last)) {
        reply = { reply: "Perfecto, te paso el resumen.", actions: [{ type: "checkout" }] };
      }
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify(reply) } }] }));
    });
  });
  server.listen(port);
  return server;
}

// ------------------------------------------------------------ app servers
function startNext(port, extraEnv) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llega-e2e-"));
  const env = {
    ...process.env,
    PORT: String(port),
    PGLITE_DIR: path.join(dir, "db"),
    SEED_DEMO: "1",
    AUTH_SECRET: "e2e-secret-0123456789abcdef-e2e",
    DEMO_TOOLS: "1",
    SIM_SECONDS: "12",
    GEOCODER: "off",
    APP_URL: `http://127.0.0.1:${port}`,
    NEXT_TELEMETRY_DISABLED: "1",
  };
  for (const k of ["DATABASE_URL", "GROQ_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "TWILIO_ACCOUNT_SID", "META_WHATSAPP_TOKEN"]) delete env[k];
  Object.assign(env, extraEnv);
  const proc = spawn("npx", ["next", "start", "-p", String(port)], { cwd: root, env, stdio: ["ignore", "pipe", "pipe"], detached: true });
  let logs = "";
  proc.stdout.on("data", (d) => (logs += d));
  proc.stderr.on("data", (d) => (logs += d));
  return {
    proc,
    base: `http://127.0.0.1:${port}`,
    logs: () => logs,
    ready: (async () => {
      for (let i = 0; i < 80; i++) {
        try {
          const r = await fetch(`http://127.0.0.1:${port}/negocios`);
          if (r.ok) {
            await fetch(`http://127.0.0.1:${port}/`); // first hit runs migrations + seed
            return;
          }
        } catch {}
        await sleep(500);
      }
      throw new Error(`next on ${port} did not start\n${logs}`);
    })(),
  };
}

async function newContext(browser, { geo, mobile = true, dark = false } = {}) {
  const ctx = await browser.newContext({
    viewport: mobile ? { width: 390, height: 844 } : { width: 1280, height: 900 },
    deviceScaleFactor: 2,
    geolocation: geo,
    permissions: geo ? ["geolocation"] : [],
    colorScheme: dark ? "dark" : "light",
    locale: "es-MX",
    timezoneId: "America/Mexico_City",
  });
  // Map tiles and Google Fonts are not reachable from the test sandbox; don't let that slow pages down.
  await ctx.route(/tile\.openstreetmap\.org|fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => {
    if (m.type() === "error" && !/ERR_FAILED|ERR_TUNNEL|net::|Failed to load resource/.test(m.text())) errors.push(m.text());
  });
  return { ctx, page, errors };
}

async function login(page, base, email, password = "demo1234") {
  await page.goto(`${base}${email.startsWith("repartidor") || email.startsWith("ana") ? "/repartidor/login" : "/panel/login"}`);
  await page.getByLabel("Correo").fill(email);
  await page.getByLabel("Contraseña").fill(password);
  await page.getByRole("button", { name: "Entrar" }).click();
  await page.waitForURL((u) => /^\/(panel|repartidor|admin)/.test(u.pathname) && !u.pathname.endsWith("/login"), { timeout: 15000 });
}

const shot = (page, name, fullPage = false) => page.screenshot({ path: path.join(out, `${name}.png`), fullPage });

// ------------------------------------------------------------ scenarios
async function scenarioA(browser, app) {
  console.log("\nA) Cliente pide en la tienda → restaurante acepta → repartidor con GPS → entrega con código → calificación");
  const cust = await newContext(browser, { geo: CUSTOMER });
  const p = cust.page;
  await p.goto(app.base);
  await p.getByRole("link", { name: /Tacos Don Chava/ }).first().waitFor();
  await shot(p, "A1-marketplace");
  await p.getByRole("link", { name: /Tacos Don Chava/ }).first().click();
  await p.getByRole("button", { name: "Agregar Taco al pastor" }).click();
  await p.getByRole("group", { name: "Cantidad de Taco al pastor" }).getByRole("button", { name: "Agregar uno" }).click();
  await p.getByRole("button", { name: "Agregar Agua de horchata" }).click();
  await shot(p, "A2-tienda");
  await p.getByTestId("go-checkout").click();
  await p.getByLabel("Nombre").fill("Ana López");
  await p.getByLabel("Celular").fill("55 1234 5678");
  await p.getByLabel("Dirección", { exact: true }).fill("Calle Hidalgo 12, Centro, Tepotzotlán");
  await p.getByRole("button", { name: "📍 Yo" }).click();
  await p.getByText(/km del restaurante/).waitFor();
  await p.getByRole("group", { name: "Propina" }).getByRole("button").nth(1).click();
  await shot(p, "A3-checkout", true);
  await p.getByTestId("place-order").click();
  await p.waitForURL(/\/t\/[A-Za-z0-9_-]+$/, { timeout: 15000 });
  const trackUrl = p.url();
  await p.getByTestId("headline").waitFor();
  check((await p.getByTestId("headline").textContent()).includes("Esperando"), "tracking page opens: waiting for the restaurant");
  await shot(p, "A4-rastreo-recibido");

  const rest = await newContext(browser, { mobile: false });
  await login(rest.page, app.base, "dueno@llega.demo");
  const card = rest.page.getByTestId("order-card").filter({ hasText: "Ana López" });
  await card.waitFor({ timeout: 10000 });
  check(true, "new order appears on the restaurant board");
  const cardText = await card.textContent();
  // 2 × $22 pastor + $30 horchata + $30 envío + $10 propina = $114, computed by the server from DB prices.
  check(cardText.includes("114.00"), "board shows the server-computed total ($114.00)");
  await shot(rest.page, "A5-panel-nuevo");
  await card.getByRole("button", { name: "Aceptar" }).click();
  await card.getByRole("button", { name: "Listo para recoger" }).waitFor();
  await card.getByLabel("Repartidor").selectOption({ label: /Luis/ }).catch(async () => {
    const opts = await card.locator("select").first().locator("option").allTextContents();
    const luis = opts.find((o) => o.startsWith("Luis"));
    await card.locator("select").first().selectOption({ label: luis });
  });
  await card.getByRole("button", { name: "Listo para recoger" }).click();
  await sleep(800);
  await shot(rest.page, "A6-panel-listo");

  const cour = await newContext(browser, { geo: RESTAURANT });
  await login(cour.page, app.base, "repartidor@llega.demo");
  await cour.page.getByLabel("Disponible para pedidos").check();
  await cour.page.getByTestId("my-job").waitFor({ timeout: 15000 });
  await cour.page.getByTestId("gps").filter({ hasText: "GPS activo" }).waitFor({ timeout: 15000 });
  check(true, "courier sees the assigned order and shares GPS");
  await sleep(1200);
  const pinsInView = await cour.page.evaluate(() => {
    const map = document.querySelector(".job-map .map")?.getBoundingClientRect();
    return [...document.querySelectorAll(".job-map .map-pin")].filter((el) => {
      const r = el.getBoundingClientRect();
      return map && r.top >= map.top - 5 && r.bottom <= map.bottom + 5 && r.left >= map.left - 5 && r.right <= map.right + 5;
    }).length;
  });
  check(pinsInView === 3, `courier map shows restaurant, courier and customer inside the frame (${pinsInView}/3)`);
  await shot(cour.page, "A7-repartidor-recoger");
  await cour.page.getByRole("button", { name: "Recogí el pedido" }).click();
  await cust.page.getByTestId("headline").filter({ hasText: "va en camino" }).waitFor({ timeout: 15000 });
  check(true, "customer sees 'Luis va en camino'");
  await cour.ctx.setGeolocation(HALFWAY);
  await sleep(6500);
  await cust.page.getByTestId("live").waitFor({ timeout: 10000 });
  const eta = await cust.page.getByTestId("eta").textContent();
  check(/\d{1,2}:\d{2}/.test(eta), `ETA shown from live GPS (${eta.trim()})`);
  await shot(cust.page, "A8-rastreo-en-camino");
  const pin = (await cust.page.getByTestId("pin").textContent()).replace(/\D/g, "");
  check(/^\d{4}$/.test(pin), "customer sees a 4-digit delivery code");

  await cour.ctx.setGeolocation(CUSTOMER);
  await cour.page.getByTestId("pin-input").fill("0000" === pin ? "1111" : "0000");
  await cour.page.getByRole("button", { name: "Entregado" }).click();
  await cour.page.getByText(/código de entrega no coincide/).waitFor();
  check(true, "wrong code is rejected");
  await cour.page.getByTestId("pin-input").fill(pin);
  await cour.page.getByRole("button", { name: "Entregado" }).click();
  await cour.page.getByText("¡Entregado! Buen trabajo.").waitFor();
  await shot(cour.page, "A9-repartidor-entregado");
  await cust.page.getByTestId("headline").filter({ hasText: "Entregado" }).waitFor({ timeout: 15000 });
  await cust.page.getByRole("button", { name: "5 estrellas" }).click();
  await cust.page.getByRole("button", { name: /Enviar/ }).last().click().catch(() => {});
  await cust.page.getByText("¡Gracias por tu calificación!").waitFor({ timeout: 8000 });
  check(true, "customer rates the delivery");
  await shot(cust.page, "A10-rastreo-entregado");

  await rest.page.goto(`${app.base}/panel/mensajes`);
  await rest.page.getByTestId("notification").first().waitFor();
  const inbox = await rest.page.locator("body").innerText();
  check(inbox.includes("va en camino") && inbox.includes(trackUrl.replace(/^https?:\/\/[^/]+/, "")), "SMS log contains the 'on the way' message with the tracking link");
  await shot(rest.page, "A11-panel-mensajes");

  for (const [who, c] of [["customer", cust], ["restaurant", rest], ["courier", cour]]) {
    check(c.errors.length === 0, `no page errors (${who}) ${c.errors.join(" | ").slice(0, 300)}`);
    await c.ctx.close();
  }
}

async function scenarioB(browser, app) {
  console.log("\nB) Solo rastreo: pedido capturado en el panel → SMS con link → repartidor simulado → entregado");
  const rest = await newContext(browser, { geo: CUSTOMER, mobile: false });
  await login(rest.page, app.base, "dueno@llega.demo");
  await rest.page.goto(`${app.base}/panel/nuevo`);
  await rest.page.getByLabel("Nombre").fill("Carlos Pérez");
  await rest.page.getByLabel("Celular").fill("5598765432");
  await rest.page.getByLabel("Dirección", { exact: true }).fill("Av. Juárez 45, Tepotzotlán");
  await rest.page.getByText("Marcar en el mapa").click();
  await rest.page.getByRole("button", { name: "📍 Yo" }).click();
  await sleep(500);
  await rest.page.getByLabel("Total a cobrar").fill("230");
  await shot(rest.page, "B1-pedido-manual", true);
  await rest.page.getByRole("button", { name: /Crear|Enviar|Guardar/ }).last().click();
  await rest.page.getByTestId("manual-done").waitFor({ timeout: 10000 });
  const link = await rest.page.getByLabel("Link de rastreo").inputValue().catch(async () => rest.page.getByLabel("Link de rastreo").textContent());
  check(/\/t\/[A-Za-z0-9_-]+/.test(link), "tracking link created for a phone/WhatsApp order");
  await rest.page.goto(`${app.base}/panel`);
  const card = rest.page.getByTestId("order-card").filter({ hasText: "Carlos Pérez" });
  await card.waitFor();
  await card.getByRole("button", { name: "▶ Simular entrega (demo)" }).click();
  const cust = await newContext(browser, {});
  await cust.page.goto(link.startsWith("http") ? link : `${app.base}${link}`);
  await cust.page.getByTestId("headline").filter({ hasText: "va en camino" }).waitFor({ timeout: 15000 });
  await sleep(4000);
  await shot(cust.page, "B2-rastreo-simulado");
  check(true, "simulated courier on the way");
  await cust.page.getByTestId("headline").filter({ hasText: "Entregado" }).waitFor({ timeout: 25000 });
  check(true, "simulation ends delivered");
  const inbox = await (await fetch(`${app.base}/api/panel/notifications`, { headers: { cookie: (await rest.ctx.cookies()).map((c) => `${c.name}=${c.value}`).join("; ") } })).json();
  check(inbox.notifications.some((n) => n.body.includes("está preparando tu pedido")), "customer got the 'tracking only' SMS (logged in demo mode)");
  for (const c of [rest, cust]) {
    check(c.errors.length === 0, `no page errors ${c.errors.join(" | ").slice(0, 300)}`);
    await c.ctx.close();
  }
}

async function scenarioC(browser, app) {
  console.log("\nC) Asistente por chat SIN IA (reglas) toma un pedido real");
  const c = await newContext(browser, { geo: CUSTOMER });
  const p = c.page;
  await p.goto(`${app.base}/r/tacos-don-chava/chat`);
  check((await p.locator(".chip").first().textContent()).includes("Sin IA"), "chat shows it is running without AI");
  const say = async (t) => {
    const n = await p.locator(".bubble").count();
    await p.getByLabel("Escribe tu pedido").fill(t);
    await p.getByRole("button", { name: "Enviar" }).click();
    await p.waitForFunction((k) => document.querySelectorAll(".bubble").length >= k + 2 && !document.querySelector('[aria-label="El asistente está escribiendo"]'), n);
  };
  await say("hola, quiero 3 tacos de suadero sin cebolla y una gringa");
  check((await p.getByTestId("agent-cart").textContent()).includes("3× Taco de suadero"), "rules agent understood quantities and dishes");
  await say("es todo");
  await say("me llamo Diana Ruiz");
  await say("es todo");
  await say("5511223344");
  await say("mi dirección es Calle Morelos 3, Centro");
  await p.getByRole("button", { name: "📍 Compartir ubicación" }).click();
  await p.getByText("¿Lo confirmo?").waitFor({ timeout: 10000 });
  await shot(p, "C1-chat-resumen");
  await say("sí");
  await p.getByTestId("agent-track").waitFor();
  await shot(p, "C2-chat-confirmado");
  await p.getByTestId("agent-track").click();
  await p.getByTestId("headline").waitFor();
  check(p.url().includes("/t/"), "chat order opens live tracking");
  check(c.errors.length === 0, `no page errors ${c.errors.join(" | ").slice(0, 300)}`);
  await c.ctx.close();
}

async function scenarioD(browser, app) {
  console.log("\nD) Alta de restaurante → menú → invitar repartidor → el repartidor se une");
  const o = await newContext(browser, { geo: { latitude: 19.72, longitude: -99.23 }, mobile: false });
  const p = o.page;
  await p.goto(`${app.base}/panel/registro`);
  await p.getByLabel("Nombre", { exact: true }).fill("Tortas La Güera");
  await p.getByLabel("Tipo de comida").fill("Tortas");
  await p.getByLabel("Tu nombre").fill("María");
  await p.getByLabel("Correo").fill("maria@tortas.test");
  await p.getByLabel("Contraseña").fill("secreta123");
  await p.getByLabel("Celular").fill("5522334455");
  await p.getByLabel("Dirección", { exact: true }).fill("Calle 5 de Mayo 9, Tepotzotlán");
  await p.getByRole("button", { name: "📍 Yo" }).click();
  await sleep(400);
  await shot(p, "D1-registro", true);
  await p.getByRole("button", { name: /Crear/ }).click();
  await p.waitForURL(/\/panel\/ajustes/, { timeout: 15000 });
  await p.getByText("¡Tu restaurante está creado!").waitFor();
  check(true, "restaurant signup creates the account and opens settings");
  await shot(p, "D2-ajustes", true);
  await p.goto(`${app.base}/panel/menu`);
  await p.getByPlaceholder("Nueva categoría (ej. Postres)").fill("Tortas");
  await p.getByRole("button", { name: "Agregar categoría" }).click();
  await p.getByText("Tortas", { exact: true }).first().waitFor();
  await p.getByRole("button", { name: "+ Agregar platillo" }).click();
  await p.getByLabel("Nombre").first().fill("Torta de milanesa");
  await p.getByLabel("Precio (MXN)").first().fill("85");
  await p.getByRole("button", { name: "Guardar" }).first().click();
  await p.getByText("Torta de milanesa").first().waitFor();
  await shot(p, "D3-menu", true);
  const store = await fetch(`${app.base}/r/tortas-la-guera`).then((r) => r.text());
  check(store.includes("Torta de milanesa"), "new dish appears on the public store");
  await p.goto(`${app.base}/panel/equipo`);
  const code = (await p.getByTestId("invite-code").textContent()).trim();
  check(/^[A-Z0-9]{6,10}$/.test(code), `invite code shown (${code})`);
  await shot(p, "D4-equipo", true);
  const c = await newContext(browser, { geo: RESTAURANT });
  await c.page.goto(`${app.base}/repartidor/unirse?code=${code}`);
  await c.page.getByLabel("Nombre").fill("Jorge");
  await c.page.getByLabel("Correo").fill("jorge@tortas.test");
  await c.page.getByLabel("Contraseña").fill("secreta123");
  await c.page.getByLabel("Celular").fill("5533445566");
  await c.page.getByRole("button", { name: /Unirme|Crear|Entrar/ }).click();
  await c.page.waitForURL(/\/repartidor$/, { timeout: 15000 });
  check(true, "courier joined the team with the invite code");
  await shot(c.page, "D5-repartidor-nuevo");
  for (const x of [o, c]) {
    check(x.errors.length === 0, `no page errors ${x.errors.join(" | ").slice(0, 300)}`);
    await x.ctx.close();
  }
}

async function scenarioE(app) {
  console.log("\nE) API pública (solo rastreo) y seguridad");
  // Owner creates an API key through the panel API (same as the button in Ajustes).
  const loginRes = await fetch(`${app.base}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "dueno@llega.demo", password: "demo1234" }) });
  const cookie = loginRes.headers.get("set-cookie").split(";")[0];
  const { key } = await (await fetch(`${app.base}/api/panel/api-keys`, { method: "POST", headers: { "Content-Type": "application/json", cookie }, body: JSON.stringify({ name: "POS" }) })).json();
  check(key?.startsWith("llk_"), "API key created");
  const res = await fetch(`${app.base}/api/v1/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ customer: { name: "Cliente POS", phone: "5512121212" }, address: { text: "Calle 1", lat: 19.716, lng: -99.219 }, items: [{ name: "Combo", qty: 2, unitPriceCents: 9900 }], notify: true }),
  });
  const created = await res.json();
  check(res.status === 201 && created.tracking_url?.includes("/t/"), "POST /api/v1/orders returns a tracking link");
  const st = await fetch(`${app.base}/api/v1/orders/${created.id}/status`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` }, body: JSON.stringify({ status: "ready" }) });
  check((await st.json()).status === "ready", "POS can mark the order ready");
  const bad = await fetch(`${app.base}/api/v1/orders`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer llk_invalid" }, body: "{}" });
  check(bad.status === 401, "invalid API key → 401");
  const noAuth = await fetch(`${app.base}/api/panel/orders`);
  check(noAuth.status === 401, "panel API without session → 401");
  const csrf = await fetch(`${app.base}/api/panel/settings`, { method: "PATCH", headers: { "Content-Type": "application/json", cookie, Origin: "https://evil.example" }, body: JSON.stringify({ isOpen: false }) });
  check(csrf.status === 403, "cross-site request with the owner's cookie → 403");
  const courierOnPanel = await fetch(`${app.base}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "repartidor@llega.demo", password: "demo1234" }) });
  const cc = courierOnPanel.headers.get("set-cookie").split(";")[0];
  const forbidden = await fetch(`${app.base}/api/panel/orders`, { headers: { cookie: cc } });
  check(forbidden.status === 403, "courier cannot use the restaurant panel API → 403");
  const wrongPw = await fetch(`${app.base}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "dueno@llega.demo", password: "nope" }) });
  check(wrongPw.status === 401, "wrong password → 401");
  const fake = await fetch(`${app.base}/api/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ slug: "tacos-don-chava", items: [{ itemId: "00000000-0000-4000-8000-000000000000", qty: 1 }], customer: { name: "X Y", phone: "5511111111" }, address: { text: "Calle 2 #3", lat: 19.716, lng: -99.219 }, paymentMethod: "cash" }),
  });
  check(fake.status === 400, "order with an item that isn't on the menu → 400");
  const track404 = await fetch(`${app.base}/api/track/not-a-real-token-123456`);
  check(track404.status === 404, "unknown tracking token → 404");
}

async function scenarioF(browser, app) {
  console.log("\nF) Agente CON IA (API tipo Groq simulada): la IA propone, el código valida y pide confirmación");
  const c = await newContext(browser, { geo: CUSTOMER, dark: true });
  const p = c.page;
  await p.goto(`${app.base}/r/tacos-don-chava/chat`);
  check((await p.locator(".chip").first().textContent()).includes("IA"), "chat shows the AI agent is active");
  const say = async (t) => {
    const n = await p.locator(".bubble").count();
    await p.getByLabel("Escribe tu pedido").fill(t);
    await p.getByRole("button", { name: "Enviar" }).click();
    await p.waitForFunction((k) => document.querySelectorAll(".bubble").length >= k + 2 && !document.querySelector('[aria-label="El asistente está escribiendo"]'), n);
  };
  await say("quiero 3 de pastor y una de jamaica");
  const cart = await p.getByTestId("agent-cart").textContent();
  check(cart.includes("3× Taco al pastor") && cart.includes("1× Agua de jamaica") && !cart.includes("5×"), "AI actions applied; the invented item was ignored");
  await say("soy Pedro, mi nombre es Pedro Gómez");
  await say("es todo");
  await p.getByRole("button", { name: "📍 Compartir ubicación" }).click();
  await p.getByText("¿Lo confirmo?").waitFor({ timeout: 10000 });
  await shot(p, "F1-chat-ia-oscuro");
  await say("sí, confirmo");
  await p.getByTestId("agent-track").waitFor();
  check(aiLog.length >= 3 && aiLog.every((l) => l.json === "json_object"), `AI called in JSON mode (${aiLog.length} calls)`);
  check(c.errors.length === 0, `no page errors ${c.errors.join(" | ").slice(0, 300)}`);
  await c.ctx.close();
}

// ------------------------------------------------------------ run
const mockAi = startMockAi(4020);
const app = startNext(3301, {});
const appAi = startNext(3302, { GROQ_API_KEY: "mock", GROQ_BASE_URL: "http://127.0.0.1:4020/v1" });
let browser;
try {
  await Promise.all([app.ready, appAi.ready]);
  browser = await chromium.launch({ executablePath });
  const only = process.argv[2];
  const run = [
    ["A", () => scenarioA(browser, app)],
    ["B", () => scenarioB(browser, app)],
    ["C", () => scenarioC(browser, app)],
    ["D", () => scenarioD(browser, app)],
    ["E", () => scenarioE(app)],
    ["F", () => scenarioF(browser, appAi)],
  ];
  for (const [name, fn] of run) {
    if (only && !only.includes(name)) continue;
    try {
      await fn();
    } catch (e) {
      failures++;
      console.log(`  ✗ scenario ${name} crashed: ${String(e.message).split("\n").slice(0, 3).join(" ")}`);
      for (const ctx of browser.contexts()) {
        for (const [i, pg] of ctx.pages().entries()) await pg.screenshot({ path: path.join(out, `${name}-crash-${i}.png`), fullPage: true }).catch(() => {});
        await ctx.close().catch(() => {});
      }
    }
  }
} finally {
  await browser?.close();
  for (const a of [app, appAi]) {
    try {
      process.kill(-a.proc.pid, "SIGTERM");
    } catch {}
  }
  mockAi.close();
  fs.writeFileSync(path.join(out, "server.log"), app.logs());
  fs.writeFileSync(path.join(out, "server-ai.log"), appAi.logs());
}
console.log(failures ? `\n${failures} check(s) failed` : "\nAll e2e checks passed");
process.exit(failures ? 1 : 0);
