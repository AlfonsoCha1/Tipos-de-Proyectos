import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";

// Real Postgres (PGlite) in memory, with demo data.
process.env.PGLITE_DIR = "memory";
process.env.SEED_DEMO = "1";
delete process.env.GROQ_API_KEY;
delete process.env.OPENAI_API_KEY;
delete process.env.ANTHROPIC_API_KEY;

const BASE = "https://llega.test";

const { one, sql, getDb } = await import("@/server/db");
const { placeOrder, transitionOrder, assignCourier, createManualOrder, trackView, listPanelOrders, courierJobs, startSimulation } = await import("@/server/orders");
const { handleAgentTurn } = await import("@/server/agent");
const { getRestaurantBySlug, getMenu } = await import("@/server/repo/restaurants");

type R = NonNullable<Awaited<ReturnType<typeof getRestaurantBySlug>>>;
let tacos: R;
let menu: { id: string; name: string; priceCents: number }[];
let luis: { id: string };

beforeAll(async () => {
  await getDb();
  tacos = (await getRestaurantBySlug("tacos-don-chava"))!;
  menu = (await getMenu(tacos.id)).flatMap((c) => c.items);
  luis = (await one<{ id: string }>("select id from users where email = 'repartidor@llega.demo'"))!;
});

afterEach(() => {
  vi.unstubAllGlobals();
  delete process.env.GROQ_API_KEY;
  delete process.env.GROQ_BASE_URL;
});

const near = { lat: 19.7205, lng: -99.2150 };
const byName = (n: string) => menu.find((m) => m.name === n)!;

describe("checkout", () => {
  it("prices come from the database and totals add up", async () => {
    const o = await placeOrder(
      {
        restaurantId: tacos.id,
        source: "web",
        items: [
          { itemId: byName("Taco al pastor").id, qty: 3 },
          { itemId: byName("Agua de horchata").id, qty: 1 },
        ],
        customer: { name: "Ana", phone: "55 1111 2222" },
        address: { text: "Calle Hidalgo 12, Centro", ...near },
        paymentMethod: "cash",
        tipCents: 1000,
      },
      BASE,
    );
    const row = (await one<{ subtotal_cents: number; total_cents: number; status: string; customer_phone: string }>("select * from orders where id = $1", [o.id]))!;
    expect(row.subtotal_cents).toBe(3 * 2200 + 3000);
    expect(row.total_cents).toBe(3 * 2200 + 3000 + tacos.delivery_fee_cents + 1000);
    expect(row.status).toBe("pending");
    expect(row.customer_phone).toBe("+525511112222");
    const notes = await sql<{ status: string; body: string }>("select status, body from notifications where order_id = $1", [o.id]);
    expect(notes[0].status).toBe("logged");
    expect(notes[0].body).toContain(`${BASE}/t/${o.trackingToken}`);
  });

  it("rejects addresses outside the delivery radius", async () => {
    await expect(
      placeOrder(
        {
          restaurantId: tacos.id,
          source: "web",
          items: [{ itemId: byName("Taco al pastor").id, qty: 1 }],
          customer: { name: "Lejos", phone: "5511112222" },
          address: { text: "Zócalo, CDMX", lat: 19.4326, lng: -99.1332 },
          paymentMethod: "cash",
        },
        BASE,
      ),
    ).rejects.toThrow(/entrega hasta/);
  });

  it("rejects unknown or unavailable items", async () => {
    await expect(
      placeOrder(
        {
          restaurantId: tacos.id,
          source: "web",
          items: [{ itemId: "00000000-0000-0000-0000-000000000000", qty: 1 }],
          customer: { name: "Xavi", phone: "5511112222" },
          address: { text: "Calle 1 #2", ...near },
          paymentMethod: "cash",
        },
        BASE,
      ),
    ).rejects.toThrow(/ya no existe/);
  });
});

describe("full delivery lifecycle", () => {
  it("restaurant accepts, courier picks up, PIN required to deliver", async () => {
    const o = await placeOrder(
      {
        restaurantId: tacos.id,
        source: "marketplace",
        items: [{ itemId: byName("Gringa de pastor").id, qty: 2 }],
        customer: { name: "Beto", phone: "5522223333" },
        address: { text: "Av. Juárez 5", ...near },
        paymentMethod: "cash",
      },
      BASE,
    );
    await expect(transitionOrder(o.id, "delivered", { actor: "restaurant", restaurantId: tacos.id }, BASE)).rejects.toThrow(/No se puede/);
    await transitionOrder(o.id, "preparing", { actor: "restaurant", restaurantId: tacos.id, prepMinutes: 10 }, BASE);
    await assignCourier(o.id, tacos.id, luis.id);

    const jobs = await courierJobs(luis.id, tacos.id);
    const job = jobs.find((j) => j.id === o.id)!;
    expect(job.mine).toBe(true);
    expect(job.customerPhone).toBe("+525522223333");

    await sql("update courier_status set lat = $2, lng = $3, updated_at = now() where user_id = $1", [luis.id, tacos.lat, tacos.lng]);
    await transitionOrder(o.id, "on_the_way", { actor: "courier", courierId: luis.id }, BASE);
    const view = (await trackView(o.trackingToken, BASE))!;
    expect(view.status).toBe("on_the_way");
    expect(view.stepIndex).toBe(2);
    expect(view.courier?.name).toBe("Luis");
    expect(view.courier?.lat).toBeCloseTo(tacos.lat, 4);
    expect(view.etaBasis).toBe("live");

    await expect(transitionOrder(o.id, "delivered", { actor: "courier", courierId: luis.id, pin: "0000x" }, BASE)).rejects.toThrow(/código de entrega/);
    const pin = (await one<{ delivery_pin: string }>("select delivery_pin from orders where id = $1", [o.id]))!.delivery_pin;
    const done = await transitionOrder(o.id, "delivered", { actor: "courier", courierId: luis.id, pin }, BASE);
    expect(done.status).toBe("delivered");
    expect(done.payment_status).toBe("paid");
    const msgs = await sql<{ body: string }>("select body from notifications where order_id = $1 order by created_at", [o.id]);
    expect(msgs.map((m) => m.body).join(" | ")).toMatch(/va en camino.*código de entrega es \d{4}/);
  });

  it("a courier from another restaurant cannot take the order", async () => {
    const ana = (await one<{ id: string }>("select id from users where email = 'ana@llega.demo'"))!;
    const o = await createManualOrder(
      { restaurantId: tacos.id, source: "manual", customer: { name: "C", phone: "5533334444" }, address: { text: "Calle 3" }, items: [], totalCents: 15000, paymentMethod: "prepaid", notify: false },
      BASE,
    );
    await expect(transitionOrder(o.id, "on_the_way", { actor: "courier", courierId: ana.id }, BASE)).rejects.toThrow(/no es de tu restaurante/);
  });

  it("tracking-only orders start in preparation and can be simulated to delivery", async () => {
    process.env.SIM_SECONDS = "1";
    const o = await createManualOrder(
      {
        restaurantId: tacos.id,
        source: "manual",
        customer: { name: "Dani", phone: "5544445555" },
        address: { text: "Calle Morelos 8", ...near },
        items: [{ name: "Pedido por teléfono", qty: 1, unitPriceCents: 18000 }],
        paymentMethod: "cash",
        notify: true,
      },
      BASE,
    );
    expect(o.status).toBe("preparing");
    const note = await one<{ body: string }>("select body from notifications where order_id = $1", [o.id]);
    expect(note?.body).toMatch(/está preparando tu pedido/);
    await startSimulation(o.id, tacos.id, BASE);
    const mid = (await trackView(o.tracking_token, BASE))!;
    expect(mid.status).toBe("on_the_way");
    expect(mid.simulated).toBe(true);
    const panel = await listPanelOrders(tacos.id);
    expect(panel.some((p) => p.id === o.id)).toBe(true);
  });
});

describe("ordering agent without AI (rules)", () => {
  it("takes a whole order by chat and places a real order after confirmation", async () => {
    const say = async (text: string, sessionId?: string, location?: { lat: number; lng: number }) =>
      handleAgentTurn({ restaurant: tacos, channel: "web", sessionId, text, location }, BASE);
    let t = await say("hola");
    expect(t.mode).toBe("rules");
    const sid = t.sessionId;
    t = await say("quiero 2 tacos al pastor y una horchata", sid);
    expect(t.cart.lines.map((l) => [l.name, l.qty])).toEqual([["Taco al pastor", 2], ["Agua de horchata", 1]]);
    t = await say("es todo", sid);
    expect(t.reply).toMatch(/nombre/);
    t = await say("me llamo Carla Ruiz", sid);
    t = await say("es todo", sid);
    expect(t.reply).toMatch(/celular/);
    t = await say("55 6666 7777", sid);
    expect(t.reply).toMatch(/dirección/);
    t = await say("mi dirección es Calle Hidalgo 45, Centro", sid);
    expect(t.reply).toMatch(/ubicación/);
    t = await say("", sid, near);
    expect(t.awaitingConfirmation).toBe(true);
    expect(t.reply).toMatch(/¿Lo confirmo\?/);
    t = await say("sí", sid);
    expect(t.order?.code).toMatch(/^[A-Z0-9]{4}$/);
    const row = await one<{ source: string; total_cents: number; customer_name: string }>("select source, total_cents, customer_name from orders where code = $1 and restaurant_id = $2", [t.order!.code, tacos.id]);
    expect(row?.source).toBe("agent");
    expect(row?.customer_name).toBe("Carla Ruiz");
    expect(row?.total_cents).toBe(2 * 2200 + 3000 + tacos.delivery_fee_cents);
  });
});

describe("ordering agent: customer says everything quickly", () => {
  it("handles dishes + 'es todo' in one message, then details, 'sin ubicación' and 'sí'", async () => {
    const say = async (text: string, sessionId?: string) => handleAgentTurn({ restaurant: tacos, channel: "web", sessionId, text }, BASE);
    let t = await say("2 tacos al pastor y una horchata, es todo");
    expect(t.cart.lines).toHaveLength(2);
    expect(t.reply).toMatch(/Llevas: 2× Taco al pastor.*nombre/s);
    const sid = t.sessionId;
    t = await say("me llamo Pepe Luna", sid);
    expect(t.reply).toMatch(/celular/);
    t = await say("5512345678", sid);
    expect(t.reply).toMatch(/dirección/);
    t = await say("mi dirección es Calle Hidalgo 3, Centro", sid);
    expect(t.reply).toMatch(/ubicación/);
    t = await say("sin ubicación", sid);
    expect(t.awaitingConfirmation).toBe(true);
    t = await say("sí", sid);
    expect(t.order?.code).toBeTruthy();
    const row = await one<{ lat: number | null; address_text: string }>("select lat, address_text from orders where code = $1 and restaurant_id = $2", [t.order!.code, tacos.id]);
    expect(row?.lat).toBeNull();
    expect(row?.address_text).toBe("Calle Hidalgo 3, Centro");
  });

  it("never says 'no te entendí' without telling the customer what to do next", async () => {
    let t = await handleAgentTurn({ restaurant: tacos, channel: "web", text: "una gringa" }, BASE);
    t = await handleAgentTurn({ restaurant: tacos, channel: "web", sessionId: t.sessionId, text: "qwerty" }, BASE);
    expect(t.reply).toMatch(/nombre/);
  });
});

describe("ordering agent with AI (mocked Groq API)", () => {
  it("drops invented items and still requires a code-generated confirmation", async () => {
    process.env.GROQ_API_KEY = "test";
    process.env.GROQ_BASE_URL = "http://mock.local/v1";
    const replies = [
      // The model tries to add a real item (m1) and an invented one (m99), and to check out immediately.
      { reply: "¡Claro! Agregué 3 tacos al pastor.", actions: [{ type: "add", item: "m1", qty: 3 }, { type: "add", item: "m99", qty: 1 }, { type: "set_name", value: "Luis Mora" }, { type: "set_phone", value: "5588889999" }, { type: "set_address", value: "Calle Juárez 20" }, { type: "checkout" }] },
      { reply: "ok", actions: [] },
    ];
    const calls: { body: string }[] = [];
    vi.stubGlobal("fetch", async (url: string, init: RequestInit) => {
      calls.push({ body: String(init.body) });
      const content = JSON.stringify(replies[Math.min(calls.length - 1, replies.length - 1)]);
      return new Response(JSON.stringify({ choices: [{ message: { content } }] }), { status: 200 });
    });
    let t = await handleAgentTurn({ restaurant: tacos, channel: "web", text: "3 de pastor a nombre de Luis Mora, 5588889999, Calle Juárez 20", location: near }, BASE);
    expect(t.mode).toBe("ai");
    expect(t.cart.lines).toHaveLength(1);
    expect(t.cart.lines[0].qty).toBe(3);
    // No order yet: code shows a summary and waits for "sí".
    expect(t.order).toBeUndefined();
    expect(t.awaitingConfirmation).toBe(true);
    expect(JSON.parse(calls[0].body).response_format).toEqual({ type: "json_object" });
    t = await handleAgentTurn({ restaurant: tacos, channel: "web", sessionId: t.sessionId, text: "sí, confirmo" }, BASE);
    expect(t.order?.trackingUrl).toContain(`${BASE}/t/`);
  });

  it("falls back to rules when the AI provider fails", async () => {
    process.env.GROQ_API_KEY = "test";
    vi.stubGlobal("fetch", async () => new Response("rate limited", { status: 429 }));
    const t = await handleAgentTurn({ restaurant: tacos, channel: "web", text: "2 gringas" }, BASE);
    expect(t.fallback).toBe(true);
    expect(t.cart.lines[0]?.name).toBe("Gringa de pastor");
  });
});
