import { createHmac } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";
import { composeMessage, templateParams, type NotifyOrder } from "@/server/notify";
import { MetaWhatsAppProvider, TwilioProvider, smsProvider, whatsappProvider } from "@/server/notify/providers";
import { verifyMetaSignature, verifyTwilioSignature } from "@/server/agent/whatsapp";

const order: NotifyOrder = {
  id: "o1",
  code: "AB12",
  restaurantId: "r1",
  restaurantName: "Tacos Don Chava",
  notifyChannel: "whatsapp",
  customerPhone: "+525512345678",
  trackingToken: "tok_abcdefghijklmnop",
  deliveryPin: "4821",
  requirePin: true,
  totalCents: 11400,
  etaAt: new Date("2026-09-27T20:05:00Z"),
  courierName: "Luis",
};

afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

function captureFetch() {
  const calls: { url: string; init: RequestInit }[] = [];
  vi.stubGlobal("fetch", async (url: string, init: RequestInit) => {
    calls.push({ url, init });
    return new Response(JSON.stringify({ sid: "SM1", messages: [{ id: "wamid.1" }] }), { status: 200 });
  });
  return calls;
}

describe("messages", () => {
  it("writes the 'on the way' message like a delivery app, with PIN and link", () => {
    const text = composeMessage("on_the_way", order, "https://llega.mx");
    expect(text).toContain("Luis va en camino");
    expect(text).toContain("4821");
    expect(text).toContain("https://llega.mx/t/tok_abcdefghijklmnop");
    expect(templateParams("on_the_way", order, "https://llega.mx")).toEqual(["Luis", "Tacos Don Chava", "4821", "https://llega.mx/t/tok_abcdefghijklmnop"]);
  });

  it("falls back to the demo log when no provider keys are set", async () => {
    vi.stubEnv("TWILIO_ACCOUNT_SID", "");
    vi.stubEnv("META_WHATSAPP_TOKEN", "");
    expect(smsProvider().id).toBe("log");
    expect(whatsappProvider().id).toBe("log");
    expect((await smsProvider().send("+52", "x")).status).toBe("logged");
  });
});

describe("Meta WhatsApp Cloud API", () => {
  it("sends free text inside the service window and an approved template otherwise", async () => {
    const calls = captureFetch();
    const p = new MetaWhatsAppProvider("tkn", "123456", "https://graph.test/v21.0");
    await p.send("+525512345678", "hola");
    expect(JSON.parse(String(calls[0].init.body))).toMatchObject({ type: "text", to: "525512345678", text: { body: "hola" } });
    vi.stubEnv("META_USE_TEMPLATES", "1");
    await p.send("+525512345678", "texto", { event: "on_the_way", params: ["Luis", "Tacos", "4821", "https://x/t/1"] });
    const body = JSON.parse(String(calls[1].init.body));
    expect(calls[1].url).toBe("https://graph.test/v21.0/123456/messages");
    expect(body.type).toBe("template");
    expect(body.template.name).toBe("llega_on_the_way");
    expect(body.template.language.code).toBe("es_MX");
    expect(body.template.components[0].parameters.map((x: { text: string }) => x.text)).toEqual(["Luis", "Tacos", "4821", "https://x/t/1"]);
  });
});

describe("Twilio", () => {
  it("sends SMS with Basic auth and WhatsApp with a Content Template when configured", async () => {
    const calls = captureFetch();
    const sms = new TwilioProvider("twilio-sms", "AC1", "secret", "+15550001111", false, "https://twilio.test");
    await sms.send("+525512345678", "hola");
    const f1 = new URLSearchParams(String(calls[0].init.body));
    expect(calls[0].url).toBe("https://twilio.test/2010-04-01/Accounts/AC1/Messages.json");
    expect((calls[0].init.headers as Record<string, string>).Authorization).toBe(`Basic ${Buffer.from("AC1:secret").toString("base64")}`);
    expect(f1.get("To")).toBe("+525512345678");
    expect(f1.get("Body")).toBe("hola");

    vi.stubEnv("TWILIO_CONTENT_SID_ON_THE_WAY", "HX123");
    const wa = new TwilioProvider("twilio-whatsapp", "AC1", "secret", "+14155238886", true, "https://twilio.test");
    await wa.send("+525512345678", "texto", { event: "on_the_way", params: ["Luis", "Tacos"] });
    const f2 = new URLSearchParams(String(calls[1].init.body));
    expect(f2.get("To")).toBe("whatsapp:+525512345678");
    expect(f2.get("From")).toBe("whatsapp:+14155238886");
    expect(f2.get("ContentSid")).toBe("HX123");
    expect(JSON.parse(f2.get("ContentVariables")!)).toEqual({ "1": "Luis", "2": "Tacos" });
    expect(f2.get("Body")).toBeNull();
  });
});

describe("webhook signatures", () => {
  it("accepts genuine Meta and Twilio signatures and rejects forged ones", () => {
    const raw = JSON.stringify({ entry: [] });
    const good = `sha256=${createHmac("sha256", "appsecret").update(raw).digest("hex")}`;
    expect(verifyMetaSignature(raw, good, "appsecret")).toBe(true);
    expect(verifyMetaSignature(raw, good, "other")).toBe(false);
    expect(verifyMetaSignature(raw, null, "appsecret")).toBe(false);

    const url = "https://llega.mx/api/webhooks/twilio";
    const params = { From: "whatsapp:+525512345678", Body: "hola", To: "whatsapp:+14155238886" };
    const data = url + Object.keys(params).sort().map((k) => k + params[k as keyof typeof params]).join("");
    const sig = createHmac("sha1", "tok").update(data).digest("base64");
    expect(verifyTwilioSignature(url, params, sig, "tok")).toBe(true);
    expect(verifyTwilioSignature(url, { ...params, Body: "otra cosa" }, sig, "tok")).toBe(false);
  });
});
