import { describe, expect, it } from "vitest";
import { estimateEta, minutesUntil } from "@/lib/eta";
import { distanceKm, interpolate, travelMinutes } from "@/lib/geo";
import { mxn, parsePesos } from "@/lib/money";
import { canTransition, customerStepIndex } from "@/lib/order-flow";
import { normalizePhone, prettyPhone } from "@/lib/phone";
import { isAffirmative, matchItems, parseRules } from "@/server/agent/rules";
import type { MenuItem } from "@/lib/types";

const item = (id: string, name: string, price = 2000): MenuItem => ({ id, categoryId: null, name, description: "", priceCents: price, emoji: "", available: true, sort: 0 });
const MENU = [
  item("p", "Taco al pastor", 2200),
  item("s", "Taco de suadero", 2200),
  item("b", "Taco de bistec", 2400),
  item("g", "Gringa de pastor", 5500),
  item("h", "Agua de horchata", 3000),
  item("j", "Agua de jamaica", 3000),
];

describe("money / phone", () => {
  it("formats pesos", () => {
    expect(mxn(12350)).toMatch(/\$123\.50/);
    expect(parsePesos("1,234.5")).toBe(123450);
    expect(parsePesos("abc")).toBeNull();
  });
  it("normalizes Mexican phones", () => {
    expect(normalizePhone("55 1234 5678")).toBe("+525512345678");
    expect(normalizePhone("+52 1 55 1234 5678")).toBe("+525512345678");
    expect(normalizePhone("(55) 1234-5678")).toBe("+525512345678");
    expect(normalizePhone("12345")).toBeNull();
    expect(normalizePhone("+1 415 555 0100")).toBe("+14155550100");
    expect(prettyPhone("+525512345678")).toBe("55 1234 5678");
  });
});

describe("order lifecycle", () => {
  it("only allows valid transitions per actor", () => {
    expect(canTransition("pending", "preparing", "restaurant")).toBe(true);
    expect(canTransition("pending", "preparing", "courier")).toBe(false);
    expect(canTransition("pending", "delivered", "restaurant")).toBe(false);
    expect(canTransition("ready", "on_the_way", "courier")).toBe(true);
    expect(canTransition("on_the_way", "cancelled", "restaurant")).toBe(false);
    expect(canTransition("delivered", "cancelled", "system")).toBe(false);
    expect(customerStepIndex("ready")).toBe(1);
  });
});

describe("geo / ETA", () => {
  const rest = { lat: 19.7142, lng: -99.2219 };
  const home = { lat: 19.7242, lng: -99.2119 };
  it("distance and travel time are sane", () => {
    const d = distanceKm(rest, home);
    expect(d).toBeGreaterThan(1.3);
    expect(d).toBeLessThan(1.6);
    expect(travelMinutes(rest, home)).toBeGreaterThanOrEqual(5);
    const mid = interpolate(rest, home, 0.5);
    expect(mid.lat).toBeCloseTo(home.lat, 5);
  });
  it("uses live GPS when the courier is on the way", () => {
    const now = Date.now();
    const eta = estimateEta({
      status: "on_the_way",
      now,
      createdAt: now - 30 * 60000,
      prepMinutes: 15,
      restaurant: rest,
      destination: home,
      courier: { pos: home, updatedAt: now - 5000, vehicle: "moto" },
    });
    expect(eta.basis).toBe("live");
    expect(minutesUntil(eta.etaAt, now)).toBeLessThanOrEqual(1);
  });
  it("pending orders include prep time", () => {
    const now = Date.now();
    const eta = estimateEta({ status: "pending", now, createdAt: now, prepMinutes: 20, restaurant: rest, destination: home });
    expect(minutesUntil(eta.etaAt, now)).toBeGreaterThan(25);
    expect(eta.basis).toBe("estimate");
  });
});

describe("offline ordering parser", () => {
  it("understands quantities and specific dishes", () => {
    const { found } = matchItems("quiero 2 tacos al pastor y una horchata", MENU);
    expect(found.map((f) => [f.item.id, f.qty])).toEqual([["p", 2], ["h", 1]]);
  });
  it("asks when the dish is ambiguous", () => {
    const r = parseRules("dame 3 tacos", MENU);
    expect(r.actions.filter((a) => a.type === "add")).toHaveLength(0);
    expect(r.ambiguous[0].options.length).toBeGreaterThanOrEqual(3);
  });
  it("keeps notes like 'sin cebolla' on the item", () => {
    const { found } = matchItems("4 de suadero sin cebolla", MENU);
    expect(found[0].item.id).toBe("s");
    expect(found[0].qty).toBe(4);
    expect(found[0].notes).toBe("sin cebolla");
  });
  it("extracts name, phone and address", () => {
    const r = parseRules("me llamo Juan Pérez, mi cel es 55 1234 5678. Mi dirección es Calle Hidalgo 12, Centro", MENU);
    expect(r.actions).toContainEqual({ type: "set_name", value: "Juan Pérez" });
    expect(r.actions.some((a) => a.type === "set_phone")).toBe(true);
    expect(r.actions.some((a) => a.type === "set_address" && a.value.startsWith("Calle Hidalgo 12"))).toBe(true);
    expect(r.actions.some((a) => a.type === "add")).toBe(false);
  });
  it("recognizes removals and checkout", () => {
    expect(parseRules("quita la gringa", MENU).actions).toContainEqual({ type: "remove", itemId: "g", qty: undefined });
    expect(parseRules("es todo", MENU).actions).toContainEqual({ type: "checkout" });
    expect(isAffirmative("Sí, confirmo")).toBe(true);
    expect(isAffirmative("no gracias")).toBe(false);
  });
});
