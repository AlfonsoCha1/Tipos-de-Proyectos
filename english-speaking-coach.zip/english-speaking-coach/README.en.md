# English Speaking Coach

[Español](README.md) · **English**

A **voice-first** English tutor for Spanish speakers. You talk into the microphone; an **AI agent** listens, answers out loud, corrects you, and makes you repeat hard words. At the end you get your top 3 mistakes with exercises.

The first complete demo is a **job interview for a software or AI engineering role**: spoken greeting → questions → your spoken answers → spoken corrections → pronunciation practice → final summary.

<p>
  <img src="docs/screenshots/inicio.png" width="240" alt="Home screen">
  <img src="docs/screenshots/sesion.png" width="240" alt="Voice session">
  <img src="docs/screenshots/practica-pronunciacion.png" width="240" alt="Pronunciation drill">
</p>

---

## Honest status: what works and what doesn't

| Feature | Status | How it was tested |
|---|---|---|
| Voice conversation (you speak, the coach answers aloud) | ✅ Works with the browser's speech recognition and voices | E2E in Chromium with a simulated microphone |
| End-of-turn detection (silence threshold adapts to level) | ✅ | VAD unit tests + E2E with a real (simulated) audio signal |
| Interrupting the coach | ✅ By voice (barge-in detector) and by button | E2E: coach stops ~1.9 s after the voice starts |
| **AI agent** deciding every turn (ask, correct, drill a word, adjust difficulty, close) | ✅ Code ready for Groq, OpenAI, Anthropic. **Needs your key** | Tested against a server mimicking Groq's API. **Not tested against real Groq** (no key here) |
| Modes: interview, daily, travel, meetings, presentations, business | ✅ With AI. The no-AI backup has fixed questions for each | Interview: full E2E. Others: code only |
| Pace/difficulty adjustment; Spanish hint when you get stuck | ✅ | E2E: silence → spoken Spanish hint + starter phrase |
| Voice commands: "repeat", "slower", "no sé", "next question", "end the interview" | ✅ | Unit + E2E |
| **Teacher** mode (corrects what matters without interrupting every sentence) and **fluent** mode (everything at the end) | ✅ Rules enforced in code, not left to the model | Unit + E2E |
| Grammar, vocabulary and naturalness corrections | ✅ With AI. Without AI: 30 rules for typical Spanish-speaker errors | Unit + E2E |
| **Measured pronunciation** (phonemes, fluency, prosody) | ✅ Integrated with **Azure AI Speech – Pronunciation Assessment**. **Needs an Azure key** | Tested with simulated Azure responses. **Not tested against real Azure** |
| Pronunciation **without** Azure | ⚠️ **No acoustic measurement.** It only suggests commonly hard words and compares recognized text, and says so on screen | Unit + E2E check the "not measured" labels |
| Model audio at normal and slow speed, replay your recording, retry | ✅ | E2E |
| Summary: top 3 errors + exercises + words to practice | ✅ | E2E |
| Cost limits (time, turns, voice, assessments, daily sessions) | ✅ In memory (single server) | API tests |
| Consent before mic; recordings kept only if you opt in (on your device) | ✅ | E2E |
| Server neural voice (Azure/OpenAI) and server Whisper | ✅ Optional | Tested with mock servers |
| Payments, user accounts, cloud history | ❌ Intentionally not included | — |

**With no keys at all** the app still runs end to end, but the coach is a **rule-based backup (no AI)** with fixed questions, and the UI labels it "Sin IA". To get the AI agent, you need at least `GROQ_API_KEY`.

---

## How it works

```
Browser (phone or PC)                            Next.js server (keys live here)          Providers
─────────────────────                            ───────────────────────────────          ─────────
mic → VAD (end of turn, barge-in)
    → speech recognition (browser) ──── or ──── /api/stt ───────────────────────────────→ Whisper (Groq/OpenAI)
    → 16 kHz WAV ─────────────────────────────── /api/pronunciation ────────────────────→ Azure Pronunciation Assessment
text + evidence ──────────────────────────────── /api/agent (agent + policy) ───────────→ LLM (Groq/OpenAI/Anthropic)
actions ← say · correct · drill word · adjust · ask
coach voice ← browser ──── or ──── /api/tts ────────────────────────────────────────────→ Azure / OpenAI TTS
```

**The agent.** Each turn it gets an *observation* (what you said, your pauses, pronunciation evidence if available) plus its session *memory* (your recurring errors, estimated level, notes about you), and returns an ordered list of actions. A **policy in code** (`src/lib/server/agent/policy.ts`) validates those actions, whichever model you use:
- fluent mode never corrects or drills mid-conversation;
- teacher mode allows at most 1 correction + 1 drill per turn, with cooldowns;
- drills only use words you actually said (or words Azure flagged);
- whether something counts as "measured" comes from the evidence, never from the model;
- every turn ends with exactly one question.

**Swappable providers.** Each one sits behind a small interface:

| Layer | File | Included options |
|---|---|---|
| Agent LLM | `src/lib/server/providers/llm/index.ts` | Groq, OpenAI (or any compatible API), Anthropic |
| Speech-to-text | `src/lib/client/speech/listen.ts`, `src/lib/server/providers/stt` | Browser (Web Speech), Whisper via Groq/OpenAI |
| Coach voice | `src/lib/client/speech/tts.ts`, `src/lib/server/providers/tts` | Browser, Azure Neural, OpenAI |
| Pronunciation | `src/lib/server/providers/pronunciation` | Azure (acoustic), transcript-only (honest, no measurement) |

---

## Run it locally

Requires **Node.js 20+** and **Chrome or Edge** (best built-in speech recognition).

```bash
npm install
cp .env.example .env.local     # Windows PowerShell: Copy-Item .env.example .env.local
# add GROQ_API_KEY (and Azure if you have it)
npm run dev
```

Open **http://localhost:3000** in Chrome. The mic works on `localhost` without HTTPS. On a phone you need **HTTPS**: deploy to Vercel or use a tunnel (e.g. `ngrok http 3000`). Production: `npm run build && npm start`.

## Keys and costs

Prices checked in September 2026. They change, so verify them before launch.

| Service | Used for | Required? | Approx. price | Free |
|---|---|---|---|---|
| **Groq** | AI agent (`openai/gpt-oss-20b`), optional Whisper | **Yes, for the AI agent** | gpt-oss-20b: US$0.075 per 1M input tokens, US$0.30 per 1M output tokens. Whisper turbo: US$0.04/hour | Free tier with rate limits |
| **Azure AI Speech** | Measured pronunciation, neural voice | Only to measure pronunciation | Speech-to-text ≈ US$1 per audio hour; pronunciation assessment is billed as an add-on (≈ US$0.30/hour per public listings); neural TTS ≈ US$15–16 per 1M characters | F0 tier: 5 audio hours and 0.5M TTS characters per month |

**Estimated cost of a 15-minute session:** < US$0.01 for the agent (Groq), ≈ US$0.12–0.15 for Azure pronunciation, ≈ US$0.14 for optional Azure voice. That's about **US$0.30** with everything on, or **≈ US$0.15** with the browser voice and recognition.

Azure's REST assessment scores up to 30 s of audio per call; the app trims anything longer. Prosody is en-US only.

## Cost limits

Set them in `.env.local`. The server enforces them with an HMAC-signed session token: session minutes (inside the token, so they can't be tampered with), turns, TTS characters, assessments, answer seconds, sessions per IP per day, and a global daily cap. Counters are in memory; on serverless, swap `UsageStore` in `src/lib/server/session.ts` for Redis (e.g. Upstash).

## Privacy

- Consent screen before the mic is used.
- Recordings stay in tab memory. They're only saved to the device (IndexedDB) if you opt in, and you can delete them from the home screen.
- The server stores no audio or text. Audio goes to Azure or Groq only when those are enabled, and the consent screen says so.
- Chrome's built-in recognition sends audio to Google.

## Tests

```bash
npm test            # 28 unit tests
npm run build && npm run test:e2e   # real Chromium, fake mic, 4 scenarios, mocked Groq/Whisper/Azure
```

## Known limitations

- Safari/iOS: browser speech recognition is unreliable. Use `STT_PROVIDER=groq`.
- Firefox has no speech recognition; the app falls back to typing, or you can use server Whisper.
- Barge-in works best with headphones; speaker echo can trigger it (you can turn it off).
- With browser recognition, the first syllables after an interruption may be lost (server Whisper keeps ~1 s of pre-roll).
- Whisper sometimes silently "fixes" small grammar slips, which hides them from the corrector.
