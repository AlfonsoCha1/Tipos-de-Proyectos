# English Speaking Coach

**Español** · [English](README.en.md)

Tutor de inglés **por voz** para hispanohablantes. Hablas por el micrófono, un **agente de IA** te escucha, te responde en voz alta, te corrige y te hace repetir las palabras difíciles. Al final recibes tus 3 errores principales con ejercicios.

La primera demo completa es una **entrevista de trabajo para ingeniería de software o IA**: saludo hablado, preguntas, tus respuestas por voz, correcciones habladas, práctica de pronunciación y resumen final.

<p>
  <img src="docs/screenshots/inicio.png" width="240" alt="Capturas (celular): inicio">
  <img src="docs/screenshots/sesion.png" width="240" alt="Capturas (celular): sesión">
  <img src="docs/screenshots/practica-pronunciacion.png" width="240" alt="Capturas (celular): práctica de pronunciación">
</p>

---

## Estado honesto: qué funciona y qué no

| Función | Estado | Cómo se probó |
|---|---|---|
| Conversación por voz (hablas, el coach responde en voz alta) | ✅ Funciona con el reconocimiento y las voces del navegador | Prueba E2E en Chromium con micrófono simulado |
| Detectar cuándo terminas de hablar (silencio adaptable al nivel) | ✅ | Pruebas unitarias del VAD y E2E con audio real simulado |
| Interrumpir al coach hablando | ✅ Por voz (detector de barge-in) y con botón | E2E: el coach se calla ~1.9 s después de que empieza la voz |
| **Agente de IA** que decide cada turno (preguntar, corregir, practicar una palabra, ajustar dificultad, cerrar) | ✅ Código listo para Groq, OpenAI y Anthropic. **Necesita tu clave** | Probado contra un servidor que imita la API de Groq. **No se probó con Groq real** (no tengo tu clave) |
| Modos: entrevista, cotidiano, viajes, reuniones, presentaciones, negocios | ✅ Con IA. El respaldo sin IA tiene preguntas fijas para cada modo | Entrevista: E2E completo. Otros modos: solo por código |
| Ajuste de velocidad y dificultad; pista en español si te bloqueas | ✅ | E2E: silencio → pista hablada en español + frase de inicio |
| Comandos por voz: "repeat", "slower", "no sé", "next question", "end the interview" | ✅ | Unitarias + E2E |
| Modo **profesor** (corrige lo importante sin interrumpir cada frase) y modo **conversación fluida** (todo al final) | ✅ Reglas aplicadas en código, no dependen del modelo | Unitarias + E2E |
| Corrección de gramática, vocabulario y expresiones poco naturales | ✅ Con IA. Sin IA: 30 reglas para errores típicos de hispanohablantes | Unitarias + E2E |
| **Pronunciación medida** (sonidos, fluidez, entonación) | ✅ Integrado con **Azure AI Speech – Pronunciation Assessment**. **Necesita clave de Azure** | Probado con respuestas simuladas de Azure. **No se probó con Azure real** |
| Pronunciación **sin** Azure | ⚠️ **No hay medición acústica.** Solo sugerimos palabras que suelen costar y comparamos el texto reconocido. La app lo dice en pantalla | Unitarias + E2E verifican las etiquetas "Sugerencia, no medido" |
| Escuchar el modelo a velocidad normal y lenta, oír tu grabación y reintentar | ✅ | E2E |
| Resumen: 3 errores principales + ejercicios + palabras para practicar | ✅ | E2E |
| Límites de costo (tiempo, turnos, voz, evaluaciones, sesiones por día) | ✅ En memoria (un servidor) | Pruebas de API |
| Permiso antes del micrófono; grabaciones solo si aceptas guardarlas en tu dispositivo | ✅ | E2E |
| Voz neural (Azure/OpenAI) y Whisper en el servidor | ✅ Opcional | Probado con servidores simulados |
| Pagos, cuentas de usuario, historial en la nube | ❌ No incluido a propósito | — |

**Sin ninguna clave**, la app funciona completa, pero el coach es un **respaldo sin IA** con preguntas fijas y reglas. La interfaz lo muestra como "Sin IA". Para tener el agente de IA necesitas al menos `GROQ_API_KEY`.

---

## Cómo funciona

```
Navegador (celular o PC)                         Servidor Next.js (claves aquí)            Proveedores
───────────────────────                          ─────────────────────────────            ───────────
micrófono → VAD (fin de turno, interrupción)
          → reconocimiento de voz (navegador) ── o ── /api/stt ─────────────────────────→ Whisper (Groq/OpenAI)
          → audio WAV 16 kHz ─────────────────────── /api/pronunciation ────────────────→ Azure Pronunciation Assessment
texto + evidencia ─────────────────────────────────── /api/agent  (agente + política) ──→ LLM (Groq/OpenAI/Anthropic)
acciones ← decir · corregir · practicar palabra · ajustar · preguntar
voz del coach ← navegador ── o ── /api/tts ─────────────────────────────────────────────→ Azure / OpenAI TTS
```

**El agente.** En cada turno recibe una *observación* (lo que dijiste, tus pausas, la medición de pronunciación si existe) y su *memoria* de la sesión (tus errores repetidos, tu nivel estimado, notas sobre ti). Devuelve una lista ordenada de acciones. Una **política en código** (`src/lib/server/agent/policy.ts`) valida esas acciones sin importar qué modelo uses:
- en modo fluido nunca corrige ni hace prácticas a mitad de la conversación;
- en modo profesor hace como máximo 1 corrección y 1 práctica por turno, con pausas entre ellas;
- solo practica palabras que dijiste (o que Azure marcó);
- decide si algo está "medido" según la evidencia, nunca según el modelo;
- cada turno termina con una sola pregunta.

**Proveedores intercambiables.** Cada uno está detrás de una interfaz pequeña:

| Capa | Archivo | Opciones incluidas |
|---|---|---|
| LLM del agente | `src/lib/server/providers/llm/index.ts` | Groq, OpenAI (o cualquier API compatible), Anthropic |
| Reconocimiento de voz | `src/lib/client/speech/listen.ts`, `src/lib/server/providers/stt` | Navegador (Web Speech), Whisper vía Groq/OpenAI |
| Voz del coach | `src/lib/client/speech/tts.ts`, `src/lib/server/providers/tts` | Navegador, Azure Neural, OpenAI |
| Pronunciación | `src/lib/server/providers/pronunciation` | Azure (acústica), solo-transcripción (honesta, sin medición) |

---

## Ejecutarlo en tu computadora

Requisitos: **Node.js 20 o más nuevo** y **Chrome o Edge** (tienen el mejor reconocimiento de voz del navegador).

**Windows (PowerShell):**
```powershell
git clone https://github.com/<tu-usuario>/english-speaking-coach.git
cd english-speaking-coach
npm install
Copy-Item .env.example .env.local
notepad .env.local      # pega tu GROQ_API_KEY (y Azure si la tienes)
npm run dev
```

**Mac / Linux:**
```bash
npm install
cp .env.example .env.local   # edita tus claves
npm run dev
```

Abre **http://localhost:3000** en Chrome. El micrófono funciona en `localhost` sin HTTPS. En el celular necesitas **HTTPS**: despliega en Vercel (abajo) o usa un túnel (por ejemplo `ngrok http 3000`).

Para producción: `npm run build` y luego `npm start`.

---

## Claves y costos

Precios consultados en septiembre de 2026. Pueden cambiar, así que revísalos antes de lanzar.

| Servicio | Para qué | ¿Obligatorio? | Precio aproximado | Gratis |
|---|---|---|---|---|
| **Groq** ([console.groq.com](https://console.groq.com)) | Agente de IA (`openai/gpt-oss-20b`) y Whisper opcional | **Sí, para el agente de IA** | gpt-oss-20b: US$0.075 por millón de tokens de entrada y US$0.30 por millón de salida. Whisper turbo: US$0.04/hora | Plan gratis con límites por minuto y por día |
| **Azure AI Speech** ([portal.azure.com](https://portal.azure.com) → recurso *Speech*) | Pronunciación medida y voz neural | Solo para medir la pronunciación | Reconocimiento ≈ US$1/hora de audio; la evaluación de pronunciación se cobra como *add-on* (≈ US$0.30/hora según listados públicos); voz neural ≈ US$15–16 por millón de caracteres | Nivel F0: 5 h de audio al mes y 0.5 M caracteres de voz al mes |
| OpenAI / Anthropic | Alternativas al LLM o a la voz | No | Según el modelo | — |

**Costo estimado de una sesión de 15 minutos** (≈6 min hablando tú, ≈16 turnos):
- agente con Groq: menos de US$0.01;
- Whisper en el servidor (opcional): ≈ US$0.004;
- pronunciación con Azure: ≈ US$0.12–0.15;
- voz neural de Azure (opcional): ≈ US$0.14.

Con todo activado, una sesión cuesta **≈ US$0.30**. Con la voz y el reconocimiento del navegador, **≈ US$0.15**. El nivel gratuito de Azure alcanza para unas 40 sesiones al mes con pronunciación medida.

**Cómo obtener la clave de Azure:** crea una cuenta en Azure → *Create a resource* → *Speech* → región `eastus` (la prosodia solo está en inglés de EE. UU.) → nivel **Free F0** → copia *Key 1* y la región a `.env.local`. Azure pide una tarjeta para verificar la cuenta, aunque uses el nivel gratis.

**Límites de la evaluación de Azure:** la API REST evalúa hasta 30 s de audio por llamada, y la app recorta lo demás. Para respuestas más largas con medición completa, el siguiente paso es usar el SDK de Azure en modo continuo.

---

## Límites de costo

Se configuran en `.env.local` y se aplican en el servidor con un token de sesión firmado (HMAC):
- `LIMIT_SESSION_MINUTES` (15): la duración viene dentro del token firmado y no se puede alterar;
- `LIMIT_TURNS_PER_SESSION`, `LIMIT_ASSESSMENTS_PER_SESSION`, `LIMIT_TTS_CHARS_PER_SESSION`, `LIMIT_ANSWER_SECONDS`;
- `LIMIT_SESSIONS_PER_IP_PER_DAY` y `LIMIT_GLOBAL_SESSIONS_PER_DAY`, que funcionan como tope total de gasto diario.

Los contadores viven en memoria. En Vercel (serverless, varias instancias) conviene cambiar `UsageStore` en `src/lib/server/session.ts` por Redis (por ejemplo Upstash). La interfaz tiene 3 métodos.

## Privacidad

- El micrófono se pide solo después de una pantalla que explica qué pasa con tu voz.
- Las grabaciones se quedan en la memoria de la pestaña. Solo se guardan en el dispositivo (IndexedDB) si marcas la casilla, y se pueden borrar desde el inicio.
- El servidor no guarda audio ni texto. El audio solo va a Azure o Groq cuando esos proveedores están activados, y la pantalla de permiso lo dice.
- En Chrome, el reconocimiento de voz del navegador envía el audio a Google.

## Pruebas

```bash
npm test             # 28 pruebas unitarias: corrector, agente y política, Azure, VAD, WAV
npm run build
npm run test:e2e     # Chromium real con micrófono simulado: 4 escenarios, 37 verificaciones
```
Las pruebas E2E levantan un servidor falso que imita Groq, Whisper y Azure (`tests/e2e/mock-providers.mjs`). Así prueban el camino real del código sin claves ni costo. El modo `?test=1` (voz simulada y respuestas escritas) solo existe en desarrollo o con `ALLOW_TEST_MODE=1`.

## Desplegar en Vercel

1. Sube el repo a GitHub e impórtalo en Vercel.
2. En *Settings → Environment Variables*, agrega `GROQ_API_KEY`, `SESSION_SECRET` y, si la tienes, `AZURE_SPEECH_KEY` + `AZURE_SPEECH_REGION`.
3. Despliega y abre la URL `https://…vercel.app` en tu celular.

## Limitaciones conocidas

- **Safari/iOS:** el reconocimiento de voz del navegador es inestable. Para iPhone, activa `STT_PROVIDER=groq` (Whisper).
- **Firefox:** no tiene reconocimiento de voz. La app cambia a escribir, o puedes usar Whisper.
- **Android + Chrome:** el reconocimiento del navegador y la captura del micrófono pueden competir. Si ves que no te escucha bien, usa `STT_PROVIDER=groq`.
- **Interrupción por voz:** funciona mejor con audífonos. Con bocina, el eco puede interrumpir al coach; se puede desactivar en ajustes.
- Con el reconocimiento del navegador, al interrumpir se pueden perder las primeras sílabas. Con Whisper no pasa, porque se guarda ~1 s de audio previo.
- Whisper a veces "limpia" pequeños errores al transcribir, y entonces el corrector no los ve. El reconocimiento del navegador es más literal.
- Los precios y los modelos de los proveedores cambian: verifica `GROQ_MODEL` y los precios antes de lanzar.

## Estructura

```
src/app/api/            agent · summary · session · config · stt · tts · pronunciation
src/lib/server/agent/   prompt, política y ciclo del agente
src/lib/server/offline/ respaldo sin IA: guion de preguntas y 30 reglas de corrección
src/lib/server/providers/  llm · stt · tts · pronunciation
src/lib/client/audio/   micrófono, VAD, WAV 16 kHz
src/lib/client/speech/  escuchar (navegador/servidor/texto) y hablar (navegador/servidor)
src/lib/client/engine/  controlador de la sesión (turnos, interrupciones, prácticas)
src/components/         pantallas: inicio, permiso, sesión, resumen
docs/NEGOCIO.md         cómo validar con usuarios y convertirlo en negocio
```

Licencia: define la tuya antes de publicar (por ejemplo MIT si quieres que sea abierta).
