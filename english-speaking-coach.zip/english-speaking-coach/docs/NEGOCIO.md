# Validación con usuarios y modelo de negocio

Este documento es una propuesta. No incluye pagos (a propósito): primero hay que confirmar que alguien usa el producto más de una vez y que pagaría por él.

## 1. La apuesta

**Para quién:** profesionistas de tecnología en México y Latinoamérica (soporte TI, desarrolladores, ingenieros, analistas de datos) que ya leen inglés técnico, pero se traban al **hablarlo** en entrevistas con empresas de EE. UU. o en reuniones con clientes extranjeros.

**Problema:** practicar conversación cuesta. Un tutor humano es caro y hay que agendarlo, y a muchos les da pena equivocarse frente a una persona. Las apps genéricas no preparan para una entrevista técnica ni explican los errores típicos de un hispanohablante.

**Propuesta:** un simulador de entrevista por voz que te corrige como un profesor que habla tu idioma, te dice honestamente qué pronunciaste mal (medido, no adivinado) y te deja un plan de práctica de 3 errores.

**Ventaja de fundador:** tú eres el usuario objetivo. Has aplicado a Microsoft y Goldman Sachs, conoces soporte TI y tienes una red de técnicos e ingenieros para las primeras pruebas.

## 2. Plan de validación en 4 semanas

### Semana 1: entrevistas de problema (sin mostrar la app)
- Habla con 12–15 personas: excompañeros, grupos de LinkedIn, comunidades de bootcamps y universidades, gente que prepara entrevistas para trabajos remotos.
- Preguntas: ¿cuándo fue la última vez que tuviste que hablar inglés en el trabajo o en una entrevista? ¿Cómo te preparaste? ¿Cuánto gastaste (clases, apps, tutores)? ¿Qué fue lo más difícil?
- **Señal de avance:** al menos 8 de 15 describen el problema sin que se los sugieras y ya gastaron dinero o tiempo intentando resolverlo.

### Semana 2: demo con 20 usuarios reales
- Despliega en Vercel con Groq (plan gratis) y Azure F0 (5 h/mes gratis, ≈40 sesiones con pronunciación medida).
- Invita a 20 personas a hacer la entrevista demo. Observa en vivo a 5 de ellas (por videollamada, compartiendo pantalla).
- Mide:
  - % que termina la sesión (meta: ≥60 %);
  - % que regresa por su cuenta en 7 días (meta: ≥30 %);
  - % que completa al menos una práctica de pronunciación;
  - pregunta de Sean Ellis: "¿Qué tan decepcionado estarías si ya no pudieras usarla?" (meta: ≥40 % "muy decepcionado").
- Para medir necesitas analítica mínima: eventos de sesión iniciada, terminada, práctica completada y regreso. Por ejemplo, Vercel Analytics o PostHog, sin grabar audio.

### Semana 3: prueba de precio sin cobrar
- Página con 2 planes y un botón "Reservar mi lugar" que solo guarda el correo.
- Planes de prueba: **Básico MXN 149/mes** (voz del navegador, pronunciación sugerida) y **Pro MXN 299/mes** (pronunciación medida, voz natural, entrevistas ilimitadas).
- Mejor señal: **preventa en persona**. Pide a los 5 usuarios más activos que paguen el primer mes por adelantado (por transferencia, sin construir pagos). Si 2 o más pagan, hay negocio.

### Semana 4: decidir
- **Seguir (B2C)** si retención ≥30 % y hubo preventas.
- **Cambiar a B2B** si a los individuos les gusta pero no pagan. Busca a quien sí paga por inglés hablado:
  - **Call centers / BPO** en México: entrenan agentes en inglés constantemente.
  - **Empresas de nearshoring y consultoras de software**: preparan a sus ingenieros para clientes de EE. UU.
  - **Bootcamps y universidades**: módulo de preparación para entrevistas.
- **Parar** si nadie regresa después de la primera sesión: el problema no duele lo suficiente.

## 3. Números

| Concepto | Estimado |
|---|---|
| Costo por sesión de 15 min (Groq + Azure pronunciación, voz del navegador) | ≈ US$0.15 |
| Costo por sesión con voz neural de Azure | ≈ US$0.30 |
| Usuario activo: 12 sesiones al mes | ≈ US$2–4 al mes |
| Precio de prueba Pro | MXN 299 al mes |

Con esos números, el margen bruto del plan Pro queda muy por arriba del 50 % aun con uso intenso. Los límites por sesión y por día que ya tiene la app evitan que un usuario dispare el costo. Revisa el tipo de cambio y los precios de los proveedores antes de fijar el precio final.

## 4. Competencia (verifica precios actuales)

- **ELSA Speak:** fuerte en pronunciación, débil en conversación de entrevista técnica.
- **Speak, Praktika, Duolingo Max:** conversación con IA, generalista, no enfocada en errores de hispanohablantes.
- **Cambly, italki:** tutores humanos, más caros y hay que agendar.
- **ChatGPT en modo voz:** gratis o barato, pero no mide la pronunciación, no tiene método de corrección ni resumen de práctica.

**Diferenciador:** entrevista técnica para ingeniería e IA, correcciones pensadas para hispanohablantes, pistas en español, pronunciación medida de verdad y honestidad sobre qué se midió.

## 5. Antes de cobrar (no ahora)

- Cuentas de usuario e historial de progreso (base de datos, por ejemplo Neon, que ya usas en SOPHYA).
- Límites en Redis en vez de memoria.
- **Aviso de privacidad** conforme a la ley mexicana de datos personales: la voz es un dato personal. Consúltalo con un abogado; esto no es asesoría legal.
- Pagos (Stripe o Mercado Pago) solo después de ver retención.
- Pruebas en iPhone con Whisper en el servidor.
