import { NextResponse } from "next/server";
import { runAgent } from "@/lib/server/agent";
import { errorResponse, sessionFrom } from "@/lib/server/http";
import { agentRequestSchema } from "@/lib/server/schemas";
import { consume, usageOf } from "@/lib/server/session";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/** One step of the coach agent. Each learner answer consumes one turn of the session budget. */
export async function POST(req: Request) {
  try {
    const claims = sessionFrom(req);
    const input = agentRequestSchema.parse(await req.json());
    const usage = input.observation.kind === "answer" ? consume(claims, "turns", 1) : usageOf(claims);
    const decision = await runAgent(input);
    return NextResponse.json({ ...decision, usage: { turns: usage.turns } });
  } catch (err) {
    return errorResponse(err);
  }
}
