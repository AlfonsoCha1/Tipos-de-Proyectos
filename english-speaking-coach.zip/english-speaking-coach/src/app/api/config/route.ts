import { NextResponse } from "next/server";
import { publicConfig } from "@/lib/server/config";

export const dynamic = "force-dynamic";

/** What the browser may know: which providers are active and the limits. Never keys. */
export async function GET() {
  return NextResponse.json(publicConfig());
}
