import { NextResponse } from "next/server";
import { pronunciationProvider } from "@/lib/server/config";
import { errorResponse, providerError, sessionFrom, wavDurationSec } from "@/lib/server/http";
import { createPronunciationProvider } from "@/lib/server/providers/pronunciation";
import { ApiError, consume } from "@/lib/server/session";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/**
 * Pronunciation assessment. With Azure configured the audio is scored acoustically
 * (measured=true). Without it, only the recognized text is compared (measured=false).
 * Audio is processed and discarded, never stored.
 */
export async function POST(req: Request) {
  try {
    const claims = sessionFrom(req, 30 * 60_000);
    const form = await req.formData();
    const referenceText = String(form.get("referenceText") ?? "").slice(0, 600).trim();
    const recognizedText = String(form.get("recognizedText") ?? "").slice(0, 1500);
    const mode = form.get("mode") === "conversation" ? "conversation" : "scripted";
    if (!referenceText) throw new ApiError(400, { error: "missing referenceText", code: "bad_request", messageEs: "Falta el texto de referencia." });

    const which = pronunciationProvider();
    const provider = createPronunciationProvider(which);
    let wav: Buffer | undefined;
    const file = form.get("audio");
    if (file instanceof Blob && file.size > 0) {
      wav = Buffer.from(await file.arrayBuffer());
      if (wavDurationSec(wav) === null) throw new ApiError(400, { error: "audio must be WAV", code: "bad_request", messageEs: "El audio debe ser WAV 16 kHz." });
    }
    if (provider.measured) {
      if (!wav) throw new ApiError(400, { error: "missing audio", code: "bad_request", messageEs: "Falta el audio para evaluar." });
      consume(claims, "assessments", 1);
      try {
        return NextResponse.json(await provider.assess({ wav, referenceText, recognizedText, mode }));
      } catch (e) {
        providerError("evaluación de pronunciación", (e as Error).message);
      }
    }
    return NextResponse.json(await provider.assess({ referenceText, recognizedText, mode }));
  } catch (err) {
    return errorResponse(err);
  }
}
