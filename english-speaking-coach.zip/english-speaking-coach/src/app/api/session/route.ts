import { NextResponse } from "next/server";
import { limits } from "@/lib/server/config";
import { clientIp, errorResponse } from "@/lib/server/http";
import { createSession } from "@/lib/server/session";
import type { SessionStart } from "@/lib/shared/types";

export const dynamic = "force-dynamic";

/** Starts a practice session: checks daily limits and returns a signed, expiring token. */
export async function POST(req: Request) {
  try {
    const { token, claims } = createSession(clientIp(req));
    const body: SessionStart = { token, expiresAt: claims.exp, limits: limits() };
    return NextResponse.json(body);
  } catch (err) {
    return errorResponse(err);
  }
}
