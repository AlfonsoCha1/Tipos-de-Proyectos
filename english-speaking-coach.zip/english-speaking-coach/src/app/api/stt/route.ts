import { NextResponse } from "next/server";
import { limits, sttConfig } from "@/lib/server/config";
import { errorResponse, notConfigured, providerError, sessionFrom, wavDurationSec } from "@/lib/server/http";
import { createSttProvider } from "@/lib/server/providers/stt";
import { ApiError, consume } from "@/lib/server/session";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/** Server speech-to-text (Whisper via Groq/OpenAI). Audio is processed and discarded, never stored. */
export async function POST(req: Request) {
  try {
    const claims = sessionFrom(req);
    const cfg = sttConfig();
    if (!cfg) notConfigured("stt", "El reconocimiento de voz del servidor no está configurado; se usa el del navegador.");
    const form = await req.formData();
    const file = form.get("audio");
    if (!(file instanceof Blob)) throw new ApiError(400, { error: "missing audio", code: "bad_request", messageEs: "Falta el audio." });
    const wav = Buffer.from(await file.arrayBuffer());
    const seconds = wavDurationSec(wav);
    if (seconds === null) throw new ApiError(400, { error: "audio must be WAV", code: "bad_request", messageEs: "El audio debe ser WAV." });
    if (seconds > limits().maxAnswerSeconds + 2) {
      throw new ApiError(413, { error: "answer too long", code: "limit_audio", messageEs: `Las respuestas pueden durar hasta ${limits().maxAnswerSeconds} segundos.` });
    }
    consume(claims, "audioSeconds", Math.ceil(seconds));
    const prompt = typeof form.get("prompt") === "string" ? (form.get("prompt") as string) : undefined;
    try {
      const out = await createSttProvider(cfg!).transcribe(wav, { prompt });
      return NextResponse.json({ text: out.text, durationSec: seconds });
    } catch (e) {
      providerError("reconocimiento de voz", (e as Error).message);
    }
  } catch (err) {
    return errorResponse(err);
  }
}
