import { NextResponse } from "next/server";
import { summarize } from "@/lib/server/agent";
import { errorResponse, sessionFrom } from "@/lib/server/http";
import { summaryRequestSchema } from "@/lib/server/schemas";
import type { SummaryPronItem } from "@/lib/shared/types";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/** End-of-session summary. Allowed for 30 minutes after the session time runs out. */
export async function POST(req: Request) {
  try {
    sessionFrom(req, 30 * 60_000);
    const input = summaryRequestSchema.parse(await req.json());
    const summary = await summarize({ ...input, pronunciation: input.pronunciation as SummaryPronItem[] });
    return NextResponse.json(summary);
  } catch (err) {
    return errorResponse(err);
  }
}
