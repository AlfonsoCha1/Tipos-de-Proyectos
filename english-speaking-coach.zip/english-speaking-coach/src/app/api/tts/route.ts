import { errorResponse, notConfigured, providerError, sessionFrom } from "@/lib/server/http";
import { ttsRequestSchema } from "@/lib/server/schemas";
import { createTtsProvider, ttsCache } from "@/lib/server/providers/tts";
import { consume } from "@/lib/server/session";

export const dynamic = "force-dynamic";

/** Server text-to-speech (Azure neural voices or OpenAI). Cached; counts characters per session. */
export async function POST(req: Request) {
  try {
    const claims = sessionFrom(req, 30 * 60_000);
    const provider = createTtsProvider();
    if (!provider) notConfigured("tts", "La voz del servidor no está configurada; se usa la voz del navegador.");
    const body = ttsRequestSchema.parse(await req.json());
    const key = `${provider!.id}|${body.lang}|${body.slow ? 1 : 0}|${body.text}`;
    let out = ttsCache.get(key);
    if (!out) {
      consume(claims, "ttsChars", body.text.length);
      try {
        out = await provider!.synthesize(body);
      } catch (e) {
        providerError("voz", (e as Error).message);
      }
      ttsCache.set(key, out!);
    }
    return new Response(out!.audio, {
      headers: { "Content-Type": out!.contentType, "Cache-Control": "private, max-age=3600" },
    });
  } catch (err) {
    return errorResponse(err);
  }
}
