import CoachApp from "@/components/CoachApp";

export const dynamic = "force-dynamic";

export default function Page() {
  // ?test=1 swaps voice for typing + a silent voice so the flow can be tested automatically.
  const allowTestMode = process.env.NODE_ENV !== "production" || process.env.ALLOW_TEST_MODE === "1";
  return <CoachApp allowTestMode={allowTestMode} />;
}
