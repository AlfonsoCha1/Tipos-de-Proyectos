"use client";
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { MicCapture } from "@/lib/client/audio/mic";
import { Vad } from "@/lib/client/audio/vad";
import { ApiFailure, fetchConfig, SessionApi, startSession } from "@/lib/client/api";
import { SessionController } from "@/lib/client/engine/controller";
import { PracticeService } from "@/lib/client/engine/practice";
import { BrowserSpeechListener, ServerSttListener, TextListener, type Listener } from "@/lib/client/speech/listen";
import { BrowserTts, ServerTts, TestTts, testHooks, type TtsEngine } from "@/lib/client/speech/tts";
import { deleteAllSessions, listSessions, recordingsFromUrls, saveSession } from "@/lib/client/storage/recordings";
import { BASE_TTS_RATE, DEFAULT_SETTINGS, scenarioInfo } from "@/lib/shared/scenarios";
import type { PublicConfig, SessionSettings } from "@/lib/shared/types";
import Consent from "./Consent";
import Home from "./Home";
import SessionView from "./SessionView";
import SummaryView from "./SummaryView";

type View = "home" | "consent" | "session" | "summary";

interface Runtime {
  controller: SessionController;
  practice: PracticeService;
  mic: MicCapture | null;
  keep: boolean;
  settings: SessionSettings;
}

const SETTINGS_KEY = "esc.settings.v1";

function loadSettings(): SessionSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    /* storage unavailable */
  }
  return DEFAULT_SETTINGS;
}

function useRuntimeState(rt: Runtime | null) {
  return useSyncExternalStore(
    (cb) => (rt ? rt.controller.subscribe(cb) : () => undefined),
    () => rt?.controller.getState() ?? null,
    () => null,
  );
}

export default function CoachApp({ allowTestMode }: { allowTestMode: boolean }) {
  const [view, setView] = useState<View>("home");
  const [config, setConfig] = useState<PublicConfig | null>(null);
  const [configError, setConfigError] = useState<string | null>(null);
  const [settings, setSettings] = useState<SessionSettings>(DEFAULT_SETTINGS);
  const [busy, setBusy] = useState(false);
  const [consentError, setConsentError] = useState<string | null>(null);
  const [saved, setSaved] = useState(0);
  const [testMode, setTestMode] = useState(false);
  const [testRealMic, setTestRealMic] = useState(false);
  const [runtime, setRuntime] = useState<Runtime | null>(null);
  const lastKeep = useRef(false);
  const state = useRuntimeState(runtime);

  useEffect(() => {
    setSettings(loadSettings());
    const params = new URLSearchParams(window.location.search);
    const test = allowTestMode && params.has("test");
    setTestMode(test);
    setTestRealMic(test && params.has("realmic"));
    if (test) {
      const hooks = testHooks();
      const ms = Number(params.get("ttsms"));
      if (ms > 0) hooks.ttsMs = ms;
    }
    fetchConfig()
      .then(setConfig)
      .catch((e) => setConfigError(e instanceof ApiFailure ? e.messageEs : "No pudimos conectar con el servidor."));
    listSessions().then((s) => setSaved(s.length));
  }, [allowTestMode]);

  const changeSettings = (s: SessionSettings) => {
    setSettings(s);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
    } catch {
      /* ignore */
    }
  };

  const teardown = useCallback((rt: Runtime | null) => {
    if (!rt) return;
    rt.controller.dispose();
    void rt.mic?.close();
  }, []);

  /** Runs inside the button's click: voices must be unlocked before any await (iOS/Safari). */
  const begin = async (keep: boolean) => {
    if (!config) return;
    lastKeep.current = keep;
    const api = new SessionApi();
    const browserTts = new BrowserTts();
    const tts: TtsEngine = testMode ? new TestTts() : config.tts.provider !== "browser" ? new ServerTts(api, browserTts) : browserTts;
    tts.unlock();
    setBusy(true);
    setConsentError(null);

    let mic: MicCapture | null = null;
    try {
      mic = await MicCapture.open();
    } catch (e) {
      if (!testMode) {
        setConsentError((e as Error).message);
        setBusy(false);
        setView("consent");
        return;
      }
    }
    let session;
    try {
      session = await startSession();
    } catch (e) {
      setConsentError(e instanceof ApiFailure ? e.messageEs : "No se pudo iniciar la sesión.");
      void mic?.close();
      setBusy(false);
      setView("consent");
      return;
    }
    api.setToken(session.token);

    const vad = new Vad({ silenceMs: 1500, minSpeechMs: 160, thresholdDb: 12, absoluteMinDb: -55 });
    const typing = () => new TextListener(mic, testMode);
    let listener: Listener;
    if (testMode && !testRealMic) listener = typing();
    else if (config.stt.provider !== "browser" && mic) listener = new ServerSttListener(mic, vad, api, config.limits.maxAnswerSeconds);
    else if (BrowserSpeechListener.supported()) listener = new BrowserSpeechListener(mic, vad);
    else listener = typing();

    const runSettings = settings;
    const controller = new SessionController({
      settings: runSettings,
      config,
      api,
      tts,
      listener,
      mic,
      vad,
      endsAt: session.expiresAt,
      onListenerFailure: () => typing(),
    });
    tts.onFallback = (msg) => controller.announce(msg, "warn");
    if (listener.kind === "text" && !testMode) {
      controller.announce("Tu navegador no tiene reconocimiento de voz. Escribe tus respuestas, o abre la app en Chrome o Edge para hablar.", "warn");
    }
    const practice = new PracticeService({
      tts,
      listener: () => controller.currentListener,
      api,
      rate: BASE_TTS_RATE[runSettings.level],
    });
    const rt: Runtime = { controller, practice, mic, keep, settings: runSettings };
    const unsub = controller.subscribe((s) => {
      if (s.phase !== "finished") return;
      unsub();
      if (keep) {
        void recordingsFromUrls(controller.recordings()).then(async (recordings) => {
          if (!recordings.length) return;
          await saveSession({
            id: crypto.randomUUID?.() ?? String(Date.now()),
            createdAt: Date.now(),
            scenarioLabel: scenarioInfo(runSettings.scenario).labelEs,
            recordings,
          });
          setSaved((await listSessions()).length);
        });
      }
      setView("summary");
    });
    setRuntime(rt);
    setView("session");
    setBusy(false);
    void controller.start();
  };

  const leave = (next: "home" | "again") => {
    teardown(runtime);
    setRuntime(null);
    if (next === "again") void begin(lastKeep.current);
    else setView("home");
  };

  useEffect(() => () => teardown(runtime), [runtime, teardown]);

  return (
    <div className="app">
      {testMode && <p className="note warn">Modo de prueba: voz simulada y respuestas escritas.</p>}
      {view === "home" && (
        <Home
          config={config}
          configError={configError}
          settings={settings}
          onChange={changeSettings}
          onStart={() => setView("consent")}
          savedSessions={saved}
          onDeleteSaved={() => void deleteAllSessions().then(() => setSaved(0))}
        />
      )}
      {view === "consent" && config && (
        <Consent config={config} busy={busy} error={consentError} onAccept={(keep) => void begin(keep)} onBack={() => setView("home")} />
      )}
      {view === "session" && runtime && <SessionView controller={runtime.controller} settings={runtime.settings} />}
      {view === "summary" && runtime && state?.summary && (
        <SummaryView
          summary={state.summary}
          feed={state.feed}
          practice={runtime.practice}
          errorEs={state.errorEs}
          recordingsKept={runtime.keep}
          onAgain={() => leave("again")}
          onHome={() => leave("home")}
        />
      )}
    </div>
  );
}
