"use client";
import { useState } from "react";
import type { PublicConfig } from "@/lib/shared/types";

interface Props {
  config: PublicConfig;
  busy: boolean;
  error: string | null;
  onAccept: (keepRecordings: boolean) => void;
  onBack: () => void;
}

/** Asks before touching the microphone and before keeping any recording. */
export default function Consent({ config, busy, error, onAccept, onBack }: Props) {
  const [keep, setKeep] = useState(false);
  const sendsAudio = config.stt.provider !== "browser" || config.pronunciation.measured;
  const thirdParties = [
    config.stt.provider !== "browser" ? `${config.stt.provider === "groq" ? "Groq" : "OpenAI"} (transcripción)` : null,
    config.pronunciation.measured ? "Microsoft Azure (evaluación de pronunciación)" : null,
  ].filter(Boolean);

  return (
    <main className="consent">
      <h1>Antes de empezar</h1>
      <p>El coach necesita tu micrófono para escucharte. Esto es lo que pasa con tu voz:</p>
      <ul>
        <li>Solo escuchamos mientras la sesión está abierta. Puedes terminarla cuando quieras.</li>
        {config.stt.provider === "browser" && (
          <li>
            El reconocimiento de voz lo hace tu navegador. En Chrome, el audio se procesa en los servidores de Google para
            convertirlo en texto.
          </li>
        )}
        {sendsAudio && (
          <li>
            Tu audio se envía a {thirdParties.join(" y ")} solo para procesarlo. Este servidor no lo guarda.
          </li>
        )}
        <li>
          El texto de tus respuestas se envía al{" "}
          {config.agent.live ? "modelo de IA que actúa como coach" : "servidor para aplicar las reglas de corrección"}.
        </li>
        <li>Tus grabaciones se quedan en la memoria de esta pestaña para que puedas escucharlas, y se borran al cerrarla.</li>
      </ul>

      <label className="toggle">
        <input type="checkbox" checked={keep} onChange={(e) => setKeep(e.target.checked)} />
        <div>
          Guardar mis grabaciones en este dispositivo
          <span>Opcional. Se guardan solo en este navegador para escucharlas después. Puedes borrarlas desde el inicio.</span>
        </div>
      </label>

      {error && (
        <p className="alert" role="alert">
          {error}
        </p>
      )}

      <div className="actions">
        <button type="button" className="btn btn-primary" onClick={() => onAccept(keep)} disabled={busy}>
          {busy ? "Abriendo micrófono…" : "Permitir micrófono y empezar"}
        </button>
        <button type="button" className="btn btn-quiet" onClick={onBack} disabled={busy}>
          Volver
        </button>
      </div>
    </main>
  );
}
