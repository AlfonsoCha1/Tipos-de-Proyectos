"use client";
import { LEVELS, SCENARIOS } from "@/lib/shared/scenarios";
import type { PublicConfig, SessionSettings } from "@/lib/shared/types";

interface Props {
  config: PublicConfig | null;
  configError: string | null;
  settings: SessionSettings;
  onChange: (s: SessionSettings) => void;
  onStart: () => void;
  savedSessions: number;
  onDeleteSaved: () => void;
}

const AGENT_NAMES: Record<string, string> = { groq: "Groq", openai: "OpenAI", anthropic: "Anthropic" };

export default function Home({ config, configError, settings, onChange, onStart, savedSessions, onDeleteSaved }: Props) {
  const set = <K extends keyof SessionSettings>(k: K, v: SessionSettings[K]) => onChange({ ...settings, [k]: v });

  return (
    <main className="home">
      <header>
        <h1 className="wordmark">
          English <span className="stress">Speak</span>ing Coach
        </h1>
        <p className="lede">
          Habla en inglés con un coach de IA. Te escucha, te corrige y te hace repetir las palabras difíciles. No
          tienes que escribir nada.
        </p>
      </header>

      <section className="field" aria-labelledby="f-scenario">
        <h2 id="f-scenario">¿Qué quieres practicar?</h2>
        <div className="choices">
          {SCENARIOS.map((s) => (
            <button
              key={s.id}
              type="button"
              className="choice"
              aria-pressed={settings.scenario === s.id}
              onClick={() => set("scenario", s.id)}
            >
              <strong>{s.labelEs}</strong>
              <span>{s.descriptionEs}</span>
              {s.id === "interview" && <em className="tag">Demo completa</em>}
            </button>
          ))}
        </div>
      </section>

      {settings.scenario === "interview" && (
        <section className="field" aria-labelledby="f-role">
          <h2 id="f-role">Puesto</h2>
          <div className="choices two">
            <button type="button" className="choice" aria-pressed={settings.role === "software"} onClick={() => set("role", "software")}>
              <strong>Software Engineer</strong>
              <span>Código, pruebas, proyectos</span>
            </button>
            <button type="button" className="choice" aria-pressed={settings.role === "ai"} onClick={() => set("role", "ai")}>
              <strong>AI / ML Engineer</strong>
              <span>Modelos, datos, LLMs</span>
            </button>
          </div>
        </section>
      )}

      <section className="field" aria-labelledby="f-level">
        <h2 id="f-level">Tu nivel</h2>
        <div className="choices four">
          {LEVELS.map((l) => (
            <button key={l.id} type="button" className="choice" aria-pressed={settings.level === l.id} onClick={() => set("level", l.id)}>
              <strong>{l.id}</strong>
              <span>{l.labelEs}</span>
            </button>
          ))}
        </div>
        <p className="field-note">{LEVELS.find((l) => l.id === settings.level)?.descriptionEs} El coach ajusta velocidad y dificultad mientras hablas.</p>
      </section>

      <section className="field" aria-labelledby="f-mode">
        <h2 id="f-mode">¿Cómo quieres que te corrija?</h2>
        <div className="choices two">
          <button type="button" className="choice" aria-pressed={settings.correctionMode === "teacher"} onClick={() => set("correctionMode", "teacher")}>
            <strong>Profesor</strong>
            <span>Corrige durante la charla lo importante, sin interrumpir cada frase.</span>
          </button>
          <button type="button" className="choice" aria-pressed={settings.correctionMode === "fluent"} onClick={() => set("correctionMode", "fluent")}>
            <strong>Conversación fluida</strong>
            <span>No te interrumpe. Todas las correcciones al final.</span>
          </button>
        </div>
      </section>

      <section className="field" aria-labelledby="f-length">
        <h2 id="f-length">Duración</h2>
        <div className="choices two">
          <button type="button" className="choice" aria-pressed={settings.length === "short"} onClick={() => set("length", "short")}>
            <strong>Corta</strong>
            <span>Unas 5 respuestas, 5–8 min</span>
          </button>
          <button type="button" className="choice" aria-pressed={settings.length === "full"} onClick={() => set("length", "full")}>
            <strong>Completa</strong>
            <span>Unas 9 respuestas, 10–15 min</span>
          </button>
        </div>
        <label className="toggle">
          <input type="checkbox" checked={settings.bargeIn} onChange={(e) => set("bargeIn", e.target.checked)} />
          <div>
            Interrumpir al coach hablando
            <span>Si empiezas a hablar, el coach se calla. Funciona mejor con audífonos.</span>
          </div>
        </label>
        <label className="toggle">
          <input type="checkbox" checked={settings.spokenSpanishTips} onChange={(e) => set("spokenSpanishTips", e.target.checked)} />
          <div>
            Explicaciones habladas en español
            <span>Además de verlas en pantalla, el coach las dice en voz alta.</span>
          </div>
        </label>
      </section>

      <section className="field" aria-labelledby="f-engines">
        <h2 id="f-engines">Qué está funcionando</h2>
        {configError && <p className="alert">{configError}</p>}
        {config && (
          <dl className="engines">
            <div>
              <dt>
                Coach
                <span className={`engine-state ${config.agent.live ? "on" : "off"}`}>
                  {config.agent.live ? `Agente IA (${AGENT_NAMES[config.agent.provider] ?? config.agent.provider})` : "Sin IA"}
                </span>
              </dt>
              <dd>
                {config.agent.live
                  ? "Un modelo de lenguaje decide cada turno: qué preguntar, qué corregir y qué palabra practicar."
                  : "No hay clave de IA configurada. Funciona un respaldo con preguntas fijas y reglas: sirve para probar, pero no es el agente."}
              </dd>
            </div>
            <div>
              <dt>
                Pronunciación
                <span className={`engine-state ${config.pronunciation.measured ? "on" : "off"}`}>
                  {config.pronunciation.measured ? "Medida con Azure" : "Sin medición acústica"}
                </span>
              </dt>
              <dd>
                {config.pronunciation.measured
                  ? "Tu audio se evalúa por sonido, palabra, fluidez y entonación."
                  : "Solo sabemos qué palabras reconoció el sistema. Te sugerimos palabras que suelen costar, pero no medimos tus sonidos."}
              </dd>
            </div>
            <div>
              <dt>Voz y reconocimiento</dt>
              <dd>
                {config.tts.provider === "browser" ? "Voz del navegador" : `Voz neural (${config.tts.provider})`}.{" "}
                {config.stt.provider === "browser" ? "Reconocimiento de voz del navegador (mejor en Chrome o Edge)." : `Reconocimiento con Whisper (${config.stt.provider}).`}
              </dd>
            </div>
            <div>
              <dt>Límites por sesión</dt>
              <dd>
                {config.limits.maxMinutes} minutos, {config.limits.maxTurns} turnos, respuestas de hasta {config.limits.maxAnswerSeconds} s.
              </dd>
            </div>
          </dl>
        )}
      </section>

      {savedSessions > 0 && (
        <section className="field">
          <p className="field-note">
            Tienes {savedSessions} {savedSessions === 1 ? "sesión grabada" : "sesiones grabadas"} en este dispositivo.
          </p>
          <button type="button" className="btn btn-small" onClick={onDeleteSaved}>
            Borrar grabaciones guardadas
          </button>
        </section>
      )}

      <div className="sticky-cta">
        <button type="button" className="btn btn-primary" onClick={onStart} disabled={!config}>
          Empezar a hablar
        </button>
      </div>
    </main>
  );
}
