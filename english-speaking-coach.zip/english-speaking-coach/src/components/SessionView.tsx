"use client";
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { ControllerState, DrillState, FeedItem, SessionController } from "@/lib/client/engine/controller";
import type { TextListener } from "@/lib/client/speech/listen";
import { scenarioInfo } from "@/lib/shared/scenarios";
import type { SessionSettings } from "@/lib/shared/types";
import StressWord from "./StressWord";

function useController(c: SessionController): ControllerState {
  return useSyncExternalStore(
    (cb) => c.subscribe(cb),
    () => c.getState(),
    () => c.getState(),
  );
}

function useClock(endsAt: number) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const left = Math.max(0, endsAt - now);
  const m = Math.floor(left / 60000);
  const s = Math.floor((left % 60000) / 1000);
  return { label: `${m}:${String(s).padStart(2, "0")}`, low: left < 60_000 };
}

/** The live voice line: green when you talk, indigo when the coach talks. */
function VoiceLine({ controller, who }: { controller: SessionController; who: "coach" | "you" | "idle" }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const whoRef = useRef(who);
  whoRef.current = who;
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const levels: number[] = new Array(64).fill(0);
    let raf = 0;
    let t = 0;
    const styles = getComputedStyle(document.documentElement);
    const draw = () => {
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      if (canvas.width !== w * dpr) {
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const mode = whoRef.current;
      t += 1;
      const level =
        mode === "you"
          ? controller.micLevel()
          : mode === "coach"
            ? 0.35 + 0.25 * Math.abs(Math.sin(t / 9)) * Math.abs(Math.sin(t / 23))
            : 0.02;
      levels.push(level);
      levels.shift();
      const color = mode === "coach" ? styles.getPropertyValue("--coach") : mode === "you" ? styles.getPropertyValue("--you") : styles.getPropertyValue("--ink-3");
      ctx.strokeStyle = color.trim() || "#888";
      ctx.lineWidth = 3;
      ctx.lineCap = "round";
      const step = w / (levels.length - 1);
      const mid = h / 2;
      for (let i = 0; i < levels.length; i++) {
        const amp = Math.max(1.5, levels[i] * (h / 2 - 4));
        const x = i * step;
        ctx.beginPath();
        ctx.moveTo(x, mid - amp);
        ctx.lineTo(x, mid + amp);
        ctx.stroke();
      }
      if (!reduce) raf = requestAnimationFrame(draw);
    };
    draw();
    const slow = reduce ? setInterval(draw, 250) : undefined;
    return () => {
      cancelAnimationFrame(raf);
      if (slow) clearInterval(slow);
    };
  }, [controller]);
  return <canvas ref={ref} className="voice-line" aria-hidden="true" />;
}

function DrillCard({ drill, controller, active }: { drill: DrillState; controller: SessionController; active: boolean }) {
  const statusEs: Record<DrillState["status"], string> = {
    model: "Escucha el modelo",
    listening: "Tu turno: dilo ahora",
    evaluating: "Evaluando…",
    done: "Terminado",
    skipped: "Saltada",
  };
  return (
    <section className="drill" aria-label={`Práctica de la palabra ${drill.word}`} data-testid="drill">
      <div className="row" style={{ justifyContent: "space-between" }}>
        <span className="field-note">{statusEs[drill.status]}</span>
        <span className={`badge ${drill.measured ? "measured" : "tip"}`}>{drill.measured ? "Medido con audio" : "Sugerencia, no medido"}</span>
      </div>
      <div className="drill-word">
        <StressWord word={drill.word} tip={drill.tip} /> {drill.tip && <span className="ipa">/{drill.tip.ipa}/</span>}
      </div>
      <p className="advice">{drill.adviceEs}</p>
      <p className="field-note">{drill.reasonEs}</p>
      <div className="row">
        <button type="button" className="btn btn-small" onClick={() => controller.playModel(drill.word, false)}>
          Escuchar
        </button>
        <button type="button" className="btn btn-small" onClick={() => controller.playModel(drill.word, true)}>
          Lento
        </button>
        {!active && (
          <button type="button" className="btn btn-small" onClick={() => controller.retryDrill(drill.word)}>
            Practicar otra vez
          </button>
        )}
        {active && (
          <button type="button" className="btn btn-small btn-quiet" onClick={() => controller.skipDrill()}>
            Saltar
          </button>
        )}
      </div>
      {drill.attempts.map((a, i) => (
        <div key={i} className={`attempt ${a.ok ? "ok" : "bad"}`}>
          <strong>
            Intento {i + 1}
            {a.score !== undefined ? `: ${Math.round(a.score)}/100` : a.ok ? ": reconocido" : ": no reconocido"}
          </strong>
          {a.audioUrl && (
            <button type="button" className="btn btn-small" onClick={() => controller.playRecording(a.audioUrl!)}>
              Mi grabación
            </button>
          )}
          <span>{a.feedbackEs}</span>
        </div>
      ))}
    </section>
  );
}

function FeedEntry({ item, controller, state, settings }: { item: FeedItem; controller: SessionController; state: ControllerState; settings: SessionSettings }) {
  switch (item.kind) {
    case "coach":
      return (
        <div className={`msg coach${item.spoken ? "" : " unspoken"}`} lang="en">
          {item.text}
          {!item.spoken && <div className="field-note">Lo interrumpiste: aquí está la pregunta.</div>}
        </div>
      );
    case "user":
      return (
        <div className="msg you" lang="en" data-testid="user-msg">
          {item.text}
          <div className="meta">
            {item.audioUrl && (
              <button type="button" className="btn btn-small" onClick={() => controller.playRecording(item.audioUrl!)}>
                Mi grabación
              </button>
            )}
            {settings.correctionMode === "teacher" && item.pron?.measured && item.pron.scores?.overall !== undefined && (
              <span className="badge measured">Pronunciación {Math.round(item.pron.scores.overall)}/100</span>
            )}
          </div>
          {settings.correctionMode === "teacher" && item.corrections.length > 0 && (
            <div className="fix-list">
              {item.corrections.map((c) => (
                <div key={c.id} className={`fix${c.id === item.spokenCorrectionId ? " spoken" : ""}`} data-testid="correction">
                  <del>{c.original}</del> → <ins>{c.corrected}</ins>
                  <p lang="es">{c.explanationEs}</p>
                </div>
              ))}
            </div>
          )}
          {settings.correctionMode === "teacher" && item.pron?.measured && item.pron.notes.map((n, i) => (
            <p key={i} className="field-note" lang="es">
              {n}
            </p>
          ))}
        </div>
      );
    case "drill":
      return <DrillCard drill={item.drill} controller={controller} active={state.activeDrillId === item.id} />;
    case "hint":
      return (
        <div className="hint-card" data-testid="hint">
          <p lang="es">{item.hint.es}</p>
          <p className="starter" lang="en">
            {item.hint.starter}
          </p>
        </div>
      );
    case "notice":
      return <p className={`note${item.tone === "warn" ? " warn" : ""}`}>{item.textEs}</p>;
  }
}

export default function SessionView({ controller, settings }: { controller: SessionController; settings: SessionSettings }) {
  const state = useController(controller);
  const clock = useClock(state.endsAt);
  const feedEnd = useRef<HTMLDivElement>(null);
  const [typed, setTyped] = useState("");
  const ringRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    feedEnd.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [state.feed.length, state.interim]);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      if (ringRef.current) ringRef.current.style.transform = `scale(${1 + controller.micLevel() * 0.35})`;
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [controller]);

  const drill = state.feed.find((f) => f.kind === "drill" && f.id === state.activeDrillId);
  const drillListening = drill?.kind === "drill" && drill.drill.status === "listening";
  const listening = state.phase === "listening" || drillListening;
  const speaking = state.phase === "coach" || (state.phase === "drill" && !drillListening && drill?.kind === "drill" && drill.drill.status === "model");
  const who: "coach" | "you" | "idle" = listening ? "you" : speaking ? "coach" : "idle";
  const lastCoach = [...state.feed].reverse().find((f) => f.kind === "coach");
  const statusEs = drillListening ? "Tu turno: repite la palabra" : state.statusEs;

  const mode = listening ? "listening" : speaking ? "coach" : "busy";
  const onMain = () => {
    if (listening) controller.finishTurn();
    else if (speaking) controller.interrupt();
  };
  const mainLabel = listening ? "Listo" : speaking ? "Interrumpir" : "…";

  const textListener = state.typing ? (controller.currentListener as TextListener) : null;
  const submitTyped = (e: React.FormEvent) => {
    e.preventDefault();
    if (textListener?.submit(typed)) setTyped("");
  };

  return (
    <div className="session">
      <div className="session-head">
      <div className="topbar">
        <span className="grow">
          {scenarioInfo(settings.scenario).labelEs}, nivel {settings.level}
        </span>
        <span className={`pill${state.usingBackup ? " backup" : ""}`} title="Quién responde">
          {state.usingBackup ? "Sin IA" : "IA"}
        </span>
        <span className="pill" aria-label="Tiempo restante" style={clock.low ? { color: "var(--pen)" } : undefined}>
          {clock.label}
        </span>
        <button type="button" className="btn btn-small" onClick={() => controller.end()} disabled={state.phase === "summarizing"}>
          Terminar
        </button>
      </div>

      <section className="stage" data-who={who} aria-live="polite">
        <div className="status" data-testid="status">
          {statusEs}
        </div>
        <VoiceLine controller={controller} who={who} />
        <p className={`caption${listening && state.interim ? " you" : ""}`} lang="en">
          {listening ? state.interim || (lastCoach?.kind === "coach" ? lastCoach.text : "") : lastCoach?.kind === "coach" ? lastCoach.text : ""}
        </p>
        {settings.correctionMode === "fluent" && state.deferredCorrections > 0 && (
          <p className="field-note">
            {state.deferredCorrections === 1
              ? "1 corrección guardada para el final."
              : `${state.deferredCorrections} correcciones guardadas para el final.`}
          </p>
        )}
      </section>
      </div>

      <div className="feed" aria-label="Conversación">
        {state.feed.map((item) => (
          <FeedEntry key={item.id} item={item} controller={controller} state={state} settings={settings} />
        ))}
        {state.errorEs && (
          <p className="alert" role="alert">
            {state.errorEs}
          </p>
        )}
        <div ref={feedEnd} style={{ scrollMarginBottom: 150 }} />
      </div>

      {textListener && (
        <form className="type-box" onSubmit={submitTyped}>
          <label htmlFor="typed" className="sr-only">
            Escribe tu respuesta en inglés
          </label>
          <input id="typed" value={typed} onChange={(e) => setTyped(e.target.value)} placeholder="Escribe tu respuesta en inglés" autoComplete="off" lang="en" />
          <button type="submit" className="btn btn-primary btn-small">
            Enviar
          </button>
        </form>
      )}

      <div className="dock">
        <div className="side">
          <button
            type="button"
            className="btn btn-small"
            onClick={() => controller.requestHint()}
            disabled={state.phase !== "listening"}
            aria-label="Pista en español"
            title="Pista en español"
          >
            Pista
          </button>
        </div>
        <button type="button" className="mic-btn" data-mode={mode} onClick={onMain} disabled={mode === "busy"} aria-label={mainLabel}>
          {listening && <span className="mic-ring" ref={ringRef} />}
          {mainLabel}
        </button>
        <div className="side right">
          <span className="pill" aria-label="Turnos usados">
            {state.turnsUsed}/{state.maxTurns}
          </span>
        </div>
      </div>
    </div>
  );
}
