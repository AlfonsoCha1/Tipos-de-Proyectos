import type { PronunciationTip } from "@/lib/shared/types";

/** Shows "de·VEL·op" with the stressed syllable highlighted like a marker pen. */
export default function StressWord({ word, tip }: { word: string; tip: PronunciationTip | null }) {
  const hasStress = !!tip && /[A-Z]/.test(tip.stress);
  if (!tip || !tip.stress.includes("·")) {
    // One syllable: the whole word carries the stress (if we know it).
    return <span className={hasStress ? "syl stressed" : "syl"}>{word}</span>;
  }
  const parts = tip.stress.split("·");
  return (
    <span aria-label={word}>
      {parts.map((p, i) => {
        const stressed = p === p.toUpperCase() && /[A-Z]/.test(p);
        return (
          <span key={i} aria-hidden="true">
            {i > 0 && <span className="syl-dot">·</span>}
            <span className={stressed ? "syl stressed" : "syl"}>{p.toLowerCase()}</span>
          </span>
        );
      })}
    </span>
  );
}
