"use client";
import { useState } from "react";
import type { FeedItem } from "@/lib/client/engine/controller";
import type { PracticeResult, PracticeService } from "@/lib/client/engine/practice";
import type { Exercise, SessionSummary } from "@/lib/shared/types";
import StressWord from "./StressWord";

function PracticePad({ target, practice, label }: { target: string; practice: PracticeService; label: string }) {
  const [state, setState] = useState<"idle" | "recording">("idle");
  const [result, setResult] = useState<PracticeResult | null>(null);
  const record = async () => {
    setState("recording");
    const r = await practice.attempt(target);
    setState("idle");
    if (r) setResult(r);
  };
  return (
    <div className="row" aria-label={label}>
      <button type="button" className="btn btn-small" onClick={() => practice.model(target, false)}>
        Escuchar
      </button>
      <button type="button" className="btn btn-small" onClick={() => practice.model(target, true)}>
        Lento
      </button>
      <button type="button" className="btn btn-small btn-primary" onClick={record} disabled={state === "recording"}>
        {state === "recording" ? "Te escucho…" : result ? "Otra vez" : "Grabar mi intento"}
      </button>
      {result?.audioUrl && (
        <button type="button" className="btn btn-small" onClick={() => practice.playRecording(result.audioUrl!)}>
          Mi grabación
        </button>
      )}
      {result && (
        <p className="practice-result" data-testid="practice-result">
          <strong style={{ color: result.ok ? "var(--you)" : "var(--pen)" }}>{result.ok ? "Bien." : "Casi."}</strong>{" "}
          {result.heard && <span lang="en">Escuchamos: «{result.heard}». </span>}
          {result.feedbackEs}
        </p>
      )}
    </div>
  );
}

function ExerciseItem({ ex, practice }: { ex: Exercise; practice: PracticeService }) {
  const [shown, setShown] = useState(ex.kind === "say");
  return (
    <li className="exercise">
      <p>{ex.promptEs}</p>
      {ex.wrong && (
        <p lang="en">
          <del style={{ color: "var(--pen)" }}>{ex.wrong}</del>
        </p>
      )}
      {shown ? (
        <>
          <p className="target" lang="en">
            {ex.target}
          </p>
          <PracticePad target={ex.target} practice={practice} label={`Practicar: ${ex.target}`} />
        </>
      ) : (
        <button type="button" className="btn btn-small" onClick={() => setShown(true)}>
          {ex.kind === "fix" ? "Ver la corrección" : "Ver un ejemplo"}
        </button>
      )}
    </li>
  );
}

interface Props {
  summary: SessionSummary;
  feed: FeedItem[];
  practice: PracticeService;
  errorEs: string | null;
  recordingsKept: boolean;
  onAgain: () => void;
  onHome: () => void;
}

export default function SummaryView({ summary, feed, practice, errorEs, recordingsKept, onAgain, onHome }: Props) {
  const { stats } = summary;
  const minutes = Math.floor(stats.speakingSeconds / 60);
  const seconds = stats.speakingSeconds % 60;
  return (
    <main className="summary" data-testid="summary">
      <header>
        <h1>Tu resumen</h1>
        <p className="lede">{summary.closingEs}</p>
        {errorEs && <p className="alert">{errorEs}</p>}
      </header>

      <section className="stats" aria-label="Estadísticas">
        <div className="stat">
          <b>{stats.turns}</b>
          <span>respuestas</span>
        </div>
        <div className="stat">
          <b>{stats.userWords}</b>
          <span>palabras en inglés</span>
        </div>
        <div className="stat">
          <b>{stats.speakingSeconds ? `${minutes}:${String(seconds).padStart(2, "0")}` : "–"}</b>
          <span>hablando</span>
        </div>
        <div className="stat">
          <b>{stats.wordsPerMinute || "–"}</b>
          <span>palabras por minuto</span>
        </div>
      </section>

      <section className="field" aria-labelledby="s-errors">
        <h2 id="s-errors">Tus 3 errores principales</h2>
        {summary.topErrors.length === 0 && (
          <p className="field-note">No detectamos errores de gramática o vocabulario en esta sesión. Prueba un nivel más alto.</p>
        )}
        {summary.topErrors.map((e, i) => (
          <article key={e.category} className="error-card" data-testid="top-error">
            <header>
              <span className="rank" aria-label={`Error número ${i + 1}`}>
                {i + 1}
              </span>
              <div>
                <h3>{e.labelEs}</h3>
                <span className="count">
                  {e.count === 1 ? "1 vez" : `${e.count} veces`} en esta sesión
                </span>
              </div>
            </header>
            {e.examples.map((x, j) => (
              <div key={j} className="fix">
                <del>{x.original}</del> → <ins>{x.corrected}</ins>
              </div>
            ))}
            <p>{e.explanationEs}</p>
            <ul className="exercises">
              {e.exercises.map((ex, j) => (
                <ExerciseItem key={j} ex={ex} practice={practice} />
              ))}
            </ul>
          </article>
        ))}
      </section>

      <section className="field" aria-labelledby="s-pron">
        <h2 id="s-pron">Pronunciación</h2>
        {summary.pronunciation.length === 0 && <p className="field-note">No hubo palabras para practicar esta vez.</p>}
        <div className="pron-list">
          {summary.pronunciation.map((p) => (
            <div key={p.word} className="pron-item">
              <div className="row" style={{ justifyContent: "space-between" }}>
                <span className="word">
                  <StressWord word={p.word} tip={p.tip} /> {p.tip && <span className="ipa">/{p.tip.ipa}/</span>}
                </span>
                <span className={`badge ${p.measured ? "measured" : "tip"}`}>
                  {p.measured ? (p.accuracy !== undefined ? `Medido: ${Math.round(p.accuracy)}/100` : "Medido con audio") : "Sugerencia, no medido"}
                </span>
              </div>
              <p className="advice field-note">{p.adviceEs}</p>
              <PracticePad target={p.word} practice={practice} label={`Practicar ${p.word}`} />
            </div>
          ))}
        </div>
      </section>

      <details className="transcript">
        <summary>Ver la conversación completa</summary>
        <ol>
          {feed
            .filter((f) => f.kind === "coach" || f.kind === "user")
            .map((f) =>
              f.kind === "coach" ? (
                <li key={f.id} lang="en">
                  <b>Coach:</b> {f.text}
                </li>
              ) : f.kind === "user" ? (
                <li key={f.id} lang="en">
                  <b>Tú:</b> {f.text}
                </li>
              ) : null,
            )}
        </ol>
      </details>

      <p className="field-note">
        {recordingsKept
          ? "Tus grabaciones de esta sesión se guardaron en este dispositivo."
          : "Tus grabaciones se borran al salir de esta pantalla."}
      </p>

      <div className="row">
        <button type="button" className="btn btn-primary" onClick={onAgain}>
          Practicar otra vez
        </button>
        <button type="button" className="btn" onClick={onHome}>
          Cambiar ajustes
        </button>
      </div>
    </main>
  );
}
