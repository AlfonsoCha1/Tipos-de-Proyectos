"use client";
import type {
  AgentDecision,
  AgentMemory,
  ApiErrorBody,
  ChatMessage,
  Correction,
  Observation,
  PronunciationAssessment,
  PublicConfig,
  SessionSettings,
  SessionStart,
  SessionStats,
  SessionSummary,
  SummaryPronItem,
} from "@/lib/shared/types";

export class ApiFailure extends Error {
  constructor(
    public status: number,
    public code: ApiErrorBody["code"] | "network",
    public messageEs: string,
  ) {
    super(`${status} ${code}`);
  }
}

async function parse<T>(res: Response): Promise<T> {
  if (res.ok) return (await res.json()) as T;
  let body: Partial<ApiErrorBody> = {};
  try {
    body = await res.json();
  } catch {
    /* not JSON */
  }
  throw new ApiFailure(res.status, body.code ?? "provider_error", body.messageEs ?? "El servidor respondió con un error.");
}

async function send(input: string, init: RequestInit): Promise<Response> {
  try {
    return await fetch(input, init);
  } catch {
    throw new ApiFailure(0, "network", "Sin conexión con el servidor. Revisa tu internet.");
  }
}

export async function fetchConfig(): Promise<PublicConfig> {
  return parse(await send("/api/config", { cache: "no-store" }));
}

export async function startSession(): Promise<SessionStart> {
  return parse(await send("/api/session", { method: "POST" }));
}

/** Calls to the server during one practice session (authenticated by the session token). */
export class SessionApi {
  constructor(private token = "") {}

  setToken(token: string) {
    this.token = token;
  }

  private headers(json = true): HeadersInit {
    return json
      ? { "Content-Type": "application/json", "x-session-token": this.token }
      : { "x-session-token": this.token };
  }

  async agent(body: {
    settings: SessionSettings;
    history: ChatMessage[];
    observation: Observation;
    memory: AgentMemory | null;
    engineState?: string;
  }): Promise<AgentDecision & { usage: { turns: number } }> {
    return parse(await send("/api/agent", { method: "POST", headers: this.headers(), body: JSON.stringify(body) }));
  }

  async summary(body: {
    settings: SessionSettings;
    corrections: Correction[];
    pronunciation: SummaryPronItem[];
    stats: SessionStats;
    memory: AgentMemory | null;
  }): Promise<SessionSummary> {
    return parse(await send("/api/summary", { method: "POST", headers: this.headers(), body: JSON.stringify(body) }));
  }

  async tts(text: string, lang: "en" | "es", slow: boolean): Promise<Blob> {
    const res = await send("/api/tts", {
      method: "POST",
      headers: this.headers(),
      body: JSON.stringify({ text, lang, slow }),
    });
    if (!res.ok) await parse(res);
    return res.blob();
  }

  async stt(wav: ArrayBuffer, prompt?: string): Promise<{ text: string }> {
    const form = new FormData();
    form.append("audio", new Blob([wav], { type: "audio/wav" }), "answer.wav");
    if (prompt) form.append("prompt", prompt);
    return parse(await send("/api/stt", { method: "POST", headers: this.headers(false), body: form }));
  }

  async pronunciation(args: {
    wav?: ArrayBuffer;
    referenceText: string;
    recognizedText?: string;
    mode: "scripted" | "conversation";
  }): Promise<PronunciationAssessment> {
    const form = new FormData();
    if (args.wav) form.append("audio", new Blob([args.wav], { type: "audio/wav" }), "attempt.wav");
    form.append("referenceText", args.referenceText);
    form.append("recognizedText", args.recognizedText ?? "");
    form.append("mode", args.mode);
    return parse(await send("/api/pronunciation", { method: "POST", headers: this.headers(false), body: form }));
  }
}
