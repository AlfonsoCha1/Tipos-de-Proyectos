"use client";
import { concatFloat32, rms, toDb } from "./wav";

export type FrameListener = (frame: Float32Array, db: number, frameMs: number) => void;

export class MicError extends Error {
  constructor(
    public code: "unsupported" | "insecure" | "denied" | "not-found" | "busy" | "unknown",
    message: string,
  ) {
    super(message);
  }
}

/**
 * One microphone stream for the whole session. Everything else (VAD, barge-in,
 * recordings for "play my answer") subscribes to its frames, so the browser's
 * permission prompt appears once and only after the learner agreed.
 */
export class MicCapture {
  private listeners = new Set<FrameListener>();
  private recording: Float32Array[] | null = null;
  private preRoll: Float32Array[] = [];
  private preRollSamples = 0;
  private nodes: AudioNode[] = [];
  /** Smoothed 0..1 level for the on-screen meter. */
  level = 0;

  private constructor(
    public readonly ctx: AudioContext,
    private stream: MediaStream,
    private source: MediaStreamAudioSourceNode,
  ) {}

  static async open(): Promise<MicCapture> {
    if (typeof window === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      throw new MicError("unsupported", "Este navegador no permite usar el micrófono.");
    }
    if (!window.isSecureContext) {
      throw new MicError("insecure", "El micrófono solo funciona en https:// o en localhost.");
    }
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
      });
    } catch (e) {
      const name = (e as DOMException).name;
      if (name === "NotAllowedError" || name === "SecurityError")
        throw new MicError("denied", "Bloqueaste el micrófono. Actívalo en el candado de la barra de direcciones y recarga.");
      if (name === "NotFoundError" || name === "OverconstrainedError")
        throw new MicError("not-found", "No encontramos un micrófono conectado.");
      if (name === "NotReadableError") throw new MicError("busy", "Otra aplicación está usando el micrófono.");
      throw new MicError("unknown", `No pudimos abrir el micrófono (${name}).`);
    }
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    if (ctx.state === "suspended") await ctx.resume().catch(() => undefined);
    const mic = new MicCapture(ctx, stream, ctx.createMediaStreamSource(stream));
    await mic.connect();
    return mic;
  }

  get sampleRate() {
    return this.ctx.sampleRate;
  }

  private async connect() {
    const sink = this.ctx.createGain();
    sink.gain.value = 0; // keeps the graph running without playing the mic back
    sink.connect(this.ctx.destination);
    try {
      await this.ctx.audioWorklet.addModule("/worklets/capture-processor.js");
      const node = new AudioWorkletNode(this.ctx, "capture-processor");
      node.port.onmessage = (e: MessageEvent<Float32Array>) => this.handle(e.data);
      this.source.connect(node);
      node.connect(sink);
      this.nodes = [node, sink];
    } catch {
      // Older Safari: ScriptProcessor fallback.
      const node = this.ctx.createScriptProcessor(1024, 1, 1);
      node.onaudioprocess = (e) => this.handle(new Float32Array(e.inputBuffer.getChannelData(0)));
      this.source.connect(node);
      node.connect(sink);
      this.nodes = [node, sink];
    }
  }

  private handle(frame: Float32Array) {
    const r = rms(frame);
    const db = toDb(r);
    this.level = this.level * 0.6 + Math.min(1, r * 9) * 0.4;
    if (this.recording) this.recording.push(frame);
    // Keep ~1 s of audio so an interruption doesn't lose its first syllables.
    this.preRoll.push(frame);
    this.preRollSamples += frame.length;
    while (this.preRollSamples > this.ctx.sampleRate && this.preRoll.length > 1) {
      this.preRollSamples -= this.preRoll.shift()!.length;
    }
    const ms = (frame.length / this.ctx.sampleRate) * 1000;
    for (const l of this.listeners) l(frame, db, ms);
  }

  onFrame(l: FrameListener): () => void {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  }

  startRecording(preRollMs = 0) {
    const want = Math.floor((preRollMs / 1000) * this.ctx.sampleRate);
    const seed: Float32Array[] = [];
    let have = 0;
    for (let i = this.preRoll.length - 1; i >= 0 && have < want; i--) {
      seed.unshift(this.preRoll[i]);
      have += this.preRoll[i].length;
    }
    this.recording = seed;
  }

  stopRecording(): Float32Array {
    const out = concatFloat32(this.recording ?? []);
    this.recording = null;
    return out;
  }

  async close() {
    this.listeners.clear();
    for (const n of this.nodes) n.disconnect();
    this.source.disconnect();
    this.stream.getTracks().forEach((t) => t.stop());
    await this.ctx.close().catch(() => undefined);
  }
}
