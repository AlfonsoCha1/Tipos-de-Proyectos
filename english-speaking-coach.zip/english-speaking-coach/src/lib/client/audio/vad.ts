/**
 * Energy-based voice activity detection with an adaptive noise floor.
 *
 * It answers two questions for the conversation loop:
 *  1. "Did the learner start / finish talking?" (end-of-turn detection)
 *  2. "Is the learner talking over the coach?" (barge-in / interruption)
 *
 * It measures loudness, not language — good enough for turn-taking, and it never
 * claims anything about pronunciation.
 */

export interface VadOptions {
  /** Silence after speech that ends the turn. */
  silenceMs: number;
  /** Continuous voiced time needed to count as speech (filters clicks and coughs). */
  minSpeechMs: number;
  /** How far above the noise floor a frame must be to count as voiced. */
  thresholdDb: number;
  /** Never treat anything below this as speech. */
  absoluteMinDb: number;
}

export type VadEvent = "speech-start" | "speech-end" | null;

export class Vad {
  private noiseDb = -60;
  /** Recent frame levels; the noise floor is their 10th percentile (robust to speech). */
  private history: number[] = [];
  private framesSinceEstimate = 0;
  private voicedMs = 0;
  private silentMs = 0;
  private speaking = false;
  private started = false;
  /** Latest loudness in dB, for meters. */
  levelDb = -100;

  constructor(private opts: VadOptions) {}

  configure(patch: Partial<VadOptions>) {
    this.opts = { ...this.opts, ...patch };
  }

  get isSpeaking() {
    return this.speaking;
  }
  get hasSpoken() {
    return this.started;
  }
  get noiseFloorDb() {
    return this.noiseDb;
  }

  reset(keepNoise = true) {
    if (!keepNoise) {
      this.noiseDb = -60;
      this.history = [];
    }
    this.voicedMs = 0;
    this.silentMs = 0;
    this.speaking = false;
    this.started = false;
  }

  /** Feed one frame's loudness (dBFS) and its duration. */
  push(db: number, frameMs: number): VadEvent {
    this.levelDb = db;
    const threshold = Math.max(this.noiseDb + this.opts.thresholdDb, this.opts.absoluteMinDb);
    const voiced = db > threshold;

    this.trackNoise(db);

    if (voiced) {
      this.voicedMs += frameMs;
      this.silentMs = 0;
      if (!this.speaking && this.voicedMs >= this.opts.minSpeechMs) {
        this.speaking = true;
        this.started = true;
        return "speech-start";
      }
    } else {
      this.silentMs += frameMs;
      if (this.silentMs > 120) this.voicedMs = 0;
      if (this.speaking && this.silentMs >= this.opts.silenceMs) {
        this.speaking = false;
        return "speech-end";
      }
    }
    return null;
  }

  private trackNoise(db: number) {
    this.history.push(db);
    if (this.history.length > 250) this.history.shift(); // ~5 s of 20 ms frames
    if (db < this.noiseDb) this.noiseDb = this.noiseDb + 0.3 * (db - this.noiseDb); // quiet room: follow quickly
    if (++this.framesSinceEstimate >= 10 && this.history.length >= 25) {
      this.framesSinceEstimate = 0;
      const sorted = [...this.history].sort((a, b) => a - b);
      this.noiseDb = sorted[Math.floor(sorted.length * 0.1)];
    }
  }
}

/**
 * Barge-in detector used while the coach is talking. Speaker echo raises the mic
 * level, so it first learns the echo level for a moment and then requires the
 * learner to be clearly louder than that, for long enough.
 */
export class BargeInDetector {
  private elapsed = 0;
  private echoDb = -100;
  private loudMs = 0;

  constructor(
    private noiseFloorDb: number,
    private opts = { learnMs: 350, marginDb: 9, minLoudMs: 280, absoluteMinDb: -42 },
  ) {}

  push(db: number, frameMs: number): boolean {
    this.elapsed += frameMs;
    if (this.elapsed <= this.opts.learnMs) {
      this.echoDb = Math.max(this.echoDb, db);
      return false;
    }
    // Slowly follow the echo level so long TTS sentences don't drift into false triggers.
    const threshold = Math.max(this.echoDb + this.opts.marginDb, this.noiseFloorDb + 18, this.opts.absoluteMinDb);
    if (db > threshold) {
      this.loudMs += frameMs;
      if (this.loudMs >= this.opts.minLoudMs) return true;
    } else {
      this.loudMs = Math.max(0, this.loudMs - frameMs);
      // Follow the echo level: rise quickly, fall slowly.
      const k = db > this.echoDb ? 0.2 : 0.01;
      this.echoDb += k * (db - this.echoDb);
    }
    return false;
  }
}
