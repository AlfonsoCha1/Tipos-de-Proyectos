/** Pure audio helpers (no DOM): resampling and 16-bit PCM WAV encoding. */

export function concatFloat32(chunks: Float32Array[]): Float32Array {
  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Float32Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.length;
  }
  return out;
}

/** Linear-interpolation resampler with a simple box low-pass when downsampling. */
export function resample(input: Float32Array, fromRate: number, toRate: number): Float32Array {
  if (fromRate === toRate) return input;
  const ratio = fromRate / toRate;
  const outLength = Math.floor(input.length / ratio);
  const out = new Float32Array(outLength);
  const window = Math.max(1, Math.floor(ratio));
  for (let i = 0; i < outLength; i++) {
    const pos = i * ratio;
    if (ratio > 1) {
      // average the samples that fall into this output slot (anti-aliasing)
      const start = Math.floor(pos);
      let sum = 0;
      let n = 0;
      for (let j = start; j < start + window && j < input.length; j++) {
        sum += input[j];
        n++;
      }
      out[i] = n ? sum / n : 0;
    } else {
      const i0 = Math.floor(pos);
      const i1 = Math.min(i0 + 1, input.length - 1);
      const t = pos - i0;
      out[i] = input[i0] * (1 - t) + input[i1] * t;
    }
  }
  return out;
}

/** Encodes mono float samples [-1, 1] as a canonical 44-byte-header PCM16 WAV. */
export function encodeWav(samples: Float32Array, sampleRate: number): ArrayBuffer {
  const dataSize = samples.length * 2;
  const buf = new ArrayBuffer(44 + dataSize);
  const v = new DataView(buf);
  const str = (o: number, s: string) => {
    for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
  };
  str(0, "RIFF");
  v.setUint32(4, 36 + dataSize, true);
  str(8, "WAVE");
  str(12, "fmt ");
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); // PCM
  v.setUint16(22, 1, true); // mono
  v.setUint32(24, sampleRate, true);
  v.setUint32(28, sampleRate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  str(36, "data");
  v.setUint32(40, dataSize, true);
  let o = 44;
  for (let i = 0; i < samples.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return buf;
}

/** 16 kHz mono WAV, the format pronunciation engines and Whisper handle best. */
export function toWav16k(samples: Float32Array, sampleRate: number, maxSeconds?: number): ArrayBuffer {
  let s = resample(samples, sampleRate, 16000);
  if (maxSeconds && s.length > maxSeconds * 16000) s = s.subarray(0, maxSeconds * 16000);
  return encodeWav(s, 16000);
}

export function rms(frame: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < frame.length; i++) sum += frame[i] * frame[i];
  return Math.sqrt(sum / Math.max(1, frame.length));
}

export function toDb(r: number): number {
  return 20 * Math.log10(Math.max(r, 1e-6));
}
