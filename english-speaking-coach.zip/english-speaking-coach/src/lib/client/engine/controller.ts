"use client";
import { BargeInDetector, type Vad } from "../audio/vad";
import type { MicCapture } from "../audio/mic";
import { toWav16k } from "../audio/wav";
import { ApiFailure, type SessionApi } from "../api";
import type { Listener, ListenResult } from "../speech/listen";
import type { TtsEngine } from "../speech/tts";
import { BASE_TTS_RATE, END_OF_TURN_SILENCE_MS, HINT_AFTER_MS } from "@/lib/shared/scenarios";
import { CATEGORY_ADVICE_ES, lookupTip } from "@/lib/shared/pronunciation";
import { detectCommand, rankErrors, wordCount, words } from "@/lib/shared/text";
import type {
  AgentAction,
  AgentDecision,
  AgentMemory,
  ChatMessage,
  Correction,
  Hint,
  Observation,
  PronunciationAssessment,
  PronunciationTip,
  PublicConfig,
  SessionSettings,
  SessionSummary,
  SummaryPronItem,
} from "@/lib/shared/types";

// ---------------------------------------------------------------------------
// State exposed to the UI
// ---------------------------------------------------------------------------

export type Phase = "starting" | "coach" | "listening" | "thinking" | "drill" | "summarizing" | "finished" | "error";

export interface DrillAttempt {
  audioUrl?: string;
  heard: string;
  score?: number;
  ok: boolean;
  feedbackEs: string;
}

export interface DrillState {
  id: string;
  word: string;
  tip: PronunciationTip | null;
  adviceEs: string;
  reasonEs: string;
  measured: boolean;
  status: "model" | "listening" | "evaluating" | "done" | "skipped";
  attempts: DrillAttempt[];
}

export type FeedItem =
  | { id: string; kind: "coach"; text: string; spoken: boolean }
  | {
      id: string;
      kind: "user";
      text: string;
      audioUrl?: string;
      durationSec: number;
      corrections: Correction[];
      spokenCorrectionId?: string;
      pron?: PronunciationAssessment | null;
      tips: PronunciationTip[];
    }
  | { id: string; kind: "drill"; drill: DrillState }
  | { id: string; kind: "hint"; hint: Hint }
  | { id: string; kind: "notice"; textEs: string; tone: "info" | "warn" };

export interface ControllerState {
  phase: Phase;
  statusEs: string;
  feed: FeedItem[];
  interim: string;
  turnsUsed: number;
  maxTurns: number;
  endsAt: number;
  activeDrillId: string | null;
  summary: SessionSummary | null;
  errorEs: string | null;
  agentLabel: string;
  usingBackup: boolean;
  deferredCorrections: number;
  typing: boolean;
}

export interface ControllerDeps {
  settings: SessionSettings;
  config: PublicConfig;
  api: SessionApi;
  tts: TtsEngine;
  listener: Listener;
  mic: MicCapture | null;
  /** Shared with the listener so the learned noise floor is reused for barge-in. */
  vad: Vad;
  endsAt: number;
  /** Replace the listener (e.g. speech recognition failed → typing). */
  onListenerFailure?: (reason: string) => Listener | null;
}

let seq = 0;
const uid = (p: string) => `${p}${++seq}`;

const STATUS: Record<Phase, string> = {
  starting: "Preparando al coach…",
  coach: "El coach está hablando",
  listening: "Te escucho…",
  thinking: "Pensando…",
  drill: "Práctica de pronunciación",
  summarizing: "Preparando tu resumen…",
  finished: "Sesión terminada",
  error: "Algo salió mal",
};

export class SessionController {
  private state: ControllerState;
  private subs = new Set<(s: ControllerState) => void>();
  private settings: SessionSettings;
  private memory: AgentMemory | null = null;
  private engineState: string | undefined;
  private hint: Hint | undefined;
  private lastQuestion = "";
  private history: ChatMessage[] = [];
  private corrections: Correction[] = [];
  private pronItems = new Map<string, SummaryPronItem>();
  private listenCtrl: AbortController | null = null;
  private ended = false;
  private bargedIn = false;
  private rateAdj = 1;
  private paceMul = 1;
  private levelForRate: keyof typeof BASE_TTS_RATE;
  private pendingActions: (() => Promise<void>)[] = [];
  private lastDrill: Observation["drill"] | undefined;
  private speakingSeconds = 0;
  private audioUrls: string[] = [];
  private listener: Listener;

  constructor(private deps: ControllerDeps) {
    this.settings = deps.settings;
    this.listener = deps.listener;
    this.levelForRate = deps.settings.level;
    this.state = {
      phase: "starting",
      statusEs: STATUS.starting,
      feed: [],
      interim: "",
      turnsUsed: 0,
      maxTurns: deps.config.limits.maxTurns,
      endsAt: deps.endsAt,
      activeDrillId: null,
      summary: null,
      errorEs: null,
      agentLabel: deps.config.agent.live ? `Agente IA · ${deps.config.agent.provider}` : "Respaldo sin IA",
      usingBackup: !deps.config.agent.live,
      deferredCorrections: 0,
      typing: deps.listener.kind === "text",
    };
  }

  // ---------------------------------------------------------------- UI API

  getState() {
    return this.state;
  }

  subscribe(fn: (s: ControllerState) => void) {
    this.subs.add(fn);
    return () => this.subs.delete(fn);
  }

  micLevel() {
    return this.deps.mic?.level ?? 0;
  }

  get currentListener() {
    return this.listener;
  }

  /** Show an informational note in the conversation. */
  announce(textEs: string, tone: "info" | "warn" = "info") {
    this.notice(textEs, tone);
  }

  /** Stop the coach mid-sentence and listen. */
  interrupt() {
    if (this.state.phase === "coach" || this.state.phase === "drill") {
      this.bargedIn = true;
      this.deps.tts.stop();
    }
  }

  /** "I'm done talking" button. */
  finishTurn() {
    this.listener.finishNow();
  }

  requestHint() {
    if (this.state.phase === "listening" && !this.state.activeDrillId) this.listenCtrl?.abort("hint");
  }

  skipDrill() {
    if (!this.state.activeDrillId) return;
    this.deps.tts.stop();
    this.listenCtrl?.abort("skip");
  }

  end() {
    if (this.ended) return;
    this.ended = true;
    this.deps.tts.stop();
    this.listenCtrl?.abort("end");
  }

  /** Play the model word/sentence. Pauses listening while it plays. */
  playModel(text: string, slow: boolean) {
    this.runWhilePaused(async () => {
      await this.deps.tts.speak(text, { lang: "en", rate: this.rate(), slow });
    });
  }

  /** Replay one of the learner's recordings. */
  playRecording(url: string) {
    this.runWhilePaused(
      () =>
        new Promise<void>((resolve) => {
          const a = new Audio(url);
          a.onended = () => resolve();
          a.onerror = () => resolve();
          a.play().catch(() => resolve());
        }),
    );
  }

  /** Practice a word again (drill card button). */
  retryDrill(word: string) {
    this.runWhilePaused(() =>
      this.runDrill({ type: "drill", word, reasonEs: "Práctica extra que pediste.", measured: this.deps.config.pronunciation.measured }),
    );
  }

  private runWhilePaused(job: () => Promise<void>) {
    if (this.state.phase === "finished" || this.state.phase === "error") {
      void job();
      return;
    }
    this.pendingActions.push(job);
    if (this.listenCtrl) this.listenCtrl.abort("pause");
    else if (this.state.phase === "coach" || this.state.phase === "drill") this.interrupt();
  }

  // ---------------------------------------------------------------- main loop

  async start() {
    try {
      let decision = await this.callAgent({ kind: "start" });
      while (!this.ended) {
        await this.execute(decision);
        if (decision.done || this.ended) break;
        if (this.timeUp()) {
          await this.say("We're out of time for today. Great effort! Let's look at your feedback.", "en");
          break;
        }
        const obs = await this.collectAnswer();
        if (obs === "end") break;
        this.set({ phase: "thinking" });
        try {
          decision = await this.callAgent(obs);
        } catch (e) {
          if (e instanceof ApiFailure && (e.code === "limit_turns" || e.code === "session_expired")) {
            this.notice(e.messageEs, "warn");
            await this.say("That's all the time we have today. Let's look at your feedback.", "en");
            break;
          }
          throw e;
        }
      }
      await this.finish();
    } catch (e) {
      const msg = e instanceof ApiFailure ? e.messageEs : "Se perdió la conexión con el coach.";
      console.error(e);
      this.set({ phase: "error", errorEs: msg });
      await this.finish().catch(() => undefined);
    }
  }

  private async callAgent(observation: Observation): Promise<AgentDecision> {
    const obs = this.lastDrill && observation.kind === "answer" ? { ...observation, drill: this.lastDrill } : observation;
    this.lastDrill = undefined;
    let d: AgentDecision & { usage?: { turns: number } };
    try {
      d = await this.deps.api.agent({
        settings: this.settings,
        history: this.history,
        observation: obs,
        memory: this.memory,
        engineState: this.engineState,
      });
    } catch (e) {
      if (e instanceof ApiFailure && e.code === "network") {
        await new Promise((r) => setTimeout(r, 1500));
        d = await this.deps.api.agent({ settings: this.settings, history: this.history, observation: obs, memory: this.memory, engineState: this.engineState });
      } else if (e instanceof ApiFailure && e.code === "bad_request") {
        // Don't lose the conversation over an optional field: retry with the essentials.
        const minimal: Observation = { kind: obs.kind, userText: obs.userText, signals: obs.signals };
        d = await this.deps.api.agent({ settings: this.settings, history: this.history.slice(-12), observation: minimal, memory: this.memory, engineState: this.engineState });
      } else throw e;
    }
    this.memory = d.memory;
    this.engineState = d.engineState;
    if (d.hint) this.hint = d.hint;
    if (d.usage) this.set({ turnsUsed: d.usage.turns });
    if (d.fallbackUsed && !this.state.usingBackup) {
      this.notice("El agente de IA no respondió: este turno lo contestó el respaldo sin IA.", "warn");
    }
    this.set({ usingBackup: d.provider === "offline" });
    return d;
  }

  /** Runs the agent's actions in order: speech, spoken corrections, drills, adjustments. */
  private async execute(d: AgentDecision) {
    const lastUser = [...this.state.feed].reverse().find((f) => f.kind === "user");
    if (lastUser && lastUser.kind === "user" && d.corrections.length) {
      const tagged = d.corrections.map((c) => ({ ...c, turnIndex: this.history.length }));
      this.corrections.push(...tagged);
      if (this.settings.correctionMode === "teacher") {
        this.patchFeed(lastUser.id, { corrections: tagged, tips: d.pronunciationTips });
      } else {
        this.set({ deferredCorrections: this.corrections.length });
      }
    }
    for (const t of d.pronunciationTips) this.addPronItem(t.word, false, undefined, t.tipEs, t);

    const coachSaid: string[] = [];
    let interrupted = false;
    for (const action of d.actions) {
      if (this.ended) break;
      if (interrupted) {
        // Show the question on screen even if it wasn't spoken, so the learner can read it.
        if (action.type === "say" && action.purpose !== "reaction" && action.purpose !== "encouragement") {
          this.pushFeed({ id: uid("c"), kind: "coach", text: action.text, spoken: false });
          coachSaid.push(action.text);
          this.lastQuestion = action.text;
        }
        continue;
      }
      if (action.type === "say") {
        this.pushFeed({ id: uid("c"), kind: "coach", text: action.text, spoken: true });
        coachSaid.push(action.text);
        if (action.purpose !== "reaction" && action.purpose !== "encouragement") this.lastQuestion = action.text;
        interrupted = !(await this.say(action.text, "en"));
      } else if (action.type === "correct") {
        const c = this.corrections.find((x) => x.id === action.correctionId);
        if (!c || !lastUser) continue;
        this.patchFeed(lastUser.id, { spokenCorrectionId: c.id });
        interrupted = !(await this.say(c.spokenTip, "en"));
        if (!interrupted && this.settings.spokenSpanishTips) interrupted = !(await this.say(c.explanationEs, "es"));
      } else if (action.type === "drill") {
        await this.runDrill(action);
      } else if (action.type === "adjust") {
        if (action.level) this.levelForRate = action.level;
        if (action.pace) this.paceMul = action.pace === "slower" ? 0.88 : action.pace === "faster" ? 1.06 : 1;
        this.notice(action.reasonEs || "Ajusté la dificultad a tu nivel.", "info");
      }
      await this.drainPending();
    }
    if (coachSaid.length) this.history.push({ role: "coach", text: coachSaid.join(" ") });
  }

  private async drainPending() {
    while (this.pendingActions.length) {
      const job = this.pendingActions.shift()!;
      await job();
    }
  }

  /** Speaks and returns false if the learner interrupted. */
  private async say(text: string, lang: "en" | "es", slow = false): Promise<boolean> {
    const prev = this.state.phase;
    if (prev !== "drill") this.set({ phase: "coach" });
    let stopWatch: (() => void) | undefined;
    if (this.settings.bargeIn && this.deps.mic) {
      const det = new BargeInDetector(this.deps.vad.noiseFloorDb);
      stopWatch = this.deps.mic.onFrame((_f, db, ms) => {
        if (det.push(db, ms)) {
          this.bargedIn = true;
          this.deps.tts.stop();
        }
      });
    }
    const r = await this.deps.tts.speak(text, { lang, rate: this.rate(), slow });
    stopWatch?.();
    return !r.interrupted;
  }

  private rate() {
    return Math.max(0.65, Math.min(1.2, BASE_TTS_RATE[this.levelForRate] * this.paceMul * this.rateAdj));
  }

  private async listenOnce(overrides: Partial<{ silenceMs: number; maxMs: number; noSpeechMs: number }> = {}): Promise<ListenResult> {
    this.listenCtrl = new AbortController();
    const level = this.settings.level;
    const res = await this.listener.listen(
      {
        silenceMs: overrides.silenceMs ?? END_OF_TURN_SILENCE_MS[level],
        maxMs: overrides.maxMs ?? this.deps.config.limits.maxAnswerSeconds * 1000,
        noSpeechMs: overrides.noSpeechMs ?? HINT_AFTER_MS[level],
        preRollMs: this.bargedIn ? 900 : 200,
        onInterim: (t) => this.set({ interim: t }),
      },
      this.listenCtrl.signal,
    );
    this.bargedIn = false;
    this.listenCtrl = null;
    this.set({ interim: "" });
    if (res.status === "error") {
      const next = this.deps.onListenerFailure?.(res.error ?? "error");
      if (next) {
        this.listener = next;
        this.set({ typing: next.kind === "text" });
        this.notice(
          res.error === "not-allowed" || res.error === "service-not-allowed"
            ? "El reconocimiento de voz fue bloqueado. Puedes escribir tus respuestas mientras tanto."
            : "El reconocimiento de voz del navegador no está disponible aquí. Escribe tus respuestas o usa Chrome/Edge.",
          "warn",
        );
      }
    }
    return res;
  }

  /** Listens for an answer, handling silence (hint in Spanish), voice commands and pauses. */
  private async collectAnswer(): Promise<Observation | "end"> {
    let hintGiven = false;
    let silences = 0;
    let unrecognized = 0;
    const signals = new Set<NonNullable<Observation["signals"]>[number]>();
    while (!this.ended) {
      if (this.timeUp()) return "end";
      this.set({ phase: "listening" });
      const res = await this.listenOnce({ noSpeechMs: HINT_AFTER_MS[this.settings.level] * (hintGiven ? 1.6 : 1) });
      if (this.ended) return "end";

      if (res.status === "aborted") {
        if (res.abortReason === "hint") {
          signals.add("asked-hint");
          await this.giveHint();
          hintGiven = true;
        } else if (res.abortReason === "end") return "end";
        await this.drainPending();
        continue;
      }
      if (res.status === "error") continue;
      if (res.status === "no-speech") {
        silences++;
        signals.add("long-silence");
        if (!hintGiven) {
          await this.giveHint();
          hintGiven = true;
          continue;
        }
        if (silences < 3) {
          await this.say("Take your time. Here's the question again.", "en");
          this.rateAdj = Math.max(0.82, this.rateAdj - 0.06);
          await this.say(this.lastQuestion, "en");
          continue;
        }
        return { kind: "silence", signals: [...signals] };
      }
      if (res.status === "unrecognized" || !res.text.trim()) {
        unrecognized++;
        if (unrecognized >= 3) return { kind: "silence", signals: [...signals] };
        await this.say("Sorry, I didn't catch that. Could you say it again?", "en");
        continue;
      }

      const text = res.text.trim();
      const cmd = detectCommand(text);
      if (cmd === "end") return "end";
      if (cmd === "repeat" || cmd === "slower") {
        signals.add(cmd === "repeat" ? "asked-repeat" : "asked-slower");
        this.rateAdj = Math.max(0.8, this.rateAdj - (cmd === "slower" ? 0.1 : 0.05));
        if (cmd === "slower") await this.say("Sure, I'll speak more slowly.", "en");
        await this.say(this.lastQuestion, "en");
        continue;
      }
      if (cmd === "hint") {
        signals.add("asked-hint");
        await this.giveHint();
        hintGiven = true;
        continue;
      }
      if (cmd === "skip") {
        signals.add("asked-skip");
        return { kind: "silence", signals: [...signals] };
      }

      // A real answer.
      const audioUrl = this.makeAudioUrl(res);
      const durationSec = res.durationMs / 1000;
      const n = wordCount(text);
      this.speakingSeconds += Math.max(1, durationSec - (res.latencyMs ?? 0) / 1000);
      const userItem: FeedItem = { id: uid("u"), kind: "user", text, audioUrl, durationSec, corrections: [], tips: [], pron: undefined };
      this.pushFeed(userItem);
      this.history.push({ role: "user", text });
      if (n >= 12 && !signals.size) this.rateAdj = Math.min(1, this.rateAdj + 0.03);

      this.set({ phase: "thinking" });
      const pron = await this.assessAnswer(res, text);
      if (pron) this.patchFeed(userItem.id, { pron });
      const speechSec = Math.max(0.5, durationSec - (res.latencyMs ?? 0) / 1000);
      return {
        kind: "answer",
        userText: text,
        speech: {
          durationSec: Math.round(durationSec * 10) / 10,
          wordsPerMinute: Math.min(400, Math.round((n / speechSec) * 60)),
          latencySec: res.latencyMs ? Math.round(res.latencyMs / 100) / 10 : undefined,
        },
        pronunciation: pron
          ? {
              measured: pron.measured,
              overall: pron.scores?.overall,
              fluency: pron.scores?.fluency,
              prosody: pron.scores?.prosody,
              problemWords: pron.problemWords.map((p) => ({
                word: p.word,
                accuracy: p.accuracy,
                phoneme: p.worstPhoneme?.phoneme,
                phonemeAccuracy: p.worstPhoneme?.accuracy,
              })),
            }
          : undefined,
        signals: signals.size ? [...signals] : undefined,
      };
    }
    return "end";
  }

  /** Acoustic assessment of a free answer — only when a real engine is configured. */
  private async assessAnswer(res: ListenResult, text: string): Promise<PronunciationAssessment | null> {
    if (!this.deps.config.pronunciation.measured || !res.samples?.length || !res.sampleRate) return null;
    try {
      const wav = toWav16k(res.samples, res.sampleRate, 30);
      const pron = await Promise.race([
        this.deps.api.pronunciation({ wav, referenceText: text, recognizedText: text, mode: "conversation" }),
        new Promise<null>((r) => setTimeout(() => r(null), 7000)),
      ]);
      if (pron) for (const p of pron.problemWords) this.addPronItem(p.word, true, p.accuracy, p.adviceEs, p.tip);
      return pron;
    } catch (e) {
      if (e instanceof ApiFailure && e.code === "limit_assessments") this.notice(e.messageEs, "warn");
      return null;
    }
  }

  private async giveHint() {
    const hint = this.hint ?? {
      es: "Responde con una o dos frases sencillas. No tiene que ser perfecto.",
      starter: "I think that…",
    };
    this.pushFeed({ id: uid("h"), kind: "hint", hint });
    this.set({ phase: "coach" });
    const ok = await this.say(hint.es, "es");
    if (ok) await this.say(`You could start with: ${hint.starter}`, "en");
  }

  // ---------------------------------------------------------------- drills

  private async runDrill(action: Extract<AgentAction, { type: "drill" }>) {
    const word = action.word;
    const tip = lookupTip(word);
    const lastPron = [...this.state.feed].reverse().find((f) => f.kind === "user" && f.pron?.measured);
    const measuredProblem =
      lastPron && lastPron.kind === "user" ? lastPron.pron?.problemWords.find((p) => p.word === word) : undefined;
    const drill: DrillState = {
      id: uid("d"),
      word,
      tip,
      adviceEs: measuredProblem?.adviceEs ?? tip?.tipEs ?? CATEGORY_ADVICE_ES.stress,
      reasonEs: action.reasonEs,
      measured: action.measured,
      status: "model",
      attempts: [],
    };
    const feedId = drill.id;
    this.pushFeed({ id: feedId, kind: "drill", drill });
    this.set({ phase: "drill", activeDrillId: feedId });
    const update = (patch: Partial<DrillState>) => {
      Object.assign(drill, patch);
      this.patchFeed(feedId, { drill: { ...drill, attempts: [...drill.attempts] } });
    };

    const intro = action.measured
      ? `Let's work on the word "${word}". It wasn't very clear. Listen.`
      : `"${word}" is a word many Spanish speakers find tricky. Let's practice it. Listen.`;
    const model = async () =>
      (await this.say(intro, "en")) &&
      (await this.say(word, "en")) &&
      (await this.say(word, "en", true)) &&
      (!this.settings.spokenSpanishTips || (await this.say(drill.adviceEs, "es"))) &&
      (await this.say("Now you try.", "en"));
    await model();
    await this.drainPending();

    let success = false;
    let lastScore: number | undefined;
    for (let attempt = 0; attempt < 2 && !this.ended; attempt++) {
      update({ status: "listening" });
      const res = await this.listenOnce({ silenceMs: 900, maxMs: 7000, noSpeechMs: 7000 });
      if (res.status === "aborted") {
        if (res.abortReason === "pause") {
          await this.drainPending();
          attempt--;
          continue;
        }
        update({ status: "skipped" });
        break;
      }
      if (res.status === "no-speech" || res.status === "error") {
        await this.say("No problem. We'll practice it later.", "en");
        update({ status: "skipped" });
        break;
      }
      update({ status: "evaluating" });
      const audioUrl = this.makeAudioUrl(res);
      const evaluation = await this.evaluateAttempt(word, res);
      lastScore = evaluation.score;
      drill.attempts.push({ audioUrl, heard: res.text, score: evaluation.score, ok: evaluation.ok, feedbackEs: evaluation.feedbackEs });
      update({});
      if (evaluation.ok) {
        success = true;
        await this.say(
          evaluation.measured && evaluation.score !== undefined
            ? `Much better! That scored ${Math.round(evaluation.score)} out of 100.`
            : `Good, I heard "${word}" clearly.`,
          "en",
        );
        break;
      }
      if (attempt === 0) {
        await this.say(evaluation.measured ? "Almost. Listen again." : `I didn't quite catch "${word}". Listen once more.`, "en");
        await this.say(word, "en", true);
        await this.say("Try again.", "en");
      } else {
        await this.say("Good effort. I'll add it to your practice list.", "en");
      }
    }
    if (drill.status !== "skipped") update({ status: "done" });
    this.addPronItem(word, action.measured, lastScore, drill.adviceEs, tip);
    this.lastDrill = { word, success, attempts: drill.attempts.length, accuracy: lastScore, measured: action.measured };
    this.set({ activeDrillId: null, phase: "coach" });
  }

  private async evaluateAttempt(word: string, res: ListenResult) {
    const heardWords = words(res.text);
    const heard = heardWords.includes(word.toLowerCase());
    try {
      const wav = res.samples?.length && res.sampleRate ? toWav16k(res.samples, res.sampleRate, 10) : undefined;
      const a = await this.deps.api.pronunciation({ wav, referenceText: word, recognizedText: res.text, mode: "scripted" });
      if (a.measured) {
        const score = a.scores?.accuracy ?? a.words[0]?.accuracy;
        const worst = a.problemWords[0]?.worstPhoneme;
        const ok = (score ?? 0) >= 80;
        const feedbackEs =
          score === undefined
            ? a.notes[0] ?? "No se pudo medir este intento."
            : `Puntaje acústico: ${Math.round(score)}/100.` +
              (worst && !ok ? ` El sonido /${worst.phoneme}/ obtuvo ${Math.round(worst.accuracy)}/100.` : "");
        return { ok, score, measured: true, feedbackEs };
      }
    } catch (e) {
      if (e instanceof ApiFailure && e.code === "limit_assessments") this.notice(e.messageEs, "warn");
    }
    return {
      ok: heard,
      score: undefined,
      measured: false,
      feedbackEs: heard
        ? `El reconocedor escuchó «${word}». (Comparación de texto, no medición de sonidos.)`
        : `El reconocedor escuchó «${res.text || "…"}». (Comparación de texto, no medición de sonidos.)`,
    };
  }

  // ---------------------------------------------------------------- end

  private async finish() {
    if (this.state.phase === "finished") return;
    this.ended = true;
    this.set({ phase: "summarizing", activeDrillId: null });
    const userItems = this.state.feed.filter((f) => f.kind === "user");
    const userWords = userItems.reduce((n, f) => n + (f.kind === "user" ? wordCount(f.text) : 0), 0);
    // Typed answers (no speech recognition) have no meaningful speaking time.
    const spoke = this.listener.kind !== "text" && this.speakingSeconds > 0;
    const stats = {
      turns: userItems.length,
      userWords,
      speakingSeconds: spoke ? Math.round(this.speakingSeconds) : 0,
      wordsPerMinute: spoke ? Math.min(400, Math.round((userWords / this.speakingSeconds) * 60)) : 0,
      corrections: this.corrections.length,
    };
    const pronunciation = [...this.pronItems.values()].sort((a, b) => Number(b.measured) - Number(a.measured) || (a.accuracy ?? 100) - (b.accuracy ?? 100));
    let summary: SessionSummary;
    try {
      summary = await this.deps.api.summary({
        settings: this.settings,
        corrections: this.corrections,
        pronunciation,
        stats,
        memory: this.memory,
      });
    } catch {
      summary = {
        topErrors: rankErrors(this.corrections).slice(0, 3).map((g) => ({
          ...g,
          exercises: g.examples[0] ? [{ kind: "say", promptEs: "Di la versión correcta en voz alta.", target: g.examples[0].corrected }] : [],
        })),
        pronunciation,
        stats,
        closingEs: "No pudimos generar el resumen completo, pero aquí están tus errores principales.",
        provider: "local",
      };
    }
    this.set({ phase: "finished", summary, statusEs: STATUS.finished });
  }

  /** Revokes recording URLs (call when leaving the summary if recordings aren't kept). */
  dispose() {
    this.end();
    for (const u of this.audioUrls) URL.revokeObjectURL(u);
    this.audioUrls = [];
  }

  /** Recordings of this session, for optional saving on the device. */
  recordings(): { text: string; url: string }[] {
    return this.state.feed.flatMap((f) => (f.kind === "user" && f.audioUrl ? [{ text: f.text, url: f.audioUrl }] : []));
  }

  // ---------------------------------------------------------------- helpers

  private makeAudioUrl(res: ListenResult): string | undefined {
    if (!res.samples || res.samples.length < 1600 || !res.sampleRate) return undefined;
    const url = URL.createObjectURL(new Blob([toWav16k(res.samples, res.sampleRate)], { type: "audio/wav" }));
    this.audioUrls.push(url);
    return url;
  }

  private addPronItem(word: string, measured: boolean, accuracy: number | undefined, adviceEs: string, tip: PronunciationTip | null) {
    const prev = this.pronItems.get(word);
    if (prev && prev.measured && !measured) return;
    this.pronItems.set(word, { word, measured, accuracy: accuracy ?? prev?.accuracy, adviceEs, tip });
  }

  private timeUp() {
    return Date.now() > this.deps.endsAt - 3000;
  }

  private notice(textEs: string, tone: "info" | "warn") {
    this.pushFeed({ id: uid("n"), kind: "notice", textEs, tone });
  }

  private pushFeed(item: FeedItem) {
    this.set({ feed: [...this.state.feed, item] });
  }

  private patchFeed(id: string, patch: Record<string, unknown>) {
    this.set({ feed: this.state.feed.map((f) => (f.id === id ? ({ ...f, ...patch } as FeedItem) : f)) });
  }

  private set(patch: Partial<ControllerState>) {
    const next = { ...this.state, ...patch };
    if (patch.phase) next.statusEs = STATUS[patch.phase];
    this.state = next;
    for (const fn of this.subs) fn(next);
  }
}
