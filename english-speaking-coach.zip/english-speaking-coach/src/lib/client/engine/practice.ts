"use client";
import { toWav16k } from "../audio/wav";
import { ApiFailure, type SessionApi } from "../api";
import type { Listener } from "../speech/listen";
import type { TtsEngine } from "../speech/tts";
import { words } from "@/lib/shared/text";

export interface PracticeResult {
  audioUrl?: string;
  heard: string;
  ok: boolean;
  score?: number;
  measured: boolean;
  feedbackEs: string;
}

/** Standalone practice after the session: model audio, record an attempt, evaluate it. */
export class PracticeService {
  private busy = false;

  constructor(
    private deps: { tts: TtsEngine; listener: () => Listener; api: SessionApi; rate: number },
  ) {}

  get isBusy() {
    return this.busy;
  }

  async model(text: string, slow: boolean) {
    await this.deps.tts.speak(text, { lang: "en", rate: this.deps.rate, slow });
  }

  playRecording(url: string) {
    const a = new Audio(url);
    a.play().catch(() => undefined);
  }

  async attempt(target: string): Promise<PracticeResult | null> {
    if (this.busy) return null;
    this.busy = true;
    try {
      const ctrl = new AbortController();
      const res = await this.deps.listener().listen(
        { silenceMs: 1100, maxMs: 15000, noSpeechMs: 8000, preRollMs: 150 },
        ctrl.signal,
      );
      if (res.status === "no-speech" || res.status === "aborted" || res.status === "error") {
        return { heard: "", ok: false, measured: false, feedbackEs: "No escuchamos nada. Acércate al micrófono e inténtalo otra vez." };
      }
      const audioUrl =
        res.samples && res.samples.length > 1600 && res.sampleRate
          ? URL.createObjectURL(new Blob([toWav16k(res.samples, res.sampleRate)], { type: "audio/wav" }))
          : undefined;
      try {
        const wav = res.samples?.length && res.sampleRate ? toWav16k(res.samples, res.sampleRate, 30) : undefined;
        const a = await this.deps.api.pronunciation({ wav, referenceText: target, recognizedText: res.text, mode: "scripted" });
        if (a.measured) {
          const score = a.scores?.overall ?? a.scores?.accuracy;
          const ok = (score ?? 0) >= 80;
          const worst = a.problemWords[0];
          return {
            audioUrl,
            heard: res.text,
            ok,
            score,
            measured: true,
            feedbackEs:
              score === undefined
                ? a.notes[0] ?? "No se pudo medir este intento."
                : `Puntaje acústico ${Math.round(score)}/100.` + (worst && !ok ? ` Revisa «${worst.word}»: ${worst.adviceEs}` : ""),
          };
        }
      } catch (e) {
        if (!(e instanceof ApiFailure)) throw e;
      }
      const expected = words(target);
      const heard = new Set(words(res.text));
      const missing = expected.filter((w) => !heard.has(w));
      const ratio = expected.length ? (expected.length - missing.length) / expected.length : 0;
      return {
        audioUrl,
        heard: res.text,
        ok: ratio >= 0.8,
        measured: false,
        feedbackEs:
          (missing.length
            ? `El reconocedor no captó: ${missing.slice(0, 5).join(", ")}.`
            : "El reconocedor captó todas las palabras.") + " (Comparación de texto, no medición de sonidos.)",
      };
    } finally {
      this.busy = false;
    }
  }
}
