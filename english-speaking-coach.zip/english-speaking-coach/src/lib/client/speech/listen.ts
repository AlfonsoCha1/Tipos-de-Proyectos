"use client";
import type { MicCapture } from "../audio/mic";
import type { Vad } from "../audio/vad";
import { toWav16k } from "../audio/wav";
import type { SessionApi } from "../api";
import { testHooks } from "./tts";

/**
 * A Listener captures ONE learner turn: it decides when the learner finished
 * (silence detection), returns the transcript, and keeps the audio so the learner
 * can replay it and the pronunciation engine can score it.
 *
 * Implementations:
 *  - BrowserSpeechListener: Web Speech API (free; Chrome, Edge, Safari). Live captions.
 *  - ServerSttListener: our VAD + Whisper on the server (Groq/OpenAI key needed).
 *  - TextListener: typing fallback for browsers without speech recognition, and the
 *    hook used by automated tests.
 */

export interface ListenOptions {
  silenceMs: number;
  maxMs: number;
  noSpeechMs: number;
  preRollMs: number;
  onInterim?: (text: string) => void;
  onSpeechStart?: () => void;
}

export type ListenStatus = "ok" | "no-speech" | "unrecognized" | "aborted" | "error";

export interface ListenResult {
  status: ListenStatus;
  text: string;
  samples?: Float32Array;
  sampleRate?: number;
  durationMs: number;
  /** Time from "listening" to the first sign of speech. */
  latencyMs?: number;
  abortReason?: string;
  error?: string;
}

export interface Listener {
  readonly kind: "browser" | "server" | "text";
  listen(opts: ListenOptions, signal: AbortSignal): Promise<ListenResult>;
  /** Manual "I'm done" button. */
  finishNow(): void;
}

const now = () => performance.now();

/** Joins transcript pieces, removing the duplicates some Android builds send. */
export function joinText(...parts: string[]): string {
  let acc = "";
  for (const raw of parts) {
    const p = raw.trim();
    if (!p) continue;
    const a = acc.toLowerCase();
    const l = p.toLowerCase();
    if (!acc) acc = p;
    else if (l.startsWith(a)) acc = p;
    else if (a.endsWith(l) || a.includes(l)) continue;
    else acc = `${acc} ${p}`;
  }
  return acc;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: ((e: { results: ArrayLike<{ isFinal: boolean; 0?: { transcript: string } }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
}

function recognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: SpeechRecognitionCtor; webkitSpeechRecognition?: SpeechRecognitionCtor };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export class BrowserSpeechListener implements Listener {
  readonly kind = "browser" as const;
  private manual: (() => void) | null = null;

  constructor(
    private mic: MicCapture | null,
    private vad: Vad,
  ) {}

  static supported() {
    return recognitionCtor() !== null;
  }

  finishNow() {
    this.manual?.();
  }

  listen(opts: ListenOptions, signal: AbortSignal): Promise<ListenResult> {
    const Ctor = recognitionCtor()!;
    const { mic, vad } = this;
    return new Promise((resolve) => {
      const t0 = now();
      let committed = "";
      let runFinal = "";
      let runInterim = "";
      let lastResultAt = 0;
      let firstSignAt = 0;
      let vadEndAt = 0;
      let finished = false;
      let stopping = false;
      let restarts = 0;
      let onStopped: (() => void) | null = null;
      const text = () => joinText(committed, runFinal, runInterim);

      vad.reset();
      vad.configure({ silenceMs: opts.silenceMs });
      mic?.startRecording(opts.preRollMs);
      const unsub = mic?.onFrame((_f, db, ms) => {
        const e = vad.push(db, ms);
        if (e === "speech-start") {
          firstSignAt ||= now();
          vadEndAt = 0;
          opts.onSpeechStart?.();
        } else if (e === "speech-end") vadEndAt = now();
      });

      const create = () => {
        const r = new Ctor();
        r.lang = "en-US";
        r.continuous = true;
        r.interimResults = true;
        r.maxAlternatives = 1;
        r.onresult = (e) => {
          let fin = "";
          let int = "";
          for (let i = 0; i < e.results.length; i++) {
            const res = e.results[i];
            const t = res[0]?.transcript ?? "";
            if (res.isFinal) fin = joinText(fin, t);
            else int += t;
          }
          runFinal = fin;
          runInterim = int;
          lastResultAt = now();
          firstSignAt ||= lastResultAt;
          opts.onInterim?.(text());
        };
        r.onerror = (e) => {
          if (e.error === "no-speech" || e.error === "aborted") return;
          void finish("error", e.error);
        };
        r.onend = () => {
          if (stopping) {
            onStopped?.();
            return;
          }
          if (finished) return;
          // Chrome ends recognition after a pause (Android after every phrase): keep going.
          committed = text();
          runFinal = "";
          runInterim = "";
          if (restarts++ < 30) {
            try {
              rec = create();
              rec.start();
            } catch {
              /* will be finalized by the timers */
            }
          }
        };
        return r;
      };

      let rec = create();

      const finish = async (status: ListenStatus, detail?: string) => {
        if (finished) return;
        finished = true;
        clearInterval(tick);
        this.manual = null;
        if (status === "ok") {
          stopping = true;
          await new Promise<void>((r) => {
            const t = setTimeout(r, 700); // Chrome delivers the last final result after stop()
            onStopped = () => {
              clearTimeout(t);
              r();
            };
            try {
              rec.stop();
            } catch {
              r();
            }
          });
        } else {
          stopping = true;
          try {
            rec.abort();
          } catch {
            /* ignore */
          }
        }
        unsub?.();
        const samples = mic?.stopRecording();
        const finalText = text().trim();
        resolve({
          status: status === "ok" && !finalText ? "unrecognized" : status,
          text: finalText,
          samples,
          sampleRate: mic?.sampleRate,
          durationMs: now() - t0,
          latencyMs: firstSignAt ? firstSignAt - t0 : undefined,
          abortReason: status === "aborted" ? detail : undefined,
          error: status === "error" ? detail : undefined,
        });
      };

      const tick = setInterval(() => {
        const t = now() - t0;
        const has = text().trim().length > 0;
        if (t >= opts.maxMs) return void finish("ok");
        if (has) {
          const quietFor = now() - lastResultAt;
          const vadQuiet = !mic || !vad.isSpeaking;
          if (quietFor >= opts.silenceMs && vadQuiet) return void finish("ok");
          if (vadEndAt && quietFor >= 450) return void finish("ok");
        } else {
          if (vadEndAt && now() - vadEndAt >= 1800) return void finish("unrecognized");
          if (!vad.hasSpoken && t >= opts.noSpeechMs) return void finish("no-speech");
          if (t >= opts.noSpeechMs + 10_000) return void finish("unrecognized");
        }
      }, 100);

      signal.addEventListener("abort", () => void finish("aborted", String(signal.reason ?? "aborted")), { once: true });
      this.manual = () => void finish(text().trim() ? "ok" : "unrecognized");
      try {
        rec.start();
      } catch {
        void finish("error", "start-failed");
      }
    });
  }
}

const WHISPER_HALLUCINATIONS = /^(thanks? (you )?for watching[.!]?|thank you[.!]?|you[.!]?|bye[.!]?|\.+)$/i;

export class ServerSttListener implements Listener {
  readonly kind = "server" as const;
  private manual: (() => void) | null = null;

  constructor(
    private mic: MicCapture,
    private vad: Vad,
    private api: SessionApi,
    private maxAnswerSeconds: number,
  ) {}

  finishNow() {
    this.manual?.();
  }

  listen(opts: ListenOptions, signal: AbortSignal): Promise<ListenResult> {
    const { mic, vad } = this;
    return new Promise((resolve) => {
      const t0 = now();
      let firstSignAt = 0;
      let speechMs = 0;
      let finished = false;
      vad.reset();
      vad.configure({ silenceMs: opts.silenceMs });
      mic.startRecording(opts.preRollMs);
      opts.onInterim?.("");
      const unsub = mic.onFrame((_f, db, ms) => {
        const e = vad.push(db, ms);
        if (vad.isSpeaking) speechMs += ms;
        if (e === "speech-start") {
          firstSignAt ||= now();
          opts.onSpeechStart?.();
          opts.onInterim?.("…");
        } else if (e === "speech-end") void finish("transcribe");
      });

      const finish = async (kind: "transcribe" | "no-speech" | "aborted", reason?: string) => {
        if (finished) return;
        finished = true;
        clearInterval(tick);
        this.manual = null;
        unsub();
        const samples = mic.stopRecording();
        const base = { samples, sampleRate: mic.sampleRate, durationMs: now() - t0, latencyMs: firstSignAt ? firstSignAt - t0 : undefined };
        if (kind !== "transcribe") {
          return resolve({ ...base, status: kind, text: "", abortReason: reason });
        }
        if (speechMs < 250) return resolve({ ...base, status: vad.hasSpoken ? "unrecognized" : "no-speech", text: "" });
        try {
          const wav = toWav16k(samples, mic.sampleRate, this.maxAnswerSeconds);
          const { text } = await this.api.stt(wav);
          const clean = text.trim();
          if (!clean || (WHISPER_HALLUCINATIONS.test(clean) && speechMs < 1200)) {
            return resolve({ ...base, status: "unrecognized", text: "" });
          }
          opts.onInterim?.(clean);
          resolve({ ...base, status: "ok", text: clean });
        } catch (e) {
          resolve({ ...base, status: "error", text: "", error: (e as Error).message });
        }
      };

      const tick = setInterval(() => {
        const t = now() - t0;
        if (t >= opts.maxMs) return void finish("transcribe");
        if (!vad.hasSpoken && t >= opts.noSpeechMs) return void finish("no-speech");
      }, 100);
      signal.addEventListener("abort", () => void finish("aborted", String(signal.reason ?? "aborted")), { once: true });
      this.manual = () => void finish("transcribe");
    });
  }
}

/**
 * Typing fallback (no speech recognition available) and automated-test hook.
 * Still records the mic, if available, so "play my answer" keeps working.
 */
export class TextListener implements Listener {
  readonly kind = "text" as const;
  private pending: ((text: string) => void) | null = null;
  private manual: (() => void) | null = null;

  constructor(
    private mic: MicCapture | null,
    private testMode: boolean,
  ) {}

  /** Called by the on-screen text box. */
  submit(text: string): boolean {
    if (!this.pending) return false;
    this.pending(text);
    return true;
  }

  get waiting() {
    return this.pending !== null;
  }

  finishNow() {
    this.manual?.();
  }

  listen(opts: ListenOptions, signal: AbortSignal): Promise<ListenResult> {
    return new Promise((resolve) => {
      const t0 = now();
      this.mic?.startRecording(opts.preRollMs);
      let finished = false;
      const done = (r: Omit<ListenResult, "durationMs" | "samples" | "sampleRate">) => {
        if (finished) return;
        finished = true;
        this.pending = null;
        this.manual = null;
        const samples = this.mic?.stopRecording();
        if (this.testMode) testHooks().pending = null;
        resolve({ ...r, samples, sampleRate: this.mic?.sampleRate, durationMs: now() - t0 });
      };
      this.pending = (text) => {
        const t = text.trim();
        done(t ? { status: "ok", text: t, latencyMs: 400 } : { status: "unrecognized", text: "" });
      };
      this.manual = () => done({ status: "unrecognized", text: "" });
      if (this.testMode) {
        testHooks().pending = (r) => {
          if ("silence" in r) done({ status: "no-speech", text: "" });
          else this.pending?.(r.text);
        };
      }
      signal.addEventListener("abort", () => done({ status: "aborted", text: "", abortReason: String(signal.reason ?? "aborted") }), { once: true });
    });
  }
}
