"use client";
import type { SessionApi } from "../api";
import { ApiFailure } from "../api";

export interface SpeakOptions {
  lang: "en" | "es";
  /** 1 = normal speed. */
  rate: number;
  /** Model pronunciation at clearly reduced speed. */
  slow?: boolean;
}

export interface TtsEngine {
  readonly kind: "browser" | "server" | "test";
  /** Resolves when speech ends. `interrupted` is true if stop() cut it short. */
  speak(text: string, opts: SpeakOptions): Promise<{ interrupted: boolean }>;
  stop(): void;
  /** Must be called inside a user gesture (iOS/Safari autoplay rules). */
  unlock(): void;
  onFallback?: (messageEs: string) => void;
}

function sentences(text: string): string[] {
  const parts = text.match(/[^.!?¿¡]+[.!?]*|[¿¡][^?!]+[?!]/g) ?? [text];
  const out: string[] = [];
  for (const p of parts.map((s) => s.trim()).filter(Boolean)) {
    if (out.length && (out[out.length - 1].length + p.length < 120)) out[out.length - 1] += ` ${p}`;
    else out.push(p);
  }
  return out.length ? out : [text];
}

const PREFERRED_EN = ["Google US English", "Microsoft Aria", "Microsoft Jenny", "Microsoft Guy", "Samantha", "Natural"];
const PREFERRED_ES = ["Google español de Estados Unidos", "Microsoft Dalia", "Paulina", "Google español", "Sabina"];

/** Free voices built into the browser/OS. Quality varies by device. */
export class BrowserTts implements TtsEngine {
  readonly kind = "browser" as const;
  private cancelCurrent: (() => void) | null = null;
  private voices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      const load = () => (this.voices = window.speechSynthesis.getVoices());
      load();
      window.speechSynthesis.addEventListener?.("voiceschanged", load);
    }
  }

  static supported() {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  }

  unlock() {
    if (!BrowserTts.supported()) return;
    const u = new SpeechSynthesisUtterance(" ");
    u.volume = 0;
    window.speechSynthesis.speak(u);
  }

  private pickVoice(lang: "en" | "es"): SpeechSynthesisVoice | undefined {
    const prefix = lang === "en" ? "en" : "es";
    const pool = this.voices.filter((v) => v.lang.toLowerCase().startsWith(prefix));
    const preferred = lang === "en" ? PREFERRED_EN : PREFERRED_ES;
    for (const name of preferred) {
      const v = pool.find((x) => x.name.includes(name));
      if (v) return v;
    }
    const regional = pool.find((v) => v.lang === (lang === "en" ? "en-US" : "es-MX")) ?? pool.find((v) => v.lang === (lang === "en" ? "en-US" : "es-US"));
    return regional ?? pool[0];
  }

  async speak(text: string, opts: SpeakOptions): Promise<{ interrupted: boolean }> {
    if (!BrowserTts.supported()) {
      await new Promise((r) => setTimeout(r, Math.min(4000, text.length * 40)));
      return { interrupted: false };
    }
    this.stop();
    let interrupted = false;
    const synth = window.speechSynthesis;
    const voice = this.pickVoice(opts.lang);
    for (const chunk of sentences(text)) {
      if (interrupted) break;
      interrupted = await new Promise<boolean>((resolve) => {
        const u = new SpeechSynthesisUtterance(chunk);
        u.lang = opts.lang === "en" ? "en-US" : "es-MX";
        if (voice) u.voice = voice;
        u.rate = Math.max(0.5, Math.min(1.3, opts.slow ? opts.rate * 0.6 : opts.rate));
        let settled = false;
        const done = (wasInterrupted: boolean) => {
          if (settled) return;
          settled = true;
          clearTimeout(watchdog);
          this.cancelCurrent = null;
          resolve(wasInterrupted);
        };
        // Some browsers never fire onend (known Chrome/Android bugs): don't hang the lesson.
        const watchdog = setTimeout(() => done(false), 2500 + (chunk.length * 95) / u.rate);
        u.onend = () => done(false);
        u.onerror = (e) => done(e.error === "interrupted" || e.error === "canceled");
        this.cancelCurrent = () => {
          synth.cancel();
          done(true);
        };
        synth.speak(u);
      });
    }
    return { interrupted };
  }

  stop() {
    if (this.cancelCurrent) this.cancelCurrent();
    else if (BrowserTts.supported()) window.speechSynthesis.cancel();
  }
}

/** Natural neural voices from the server (Azure / OpenAI). Falls back to the browser. */
export class ServerTts implements TtsEngine {
  readonly kind = "server" as const;
  private audio: HTMLAudioElement | null = null;
  private cache = new Map<string, string>();
  private cancelCurrent: (() => void) | null = null;
  private disabled = false;
  onFallback?: (messageEs: string) => void;

  constructor(
    private api: SessionApi,
    private fallback: BrowserTts,
  ) {}

  unlock() {
    this.audio = new Audio();
    // A tiny silent WAV started inside the tap unlocks later playback on iOS.
    this.audio.src = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=";
    this.audio.play().catch(() => undefined);
    this.fallback.unlock();
  }

  async speak(text: string, opts: SpeakOptions): Promise<{ interrupted: boolean }> {
    if (this.disabled) return this.fallback.speak(text, opts);
    this.stop();
    const key = `${opts.lang}|${opts.slow ? 1 : 0}|${text}`;
    let url = this.cache.get(key);
    if (!url) {
      try {
        const blob = await this.api.tts(text, opts.lang, !!opts.slow);
        url = URL.createObjectURL(blob);
        this.cache.set(key, url);
      } catch (e) {
        if (e instanceof ApiFailure && (e.code === "limit_tts" || e.code === "not_configured")) {
          this.disabled = true;
          this.onFallback?.(e.messageEs);
        }
        return this.fallback.speak(text, opts);
      }
    }
    const audio = this.audio ?? (this.audio = new Audio());
    audio.src = url;
    audio.playbackRate = opts.slow ? 1 : Math.max(0.7, Math.min(1.25, opts.rate));
    return new Promise((resolve) => {
      let settled = false;
      const done = (interrupted: boolean) => {
        if (settled) return;
        settled = true;
        audio.onended = null;
        audio.onerror = null;
        this.cancelCurrent = null;
        resolve({ interrupted });
      };
      audio.onended = () => done(false);
      audio.onerror = () => {
        done(false);
      };
      this.cancelCurrent = () => {
        audio.pause();
        done(true);
      };
      audio.play().catch(async () => {
        // Autoplay blocked or decode error: use the browser voice for this line.
        settled = true;
        this.cancelCurrent = null;
        resolve(await this.fallback.speak(text, opts));
      });
    });
  }

  stop() {
    this.cancelCurrent?.();
    this.fallback.stop();
  }
}

/** Used by automated tests (?test=1): records what the coach says, no audio. */
export class TestTts implements TtsEngine {
  readonly kind = "test" as const;
  private cancelCurrent: (() => void) | null = null;
  unlock() {}
  async speak(text: string, opts: SpeakOptions) {
    const hooks = testHooks();
    hooks.spoken.push({ text, lang: opts.lang, slow: !!opts.slow });
    return new Promise<{ interrupted: boolean }>((resolve) => {
      const t = setTimeout(() => {
        this.cancelCurrent = null;
        resolve({ interrupted: false });
      }, hooks.ttsMs);
      this.cancelCurrent = () => {
        clearTimeout(t);
        this.cancelCurrent = null;
        resolve({ interrupted: true });
      };
    });
  }
  stop() {
    this.cancelCurrent?.();
  }
}

export interface TestHooks {
  spoken: { text: string; lang: string; slow: boolean }[];
  ttsMs: number;
  pending: ((r: { text: string } | { silence: true }) => void) | null;
  say(text: string): boolean;
  silence(): boolean;
}

export function testHooks(): TestHooks {
  const w = window as unknown as { __escTest?: TestHooks };
  if (!w.__escTest) {
    const hooks: TestHooks = {
      spoken: [],
      ttsMs: 120,
      pending: null,
      say(text: string) {
        if (!hooks.pending) return false;
        const p = hooks.pending;
        hooks.pending = null;
        p({ text });
        return true;
      },
      silence() {
        if (!hooks.pending) return false;
        const p = hooks.pending;
        hooks.pending = null;
        p({ silence: true });
        return true;
      },
    };
    w.__escTest = hooks;
  }
  return w.__escTest;
}
