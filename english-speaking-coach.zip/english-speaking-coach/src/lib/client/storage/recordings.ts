"use client";

/**
 * Optional, opt-in storage of the learner's recordings ON THIS DEVICE (IndexedDB).
 * Nothing is uploaded or stored on the server. Off by default; the learner can
 * delete everything from the home screen.
 */

export interface SavedRecording {
  text: string;
  audio: Blob;
}

export interface SavedSession {
  id: string;
  createdAt: number;
  scenarioLabel: string;
  recordings: SavedRecording[];
}

const DB = "english-speaking-coach";
const STORE = "sessions";

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: "id" });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = fn(t.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    t.oncomplete = () => db.close();
  });
}

export async function saveSession(s: SavedSession): Promise<void> {
  try {
    await tx("readwrite", (store) => store.put(s));
  } catch {
    /* private mode / storage blocked: recordings simply aren't kept */
  }
}

export async function listSessions(): Promise<SavedSession[]> {
  try {
    const all = await tx<SavedSession[]>("readonly", (store) => store.getAll());
    return all.sort((a, b) => b.createdAt - a.createdAt);
  } catch {
    return [];
  }
}

export async function deleteAllSessions(): Promise<void> {
  try {
    await tx("readwrite", (store) => store.clear());
  } catch {
    /* ignore */
  }
}

export async function recordingsFromUrls(items: { text: string; url: string }[]): Promise<SavedRecording[]> {
  const out: SavedRecording[] = [];
  for (const it of items) {
    try {
      out.push({ text: it.text, audio: await (await fetch(it.url)).blob() });
    } catch {
      /* skip */
    }
  }
  return out;
}
