import "server-only";
import { z } from "zod";
import { llmConfig } from "../config";
import { createLlmClient, extractJson } from "../providers/llm";
import { correctText, RULES_BY_ID } from "../offline/corrector";
import { offlineStep, type OfflineState } from "../offline/engine";
import { applyPolicy, initialMemory, parseCorrections, rawDecisionSchema, type RawDecision } from "./policy";
import { buildMessages, buildSystemPrompt, summaryPrompt } from "./prompt";
import { findRiskyWords } from "@/lib/shared/pronunciation";
import { clip, rankErrors, wordCount } from "@/lib/shared/text";
import type {
  AgentDecision,
  AgentMemory,
  ChatMessage,
  Correction,
  Exercise,
  ErrorGroup,
  Observation,
  SessionSettings,
  SessionStats,
  SessionSummary,
  SummaryPronItem,
  TopError,
} from "@/lib/shared/types";

export interface AgentInput {
  settings: SessionSettings;
  history: ChatMessage[];
  observation: Observation;
  memory: AgentMemory | null;
  engineState?: string;
}

function withTimeout<T>(p: (signal: AbortSignal) => Promise<T>, ms: number): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  return p(ctrl.signal).finally(() => clearTimeout(t));
}

/** One step of the coach agent: perceive the observation, decide actions, update memory. */
export async function runAgent(input: AgentInput): Promise<AgentDecision> {
  const { settings, observation } = input;
  const base = input.memory ?? initialMemory(settings);
  const memory: AgentMemory = {
    ...base,
    exchange: observation.kind === "answer" ? base.exchange + 1 : base.exchange,
  };
  const userText = observation.userText ?? "";
  const riskyWords = userText ? findRiskyWords(userText, 3, memory.drilledWords) : [];

  const llm = llmConfig();
  if (llm) {
    try {
      const client = createLlmClient(llm);
      const text = await withTimeout(
        (signal) =>
          client.complete({
            system: buildSystemPrompt(settings, memory),
            messages: buildMessages(input.history, observation, memory, settings, riskyWords),
            maxTokens: 1600,
            temperature: 0.5,
            json: true,
            signal,
          }),
        25_000,
      );
      const raw = rawDecisionSchema.parse(extractJson(text));
      const corrections =
        observation.kind === "answer" ? parseCorrections(raw.corrections, memory.exchange, userText) : [];
      return applyPolicy({
        settings,
        observation,
        memory,
        raw,
        corrections,
        riskyWords,
        provider: llm.provider,
        model: client.model,
      });
    } catch (err) {
      console.error("[coach] agent LLM failed, using offline backup:", (err as Error).message);
      return offlineDecision(input, memory, true);
    }
  }
  return offlineDecision(input, memory, false);
}

/** Rule-based backup. Same output shape and the same policy, but no AI. */
function offlineDecision(input: AgentInput, memory: AgentMemory, fallbackUsed: boolean): AgentDecision {
  const { settings, observation } = input;
  const userText = observation.userText ?? "";
  let state: OfflineState | null = null;
  try {
    state = input.engineState ? (JSON.parse(input.engineState) as OfflineState) : null;
  } catch {
    state = null;
  }
  if (!state && observation.kind === "answer") {
    // Coming from the AI agent mid-session: approximate where we are.
    state = { q: Math.max(0, memory.exchange - 1), followupDone: true, elaborated: true };
  }
  const struggling =
    memory.pace === "slower" ||
    (observation.signals ?? []).some((s) => s === "asked-repeat" || s === "long-silence" || s === "asked-slower");
  const step = offlineStep(
    settings,
    observation.kind === "start" ? null : userText,
    state,
    struggling,
    observation.kind === "silence",
  );
  const corrections = observation.kind === "answer" ? correctText(userText, memory.exchange) : [];
  const risky = userText ? findRiskyWords(userText, 3, memory.drilledWords) : [];

  const actions: unknown[] = [];
  if (step.reaction) actions.push({ type: "say", purpose: "reaction", text: step.reaction });
  if (observation.kind === "answer") {
    if (struggling && memory.pace !== "slower")
      actions.push({ type: "adjust", pace: "slower", reasonEs: "Te costó un poco: hablaré más despacio." });
    if (!struggling && wordCount(userText) >= 25 && corrections.length === 0 && memory.pace === "slower")
      actions.push({ type: "adjust", pace: "normal", reasonEs: "Vas con fluidez: vuelvo al ritmo normal." });
    if (corrections.length) actions.push({ type: "correct", index: 0 });
    const measured = observation.pronunciation?.measured ? observation.pronunciation.problemWords[0]?.word : undefined;
    const drillWord = measured ?? risky[0]?.word;
    // No drills during the warm-up answer.
    if (drillWord && memory.exchange >= 2) actions.push({ type: "drill", word: drillWord, reasonEs: "" });
  }
  actions.push({ type: "say", purpose: step.purpose, text: step.question });

  const raw: RawDecision = {
    corrections: [],
    actions,
    hint: step.hint,
    memory: {},
    done: step.done,
  };
  const decision = applyPolicy({
    settings,
    observation,
    memory,
    raw,
    corrections,
    riskyWords: risky,
    provider: "offline",
  });
  return { ...decision, fallbackUsed, engineState: JSON.stringify(step.state) };
}

// ---------------------------------------------------------------------------
// End-of-session summary
// ---------------------------------------------------------------------------

function genericExercises(g: ErrorGroup): Exercise[] {
  const ex = g.examples[0];
  if (!ex) return [];
  return [
    { kind: "say", promptEs: "Di la versión correcta en voz alta tres veces.", target: ex.corrected },
    { kind: "fix", promptEs: "Corrige la frase que dijiste.", wrong: ex.original, target: ex.corrected },
    {
      kind: "create",
      promptEs: `Crea una frase nueva sobre ti usando: «${clip(ex.corrected, 60)}».`,
      target: ex.corrected,
    },
  ];
}

const summaryOut = z.object({
  groups: z
    .array(
      z.object({
        category: z.string(),
        explanationEs: z.string().catch(""),
        exercises: z
          .array(
            z.object({
              kind: z.enum(["say", "fix", "create"]).catch("say"),
              promptEs: z.string(),
              wrong: z.string().optional().catch(undefined),
              target: z.string(),
            }),
          )
          .catch([]),
      }),
    )
    .catch([]),
  closingEs: z.string().catch(""),
});

export interface SummaryInput {
  settings: SessionSettings;
  corrections: Correction[];
  pronunciation: SummaryPronItem[];
  stats: SessionStats;
  memory: AgentMemory | null;
}

export async function summarize(input: SummaryInput): Promise<SessionSummary> {
  const groups = rankErrors(input.corrections).slice(0, 3);
  let top: TopError[] = groups.map((g) => ({
    ...g,
    exercises: RULES_BY_ID.get(g.category)?.exercises ?? genericExercises(g),
  }));
  let closingEs =
    input.stats.turns === 0
      ? "No alcanzamos a practicar. Cuando quieras, empieza otra sesión."
      : top.length
        ? `Buen trabajo: hablaste ${input.stats.userWords} palabras en inglés. Para la próxima, enfócate en «${top[0].labelEs}».`
        : `Buen trabajo: hablaste ${input.stats.userWords} palabras en inglés sin errores destacados. Sube de nivel la próxima vez.`;
  let provider = "offline";

  const llm = llmConfig();
  if (llm && groups.length) {
    try {
      const client = createLlmClient(llm);
      const text = await withTimeout(
        (signal) =>
          client.complete({
            system: summaryPrompt(),
            messages: [
              {
                role: "user",
                content: JSON.stringify({
                  scenario: input.settings.scenario,
                  level: input.memory?.levelEstimate ?? input.settings.level,
                  errorGroups: groups.map((g) => ({ category: g.category, label: g.labelEs, examples: g.examples })),
                  notes: input.memory?.notes ?? [],
                  stats: input.stats,
                }),
              },
            ],
            maxTokens: 2000,
            temperature: 0.4,
            json: true,
            signal,
          }),
        25_000,
      );
      const out = summaryOut.parse(extractJson(text));
      top = top.map((t) => {
        const g = out.groups.find((x) => x.category === t.category);
        const exercises = (g?.exercises ?? [])
          .filter((e) => e.target && e.promptEs)
          .slice(0, 3)
          .map((e) => ({ ...e, target: clip(e.target, 200), promptEs: clip(e.promptEs, 200) }));
        return {
          ...t,
          explanationEs: g?.explanationEs ? clip(g.explanationEs, 400) : t.explanationEs,
          exercises: exercises.length >= 2 ? exercises : t.exercises,
        };
      });
      if (out.closingEs) closingEs = clip(out.closingEs, 500);
      provider = llm.provider;
    } catch (err) {
      console.error("[coach] summary LLM failed, using rule-based exercises:", (err as Error).message);
    }
  }

  return {
    topErrors: top,
    pronunciation: input.pronunciation.slice(0, 6),
    stats: input.stats,
    closingEs,
    provider,
  };
}
