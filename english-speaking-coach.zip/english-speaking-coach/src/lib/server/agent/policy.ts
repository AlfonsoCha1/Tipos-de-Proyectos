import "server-only";
import { z } from "zod";
import { clip, words } from "@/lib/shared/text";
import type {
  AgentAction,
  AgentDecision,
  AgentMemory,
  Correction,
  Hint,
  Level,
  Observation,
  PronunciationTip,
  SessionSettings,
} from "@/lib/shared/types";
import { plannedExchanges } from "./prompt";

// ---------------------------------------------------------------------------
// Lenient schema for what the model returns. Anything malformed is dropped,
// not fatal: the policy below fills the gaps.
// ---------------------------------------------------------------------------

const level = z.enum(["A2", "B1", "B2", "C1"]);

const rawCorrection = z.object({
  original: z.string().min(1),
  corrected: z.string().min(1),
  type: z.enum(["grammar", "vocabulary", "naturalness"]).catch("grammar"),
  category: z.string().catch(""),
  categoryLabelEs: z.string().catch(""),
  explanationEs: z.string().catch(""),
  spokenTip: z.string().catch(""),
  severity: z.coerce.number().catch(2),
});

const rawAction = z.union([
  z.object({ type: z.literal("say"), text: z.string().min(1), purpose: z.string().catch("reaction") }),
  z.object({ type: z.literal("correct"), index: z.coerce.number() }),
  z.object({ type: z.literal("drill"), word: z.string().min(1), reasonEs: z.string().catch("") }),
  z.object({ type: z.literal("hint") }),
  z.object({
    type: z.literal("adjust"),
    level: level.optional().catch(undefined),
    pace: z.enum(["slower", "normal", "faster"]).optional().catch(undefined),
    reasonEs: z.string().catch(""),
  }),
]);

export const rawDecisionSchema = z.object({
  corrections: z.array(z.unknown()).catch([]),
  actions: z.array(z.unknown()).catch([]),
  hint: z.object({ es: z.string(), starter: z.string() }).optional().catch(undefined),
  memory: z
    .object({
      notes: z.array(z.string()).catch([]),
      levelEstimate: level.optional().catch(undefined),
      topicsCovered: z.array(z.string()).catch([]),
    })
    .partial()
    .catch({}),
  done: z.coerce.boolean().catch(false),
});

export type RawDecision = z.infer<typeof rawDecisionSchema>;

function slug(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
}

function sev(n: number): 1 | 2 | 3 {
  return n >= 3 ? 3 : n <= 1 ? 1 : 2;
}

export function parseCorrections(list: unknown[], exchange: number, userText: string): Correction[] {
  const out: Correction[] = [];
  const said = userText.toLowerCase();
  list.forEach((item, i) => {
    const r = rawCorrection.safeParse(item);
    if (!r.success) return;
    const c = r.data;
    const original = clip(c.original.trim(), 200);
    const corrected = clip(c.corrected.trim(), 200);
    if (!original || !corrected || original.toLowerCase() === corrected.toLowerCase()) return;
    // Guard against invented quotes: most of the original's words must appear in what was said.
    const ow = words(original);
    const hits = ow.filter((w) => said.includes(w)).length;
    if (ow.length && hits / ow.length < 0.6) return;
    const category = slug(c.category) || slug(c.categoryLabelEs) || slug(corrected);
    out.push({
      id: `c${exchange}-${i}`,
      category,
      categoryLabelEs: clip(c.categoryLabelEs || "Expresión", 60),
      type: c.type,
      original,
      corrected,
      explanationEs: clip(c.explanationEs || "Forma más natural en inglés.", 300),
      spokenTip: clip(c.spokenTip || `Instead of "${original}", say "${corrected}".`, 220),
      severity: sev(c.severity),
      source: "llm",
    });
  });
  return out.slice(0, 3);
}

const ACTION_ORDER: Record<string, number> = {
  reaction: 0,
  encouragement: 0,
  adjust: 1,
  correct: 2,
  drill: 3,
  hint: 4,
  question: 5,
  followup: 5,
  closing: 5,
};

export interface PolicyInput {
  settings: SessionSettings;
  observation: Observation;
  memory: AgentMemory;
  raw: RawDecision;
  corrections: Correction[];
  riskyWords: PronunciationTip[];
  provider: string;
  model?: string;
}

/**
 * The model proposes; this function disposes. It enforces the product rules in code
 * so they hold no matter which LLM is plugged in:
 *  - fluent mode never corrects or drills mid-conversation;
 *  - teacher mode: max 1 correction + 1 drill per turn, with cooldowns;
 *  - drills only on words the learner said (or words an acoustic engine flagged);
 *  - "measured" is decided by the evidence, never by the model;
 *  - every turn ends with exactly one question, or a closing when done.
 */
export function applyPolicy(input: PolicyInput): AgentDecision {
  const { settings, observation, memory, raw, corrections, riskyWords } = input;
  const isAnswer = observation.kind === "answer";
  const exchange = memory.exchange;
  const planned = plannedExchanges(settings);
  const said = new Set(words(observation.userText ?? ""));
  const measuredWords = new Map(
    (observation.pronunciation?.measured ? observation.pronunciation.problemWords : []).map((p) => [
      p.word.toLowerCase(),
      p,
    ]),
  );

  const parsed: AgentAction[] = [];
  let correctionUsed = false;
  let drillUsed = false;
  const nextMemory: AgentMemory = {
    ...memory,
    notes: [...memory.notes],
    weakCategories: memory.weakCategories.map((w) => ({ ...w })),
    drilledWords: [...memory.drilledWords],
    topicsCovered: [...memory.topicsCovered],
  };

  const sayOrder: { order: number; action: AgentAction }[] = [];
  for (const item of raw.actions) {
    const r = rawAction.safeParse(item);
    if (!r.success) continue;
    const a = r.data;
    if (a.type === "say") {
      const purpose = (["reaction", "question", "followup", "closing", "encouragement"].includes(a.purpose)
        ? a.purpose
        : "reaction") as Extract<AgentAction, { type: "say" }>["purpose"];
      const text = clip(a.text.replace(/[*_#`>]/g, "").trim(), 400);
      if (text) sayOrder.push({ order: ACTION_ORDER[purpose], action: { type: "say", text, purpose } });
    } else if (a.type === "correct") {
      if (!isAnswer || settings.correctionMode !== "teacher" || correctionUsed) continue;
      const c = corrections[a.index] ?? corrections[0];
      if (!c) continue;
      const sinceLast = exchange - memory.lastCorrectionExchange;
      if (sinceLast < 2 && c.severity < 3) continue; // don't correct every sentence
      correctionUsed = true;
      nextMemory.lastCorrectionExchange = exchange;
      sayOrder.push({ order: ACTION_ORDER.correct, action: { type: "correct", correctionId: c.id } });
    } else if (a.type === "drill") {
      if (!isAnswer || settings.correctionMode !== "teacher" || drillUsed) continue;
      const w = a.word.toLowerCase().replace(/[^a-z']/g, "");
      const measured = measuredWords.has(w);
      if (!w || (!said.has(w) && !measured)) continue; // only words they actually said
      if (nextMemory.drilledWords.filter((x) => x === w).length >= 2) continue;
      const sinceLast = exchange - memory.lastDrillExchange;
      const severe = measured && (measuredWords.get(w)?.accuracy ?? 100) < 60;
      if (sinceLast < 2 && !severe) continue;
      drillUsed = true;
      nextMemory.lastDrillExchange = exchange;
      nextMemory.drilledWords.push(w);
      const reasonEs = measured
        ? `Tu pronunciación de «${w}» obtuvo ${Math.round(measuredWords.get(w)?.accuracy ?? 0)}/100 en la evaluación acústica.`
        : `«${w}» es una palabra que suele costar a hispanohablantes (sugerencia, no medición).`;
      sayOrder.push({ order: ACTION_ORDER.drill, action: { type: "drill", word: w, reasonEs, measured } });
    } else if (a.type === "adjust") {
      if (!a.level && !a.pace) continue;
      if (a.level) nextMemory.levelEstimate = a.level as Level;
      if (a.pace) nextMemory.pace = a.pace;
      sayOrder.push({
        order: ACTION_ORDER.adjust,
        action: { type: "adjust", level: a.level as Level | undefined, pace: a.pace, reasonEs: clip(a.reasonEs, 200) },
      });
    } else if (a.type === "hint") {
      // Hints are triggered by the learner (button / silence / "no sé"), not proactively.
      continue;
    }
  }

  sayOrder.sort((x, y) => x.order - y.order);
  parsed.push(...sayOrder.map((s) => s.action));

  // Exactly one final question/closing.
  const finals = parsed.filter((a) => a.type === "say" && ["question", "followup", "closing"].includes(a.purpose));
  let done = raw.done || (isAnswer && exchange >= planned + 2);
  if (finals.length > 1) {
    const keep = finals[finals.length - 1];
    for (const f of finals) if (f !== keep) parsed.splice(parsed.indexOf(f), 1);
  }
  const lastFinal = parsed.filter((a) => a.type === "say" && ["question", "followup", "closing"].includes(a.purpose)).pop();
  if (!lastFinal) {
    if (done) parsed.push({ type: "say", purpose: "closing", text: "That's all for today. Great job! Let's look at your feedback." });
    else parsed.push({ type: "say", purpose: "followup", text: "Could you tell me a little more about that?" });
  } else if (lastFinal.type === "say" && lastFinal.purpose === "closing") {
    done = true;
  }
  if (done) {
    for (let i = parsed.length - 1; i >= 0; i--) {
      const a = parsed[i];
      if (a.type === "correct" || a.type === "drill") continue;
      if (a.type === "say" && (a.purpose === "question" || a.purpose === "followup")) a.purpose = "closing";
    }
  }

  // Memory: the model contributes notes/level/topics; counters are ours.
  const m = raw.memory ?? {};
  if (m.notes?.length) nextMemory.notes = m.notes.map((n) => clip(n, 160)).slice(-8);
  if (m.levelEstimate && !parsed.some((a) => a.type === "adjust" && a.level)) nextMemory.levelEstimate = m.levelEstimate;
  if (m.topicsCovered?.length) nextMemory.topicsCovered = m.topicsCovered.map((t) => clip(t, 60)).slice(-12);
  for (const c of corrections) {
    const w = nextMemory.weakCategories.find((x) => x.category === c.category);
    if (w) w.count += 1;
    else nextMemory.weakCategories.push({ category: c.category, labelEs: c.categoryLabelEs, count: 1 });
  }
  nextMemory.weakCategories.sort((a, b) => b.count - a.count);
  nextMemory.weakCategories = nextMemory.weakCategories.slice(0, 10);

  const hint: Hint | undefined =
    raw.hint && raw.hint.es && raw.hint.starter
      ? { es: clip(raw.hint.es, 400), starter: clip(raw.hint.starter, 200) }
      : undefined;

  return {
    actions: parsed,
    corrections,
    pronunciationTips: riskyWords,
    hint,
    memory: nextMemory,
    done,
    provider: input.provider,
    model: input.model,
    fallbackUsed: false,
  };
}

export function initialMemory(settings: SessionSettings): AgentMemory {
  return {
    exchange: 0,
    levelEstimate: settings.level,
    pace: "normal",
    notes: [],
    weakCategories: [],
    drilledWords: [],
    lastCorrectionExchange: -10,
    lastDrillExchange: -10,
    topicsCovered: [],
  };
}
