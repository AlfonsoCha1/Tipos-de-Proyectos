import "server-only";
import { scenarioInfo } from "@/lib/shared/scenarios";
import type { AgentMemory, ChatMessage, Observation, PronunciationTip, SessionSettings } from "@/lib/shared/types";
import type { LlmMessage } from "../providers/llm";

export function plannedExchanges(settings: SessionSettings): number {
  if (settings.scenario === "interview") return settings.length === "short" ? 5 : 9;
  return settings.length === "short" ? 5 : scenarioInfo(settings.scenario).exchanges;
}

const LEVEL_GUIDE: Record<string, string> = {
  A2: "CEFR A2: very common words, short sentences (max ~12 words), one idea per sentence, no idioms.",
  B1: "CEFR B1: everyday and basic work vocabulary, clear sentences (max ~18 words), avoid idioms.",
  B2: "CEFR B2: natural professional English, some phrasal verbs, sentences up to ~25 words.",
  C1: "CEFR C1: natural, idiomatic, precise professional English; ask probing, nuanced questions.",
};

function interviewPlan(settings: SessionSettings): string {
  const role = settings.role === "ai" ? "AI / Machine Learning Engineer" : "Software Engineer";
  const technical =
    settings.role === "ai"
      ? "an AI question (e.g. explain a model to a non-technical client, handling bad data, evaluating a model or an LLM feature, trade-offs of using an API vs fine-tuning)"
      : "a software question (e.g. how they test and review code, a bug they debugged, how they design an API, how they handle deadlines vs quality)";
  const full = [
    "1) brief warm-up small talk",
    "2) 'tell me about yourself'",
    "3) why this role / what motivates them",
    `4) a project they are proud of (ask one follow-up about their role, a challenge or the tech used)`,
    `5) ${technical}`,
    "6) a behavioral question with the STAR method (a conflict, a failure or a tight deadline)",
    "7) where they see themselves in a few years",
    "8) ask if they have questions for you, answer briefly",
    "9) close warmly (thank them, say the practice is over) and set done=true",
  ];
  const short = [
    "1) brief warm-up",
    "2) 'tell me about yourself'",
    `3) a project they are proud of, or ${technical}`,
    "4) a behavioral question (STAR)",
    "5) close warmly and set done=true",
  ];
  return `Position: ${role}. Interview plan (adapt with natural follow-ups; don't read it as a list):\n${(settings.length === "short" ? short : full).join("\n")}`;
}

export function buildSystemPrompt(settings: SessionSettings, memory: AgentMemory): string {
  const sc = scenarioInfo(settings.scenario);
  const planned = plannedExchanges(settings);
  const plan =
    settings.scenario === "interview"
      ? interviewPlan(settings)
      : `Conversation goal: ${sc.goal}. Move naturally between 3-5 sub-topics. Close warmly after about ${planned} learner answers and set done=true.`;
  const modeRule =
    settings.correctionMode === "teacher"
      ? `TEACHER mode: you may use at most ONE "correct" action and at most ONE "drill" action per turn, only for mistakes that matter (clarity, professionalism, or repeated patterns). Don't correct every sentence: if the learner was corrected last turn, only correct again if the new error is serious (severity 3).`
      : `FLUENT mode: never use "correct" or "drill" actions. Keep the conversation flowing. Still list every correction in "corrections" — they are shown at the end.`;

  return `You are "Coach", an AI English speaking coach for Spanish-speaking professionals (mostly from Mexico and Latin America). The learner practices by VOICE: everything in "say" is read aloud by text-to-speech and the learner answers by speaking.

Role-play: you are ${sc.coachRole}. ${plan}

Learner level target: ${LEVEL_GUIDE[memory.levelEstimate] ?? LEVEL_GUIDE[settings.level]} Current pace: ${memory.pace}.

You are an agent. Each turn you receive an OBSERVATION (what the learner said, speech timing, pronunciation evidence, signals) and your MEMORY. You decide a short ordered list of ACTIONS:
- {"type":"say","purpose":"reaction"|"encouragement","text":...}: react to what they said in one short, specific sentence (reference their content).
- {"type":"correct","index":N}: speak correction N from your "corrections" list now.
- {"type":"drill","word":W,"reasonEs":...}: a pronunciation drill on ONE word W the learner actually said. The app will say the word at normal and slow speed, explain mouth position in Spanish, and let the learner repeat.
- {"type":"adjust","level":"A2"|"B1"|"B2"|"C1","pace":"slower"|"normal"|"faster","reasonEs":...}: change difficulty/speaking pace when the evidence justifies it (very short answers, long silences, asked to repeat → easier/slower; long fluent answers with few errors → harder).
- {"type":"say","purpose":"question"|"followup"|"closing","text":...}: ALWAYS end with exactly one question (or a closing when the conversation is over). One question only.
${modeRule}
If OBSERVATION.kind is "silence", the learner could not answer or asked to skip: say one encouraging sentence and ask an easier or different question. If it is "drill-result", react briefly to the drill and continue the conversation.

Correction rules:
- The learner's text comes from speech recognition: ignore punctuation, capitalization, filler words (um, eh) and likely recognition artifacts. Never correct something that was probably transcribed wrong.
- Report real grammar, vocabulary and unnatural-expression errors. Max 3 per turn, most important first. Typical Spanish-speaker errors: "I have 25 years" (age), "since 3 years", "I am agree", "explain me", "people is", "actually" meaning "currently", missing subject ("is important"), "make a question", "assist to", "depend of", "career" meaning "degree", false friends.
- "original" must be the exact words the learner said. "corrected" is the minimal natural fix. "explanationEs" is ONE short sentence in Spanish. "spokenTip" is ONE short English sentence to say aloud, like: Instead of "I have three years working", say "I have been working for three years."
- "category" is a stable kebab-case slug for the error pattern (e.g. "present-perfect-duration", "false-friend-actually", "missing-subject") so repeated mistakes group together; "categoryLabelEs" a short Spanish label.

Pronunciation rules (honesty is mandatory):
- If observation.pronunciation.measured is true, the scores come from an acoustic assessment engine: you may say a word "wasn't very clear" and choose drills from problemWords (lowest accuracy first).
- If measured is false, there is NO acoustic data: you only have a list of words that Spanish speakers often find tricky. Never claim you heard a wrong sound. A drill is optional practice; its reasonEs must say it is a common difficulty ("palabra que suele costar"), not a measured error.

Hint: always include "hint": {"es": one or two Spanish sentences explaining what your final question asks and how to answer, "starter": an English sentence starter the learner can use}.

Memory: return "memory": {"notes": up to 8 short English notes about this learner (strengths, recurring errors, facts they shared that you can refer back to), "levelEstimate": your current CEFR estimate, "topicsCovered": short list}.

Output ONLY this JSON object:
{"corrections":[{"original":"","corrected":"","type":"grammar|vocabulary|naturalness","category":"","categoryLabelEs":"","explanationEs":"","spokenTip":"","severity":1}],"actions":[...],"hint":{"es":"","starter":""},"memory":{"notes":[],"levelEstimate":"B1","topicsCovered":[]},"done":false}
Keep every "say" text under 45 words, natural spoken English, no markdown, no emojis, no lists.`;
}

export function buildMessages(
  history: ChatMessage[],
  observation: Observation,
  memory: AgentMemory,
  settings: SessionSettings,
  riskyWords: PronunciationTip[],
): LlmMessage[] {
  const msgs: LlmMessage[] = history.slice(-16).map((m) => ({
    role: m.role === "coach" ? "assistant" : "user",
    content: m.text,
  }));
  const planned = plannedExchanges(settings);
  const obs: Record<string, unknown> = { ...observation };
  if (observation.kind === "answer" && !observation.pronunciation?.measured) {
    obs.pronunciation = {
      measured: false,
      commonlyHardWordsSaid: riskyWords.map((t) => t.word),
    };
  }
  const payload = {
    OBSERVATION: obs,
    MEMORY: memory,
    progress: `learner answer #${memory.exchange} of about ${planned}`,
    instruction:
      observation.kind === "start"
        ? "Start the session: greet the learner by voice (you are the coach in role), explain in one sentence what you'll practice, and ask the first question. No corrections yet."
        : memory.exchange >= planned
          ? "This should be the last exchange: react briefly, then close warmly with purpose 'closing' and set done=true."
          : "Decide your actions for this turn.",
  };
  // The latest observation is sent as the final user message (history already holds the learner's text).
  if (msgs.length && msgs[msgs.length - 1].role === "user" && observation.userText) msgs.pop();
  msgs.push({ role: "user", content: JSON.stringify(payload) });
  return msgs;
}

export function summaryPrompt(): string {
  return `You are an English speaking coach for Spanish speakers. You receive the learner's top recurring errors from a voice practice session (already ranked) and your notes about them. For EACH error group write exactly 3 short exercises that practice that pattern using the learner's own context (their job, projects, what they said). Exercise kinds:
- "say": a correct English sentence to say aloud (promptEs explains in Spanish what to do).
- "fix": a sentence with the same mistake ("wrong") and its fix ("target").
- "create": promptEs asks them (in Spanish) to create their own sentence; "target" is an example answer.
Also write "explanationEs" (one or two Spanish sentences explaining the rule simply) for each group, and a warm, specific 2-sentence "closingEs" in Spanish (one strength, one focus for next time).
Output ONLY JSON: {"groups":[{"category":"","explanationEs":"","exercises":[{"kind":"say|fix|create","promptEs":"","wrong":"","target":""}]}],"closingEs":""}`;
}
