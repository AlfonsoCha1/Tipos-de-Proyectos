import "server-only";
import type { PublicConfig, SessionLimits } from "@/lib/shared/types";

/**
 * All provider selection happens here, on the server, from environment variables.
 * Keys never leave this module except as request headers to the provider itself.
 */

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && v.trim() ? v.trim() : undefined;
}

function num(name: string, fallback: number): number {
  const v = Number(env(name));
  return Number.isFinite(v) && v > 0 ? v : fallback;
}

export type AgentProviderId = "groq" | "openai" | "anthropic" | "offline";

export interface LlmConfig {
  provider: Exclude<AgentProviderId, "offline">;
  apiKey: string;
  model: string;
  baseUrl: string;
}

export function llmConfig(): LlmConfig | null {
  const wanted = (env("AGENT_PROVIDER") ?? "auto").toLowerCase();
  const candidates: LlmConfig[] = [];
  const groqKey = env("GROQ_API_KEY");
  const openaiKey = env("OPENAI_API_KEY");
  const anthropicKey = env("ANTHROPIC_API_KEY");
  if (groqKey)
    candidates.push({
      provider: "groq",
      apiKey: groqKey,
      model: env("GROQ_MODEL") ?? "openai/gpt-oss-20b",
      baseUrl: env("GROQ_BASE_URL") ?? "https://api.groq.com/openai/v1",
    });
  if (openaiKey)
    candidates.push({
      provider: "openai",
      apiKey: openaiKey,
      model: env("OPENAI_MODEL") ?? "gpt-4.1-mini",
      baseUrl: env("OPENAI_BASE_URL") ?? "https://api.openai.com/v1",
    });
  if (anthropicKey)
    candidates.push({
      provider: "anthropic",
      apiKey: anthropicKey,
      model: env("ANTHROPIC_MODEL") ?? "claude-haiku-4-5-20251001",
      baseUrl: env("ANTHROPIC_BASE_URL") ?? "https://api.anthropic.com/v1",
    });
  if (wanted === "offline") return null;
  if (wanted === "auto") return candidates[0] ?? null;
  return candidates.find((c) => c.provider === wanted) ?? null;
}

export interface SttConfig {
  provider: "groq" | "openai";
  apiKey: string;
  baseUrl: string;
  model: string;
}

export function sttConfig(): SttConfig | null {
  const wanted = (env("STT_PROVIDER") ?? "browser").toLowerCase();
  if (wanted === "groq" && env("GROQ_API_KEY"))
    return {
      provider: "groq",
      apiKey: env("GROQ_API_KEY")!,
      baseUrl: env("GROQ_BASE_URL") ?? "https://api.groq.com/openai/v1",
      model: env("GROQ_STT_MODEL") ?? "whisper-large-v3-turbo",
    };
  if (wanted === "openai" && env("OPENAI_API_KEY"))
    return {
      provider: "openai",
      apiKey: env("OPENAI_API_KEY")!,
      baseUrl: env("OPENAI_BASE_URL") ?? "https://api.openai.com/v1",
      model: env("OPENAI_STT_MODEL") ?? "whisper-1",
    };
  return null;
}

export interface AzureSpeechConfig {
  key: string;
  region: string;
  /** Optional custom endpoint, e.g. https://<resource>.cognitiveservices.azure.com */
  endpoint?: string;
  voiceEn: string;
  voiceEs: string;
}

export function azureConfig(): AzureSpeechConfig | null {
  const key = env("AZURE_SPEECH_KEY");
  const region = env("AZURE_SPEECH_REGION");
  if (!key || (!region && !env("AZURE_SPEECH_ENDPOINT"))) return null;
  return {
    key,
    region: region ?? "",
    endpoint: env("AZURE_SPEECH_ENDPOINT")?.replace(/\/$/, ""),
    voiceEn: env("AZURE_TTS_VOICE_EN") ?? "en-US-JennyNeural",
    voiceEs: env("AZURE_TTS_VOICE_ES") ?? "es-MX-DaliaNeural",
  };
}

export function ttsProvider(): "browser" | "azure" | "openai" {
  const wanted = (env("TTS_PROVIDER") ?? "browser").toLowerCase();
  if (wanted === "azure" && azureConfig()) return "azure";
  if (wanted === "openai" && env("OPENAI_API_KEY")) return "openai";
  return "browser";
}

export function pronunciationProvider(): "azure" | "transcript" {
  const wanted = (env("PRONUNCIATION_PROVIDER") ?? "auto").toLowerCase();
  if ((wanted === "azure" || wanted === "auto") && azureConfig()) return "azure";
  return "transcript";
}

export function openaiTtsConfig() {
  return {
    apiKey: env("OPENAI_API_KEY") ?? "",
    baseUrl: env("OPENAI_BASE_URL") ?? "https://api.openai.com/v1",
    model: env("OPENAI_TTS_MODEL") ?? "gpt-4o-mini-tts",
    voice: env("OPENAI_TTS_VOICE") ?? "alloy",
  };
}

export function limits(): SessionLimits {
  return {
    maxMinutes: num("LIMIT_SESSION_MINUTES", 15),
    maxTurns: num("LIMIT_TURNS_PER_SESSION", 30),
    maxAssessments: num("LIMIT_ASSESSMENTS_PER_SESSION", 40),
    maxTtsChars: num("LIMIT_TTS_CHARS_PER_SESSION", 12000),
    maxAnswerSeconds: num("LIMIT_ANSWER_SECONDS", 60),
    maxSessionsPerDay: num("LIMIT_SESSIONS_PER_IP_PER_DAY", 10),
  };
}

export function globalDailySessionCap(): number {
  return num("LIMIT_GLOBAL_SESSIONS_PER_DAY", 300);
}

export function publicConfig(): PublicConfig {
  const llm = llmConfig();
  const stt = sttConfig();
  const pron = pronunciationProvider();
  return {
    agent: llm ? { provider: llm.provider, live: true, model: llm.model } : { provider: "offline", live: false },
    stt: { provider: stt?.provider ?? "browser" },
    tts: { provider: ttsProvider() },
    pronunciation: { provider: pron, measured: pron === "azure" },
    limits: limits(),
  };
}
