import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { ApiError, verifySession, type SessionClaims } from "./session";
import type { ApiErrorBody } from "@/lib/shared/types";

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "local";
}

export function sessionFrom(req: Request, graceMs = 0): SessionClaims {
  return verifySession(req.headers.get("x-session-token"), graceMs);
}

export function errorResponse(err: unknown): NextResponse {
  if (err instanceof ApiError) return NextResponse.json(err.body, { status: err.status });
  if (err instanceof ZodError) {
    const body: ApiErrorBody = {
      error: "invalid request",
      code: "bad_request",
      messageEs: "La solicitud no tiene el formato esperado.",
    };
    return NextResponse.json({ ...body, issues: err.issues.slice(0, 5) }, { status: 400 });
  }
  console.error("[coach] unexpected error", err);
  const body: ApiErrorBody = {
    error: "internal error",
    code: "provider_error",
    messageEs: "Algo falló en el servidor. Intenta de nuevo.",
  };
  return NextResponse.json(body, { status: 500 });
}

export function notConfigured(what: string, messageEs: string): never {
  throw new ApiError(501, { error: `${what} not configured`, code: "not_configured", messageEs });
}

export function providerError(what: string, detail: string): never {
  console.error(`[coach] ${what} failed: ${detail}`);
  throw new ApiError(502, {
    error: `${what} failed`,
    code: "provider_error",
    messageEs: `El servicio de ${what} no respondió bien. Intenta otra vez.`,
  });
}

/** Reads a WAV (PCM16) header and returns duration in seconds, or null if not a WAV. */
export function wavDurationSec(buf: Buffer): number | null {
  if (buf.length < 44 || buf.toString("ascii", 0, 4) !== "RIFF" || buf.toString("ascii", 8, 12) !== "WAVE") {
    return null;
  }
  // Walk chunks to find "fmt " and "data".
  let offset = 12;
  let byteRate = 0;
  let dataSize = 0;
  while (offset + 8 <= buf.length) {
    const id = buf.toString("ascii", offset, offset + 4);
    const size = buf.readUInt32LE(offset + 4);
    if (id === "fmt ") byteRate = buf.readUInt32LE(offset + 16);
    if (id === "data") {
      dataSize = Math.min(size, buf.length - offset - 8);
      break;
    }
    offset += 8 + size + (size % 2);
  }
  if (!byteRate) return null;
  return dataSize / byteRate;
}
