import type { Correction, CorrectionType, Exercise } from "@/lib/shared/types";

/**
 * Rule-based corrector for frequent errors of Spanish speakers.
 * Used only by the offline backup (no AI) and as a source of ready-made exercises.
 * It is deliberately conservative: a missed error is better than a false alarm.
 */

interface Rule {
  id: string;
  labelEs: string;
  type: CorrectionType;
  severity: 1 | 2 | 3;
  re: RegExp;
  fix: (m: RegExpExecArray) => string;
  explanationEs: string;
  exercises: Exercise[];
}

const NUM = "(\\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|many|several|a few)";

const IRREGULAR_BASE: Record<string, string> = {
  went: "go", did: "do", had: "have", was: "be", were: "be", made: "make", saw: "see", came: "come",
  wrote: "write", built: "build", took: "take", gave: "give", got: "get", said: "say", told: "tell",
  knew: "know", thought: "think", found: "find", left: "leave", began: "begin", ran: "run", spoke: "speak",
};

function toBase(verb: string): string {
  const v = verb.toLowerCase();
  if (IRREGULAR_BASE[v]) return IRREGULAR_BASE[v];
  if (v.endsWith("ied")) return v.slice(0, -3) + "y";
  if (/(at|iz|bl|iv|uc|as|ur|ag|ov|ag)ed$/.test(v)) return v.slice(0, -1); // created→create, used→use…
  if (v.endsWith("ed")) return v.slice(0, -2);
  return v;
}

function keepCase(original: string, fixed: string): string {
  return /^[A-Z]/.test(original) ? fixed.charAt(0).toUpperCase() + fixed.slice(1) : fixed;
}

export const RULES: Rule[] = [
  {
    id: "age-have-years",
    labelEs: "Decir tu edad",
    type: "grammar",
    severity: 3,
    re: /\bI have (\d{2}) years(?: old)?\b(?!\s+(?:of|in|as|at|working|studying|living|with|experience))/gi,
    fix: (m) => `I am ${m[1]} years old`,
    explanationEs: "La edad se dice con «be»: I am 25 years old (no «I have 25 years»).",
    exercises: [
      { kind: "say", promptEs: "Di tu edad en voz alta.", target: "I am 28 years old." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "My brother has 30 years.", target: "My brother is 30 years old." },
      { kind: "create", promptEs: "Presenta a alguien de tu familia con su edad.", target: "My sister is 24 years old and she is a nurse." },
    ],
  },
  {
    id: "present-perfect-duration",
    labelEs: "Duración: present perfect + for/since",
    type: "grammar",
    severity: 3,
    re: new RegExp(`\\bI (?:have|has) ${NUM} (years?|months?) (working|studying|living|doing|using|programming|developing)\\b`, "gi"),
    fix: (m) => `I have been ${m[3]} for ${m[1]} ${m[2]}`,
    explanationEs: "Para algo que empezó en el pasado y sigue: «I have been working for 3 years».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "I have been working as a technician for three years." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I have two years studying English.", target: "I have been studying English for two years." },
      { kind: "create", promptEs: "Di cuánto tiempo llevas usando una herramienta o lenguaje.", target: "I have been using Python for four years." },
    ],
  },
  {
    id: "present-perfect-since",
    labelEs: "Duración: present perfect + since",
    type: "grammar",
    severity: 3,
    re: /\bI(?: am|'m) (working|living|studying|programming) ((?:here |there |at [a-z]+ |in [a-z]+ )?)since\b/gi,
    fix: (m) => `I have been ${m[1]} ${m[2]}since`,
    explanationEs: "Con «since» usa present perfect: «I have been working here since 2020».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "I have been working here since 2021." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I am living in Tepotzotlan since 2015.", target: "I have been living in Tepotzotlan since 2015." },
      { kind: "create", promptEs: "Di desde cuándo haces algo (usa since).", target: "I have been studying AI since last year." },
    ],
  },
  {
    id: "for-duration",
    labelEs: "«for» para duración",
    type: "grammar",
    severity: 2,
    re: new RegExp(`\\b(since|during) ${NUM} (years?|months?|weeks?|days?|hours?)\\b`, "gi"),
    fix: (m) => `for ${m[2]} ${m[3]}`,
    explanationEs: "Para cantidades de tiempo usa «for»: for 3 years. «Since» va con un punto de inicio: since 2020.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I worked there since two years.", target: "I worked there for two years." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I have lived here for five years, since 2020." },
      { kind: "create", promptEs: "Usa «for» y «since» en una misma frase sobre tu trabajo.", target: "I have been a support engineer for two years, since 2023." },
    ],
  },
  {
    id: "i-agree",
    labelEs: "«I agree» (sin «am»)",
    type: "grammar",
    severity: 2,
    re: /\bI(?: am|'m) (?:totally |completely )?agree\b/gi,
    fix: () => "I agree",
    explanationEs: "«Agree» ya es verbo: se dice «I agree», no «I am agree».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "I agree with you, but I see one risk." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "We are agree with the plan.", target: "We agree with the plan." },
      { kind: "create", promptEs: "Expresa desacuerdo amable en una reunión.", target: "I don't completely agree. Could we test it first?" },
    ],
  },
  {
    id: "explain-to-me",
    labelEs: "«explain to me»",
    type: "grammar",
    severity: 2,
    re: /\bexplain(s|ed)? me\b/gi,
    fix: (m) => `explain${m[1] ?? ""} to me`,
    explanationEs: "Después de «explain» va «to»: «Can you explain to me…?» o «Can you explain it?».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "Could you explain to me how the pipeline works?" },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "My manager explained me the process.", target: "My manager explained the process to me." },
      { kind: "create", promptEs: "Pide que te expliquen algo técnico.", target: "Can you explain to me why the model failed?" },
    ],
  },
  {
    id: "people-are",
    labelEs: "«people» es plural",
    type: "grammar",
    severity: 2,
    re: /\bpeople (is|was|has|does)\b/gi,
    fix: (m) => `people ${({ is: "are", was: "were", has: "have", does: "do" } as Record<string, string>)[m[1].toLowerCase()]}`,
    explanationEs: "«People» es plural: people are, people have.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "The people in my team is very friendly.", target: "The people on my team are very friendly." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "Most people are worried about AI, but they also use it every day." },
      { kind: "create", promptEs: "Describe a las personas de tu último trabajo.", target: "The people at my last job were supportive." },
    ],
  },
  {
    id: "depend-on",
    labelEs: "«depend on»",
    type: "grammar",
    severity: 1,
    re: /\bdepend(s|ed|ing)? of\b/gi,
    fix: (m) => `depend${m[1] ?? ""} on`,
    explanationEs: "En inglés se dice «depend on», no «depend of».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "It depends on the requirements." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "The price depends of the volume.", target: "The price depends on the volume." },
      { kind: "create", promptEs: "Responde a «Which language do you prefer?» usando depend on.", target: "It depends on the project, but I usually choose Python." },
    ],
  },
  {
    id: "discuss-no-about",
    labelEs: "«discuss» sin «about»",
    type: "grammar",
    severity: 1,
    re: /\bdiscuss(es|ed|ing)? about\b/gi,
    fix: (m) => `discuss${m[1] ?? ""}`,
    explanationEs: "«Discuss» no lleva «about»: we discussed the plan. (Pero sí: we talked about the plan.)",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "We discussed about the budget.", target: "We discussed the budget." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "Let's discuss the next steps." },
      { kind: "create", promptEs: "Di qué discutieron en tu última reunión.", target: "We discussed the release date and the main risks." },
    ],
  },
  {
    id: "ask-a-question",
    labelEs: "«ask a question»",
    type: "vocabulary",
    severity: 2,
    re: /\b(make|made|making|do|did) (a|an|the|some|many|one) (questions?)\b/gi,
    fix: (m) => {
      const v = m[1].toLowerCase();
      const verb = v === "made" || v === "did" ? "asked" : v === "making" ? "asking" : "ask";
      return `${verb} ${m[2]} ${m[3]}`;
    },
    explanationEs: "Las preguntas se «ask», no se «make»: ask a question.",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "Can I ask you a question about the team?" },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "The client made many questions.", target: "The client asked many questions." },
      { kind: "create", promptEs: "Al final de una entrevista, pide hacer una pregunta.", target: "Could I ask a question about the onboarding process?" },
    ],
  },
  {
    id: "attend",
    labelEs: "Falso amigo: «assist» ≠ asistir",
    type: "vocabulary",
    severity: 2,
    re: /\b(assist|assisted|assisting) (?:to )?(a |an |the |my |our )?(meetings?|class(?:es)?|courses?|conferences?|events?|university|school|workshops?|trainings?)\b/gi,
    fix: (m) => {
      const v = m[1].toLowerCase();
      const verb = v === "assisted" ? "attended" : v === "assisting" ? "attending" : "attend";
      const det = m[2] ?? (/s$/.test(m[3]) || /university|school/.test(m[3]) ? "" : "the ");
      return `${verb} ${det}${m[3]}`;
    },
    explanationEs: "«Asistir a» es «attend». «Assist» significa ayudar.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I assisted to a conference about AI.", target: "I attended a conference about AI." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I attend the daily meeting every morning." },
      { kind: "create", promptEs: "Di a qué curso o evento asististe.", target: "Last year I attended a course on generative AI." },
    ],
  },
  {
    id: "double-comparative",
    labelEs: "Comparativos",
    type: "grammar",
    severity: 2,
    re: /\bmore (better|worse|easier|faster|bigger|cheaper|smaller|harder|older|younger)\b/gi,
    fix: (m) => m[1],
    explanationEs: "«Better», «easier», etc. ya son comparativos: no lleves «more».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "This solution is more easier.", target: "This solution is easier." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "The new version is faster and cheaper." },
      { kind: "create", promptEs: "Compara dos herramientas que conoces.", target: "Docker is easier to deploy than a manual setup." },
    ],
  },
  {
    id: "past-after-did",
    labelEs: "Verbo base después de did/didn't",
    type: "grammar",
    severity: 3,
    re: /\b(didn't|did not|did) ([a-z]+ed|went|did|had|was|made|saw|came|wrote|built|took|gave|got|said|told|knew|thought|found|left|began|spoke)\b/gi,
    fix: (m) => `${m[1]} ${toBase(m[2])}`,
    explanationEs: "Después de «did/didn't» el verbo va en forma base: I didn't go (no «didn't went»).",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I didn't finished the project on time.", target: "I didn't finish the project on time." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "Did you work with cloud services? No, I didn't work with them directly." },
      { kind: "create", promptEs: "Di algo que NO hiciste en tu último proyecto.", target: "We didn't use Kubernetes, but we used Docker." },
    ],
  },
  {
    id: "third-person-dont",
    labelEs: "he/she/it doesn't",
    type: "grammar",
    severity: 2,
    re: /\b(he|she|it) don't\b/gi,
    fix: (m) => `${m[1]} doesn't`,
    explanationEs: "Con he/she/it usa «doesn't».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "The app don't work offline.", target: "The app doesn't work offline." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "It doesn't matter, she doesn't mind." },
      { kind: "create", promptEs: "Describe algo que tu sistema no hace.", target: "It doesn't support payments yet." },
    ],
  },
  {
    id: "uncountable-nouns",
    labelEs: "Sustantivos incontables",
    type: "grammar",
    severity: 1,
    re: /\b(informations|advices|softwares|feedbacks|knowledges|equipments|furnitures|homeworks|hardwares)\b/gi,
    fix: (m) => m[1].toLowerCase().replace(/s$/, ""),
    explanationEs: "Information, advice, software, feedback, knowledge… no llevan «s» en inglés.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I received many feedbacks from users.", target: "I received a lot of feedback from users." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "Can you give me some advice and more information?" },
      { kind: "create", promptEs: "Habla del software que usas en tu trabajo.", target: "We use a lot of open-source software." },
    ],
  },
  {
    id: "interested-ed",
    labelEs: "-ed vs -ing (interested / interesting)",
    type: "vocabulary",
    severity: 3,
    re: /\bI(?: am|'m) (?:so |very |really )?(interesting|boring|exciting|confusing|tiring)(?: (in|about|for|with))?\b/gi,
    fix: (m) => {
      const adj = m[1].toLowerCase().replace(/ing$/, "ed");
      const prep = m[2] ? (adj === "interested" ? "in" : m[2].toLowerCase()) : "";
      return `I'm ${adj}${prep ? ` ${prep}` : ""}`;
    },
    explanationEs: "-ed describe cómo te sientes (I'm interested); -ing describe algo (the job is interesting).",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "I'm interested in this role because the project is interesting." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I was very boring in that job.", target: "I was very bored in that job." },
      { kind: "create", promptEs: "Di qué te interesa de la IA.", target: "I'm interested in automation because it saves time." },
    ],
  },
  {
    id: "false-friend-actually",
    labelEs: "Falso amigo: «actually» ≠ actualmente",
    type: "vocabulary",
    severity: 2,
    re: /\bactually,? (I'm|I am|I work|I study|I live|I have|we are|we work)\b/gi,
    fix: (m) => `currently ${m[1]}`,
    explanationEs: "«Actually» = en realidad. «Actualmente» = currently / right now.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "Actually I work as a support engineer.", target: "Currently, I work as a support engineer." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I'm currently looking for a role in AI." },
      { kind: "create", promptEs: "Di qué haces actualmente.", target: "Right now I'm building an AI assistant." },
    ],
  },
  {
    id: "missing-subject-it",
    labelEs: "Sujeto obligatorio («it is…»)",
    type: "grammar",
    severity: 3,
    re: /(^|\b(?:because|and|but|so|think|that)\s)(is|was) (very |really |so |more |a bit )?(important|necessary|possible|difficult|easy|hard|interesting|good|better|better to|a good|useful)\b/gi,
    fix: (m) => `${m[1]}it ${m[2]} ${m[3] ?? ""}${m[4]}`.replace(/\s+/g, " "),
    explanationEs: "En inglés siempre hay sujeto: «It is important», no «Is important».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "Is very important to test the code.", target: "It is very important to test the code." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "It was difficult, but it was worth it." },
      { kind: "create", promptEs: "Di por qué algo es importante en tu trabajo.", target: "It is important to document the process." },
    ],
  },
  {
    id: "on-the-other-hand",
    labelEs: "«on the other hand»",
    type: "vocabulary",
    severity: 1,
    re: /\bin the other hand\b/gi,
    fix: () => "on the other hand",
    explanationEs: "La expresión es «on the other hand».",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "On the one hand it's fast; on the other hand it's expensive." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "In the other hand, the risk is low.", target: "On the other hand, the risk is low." },
      { kind: "create", promptEs: "Da una ventaja y una desventaja del trabajo remoto.", target: "Remote work saves time. On the other hand, it can feel isolating." },
    ],
  },
  {
    id: "gain-experience",
    labelEs: "«gain experience» / «earn money»",
    type: "vocabulary",
    severity: 2,
    re: /\b(win|won|winning) (experience|money|knowledge|skills)\b/gi,
    fix: (m) => {
      const obj = m[2].toLowerCase();
      const v = m[1].toLowerCase();
      if (obj === "money") return `${v === "won" ? "earned" : v === "winning" ? "earning" : "earn"} money`;
      return `${v === "won" ? "gained" : v === "winning" ? "gaining" : "gain"} ${obj}`;
    },
    explanationEs: "«Ganar» experiencia es «gain»; ganar dinero es «earn». «Win» es para premios o partidos.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "In that job I won a lot of experience.", target: "In that job I gained a lot of experience." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I want to gain experience in machine learning." },
      { kind: "create", promptEs: "Di qué experiencia ganaste en tu último trabajo.", target: "I gained experience with databases and testing." },
    ],
  },
  {
    id: "carry-out",
    labelEs: "Falso amigo: «realize» ≠ realizar",
    type: "vocabulary",
    severity: 2,
    re: /\b(realize|realized|realizing|realise|realised)((?: a| an| the| my| our| this| some| many| several)?(?: functional| technical| quality| data| unit| weekly| daily| final| small| big| new)?) (projects?|tasks?|activit(?:y|ies)|tests?|analysis|analyses|audits?|reports?|maintenance)\b(?! (?:were|was|are|is|had|have|did|didn't|failed|would|could|went))/gi,
    fix: (m) => {
      const v = m[1].toLowerCase();
      const verb = v.endsWith("ing") ? "carrying out" : v.endsWith("d") ? "carried out" : "carry out";
      return `${verb}${m[2]} ${m[3]}`;
    },
    explanationEs: "«Realize» = darse cuenta. «Realizar» un proyecto es «carry out», «complete» o «do».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I realized functional tests on circuit boards.", target: "I carried out functional tests on circuit boards." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "We carried out an analysis and completed the project on time." },
      { kind: "create", promptEs: "Describe una tarea que realizabas en tu trabajo.", target: "I ran functional tests and updated the database every day." },
    ],
  },
  {
    id: "degree-not-career",
    labelEs: "Falso amigo: «career» ≠ carrera universitaria",
    type: "vocabulary",
    severity: 2,
    re: /\b(studied|study|studying|finished|finish)(?: the| my| a)? career(?: of| in)?\b/gi,
    fix: (m) => {
      const v = m[1].toLowerCase();
      return v.startsWith("stud") ? v : `${v} my degree`;
    },
    explanationEs: "La carrera universitaria es «degree» o «major». «Career» es tu trayectoria profesional.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I studied the career of computer systems engineering.", target: "I have a degree in computer systems engineering." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I have a degree in engineering, and I want to grow my career in AI." },
      { kind: "create", promptEs: "Di qué estudiaste.", target: "I majored in computer systems engineering." },
    ],
  },
  {
    id: "modal-no-to",
    labelEs: "Modales sin «to»",
    type: "grammar",
    severity: 2,
    re: /\b(can|could|must|should|will|would|might) to ([a-z]+)\b/gi,
    fix: (m) => `${m[1]} ${m[2]}`,
    explanationEs: "Después de can, should, will, must… el verbo va sin «to»: I can work.",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I can to start next month.", target: "I can start next month." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I should finish it today, and I will send it tomorrow." },
      { kind: "create", promptEs: "Di algo que puedes aportar al equipo.", target: "I can help automate the testing process." },
    ],
  },
  {
    id: "want-someone-to",
    labelEs: "«want someone to…»",
    type: "grammar",
    severity: 2,
    re: /\b(want|wants|wanted|would like) that (I|you|he|she|they|we|my team) ([a-z]+)\b/gi,
    fix: (m) => {
      const obj: Record<string, string> = { i: "me", he: "him", she: "her", they: "them", we: "us" };
      const who = obj[m[2].toLowerCase()] ?? m[2];
      return `${m[1]} ${who} to ${m[3].replace(/s$/, "")}`;
    },
    explanationEs: "En inglés no se usa «want that…»: «I want you to explain», no «I want that you explain».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "My boss wants that I travel.", target: "My boss wants me to travel." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "I would like you to review my code." },
      { kind: "create", promptEs: "Di qué quieres que haga tu equipo.", target: "I want my team to document every change." },
    ],
  },
  {
    id: "look-forward-ing",
    labelEs: "«look forward to» + -ing",
    type: "grammar",
    severity: 1,
    re: /\blook(?:ing)? forward to (work|meet|hear|see|talk|join|start|collaborate)\b/gi,
    fix: (m) => m[0].replace(new RegExp(`${m[1]}$`), `${m[1].replace(/e$/, "")}ing`),
    explanationEs: "«Look forward to» va con -ing: I look forward to working with you.",
    exercises: [
      { kind: "say", promptEs: "Repite en voz alta.", target: "I look forward to working with your team." },
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I look forward to hear from you.", target: "I look forward to hearing from you." },
      { kind: "create", promptEs: "Cierra una entrevista con esta expresión.", target: "Thank you. I look forward to hearing from you." },
    ],
  },
  {
    id: "tell-me",
    labelEs: "«tell me» / «told me»",
    type: "vocabulary",
    severity: 2,
    re: /\b(say|said|says) (me|him|her|us|them)\b/gi,
    fix: (m) => {
      const v = m[1].toLowerCase();
      return `${v === "said" ? "told" : v === "says" ? "tells" : "tell"} ${m[2]}`;
    },
    explanationEs: "Con persona después usa «tell»: he told me (no «he said me»).",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "My supervisor said me to check the logs.", target: "My supervisor told me to check the logs." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "She told me the results and said they were good." },
      { kind: "create", promptEs: "Cuenta qué te dijo un jefe o cliente.", target: "The client told me the app was slow." },
    ],
  },
  {
    id: "people-not-persons",
    labelEs: "«people» en vez de «persons»",
    type: "vocabulary",
    severity: 1,
    re: new RegExp(`\\b${NUM} persons\\b`, "gi"),
    fix: (m) => `${m[1]} people`,
    explanationEs: "El plural normal de «person» es «people».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "My team has five persons.", target: "My team has five people." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "About twenty people use the system every day." },
      { kind: "create", promptEs: "Di cuántas personas había en tu equipo.", target: "There were six people on my team." },
    ],
  },
  {
    id: "on-days",
    labelEs: "Preposiciones de tiempo (on/in)",
    type: "grammar",
    severity: 1,
    re: /\b(in) (monday|tuesday|wednesday|thursday|friday|saturday|sunday|mondays|fridays|weekends?)\b|\bon (19\d\d|20\d\d)\b/gi,
    fix: (m) => (m[3] ? `in ${m[3]}` : `on ${m[2]}`),
    explanationEs: "Días con «on» (on Monday); años con «in» (in 2020).",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I started on 2021 and I rest in Sundays.", target: "I started in 2021 and I rest on Sundays." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "We deploy on Fridays, and we started in 2023." },
      { kind: "create", promptEs: "Di qué día y en qué año empezaste algo.", target: "I started my first job on a Monday in 2019." },
    ],
  },
  {
    id: "arrive-at",
    labelEs: "«arrive at / in»",
    type: "grammar",
    severity: 1,
    re: /\b(arrive|arrived|arrives|arriving) to\b/gi,
    fix: (m) => `${m[1]} at`,
    explanationEs: "Se dice «arrive at» (lugar concreto) o «arrive in» (ciudad/país), no «arrive to».",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I arrived to the office at eight.", target: "I arrived at the office at eight." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "We arrived in Monterrey late and arrived at the hotel at midnight." },
      { kind: "create", promptEs: "Di a qué hora llegas al trabajo.", target: "I usually arrive at work at nine." },
    ],
  },
  {
    id: "make-mistake",
    labelEs: "«make a mistake» / «do homework»",
    type: "vocabulary",
    severity: 1,
    re: /\b(do|did|doing) (a |many |some )?mistakes?\b|\b(make|made|making) (my |the )?homework\b/gi,
    fix: (m) => {
      if (m[1]) {
        const v = m[1].toLowerCase();
        return `${v === "did" ? "made" : v === "doing" ? "making" : "make"} ${m[2] ?? ""}${m[0].toLowerCase().endsWith("mistakes") ? "mistakes" : "mistake"}`;
      }
      const v = m[3].toLowerCase();
      return `${v === "made" ? "did" : v === "making" ? "doing" : "do"} ${m[4] ?? ""}homework`;
    },
    explanationEs: "Errores se «make» (make a mistake); tareas se «do» (do homework).",
    exercises: [
      { kind: "fix", promptEs: "Corrige la frase.", wrong: "I did a mistake in the report.", target: "I made a mistake in the report." },
      { kind: "say", promptEs: "Repite en voz alta.", target: "Everyone makes mistakes; what matters is what you learn." },
      { kind: "create", promptEs: "Cuenta un error que cometiste y qué aprendiste.", target: "I made a mistake in a query, and now I always test on staging." },
    ],
  },
];

export const RULES_BY_ID = new Map(RULES.map((r) => [r.id, r]));

/** Finds non-overlapping mistakes in `text` (first matching rule wins for a span). */
export function correctText(text: string, turnIndex = 0): Correction[] {
  const taken: [number, number][] = [];
  const out: Correction[] = [];
  for (const rule of RULES) {
    const re = new RegExp(rule.re.source, rule.re.flags.includes("g") ? rule.re.flags : rule.re.flags + "g");
    let m: RegExpExecArray | null;
    while ((m = re.exec(text))) {
      if (m[0].length === 0) {
        re.lastIndex++;
        continue;
      }
      // Skip a leading captured separator (e.g. "because ") from the "original" span.
      let start = m.index;
      let original = m[0];
      if (rule.id === "missing-subject-it" && m[1]) {
        start += m[1].length;
        original = m[0].slice(m[1].length);
      }
      const end = start + original.length;
      if (taken.some(([a, b]) => start < b && end > a)) continue;
      let fixed = rule.fix(m);
      if (rule.id === "missing-subject-it" && m[1]) fixed = fixed.slice(m[1].length);
      fixed = keepCase(original, fixed.trim());
      if (fixed.toLowerCase() === original.trim().toLowerCase()) continue;
      taken.push([start, end]);
      out.push({
        id: `r${turnIndex}-${out.length}`,
        category: rule.id,
        categoryLabelEs: rule.labelEs,
        type: rule.type,
        original: original.trim(),
        corrected: fixed,
        explanationEs: rule.explanationEs,
        spokenTip: `Instead of "${original.trim()}", say "${fixed}".`,
        severity: rule.severity,
        source: "rules",
      });
    }
  }
  return out.sort((a, b) => b.severity - a.severity).slice(0, 3);
}
