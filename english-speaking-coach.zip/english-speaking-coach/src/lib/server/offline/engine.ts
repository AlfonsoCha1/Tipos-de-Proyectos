import type { Hint, InterviewRole, Level, ScenarioId, SessionSettings } from "@/lib/shared/types";
import { wordCount } from "@/lib/shared/text";

/**
 * Offline backup (NO AI). Used only when no LLM key is configured or the LLM fails.
 * It follows a fixed question list and reacts with generic phrases, so the app keeps
 * working, but it is not the coach agent and the UI says so.
 */

interface Q {
  simple: string;
  standard: string;
  hint: Hint;
  followup?: { simple: string; standard: string; hint: Hint };
}

const INTERVIEW_COMMON_START: Q[] = [
  {
    simple: "Hi, I'm your interviewer today. Thank you for coming. How are you today?",
    standard: "Hi, I'm Alex, and I'll be your interviewer today. Thanks for joining us. How are you doing today?",
    hint: { es: "Es charla de cortesía: di cómo estás y agradece la oportunidad.", starter: "I'm doing well, thank you. I'm happy to be here." },
  },
  {
    simple: "Great. Please tell me about yourself.",
    standard: "Great, let's get started. Could you tell me a little about yourself and your background?",
    hint: { es: "Preséntate en 3 partes: qué estudiaste, tu experiencia y qué buscas ahora.", starter: "I'm a systems engineer with experience in…" },
    followup: {
      simple: "What do you like most about your work?",
      standard: "What part of that experience did you enjoy the most, and why?",
      hint: { es: "Elige una actividad concreta y explica por qué te gustó.", starter: "What I enjoyed the most was…" },
    },
  },
  {
    simple: "Why do you want this job?",
    standard: "What interests you about this position, and why now?",
    hint: { es: "Conecta tus intereses con el puesto y di qué quieres aprender o aportar.", starter: "I'm interested in this position because…" },
  },
  {
    simple: "Tell me about a project you are proud of.",
    standard: "Tell me about a technical project you're proud of. What was your role in it?",
    hint: { es: "Describe el problema, qué hiciste tú y el resultado (idealmente con un número).", starter: "One project I'm proud of is…" },
    followup: {
      simple: "What was the biggest problem in that project?",
      standard: "What was the biggest challenge in that project, and how did you solve it?",
      hint: { es: "Cuenta un obstáculo real y los pasos que seguiste para resolverlo.", starter: "The biggest challenge was… so I decided to…" },
    },
  },
];

const TECH_Q: Record<InterviewRole, Q> = {
  software: {
    simple: "How do you check that your code works well?",
    standard: "How do you make sure your code is reliable before it goes to production?",
    hint: { es: "Habla de pruebas, revisiones de código y cómo detectas errores.", starter: "First, I write tests for… Then I…" },
  },
  ai: {
    simple: "How do you explain a machine learning model to a client with no technical background?",
    standard: "How would you explain a machine learning model to a client who has no technical background?",
    hint: { es: "Usa una analogía simple: el modelo aprende de ejemplos, como una persona con experiencia.", starter: "I would say that the model learns from examples, like…" },
  },
};

const INTERVIEW_COMMON_END: Q[] = [
  {
    simple: "Tell me about a problem with a teammate. What did you do?",
    standard: "Tell me about a time you disagreed with a teammate. How did you handle it?",
    hint: { es: "Usa el método STAR: situación, tarea, acción y resultado.", starter: "In my last job, a teammate and I disagreed about…" },
  },
  {
    simple: "Where do you want to be in three years?",
    standard: "Where do you see yourself in three years?",
    hint: { es: "Menciona una meta profesional realista relacionada con el puesto.", starter: "In three years, I'd like to…" },
  },
  {
    simple: "Do you have any questions for me?",
    standard: "Before we finish, do you have any questions for me?",
    hint: { es: "Haz una pregunta sobre el equipo, el proyecto o cómo es un día normal.", starter: "Yes, I'd like to know more about…" },
  },
];

const GENERIC: Record<Exclude<ScenarioId, "interview">, Q[]> = {
  daily: [
    { simple: "Hi! How are you today?", standard: "Hey! How's your day going so far?", hint: { es: "Di cómo estás y algo que hiciste hoy.", starter: "It's going well. Today I…" } },
    { simple: "What do you do on a normal day?", standard: "What does a typical day look like for you?", hint: { es: "Describe tu rutina en orden: mañana, tarde y noche.", starter: "I usually wake up at… and then…" } },
    { simple: "What do you like to do on weekends?", standard: "What do you usually do on weekends to relax?", hint: { es: "Menciona un pasatiempo y con quién lo haces.", starter: "On weekends I like to…" } },
    { simple: "What is your favorite food?", standard: "What's a dish you love, and where do you usually eat it?", hint: { es: "Di tu comida favorita y por qué te gusta.", starter: "My favorite food is… because…" } },
    { simple: "What are your plans for next month?", standard: "Do you have any plans or goals for the next few weeks?", hint: { es: "Usa «I'm going to…» para hablar de planes.", starter: "Next month I'm going to…" } },
  ],
  travel: [
    { simple: "Good morning. Can I see your passport, please? Where are you flying today?", standard: "Good morning! May I see your passport? Where are you flying to today?", hint: { es: "Eres pasajero en el aeropuerto. Di tu destino.", starter: "Sure, here it is. I'm flying to…" } },
    { simple: "Do you have bags to check?", standard: "Will you be checking any bags today?", hint: { es: "Di cuántas maletas documentas.", starter: "Yes, I have one bag to check." } },
    { simple: "Welcome to the hotel. Do you have a reservation?", standard: "Welcome to the Grand Hotel. Do you have a reservation with us?", hint: { es: "Di tu nombre y cuántas noches te quedas.", starter: "Yes, I have a reservation under the name…" } },
    { simple: "Are you ready to order?", standard: "Hi there! Are you ready to order, or do you need a few more minutes?", hint: { es: "Pide comida y bebida de forma amable.", starter: "Yes, I'd like the… please." } },
    { simple: "Can I help you? Are you lost?", standard: "You look a bit lost. Can I help you find something?", hint: { es: "Pregunta cómo llegar a un lugar.", starter: "Yes, please. How can I get to…?" } },
  ],
  meetings: [
    { simple: "Good morning, team. What did you work on this week?", standard: "Morning, everyone. Let's start with updates. What have you been working on this week?", hint: { es: "Da un avance: qué terminaste y qué sigue.", starter: "This week I finished… and I'm working on…" } },
    { simple: "Do you have any problems or blockers?", standard: "Is anything blocking you right now?", hint: { es: "Menciona un bloqueo y qué necesitas.", starter: "Yes, I'm blocked by… I need…" } },
    { simple: "What do you think about the new plan?", standard: "What's your opinion on the new timeline we proposed?", hint: { es: "Da tu opinión con respeto y una razón.", starter: "In my opinion… because…" } },
    { simple: "What are the next steps?", standard: "Before we wrap up, what are your next steps?", hint: { es: "Di qué harás y para cuándo.", starter: "My next step is to… by Friday." } },
  ],
  presentations: [
    { simple: "Please start. What is your project about?", standard: "Whenever you're ready. Could you introduce your project in a few sentences?", hint: { es: "Di el nombre del proyecto y qué problema resuelve.", starter: "Today I'm going to present… It solves…" } },
    { simple: "Who are the users?", standard: "Who is your target user, and what problem do they have today?", hint: { es: "Describe a tu usuario y su problema.", starter: "Our users are… Right now they struggle with…" } },
    { simple: "How does it work?", standard: "Walk us through how it works, step by step.", hint: { es: "Explica en pasos: first, then, finally.", starter: "First… then… finally…" } },
    { simple: "What are the results?", standard: "What results or metrics can you share so far?", hint: { es: "Da un número o resultado concreto.", starter: "So far we have…" } },
  ],
  business: [
    { simple: "Hello, thanks for meeting me. What does your company do?", standard: "Thanks for taking the time to meet. Could you tell me what your company offers?", hint: { es: "Explica tu producto en una frase clara.", starter: "We help… to… by…" } },
    { simple: "Why is your product better?", standard: "What makes your solution different from what we use today?", hint: { es: "Da una ventaja concreta frente a la competencia.", starter: "The main difference is that…" } },
    { simple: "The price is high for us. Can you give a discount?", standard: "Honestly, the price is above our budget. Is there any flexibility?", hint: { es: "Negocia: ofrece algo a cambio en vez de solo bajar el precio.", starter: "I understand. If you sign for a year, we can…" } },
    { simple: "What happens if there is a problem?", standard: "What kind of support do you offer if something goes wrong?", hint: { es: "Describe el soporte y los tiempos de respuesta.", starter: "We offer support by… and we respond within…" } },
  ],
};

const CLOSING = {
  interview: "Thank you, that's all for today. You did a great job. Let's look at your feedback.",
  other: "That's all for today. Great practice! Let's look at your feedback.",
};

const ACKS = [
  "Thanks for sharing that.",
  "That's interesting.",
  "Got it, thank you.",
  "I appreciate the detail.",
  "That makes sense.",
];

const TECH_WORDS = [
  "python", "java", "javascript", "typescript", "react", "sql", "docker", "kubernetes", "aws", "azure",
  "linux", "fastapi", "flask", "tensorflow", "pytorch", "excel", "cisco", "git", "github", "node",
];

function questionsFor(settings: SessionSettings): Q[] {
  if (settings.scenario === "interview") {
    const all = [...INTERVIEW_COMMON_START, TECH_Q[settings.role], ...INTERVIEW_COMMON_END];
    return settings.length === "short" ? [all[0], all[1], all[3], all[5]] : all;
  }
  return GENERIC[settings.scenario];
}

export interface OfflineState {
  q: number;
  followupDone: boolean;
  elaborated: boolean;
}

export interface OfflineStep {
  reaction?: string;
  question: string;
  purpose: "question" | "followup" | "closing";
  hint?: Hint;
  done: boolean;
  state: OfflineState;
}

function pick(q: { simple: string; standard: string }, level: Level, simplify: boolean): string {
  return level === "A2" || simplify ? q.simple : q.standard;
}

function react(userText: string, qIndex: number, state: OfflineState): string {
  const t = userText.toLowerCase();
  if (qIndex === 0 && state.q === 0) {
    if (/\b(nervous|tired|bad|sick|stressed)\b/.test(t)) return "That's normal. Let's take it step by step.";
    return "Glad to hear that.";
  }
  const tech = TECH_WORDS.find((w) => new RegExp(`\\b${w}\\b`).test(t));
  if (tech) return `${tech === "sql" ? "SQL" : tech.charAt(0).toUpperCase() + tech.slice(1)} is really useful for that.`;
  return ACKS[(qIndex + t.length) % ACKS.length];
}

export function offlineStep(
  settings: SessionSettings,
  userText: string | null,
  state: OfflineState | null,
  simplify: boolean,
  skip = false,
): OfflineStep {
  const qs = questionsFor(settings);
  const level = settings.level;
  if (!state || userText === null) {
    const s = { q: 0, followupDone: false, elaborated: false };
    return { question: pick(qs[0], level, simplify), purpose: "question", hint: qs[0].hint, done: false, state: s };
  }
  const current = qs[state.q];
  const reaction = skip ? "No problem, let's move on." : react(userText, state.q, state);
  const n = wordCount(userText);

  if (!skip && current && n < 6 && !state.elaborated && state.q > 0) {
    return {
      reaction: "Okay.",
      question: "Could you tell me a bit more? Try to give me an example.",
      purpose: "followup",
      hint: { es: "Amplía tu respuesta con un ejemplo concreto de tu experiencia.", starter: "For example, in my last job…" },
      done: false,
      state: { ...state, elaborated: true },
    };
  }
  if (!skip && current?.followup && !state.followupDone && n >= 6) {
    return {
      reaction,
      question: pick(current.followup, level, simplify),
      purpose: "followup",
      hint: current.followup.hint,
      done: false,
      state: { ...state, followupDone: true },
    };
  }
  const nextIndex = state.q + 1;
  if (nextIndex >= qs.length) {
    return {
      reaction,
      question: settings.scenario === "interview" ? CLOSING.interview : CLOSING.other,
      purpose: "closing",
      done: true,
      state: { q: nextIndex, followupDone: false, elaborated: false },
    };
  }
  const next = qs[nextIndex];
  return {
    reaction,
    question: pick(next, level, simplify),
    purpose: "question",
    hint: next.hint,
    done: false,
    state: { q: nextIndex, followupDone: false, elaborated: false },
  };
}
