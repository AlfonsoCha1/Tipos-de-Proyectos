import "server-only";
import type { LlmConfig } from "../../config";

/**
 * LLM transport. The coach agent only needs "send a system prompt + messages, get
 * JSON text back", so each provider is a small fetch wrapper (no SDK dependency).
 * To add a provider, implement `LlmClient` and register it in `createLlmClient`.
 */

export interface LlmMessage {
  role: "user" | "assistant";
  content: string;
}

export interface LlmRequest {
  system: string;
  messages: LlmMessage[];
  maxTokens: number;
  temperature?: number;
  /** Ask the provider to return a JSON object. */
  json: boolean;
  signal?: AbortSignal;
}

export interface LlmClient {
  id: LlmConfig["provider"];
  model: string;
  complete(req: LlmRequest): Promise<string>;
}

export class LlmError extends Error {
  constructor(
    message: string,
    public status?: number,
  ) {
    super(message);
  }
}

class OpenAICompatibleClient implements LlmClient {
  constructor(private cfg: LlmConfig) {}
  get id() {
    return this.cfg.provider;
  }
  get model() {
    return this.cfg.model;
  }

  async complete(req: LlmRequest): Promise<string> {
    const body: Record<string, unknown> = {
      model: this.cfg.model,
      messages: [{ role: "system", content: req.system }, ...req.messages],
      temperature: req.temperature ?? 0.6,
      max_completion_tokens: req.maxTokens,
    };
    if (req.json) body.response_format = { type: "json_object" };
    // gpt-oss models on Groq are reasoning models: keep reasoning short for voice latency.
    if (this.cfg.provider === "groq" && this.cfg.model.includes("gpt-oss")) body.reasoning_effort = "low";

    const res = await fetch(`${this.cfg.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.cfg.apiKey}` },
      body: JSON.stringify(body),
      signal: req.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new LlmError(`${this.cfg.provider} ${res.status}: ${text.slice(0, 300)}`, res.status);
    }
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const content = data.choices?.[0]?.message?.content;
    if (!content) throw new LlmError(`${this.cfg.provider}: empty response`);
    return content;
  }
}

class AnthropicClient implements LlmClient {
  id = "anthropic" as const;
  constructor(private cfg: LlmConfig) {}
  get model() {
    return this.cfg.model;
  }

  async complete(req: LlmRequest): Promise<string> {
    // Anthropic needs alternating roles starting with "user".
    const merged: LlmMessage[] = [];
    for (const m of req.messages) {
      const last = merged[merged.length - 1];
      if (last && last.role === m.role) last.content += `\n\n${m.content}`;
      else merged.push({ ...m });
    }
    if (merged[0]?.role !== "user") merged.unshift({ role: "user", content: "(The session begins.)" });

    const res = await fetch(`${this.cfg.baseUrl}/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": this.cfg.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: this.cfg.model,
        system: req.json ? `${req.system}\n\nRespond with a single JSON object and nothing else.` : req.system,
        messages: merged,
        max_tokens: req.maxTokens,
        temperature: req.temperature ?? 0.6,
      }),
      signal: req.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new LlmError(`anthropic ${res.status}: ${text.slice(0, 300)}`, res.status);
    }
    const data = (await res.json()) as { content?: { type: string; text?: string }[] };
    const text = data.content?.find((c) => c.type === "text")?.text;
    if (!text) throw new LlmError("anthropic: empty response");
    return text;
  }
}

export function createLlmClient(cfg: LlmConfig): LlmClient {
  return cfg.provider === "anthropic" ? new AnthropicClient(cfg) : new OpenAICompatibleClient(cfg);
}

/** Extracts the first JSON object from a model reply (tolerates code fences / chatter). */
export function extractJson(text: string): unknown {
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.indexOf("{");
    const end = trimmed.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new LlmError("model did not return JSON");
  }
}
