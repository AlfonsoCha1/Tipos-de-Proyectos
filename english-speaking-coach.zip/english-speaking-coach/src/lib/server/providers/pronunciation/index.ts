import "server-only";
import { azureConfig, type AzureSpeechConfig } from "../../config";
import { lookupTip, phonemeAdviceEs, CATEGORY_ADVICE_ES } from "@/lib/shared/pronunciation";
import { words as tokenize } from "@/lib/shared/text";
import type {
  PronunciationAssessment,
  ProblemWord,
  WordAssessment,
  WordErrorType,
} from "@/lib/shared/types";

/**
 * Pronunciation assessment providers.
 *
 *  - "azure": Azure AI Speech Pronunciation Assessment. Scores the AUDIO against a
 *    reference text: accuracy per phoneme/word, fluency, completeness and prosody
 *    (intonation/rhythm, en-US only). This is a real acoustic measurement.
 *  - "transcript": no acoustic analysis at all. It only compares the words the
 *    speech recognizer produced with the expected words. Every result it returns is
 *    labeled measured=false and the UI says so.
 *
 * Add another engine (e.g. Speechace, ELSA API) by implementing PronunciationProvider.
 */

export interface AssessRequest {
  /** 16 kHz mono PCM16 WAV. Required by acoustic providers. */
  wav?: Buffer;
  referenceText: string;
  recognizedText?: string;
  /** "scripted": the learner tried to say referenceText (drills). "conversation": free speech. */
  mode: "scripted" | "conversation";
}

export interface PronunciationProvider {
  id: "azure" | "transcript";
  measured: boolean;
  assess(req: AssessRequest): Promise<PronunciationAssessment>;
}

const PROBLEM_THRESHOLD = 75;

export function problemWordsFrom(words: WordAssessment[], measured: boolean): ProblemWord[] {
  const out: ProblemWord[] = [];
  for (const w of words) {
    const bad =
      w.errorType === "Mispronunciation" ||
      w.errorType === "NotRecognized" ||
      (typeof w.accuracy === "number" && w.accuracy < PROBLEM_THRESHOLD);
    if (!bad || w.errorType === "Insertion") continue;
    const clean = w.word.toLowerCase().replace(/[^a-z']/g, "");
    if (!clean) continue;
    const worst = w.phonemes?.length
      ? w.phonemes.reduce((a, b) => (b.accuracy < a.accuracy ? b : a))
      : undefined;
    const tip = lookupTip(clean);
    const phonemeAdvice = worst && worst.accuracy < 70 ? phonemeAdviceEs(worst.phoneme) : null;
    const adviceEs = phonemeAdvice ?? tip?.tipEs ?? CATEGORY_ADVICE_ES.stress;
    let reasonEs: string;
    if (measured) {
      reasonEs =
        w.errorType === "Omission"
          ? `No se detectó la palabra «${clean}» en tu audio.`
          : `Precisión ${Math.round(w.accuracy ?? 0)}/100` +
            (worst ? `; el sonido /${worst.phoneme}/ obtuvo ${Math.round(worst.accuracy)}/100.` : ".");
    } else {
      reasonEs = `El reconocedor de voz no entendió «${clean}». Puede ser pronunciación, ruido o el micrófono: no es una medición de sonidos.`;
    }
    out.push({ word: clean, accuracy: w.accuracy, worstPhoneme: worst, adviceEs, tip, reasonEs, measured });
  }
  return out
    .sort((a, b) => (a.accuracy ?? 0) - (b.accuracy ?? 0))
    .filter((p, i, arr) => arr.findIndex((x) => x.word === p.word) === i)
    .slice(0, 3);
}

// ---------------------------------------------------------------------------
// Transcript-only (honest fallback, no acoustic data)
// ---------------------------------------------------------------------------

class TranscriptOnly implements PronunciationProvider {
  id = "transcript" as const;
  measured = false;
  async assess(req: AssessRequest): Promise<PronunciationAssessment> {
    const notes = [
      "Sin evaluación acústica: solo comparamos el texto que reconoció el sistema con lo esperado. No medimos tus sonidos, ritmo ni entonación.",
    ];
    if (req.mode === "conversation" || !req.recognizedText) {
      return { measured: false, provider: "transcript", referenceText: req.referenceText, recognizedText: req.recognizedText, words: [], problemWords: [], notes };
    }
    const heard = new Set(tokenize(req.recognizedText));
    const words: WordAssessment[] = tokenize(req.referenceText).map((w) => ({
      word: w,
      errorType: (heard.has(w) ? "None" : "NotRecognized") as WordErrorType,
    }));
    return {
      measured: false,
      provider: "transcript",
      referenceText: req.referenceText,
      recognizedText: req.recognizedText,
      words,
      problemWords: problemWordsFrom(words, false),
      notes,
    };
  }
}

// ---------------------------------------------------------------------------
// Azure AI Speech — Pronunciation Assessment (REST, short audio ≤ 30 s)
// ---------------------------------------------------------------------------

interface AzurePA {
  AccuracyScore?: number;
  FluencyScore?: number;
  CompletenessScore?: number;
  ProsodyScore?: number;
  PronScore?: number;
  ErrorType?: string;
}
interface AzurePhoneme {
  Phoneme: string;
  AccuracyScore?: number;
  PronunciationAssessment?: AzurePA;
}
interface AzureWord extends AzurePA {
  Word: string;
  PronunciationAssessment?: AzurePA;
  Phonemes?: AzurePhoneme[];
  Feedback?: { Prosody?: { Break?: { ErrorTypes?: string[] }; Intonation?: { ErrorTypes?: string[] } } };
}
interface AzureNBest extends AzurePA {
  Lexical?: string;
  Display?: string;
  PronunciationAssessment?: AzurePA;
  Words?: AzureWord[];
}
export interface AzureResponse {
  RecognitionStatus: string;
  DisplayText?: string;
  NBest?: AzureNBest[];
}

/** Azure has returned both flat and nested score shapes over time; accept both. */
export function parseAzureResponse(data: AzureResponse, referenceText: string): PronunciationAssessment {
  const notes: string[] = [];
  if (data.RecognitionStatus !== "Success" || !data.NBest?.length) {
    return {
      measured: true,
      provider: "azure",
      referenceText,
      words: [],
      problemWords: [],
      notes: [
        data.RecognitionStatus === "NoMatch" || data.RecognitionStatus === "InitialSilenceTimeout"
          ? "No se detectó voz clara en la grabación. Acércate al micrófono y vuelve a intentarlo."
          : `El servicio no pudo evaluar el audio (${data.RecognitionStatus}).`,
      ],
    };
  }
  const nb = data.NBest[0];
  const pa = nb.PronunciationAssessment ?? nb;
  const words: WordAssessment[] = (nb.Words ?? []).map((w) => {
    const wpa = w.PronunciationAssessment ?? w;
    return {
      word: w.Word,
      accuracy: wpa.AccuracyScore,
      errorType: (wpa.ErrorType ?? "None") as WordErrorType,
      phonemes: (w.Phonemes ?? []).map((p) => ({
        phoneme: p.Phoneme,
        accuracy: p.PronunciationAssessment?.AccuracyScore ?? p.AccuracyScore ?? 0,
      })),
    };
  });
  const breaks = (nb.Words ?? []).filter((w) =>
    (w.Feedback?.Prosody?.Break?.ErrorTypes ?? []).includes("UnexpectedBreak"),
  ).length;
  const monotone = (nb.Words ?? []).some((w) =>
    (w.Feedback?.Prosody?.Intonation?.ErrorTypes ?? []).includes("Monotone"),
  );
  if (typeof pa.ProsodyScore === "number" && pa.ProsodyScore < 70)
    notes.push("Tu entonación y ritmo pueden mejorar: marca más las sílabas fuertes y sube/baja la voz al final de las frases.");
  if (breaks >= 2) notes.push(`Hiciste ${breaks} pausas en lugares inesperados. Intenta agrupar las palabras por ideas.`);
  if (monotone) notes.push("Tu voz sonó algo plana (monótona). Enfatiza las palabras importantes.");
  if (typeof pa.FluencyScore === "number" && pa.FluencyScore < 60)
    notes.push("Fluidez baja: hubo pausas largas o repeticiones. Está bien: prueba frases más cortas.");

  return {
    measured: true,
    provider: "azure",
    referenceText,
    recognizedText: nb.Lexical ?? data.DisplayText,
    scores: {
      accuracy: pa.AccuracyScore,
      fluency: pa.FluencyScore,
      completeness: pa.CompletenessScore,
      prosody: pa.ProsodyScore,
      overall: pa.PronScore,
    },
    words,
    problemWords: problemWordsFrom(words, true),
    notes,
  };
}

export function azureAssessmentHeader(referenceText: string, scripted: boolean): string {
  const params = {
    ReferenceText: referenceText,
    GradingSystem: "HundredMark",
    Granularity: "Phoneme",
    Dimension: "Comprehensive",
    EnableMiscue: scripted ? "True" : "False",
    EnableProsodyAssessment: "True",
    PhonemeAlphabet: "IPA",
    NBestPhonemeCount: 3,
  };
  return Buffer.from(JSON.stringify(params), "utf8").toString("base64");
}

export function azureSttUrl(cfg: AzureSpeechConfig): string {
  const path = "/speech/recognition/conversation/cognitiveservices/v1?language=en-US&format=detailed";
  return cfg.endpoint ? `${cfg.endpoint}/stt${path}` : `https://${cfg.region}.stt.speech.microsoft.com${path}`;
}

/** Keep only the first `seconds` of a PCM16 mono WAV (Azure REST accepts ≤ 30 s). */
export function trimWav(wav: Buffer, seconds: number): Buffer {
  if (wav.length < 44) return wav;
  const byteRate = wav.readUInt32LE(28);
  const maxData = Math.floor(byteRate * seconds);
  const dataSize = wav.readUInt32LE(40);
  if (dataSize <= maxData) return wav;
  const out = Buffer.from(wav.subarray(0, 44 + maxData));
  out.writeUInt32LE(36 + maxData, 4);
  out.writeUInt32LE(maxData, 40);
  return out;
}

class AzurePronunciation implements PronunciationProvider {
  id = "azure" as const;
  measured = true;
  constructor(private cfg: AzureSpeechConfig) {}
  async assess(req: AssessRequest): Promise<PronunciationAssessment> {
    if (!req.wav) throw new Error("azure pronunciation needs audio");
    const reference = req.referenceText.trim();
    if (!reference) throw new Error("azure pronunciation needs reference text");
    const res = await fetch(azureSttUrl(this.cfg), {
      method: "POST",
      headers: {
        "Ocp-Apim-Subscription-Key": this.cfg.key,
        "Content-Type": "audio/wav; codecs=audio/pcm; samplerate=16000",
        Accept: "application/json",
        "Pronunciation-Assessment": azureAssessmentHeader(reference, req.mode === "scripted"),
      },
      body: new Uint8Array(trimWav(req.wav, 29.5)),
    });
    if (!res.ok) throw new Error(`azure pronunciation ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return parseAzureResponse((await res.json()) as AzureResponse, reference);
  }
}

export function createPronunciationProvider(which: "azure" | "transcript"): PronunciationProvider {
  const cfg = azureConfig();
  if (which === "azure" && cfg) return new AzurePronunciation(cfg);
  return new TranscriptOnly();
}
