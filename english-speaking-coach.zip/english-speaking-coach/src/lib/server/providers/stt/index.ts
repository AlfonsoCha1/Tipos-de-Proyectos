import "server-only";
import type { SttConfig } from "../../config";

/**
 * Server-side speech-to-text. Optional: by default the browser's own speech
 * recognition is used (free, Chrome/Edge/Safari). Whisper via Groq or OpenAI is more
 * robust with accents and works in every browser that can record audio.
 *
 * Note: Whisper tends to "clean up" what it hears (it may silently fix small
 * grammar slips), which can hide mistakes from the corrector. The browser engine
 * is more literal. Both are transcription only — neither measures pronunciation.
 */

export interface SttResult {
  text: string;
  language?: string;
  durationSec?: number;
}

export interface SttProvider {
  id: string;
  transcribe(wav: Buffer, opts?: { prompt?: string }): Promise<SttResult>;
}

class WhisperCompatible implements SttProvider {
  constructor(private cfg: SttConfig) {}
  get id() {
    return this.cfg.provider;
  }
  async transcribe(wav: Buffer, opts: { prompt?: string } = {}): Promise<SttResult> {
    const form = new FormData();
    form.append("file", new Blob([new Uint8Array(wav)], { type: "audio/wav" }), "answer.wav");
    form.append("model", this.cfg.model);
    form.append("language", "en");
    form.append("response_format", "verbose_json");
    form.append("temperature", "0");
    if (opts.prompt) form.append("prompt", opts.prompt.slice(0, 400));
    const res = await fetch(`${this.cfg.baseUrl}/audio/transcriptions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${this.cfg.apiKey}` },
      body: form,
    });
    if (!res.ok) throw new Error(`${this.cfg.provider} stt ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = (await res.json()) as { text?: string; language?: string; duration?: number };
    return { text: (data.text ?? "").trim(), language: data.language, durationSec: data.duration };
  }
}

export function createSttProvider(cfg: SttConfig): SttProvider {
  return new WhisperCompatible(cfg);
}
