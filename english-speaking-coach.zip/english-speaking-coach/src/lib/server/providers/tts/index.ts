import "server-only";
import { azureConfig, openaiTtsConfig, ttsProvider } from "../../config";
import { escapeXml } from "@/lib/shared/text";

/**
 * Server-side text-to-speech. Optional: by default the browser's own voices are
 * used (free, quality varies by device). Azure neural voices sound much more
 * natural and support true slow speech (SSML prosody) without changing pitch.
 */

export interface TtsRequest {
  text: string;
  lang: "en" | "es";
  slow: boolean;
}

export interface TtsProvider {
  id: string;
  synthesize(req: TtsRequest): Promise<{ audio: ArrayBuffer; contentType: string }>;
}

class AzureTts implements TtsProvider {
  id = "azure";
  async synthesize(req: TtsRequest) {
    const cfg = azureConfig()!;
    const voice = req.lang === "es" ? cfg.voiceEs : cfg.voiceEn;
    const locale = req.lang === "es" ? "es-MX" : "en-US";
    const ssml =
      `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${locale}">` +
      `<voice name="${voice}"><prosody rate="${req.slow ? "-40%" : "0%"}">${escapeXml(req.text)}</prosody></voice></speak>`;
    const url = cfg.endpoint
      ? `${cfg.endpoint}/tts/cognitiveservices/v1`
      : `https://${cfg.region}.tts.speech.microsoft.com/cognitiveservices/v1`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Ocp-Apim-Subscription-Key": cfg.key,
        "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
        "User-Agent": "english-speaking-coach",
      },
      body: ssml,
    });
    if (!res.ok) throw new Error(`azure tts ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return { audio: await res.arrayBuffer(), contentType: "audio/mpeg" };
  }
}

class OpenAITts implements TtsProvider {
  id = "openai";
  async synthesize(req: TtsRequest) {
    const cfg = openaiTtsConfig();
    const res = await fetch(`${cfg.baseUrl}/audio/speech`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.apiKey}` },
      body: JSON.stringify({
        model: cfg.model,
        voice: cfg.voice,
        input: req.text,
        response_format: "mp3",
        speed: req.slow ? 0.7 : 1.0,
        instructions: req.slow
          ? "Speak slowly and very clearly, like a patient English teacher modeling pronunciation."
          : "Speak clearly and warmly, like a friendly English coach.",
      }),
    });
    if (!res.ok) throw new Error(`openai tts ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return { audio: await res.arrayBuffer(), contentType: "audio/mpeg" };
  }
}

export function createTtsProvider(): TtsProvider | null {
  const id = ttsProvider();
  if (id === "azure") return new AzureTts();
  if (id === "openai") return new OpenAITts();
  return null;
}

/** Tiny LRU so repeated drill words ("develop", slow) aren't paid for twice. */
export class AudioCache {
  private map = new Map<string, { audio: ArrayBuffer; contentType: string }>();
  constructor(private max = 200) {}
  get(key: string) {
    const v = this.map.get(key);
    if (v) {
      this.map.delete(key);
      this.map.set(key, v);
    }
    return v;
  }
  set(key: string, v: { audio: ArrayBuffer; contentType: string }) {
    this.map.set(key, v);
    if (this.map.size > this.max) this.map.delete(this.map.keys().next().value!);
  }
}

const g = globalThis as unknown as { __escTtsCache?: AudioCache };
export const ttsCache = (g.__escTtsCache ??= new AudioCache());
