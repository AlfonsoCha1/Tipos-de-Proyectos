import "server-only";
import { z } from "zod";

/** Validation for everything the browser sends. Caps sizes so a client can't inflate LLM costs. */

const level = z.enum(["A2", "B1", "B2", "C1"]);

export const settingsSchema = z.object({
  scenario: z.enum(["interview", "daily", "travel", "meetings", "presentations", "business"]),
  level,
  correctionMode: z.enum(["fluent", "teacher"]),
  role: z.enum(["software", "ai"]),
  length: z.enum(["short", "full"]),
  spokenSpanishTips: z.boolean(),
  bargeIn: z.boolean(),
});

const text = (max: number) => z.string().max(max * 4).transform((s) => s.slice(0, max));
/** Numbers from the browser are clamped, not rejected: a strange value must not end a session. */
const clamped = (min: number, max: number) => z.number().transform((n) => Math.min(max, Math.max(min, n)));

export const historySchema = z
  .array(z.object({ role: z.enum(["coach", "user"]), text: text(700) }))
  .max(200)
  .transform((h) => h.slice(-20));

export const observationSchema = z.object({
  kind: z.enum(["start", "answer", "drill-result", "silence"]),
  userText: text(1500).optional(),
  speech: z
    .object({
      durationSec: clamped(0, 600),
      wordsPerMinute: clamped(0, 1000).optional(),
      latencySec: clamped(0, 600).optional(),
    })
    .optional(),
  pronunciation: z
    .object({
      measured: z.boolean(),
      overall: z.number().optional(),
      fluency: z.number().optional(),
      prosody: z.number().optional(),
      problemWords: z
        .array(
          z.object({
            word: text(40),
            accuracy: z.number().optional(),
            phoneme: text(10).optional(),
            phonemeAccuracy: z.number().optional(),
          }),
        )
        .max(5),
    })
    .optional(),
  drill: z
    .object({
      word: text(40),
      success: z.boolean(),
      attempts: z.number().int().min(0).max(10),
      accuracy: z.number().optional(),
      measured: z.boolean(),
    })
    .optional(),
  signals: z.array(z.enum(["asked-hint", "asked-repeat", "long-silence", "asked-slower", "asked-skip"])).max(6).optional(),
});

export const memorySchema = z.object({
  exchange: z.number().int().min(0).max(200),
  levelEstimate: level,
  pace: z.enum(["slower", "normal", "faster"]),
  notes: z.array(text(160)).max(8),
  weakCategories: z.array(z.object({ category: text(48), labelEs: text(60), count: z.number().int().min(0) })).max(10),
  drilledWords: z.array(text(40)).max(40),
  lastCorrectionExchange: z.number().int(),
  lastDrillExchange: z.number().int(),
  topicsCovered: z.array(text(60)).max(12),
});

export const agentRequestSchema = z.object({
  settings: settingsSchema,
  history: historySchema,
  observation: observationSchema,
  memory: memorySchema.nullable(),
  engineState: z.string().max(500).optional(),
});

const correctionSchema = z.object({
  id: text(40),
  category: text(48),
  categoryLabelEs: text(60),
  type: z.enum(["grammar", "vocabulary", "naturalness"]),
  original: text(200),
  corrected: text(200),
  explanationEs: text(300),
  spokenTip: text(220),
  severity: z.union([z.literal(1), z.literal(2), z.literal(3)]),
  source: z.enum(["rules", "llm"]),
  turnIndex: z.number().optional(),
});

const tipSchema = z.object({
  word: text(40),
  ipa: text(60),
  stress: text(60),
  category: z.string().max(20),
  tipEs: text(300),
});

export const summaryRequestSchema = z.object({
  settings: settingsSchema,
  corrections: z.array(correctionSchema).max(120),
  pronunciation: z
    .array(
      z.object({
        word: text(40),
        measured: z.boolean(),
        accuracy: z.number().optional(),
        adviceEs: text(300),
        tip: tipSchema.nullable(),
      }),
    )
    .max(20),
  stats: z.object({
    turns: z.number().int().min(0).max(500),
    userWords: z.number().int().min(0).max(100000),
    speakingSeconds: clamped(0, 100000),
    wordsPerMinute: clamped(0, 1000),
    corrections: z.number().int().min(0).max(1000),
  }),
  memory: memorySchema.nullable(),
});

export const ttsRequestSchema = z.object({
  text: z.string().min(1).max(600),
  lang: z.enum(["en", "es"]),
  slow: z.boolean().default(false),
});
