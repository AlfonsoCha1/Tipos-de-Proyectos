import "server-only";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { globalDailySessionCap, limits } from "./config";
import type { ApiErrorBody } from "@/lib/shared/types";

/**
 * Cost control.
 *
 * - Every practice session gets a signed token (HMAC). Its expiry is inside the
 *   signature, so the time limit holds even if the server restarts.
 * - Per-session counters (turns, TTS characters, pronunciation assessments, audio
 *   seconds) and per-IP daily session counts live in memory. That is fine for one
 *   server; for serverless / several instances, swap `UsageStore` for Redis
 *   (e.g. Upstash) — the interface is intentionally tiny.
 */

export interface Usage {
  turns: number;
  ttsChars: number;
  assessments: number;
  audioSeconds: number;
}

export interface UsageStore {
  get(sessionId: string): Usage;
  set(sessionId: string, usage: Usage, ttlMs: number): void;
  incrDaily(key: string): number;
}

class MemoryUsageStore implements UsageStore {
  private usage = new Map<string, { u: Usage; exp: number }>();
  private daily = new Map<string, number>();
  private lastSweep = Date.now();

  get(id: string): Usage {
    this.sweep();
    return this.usage.get(id)?.u ?? { turns: 0, ttsChars: 0, assessments: 0, audioSeconds: 0 };
  }
  set(id: string, u: Usage, ttlMs: number) {
    this.usage.set(id, { u, exp: Date.now() + ttlMs });
  }
  incrDaily(key: string): number {
    const n = (this.daily.get(key) ?? 0) + 1;
    this.daily.set(key, n);
    return n;
  }
  private sweep() {
    const now = Date.now();
    if (now - this.lastSweep < 60_000) return;
    this.lastSweep = now;
    for (const [k, v] of this.usage) if (v.exp < now) this.usage.delete(k);
    const today = dayKey();
    for (const k of this.daily.keys()) if (!k.endsWith(today)) this.daily.delete(k);
  }
}

const globalForStore = globalThis as unknown as { __escUsageStore?: UsageStore; __escSecret?: string };
export const store: UsageStore = (globalForStore.__escUsageStore ??= new MemoryUsageStore());

function secret(): string {
  const s = process.env.SESSION_SECRET;
  if (s && s.length >= 16) return s;
  if (!globalForStore.__escSecret) {
    globalForStore.__escSecret = randomBytes(32).toString("hex");
    if (process.env.NODE_ENV === "production") {
      console.warn("[coach] SESSION_SECRET is not set: using a random one; sessions reset on restart.");
    }
  }
  return globalForStore.__escSecret;
}

function dayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export interface SessionClaims {
  sid: string;
  iat: number;
  exp: number;
}

export class ApiError extends Error {
  constructor(
    public status: number,
    public body: ApiErrorBody,
  ) {
    super(body.error);
  }
}

export function createSession(ip: string): { token: string; claims: SessionClaims } {
  const L = limits();
  const ipCount = store.incrDaily(`ip:${ip}:${dayKey()}`);
  if (ipCount > L.maxSessionsPerDay) {
    throw new ApiError(429, {
      error: "daily session limit reached",
      code: "limit_daily",
      messageEs: `Llegaste al límite de ${L.maxSessionsPerDay} sesiones por día. Vuelve mañana.`,
    });
  }
  const globalCount = store.incrDaily(`global:${dayKey()}`);
  if (globalCount > globalDailySessionCap()) {
    throw new ApiError(429, {
      error: "global daily cap reached",
      code: "limit_daily",
      messageEs: "La demo llegó a su límite diario de uso. Intenta mañana.",
    });
  }
  const now = Date.now();
  const claims: SessionClaims = {
    sid: randomBytes(12).toString("base64url"),
    iat: now,
    exp: now + L.maxMinutes * 60_000,
  };
  const payload = Buffer.from(JSON.stringify(claims)).toString("base64url");
  return { token: `${payload}.${sign(payload)}`, claims };
}

/** Verifies the token. `graceMs` lets the summary be generated right after time runs out. */
export function verifySession(token: string | null, graceMs = 0): SessionClaims {
  const fail = (code: ApiErrorBody["code"], messageEs: string): never => {
    throw new ApiError(code === "session_expired" ? 409 : 401, { error: code, code, messageEs });
  };
  if (!token) return fail("no_session", "Falta la sesión. Vuelve a empezar la práctica.");
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return fail("no_session", "Sesión inválida. Vuelve a empezar.");
  const expected = Buffer.from(sign(payload));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) {
    return fail("no_session", "Sesión inválida. Vuelve a empezar.");
  }
  let claims: SessionClaims;
  try {
    claims = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
  } catch {
    return fail("no_session", "Sesión inválida. Vuelve a empezar.");
  }
  if (Date.now() > claims.exp + graceMs) {
    return fail("session_expired", "Se terminó el tiempo de esta sesión. Revisa tu resumen o empieza otra.");
  }
  return claims;
}

type Counter = keyof Usage;

const LIMIT_OF: Record<Counter, { key: keyof ReturnType<typeof limits>; code: ApiErrorBody["code"]; es: string }> = {
  turns: { key: "maxTurns", code: "limit_turns", es: "Llegaste al máximo de turnos de esta sesión." },
  ttsChars: { key: "maxTtsChars", code: "limit_tts", es: "Se agotó la voz del servidor para esta sesión; se usará la voz del navegador." },
  assessments: { key: "maxAssessments", code: "limit_assessments", es: "Llegaste al máximo de evaluaciones de pronunciación de esta sesión." },
  audioSeconds: { key: "maxAnswerSeconds", code: "limit_audio", es: "Se superó el audio permitido para esta sesión." },
};

/**
 * Checks and consumes `amount` of a counter. Throws 429 when the limit would be exceeded.
 * audioSeconds is limited to maxAnswerSeconds × maxTurns for the whole session.
 */
export function consume(claims: SessionClaims, counter: Counter, amount: number): Usage {
  const L = limits();
  const usage = store.get(claims.sid);
  const spec = LIMIT_OF[counter];
  const max = counter === "audioSeconds" ? L.maxAnswerSeconds * L.maxTurns : (L[spec.key] as number);
  if (usage[counter] + amount > max) {
    throw new ApiError(429, { error: `${counter} limit reached`, code: spec.code, messageEs: spec.es });
  }
  const next = { ...usage, [counter]: usage[counter] + amount };
  store.set(claims.sid, next, Math.max(claims.exp - Date.now(), 0) + 30 * 60_000);
  return next;
}

export function usageOf(claims: SessionClaims): Usage {
  return store.get(claims.sid);
}
