import type { PronCategory, PronunciationTip } from "./types";

/**
 * Pronunciation knowledge for Spanish speakers.
 *
 * IMPORTANT: everything in this file is *prior knowledge* ("this word is often hard
 * for Spanish speakers"). It never says how the learner actually sounded. Only an
 * acoustic engine (see server/providers/pronunciation/azure.ts) can measure that.
 */

/** How to place the mouth for each problem sound, in plain Spanish. */
export const CATEGORY_ADVICE_ES: Record<PronCategory, string> = {
  "th-voiceless":
    "Pon la punta de la lengua entre los dientes y sopla aire sin vibrar la garganta. No es 't' ni 's'.",
  "th-voiced":
    "Lengua entre los dientes, como en 'th' de 'think', pero haciendo vibrar la garganta (suena parecido a la 'd' suave de 'nada').",
  "ed-t": "La terminación -ed suena como una 't' corta pegada a la palabra. No digas 'ed'.",
  "ed-d": "La terminación -ed suena como una 'd' suave pegada a la palabra, sin agregar sílaba.",
  "ed-id": "Aquí -ed sí es una sílaba extra: suena 'id', porque la palabra termina en t o d.",
  "v-sound":
    "Apoya los dientes de arriba sobre el labio de abajo y haz vibrar. No juntes los labios como en la 'b'.",
  "s-cluster":
    "Empieza directo con la 's', sin agregar una 'e' antes. Piensa 'sss-' y luego la palabra.",
  stress:
    "Marca fuerte la sílaba acentuada: más larga, más alta y más clara. Las demás van rápidas y suaves.",
  "dj-sound":
    "Suena como 'dy' con fuerza (como la 'll' argentina con una 'd' al inicio). No es la 'j' española ni una 'y' suave.",
  "sh-sound": "Redondea los labios hacia adelante y deja salir aire: 'sh', como cuando pides silencio.",
  "short-i":
    "Es una 'i' corta y relajada, entre 'i' y 'e'. No estires la boca como en la 'i' española.",
  "r-vowel":
    "La 'r' inglesa no vibra: curva la lengua hacia atrás sin tocar el paladar y mantén el sonido.",
  schwa: "Las sílabas débiles se dicen con una vocal neutra y rápida, casi una 'uh' muy corta.",
  "h-sound": "La 'h' es solo aire suave desde la garganta, como empañar un espejo. No es la 'j' española fuerte.",
  "vowel-a": "Abre bien la boca y baja la mandíbula: es una vocal entre 'a' y 'e' ('æ').",
};

type Entry = [word: string, ipa: string, stress: string, category: PronCategory];

// Words that show up in interviews / work talk and that Spanish speakers often find hard.
const ENTRIES: Entry[] = [
  ["develop", "dɪˈvɛləp", "de·VEL·op", "stress"],
  ["developer", "dɪˈvɛləpər", "de·VEL·op·er", "stress"],
  ["development", "dɪˈvɛləpmənt", "de·VEL·op·ment", "stress"],
  ["engineer", "ˌɛndʒɪˈnɪr", "en·gi·NEER", "stress"],
  ["engineering", "ˌɛndʒɪˈnɪrɪŋ", "en·gi·NEER·ing", "stress"],
  ["comfortable", "ˈkʌmftərbəl", "COMF·ter·ble", "stress"],
  ["algorithm", "ˈælɡəˌrɪðəm", "AL·go·ri·thm", "th-voiced"],
  ["algorithms", "ˈælɡəˌrɪðəmz", "AL·go·ri·thms", "th-voiced"],
  ["architecture", "ˈɑrkɪˌtɛktʃər", "AR·chi·tec·ture", "stress"],
  ["experience", "ɪkˈspɪriəns", "ex·PE·ri·ence", "stress"],
  ["specific", "spəˈsɪfɪk", "spe·CI·fic", "s-cluster"],
  ["skills", "skɪlz", "SKILLS", "s-cluster"],
  ["skill", "skɪl", "SKILL", "s-cluster"],
  ["stack", "stæk", "STACK", "s-cluster"],
  ["startup", "ˈstɑrtʌp", "START·up", "s-cluster"],
  ["strategy", "ˈstrætədʒi", "STRA·te·gy", "s-cluster"],
  ["study", "ˈstʌdi", "STU·dy", "s-cluster"],
  ["studied", "ˈstʌdid", "STU·died", "s-cluster"],
  ["student", "ˈstudənt", "STU·dent", "s-cluster"],
  ["school", "skul", "SCHOOL", "s-cluster"],
  ["spanish", "ˈspænɪʃ", "SPAN·ish", "s-cluster"],
  ["speak", "spik", "SPEAK", "s-cluster"],
  ["structure", "ˈstrʌktʃər", "STRUC·ture", "s-cluster"],
  ["three", "θri", "THREE", "th-voiceless"],
  ["think", "θɪŋk", "THINK", "th-voiceless"],
  ["thanks", "θæŋks", "THANKS", "th-voiceless"],
  ["thank", "θæŋk", "THANK", "th-voiceless"],
  ["through", "θru", "THROUGH", "th-voiceless"],
  ["thought", "θɔt", "THOUGHT", "th-voiceless"],
  ["python", "ˈpaɪθɑn", "PY·thon", "th-voiceless"],
  ["method", "ˈmɛθəd", "ME·thod", "th-voiceless"],
  ["growth", "ɡroʊθ", "GROWTH", "th-voiceless"],
  ["other", "ˈʌðər", "O·ther", "th-voiced"],
  ["with", "wɪð", "WITH", "th-voiced"],
  ["together", "təˈɡɛðər", "to·GE·ther", "th-voiced"],
  ["whether", "ˈwɛðər", "WHE·ther", "th-voiced"],
  ["worked", "wɜrkt", "WORKED", "ed-t"],
  ["developed", "dɪˈvɛləpt", "de·VEL·oped", "ed-t"],
  ["helped", "hɛlpt", "HELPED", "ed-t"],
  ["asked", "æskt", "ASKED", "ed-t"],
  ["finished", "ˈfɪnɪʃt", "FIN·ished", "ed-t"],
  ["fixed", "fɪkst", "FIXED", "ed-t"],
  ["learned", "lɜrnd", "LEARNED", "ed-d"],
  ["improved", "ɪmˈpruvd", "im·PROVED", "ed-d"],
  ["designed", "dɪˈzaɪnd", "de·SIGNED", "ed-d"],
  ["managed", "ˈmænɪdʒd", "MAN·aged", "ed-d"],
  ["used", "juzd", "USED", "ed-d"],
  ["created", "kriˈeɪtɪd", "cre·A·ted", "ed-id"],
  ["decided", "dɪˈsaɪdɪd", "de·CI·ded", "ed-id"],
  ["wanted", "ˈwɑntɪd", "WAN·ted", "ed-id"],
  ["needed", "ˈnidɪd", "NEE·ded", "ed-id"],
  ["started", "ˈstɑrtɪd", "STAR·ted", "ed-id"],
  ["tested", "ˈtɛstɪd", "TES·ted", "ed-id"],
  ["automated", "ˈɔtəˌmeɪtɪd", "AU·to·ma·ted", "ed-id"],
  ["implemented", "ˈɪmpləˌmɛntɪd", "IM·ple·men·ted", "ed-id"],
  ["very", "ˈvɛri", "VE·ry", "v-sound"],
  ["video", "ˈvɪdioʊ", "VI·de·o", "v-sound"],
  ["value", "ˈvælju", "VAL·ue", "v-sound"],
  ["variable", "ˈvɛriəbəl", "VA·ri·a·ble", "v-sound"],
  ["version", "ˈvɜrʒən", "VER·sion", "v-sound"],
  ["virtual", "ˈvɜrtʃuəl", "VIR·tu·al", "v-sound"],
  ["vision", "ˈvɪʒən", "VI·sion", "v-sound"],
  ["java", "ˈdʒɑvə", "JA·va", "dj-sound"],
  ["javascript", "ˈdʒɑvəˌskrɪpt", "JA·va·script", "dj-sound"],
  ["job", "dʒɑb", "JOB", "dj-sound"],
  ["just", "dʒʌst", "JUST", "dj-sound"],
  ["manager", "ˈmænɪdʒər", "MAN·a·ger", "dj-sound"],
  ["challenge", "ˈtʃælɪndʒ", "CHAL·lenge", "dj-sound"],
  ["knowledge", "ˈnɑlɪdʒ", "KNOW·ledge", "dj-sound"],
  ["machine", "məˈʃin", "ma·CHINE", "sh-sound"],
  ["solution", "səˈluʃən", "so·LU·tion", "sh-sound"],
  ["position", "pəˈzɪʃən", "po·SI·tion", "sh-sound"],
  ["communication", "kəˌmjunɪˈkeɪʃən", "com·mu·ni·CA·tion", "stress"],
  ["automation", "ˌɔtəˈmeɪʃən", "au·to·MA·tion", "stress"],
  ["certification", "ˌsɜrtɪfɪˈkeɪʃən", "cer·ti·fi·CA·tion", "stress"],
  ["business", "ˈbɪznəs", "BUS·ness", "short-i"],
  ["build", "bɪld", "BUILD", "short-i"],
  ["team", "tim", "TEAM", "short-i"],
  ["learning", "ˈlɜrnɪŋ", "LEARN·ing", "r-vowel"],
  ["work", "wɜrk", "WORK", "r-vowel"],
  ["world", "wɜrld", "WORLD", "r-vowel"],
  ["career", "kəˈrɪr", "ca·REER", "stress"],
  ["university", "ˌjunɪˈvɜrsəti", "u·ni·VER·si·ty", "stress"],
  ["technology", "tɛkˈnɑlədʒi", "tech·NOL·o·gy", "stress"],
  ["analysis", "əˈnæləsɪs", "a·NAL·y·sis", "stress"],
  ["analyze", "ˈænəˌlaɪz", "AN·a·lyze", "stress"],
  ["company", "ˈkʌmpəni", "COM·pa·ny", "schwa"],
  ["problem", "ˈprɑbləm", "PROB·lem", "schwa"],
  ["model", "ˈmɑdəl", "MOD·el", "schwa"],
  ["focus", "ˈfoʊkəs", "FO·cus", "schwa"],
  ["data", "ˈdeɪtə", "DA·ta", "schwa"],
  ["database", "ˈdeɪtəˌbeɪs", "DA·ta·base", "stress"],
  ["environment", "ɪnˈvaɪrənmənt", "en·VI·ron·ment", "stress"],
  ["responsible", "rɪˈspɑnsəbəl", "re·SPON·si·ble", "stress"],
  ["security", "sɪˈkjʊrəti", "se·CU·ri·ty", "stress"],
  ["hired", "haɪərd", "HIRED", "h-sound"],
  ["help", "hɛlp", "HELP", "h-sound"],
  ["hardware", "ˈhɑrdˌwɛr", "HARD·ware", "h-sound"],
  ["happy", "ˈhæpi", "HAP·py", "vowel-a"],
  ["can't", "kænt", "CAN'T", "vowel-a"],
  ["linux", "ˈlɪnəks", "LIN·ux", "short-i"],
  ["azure", "ˈæʒər", "AZ·ure", "vowel-a"],
  ["network", "ˈnɛtˌwɜrk", "NET·work", "r-vowel"],
  ["interview", "ˈɪntərˌvju", "IN·ter·view", "stress"],
  ["salary", "ˈsæləri", "SAL·a·ry", "vowel-a"],
];

function buildDictionary(): Map<string, PronunciationTip> {
  const map = new Map<string, PronunciationTip>();
  for (const [word, ipa, stress, category] of ENTRIES) {
    map.set(word, { word, ipa, stress, category, tipEs: tipFor(stress, category) });
  }
  return map;
}

function tipFor(stress: string, category: PronCategory): string {
  const stressed = stress.split("·").find((s) => s === s.toUpperCase() && /[A-Z]/.test(s));
  const stressLine = stress.includes("·") && stressed ? ` Acento en «${stressed.toLowerCase()}».` : "";
  return `${CATEGORY_ADVICE_ES[category]}${stressLine}`;
}

export const PRON_DICTIONARY = buildDictionary();

const ED_EXCEPTIONS = new Set([
  "need", "red", "bed", "speed", "hundred", "based", "embed", "united", "sacred", "naked", "wicked",
  "crowded", "kindred", "shed", "fed", "led", "wed", "sled", "breed", "seed", "feed", "weed", "reed",
]);

/** Classify the -ed ending of a regular past verb that is not in the dictionary. */
function edTip(word: string): PronunciationTip | null {
  if (word.length < 6 || !word.endsWith("ed") || ED_EXCEPTIONS.has(word)) return null;
  const stem = word.slice(0, -2);
  const last = stem.slice(-1);
  const last2 = stem.slice(-2);
  let category: PronCategory;
  let ending: string;
  if (last === "t" || last === "d" || (last === "e" && /[td]$/.test(stem.slice(0, -1)))) {
    category = "ed-id";
    ending = "ɪd";
  } else if (/[pkfx]$/.test(stem) || ["sh", "ch", "ss", "ce"].includes(last2) || /[^s]s$/.test(stem)) {
    category = "ed-t";
    ending = "t";
  } else {
    category = "ed-d";
    ending = "d";
  }
  return {
    word,
    ipa: `…${ending}`,
    stress: word, // stress unknown for words outside the dictionary: nothing is highlighted
    category,
    tipEs: CATEGORY_ADVICE_ES[category],
  };
}

export function lookupTip(word: string): PronunciationTip | null {
  const w = word.toLowerCase().replace(/[^a-z']/g, "");
  if (!w) return null;
  return PRON_DICTIONARY.get(w) ?? edTip(w);
}

/**
 * Words in `text` that are commonly hard for Spanish speakers. Ordered by first
 * appearance, de-duplicated. Returns dictionary knowledge only — not a measurement.
 */
export function findRiskyWords(text: string, max = 3, exclude: string[] = []): PronunciationTip[] {
  const seen = new Set(exclude.map((w) => w.toLowerCase()));
  const out: PronunciationTip[] = [];
  for (const raw of text.toLowerCase().split(/[^a-z']+/)) {
    if (!raw || seen.has(raw)) continue;
    const tip = lookupTip(raw);
    if (tip) {
      seen.add(raw);
      out.push(tip);
      if (out.length >= max) break;
    }
  }
  return out;
}

/**
 * Advice for a phoneme reported by an acoustic engine. Accepts IPA symbols and
 * the SAPI labels Azure returns by default.
 */
const PHONEME_CATEGORY: Record<string, PronCategory> = {
  θ: "th-voiceless", th: "th-voiceless",
  ð: "th-voiced", dh: "th-voiced",
  v: "v-sound",
  dʒ: "dj-sound", ʤ: "dj-sound", jh: "dj-sound",
  ʃ: "sh-sound", sh: "sh-sound", ʒ: "sh-sound", zh: "sh-sound",
  ɪ: "short-i", ih: "short-i",
  ɜr: "r-vowel", ɝ: "r-vowel", ɚ: "r-vowel", er: "r-vowel", ɹ: "r-vowel", r: "r-vowel",
  ə: "schwa", ax: "schwa", ʌ: "schwa", ah: "schwa",
  h: "h-sound", hh: "h-sound",
  æ: "vowel-a", ae: "vowel-a",
};

const PHONEME_EXTRA_ES: Record<string, string> = {
  z: "La 'z' inglesa vibra como un zumbido de abeja: 'zzz'. No la conviertas en 's'.",
  i: "Es una 'i' larga y tensa: estira los labios como sonriendo.",
  iy: "Es una 'i' larga y tensa: estira los labios como sonriendo.",
  ŋ: "La lengua toca atrás del paladar y el aire sale por la nariz. No pronuncies una 'g' al final.",
  ng: "La lengua toca atrás del paladar y el aire sale por la nariz. No pronuncies una 'g' al final.",
  t: "Toca con la lengua detrás de los dientes de arriba y suelta un poco de aire.",
  d: "La 'd' final se pronuncia completa y corta. No la omitas.",
  s: "Una 's' limpia y sin vocal antes.",
  tʃ: "Como la 'ch' española pero con los labios un poco hacia adelante.",
  ch: "Como la 'ch' española pero con los labios un poco hacia adelante.",
  w: "Redondea los labios como para decir 'u' y ábrelos rápido.",
  j: "Como la 'y' de 'yo' pero suave, sin sonar a 'll' fuerte.",
  y: "Como la 'y' de 'yo' pero suave, sin sonar a 'll' fuerte.",
};

export function phonemeAdviceEs(phoneme: string): string | null {
  const p = phoneme.trim().toLowerCase();
  const cat = PHONEME_CATEGORY[p];
  if (cat) return CATEGORY_ADVICE_ES[cat];
  return PHONEME_EXTRA_ES[p] ?? null;
}
