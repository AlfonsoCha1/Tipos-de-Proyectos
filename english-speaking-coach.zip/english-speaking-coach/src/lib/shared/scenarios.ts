import type { Level, ScenarioId, SessionSettings } from "./types";

export interface ScenarioInfo {
  id: ScenarioId;
  labelEs: string;
  descriptionEs: string;
  /** Who the coach plays. Used in LLM prompts. */
  coachRole: string;
  /** What the conversation is about. Used in LLM prompts. */
  goal: string;
  /** Approximate number of learner answers before closing. */
  exchanges: number;
}

export const SCENARIOS: ScenarioInfo[] = [
  {
    id: "interview",
    labelEs: "Entrevista de trabajo",
    descriptionEs: "Ingeniería de software o IA. Saludo, preguntas técnicas y de comportamiento, cierre.",
    coachRole: "a friendly but professional hiring manager at a tech company",
    goal: "a job interview for an engineering role",
    exchanges: 8,
  },
  {
    id: "daily",
    labelEs: "Conversación cotidiana",
    descriptionEs: "Tu día, tus gustos, planes del fin de semana.",
    coachRole: "a friendly English-speaking friend",
    goal: "a relaxed everyday conversation about the learner's life, routines and plans",
    exchanges: 8,
  },
  {
    id: "travel",
    labelEs: "Viajes",
    descriptionEs: "Aeropuerto, hotel, restaurante, pedir direcciones.",
    coachRole: "different people the traveler meets: an airline agent, a hotel receptionist, a waiter",
    goal: "practical travel situations: check-in, hotel, ordering food, asking for directions",
    exchanges: 8,
  },
  {
    id: "meetings",
    labelEs: "Reuniones",
    descriptionEs: "Dar avances, opinar, pedir aclaraciones, acordar siguientes pasos.",
    coachRole: "a project manager running a weekly team meeting",
    goal: "a team meeting: status updates, blockers, opinions, next steps",
    exchanges: 8,
  },
  {
    id: "presentations",
    labelEs: "Presentaciones",
    descriptionEs: "Presenta un proyecto y responde preguntas del público.",
    coachRole: "an audience member and presentation coach",
    goal: "the learner presents a project in short parts and answers audience questions",
    exchanges: 7,
  },
  {
    id: "business",
    labelEs: "Negocios",
    descriptionEs: "Vender una idea, negociar precio, hablar con un cliente.",
    coachRole: "a potential client or business partner",
    goal: "a business conversation: pitching, negotiating price and terms, handling objections",
    exchanges: 8,
  },
];

export function scenarioInfo(id: ScenarioId): ScenarioInfo {
  return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[0];
}

export const LEVELS: { id: Level; labelEs: string; descriptionEs: string }[] = [
  { id: "A2", labelEs: "Básico", descriptionEs: "Frases cortas, hablo despacio." },
  { id: "B1", labelEs: "Intermedio", descriptionEs: "Me doy a entender con pausas." },
  { id: "B2", labelEs: "Intermedio alto", descriptionEs: "Converso con fluidez en temas conocidos." },
  { id: "C1", labelEs: "Avanzado", descriptionEs: "Quiero sonar natural y profesional." },
];

/** Speaking rate for the coach's voice, per level (1 = normal). */
export const BASE_TTS_RATE: Record<Level, number> = { A2: 0.82, B1: 0.9, B2: 0.97, C1: 1.03 };

/** Silence (ms) that means "I finished my turn". Learners at lower levels pause more. */
export const END_OF_TURN_SILENCE_MS: Record<Level, number> = { A2: 1900, B1: 1600, B2: 1300, C1: 1100 };

/** If the learner says nothing for this long after a question, offer a hint in Spanish. */
export const HINT_AFTER_MS: Record<Level, number> = { A2: 7000, B1: 8000, B2: 9000, C1: 10000 };

export const DEFAULT_SETTINGS: SessionSettings = {
  scenario: "interview",
  level: "B1",
  correctionMode: "teacher",
  role: "software",
  length: "short",
  spokenSpanishTips: true,
  bargeIn: true,
};
