import type { Correction, ErrorGroup } from "./types";

export function words(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9'\s-]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

export function wordCount(text: string): number {
  return words(text).length;
}

export type VoiceCommand = "repeat" | "hint" | "slower" | "skip" | "end";

const COMMANDS: { cmd: VoiceCommand; re: RegExp; maxWords: number }[] = [
  {
    cmd: "end",
    re: /\b(end|finish|stop) (the |this )?(interview|session|practice|conversation)\b|\b(terminar|termina|terminemos)\b/,
    maxWords: 8,
  },
  {
    cmd: "slower",
    re: /\b(slower|more slowly|slow down|speak slowly)\b|m[aá]s (despacio|lento)/,
    maxWords: 10,
  },
  {
    cmd: "repeat",
    re: /\b(repeat|say (it|that) again|one more time|pardon|come again|again please|sorry,? what)\b|\brepite\b|\botra vez\b/,
    maxWords: 8,
  },
  {
    cmd: "hint",
    re: /\b(i don'?t know|i'?m not sure what to say|how do (you|i) say|give me a hint|hint please|help me)\b|(^|\s)no s[eé](?=$|[\s.,!?])|\bpista\b|\bay[uú]dame\b/,
    maxWords: 8,
  },
  { cmd: "skip", re: /\b(next question|skip( it| this| that)?|pass)\b|\bsiguiente\b/, maxWords: 5 },
];

/** Detects short control phrases ("repeat please", "no sé", "next question"). */
export function detectCommand(text: string): VoiceCommand | null {
  const t = text.toLowerCase().trim();
  const n = wordCount(t);
  if (!n) return null;
  for (const { cmd, re, maxWords } of COMMANDS) {
    if (n <= maxWords && re.test(t)) return cmd;
  }
  return null;
}

/** Group corrections by category and rank them: severity-weighted frequency. */
export function rankErrors(corrections: Correction[]): ErrorGroup[] {
  const groups = new Map<string, ErrorGroup>();
  for (const c of corrections) {
    const key = c.category || c.corrected.toLowerCase();
    let g = groups.get(key);
    if (!g) {
      g = {
        category: key,
        labelEs: c.categoryLabelEs,
        type: c.type,
        count: 0,
        score: 0,
        explanationEs: c.explanationEs,
        examples: [],
      };
      groups.set(key, g);
    }
    g.count += 1;
    g.score += c.severity;
    const dup = g.examples.some((e) => e.original.toLowerCase() === c.original.toLowerCase());
    if (!dup && g.examples.length < 3) g.examples.push({ original: c.original, corrected: c.corrected });
  }
  return [...groups.values()].sort((a, b) => b.score - a.score || b.count - a.count);
}

export function clip(text: string, max: number): string {
  return text.length <= max ? text : text.slice(0, max);
}

export function escapeXml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
