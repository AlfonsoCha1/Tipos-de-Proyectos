// Types shared by the browser and the server. No secrets, no Node/browser-only imports.

export type ScenarioId = "interview" | "daily" | "travel" | "meetings" | "presentations" | "business";
export type Level = "A2" | "B1" | "B2" | "C1";
export type CorrectionMode = "fluent" | "teacher";
export type InterviewRole = "software" | "ai";
export type InterviewLength = "short" | "full";

export interface SessionSettings {
  scenario: ScenarioId;
  level: Level;
  correctionMode: CorrectionMode;
  role: InterviewRole;
  length: InterviewLength;
  /** Speak the short Spanish explanations aloud (not only on screen). */
  spokenSpanishTips: boolean;
  /** Let the learner interrupt the coach by starting to speak. */
  bargeIn: boolean;
}

export interface ChatMessage {
  role: "coach" | "user";
  text: string;
}

export type CorrectionType = "grammar" | "vocabulary" | "naturalness";

export interface Correction {
  id: string;
  /** Stable key used to group repeated mistakes (rule id or LLM slug). */
  category: string;
  categoryLabelEs: string;
  type: CorrectionType;
  original: string;
  corrected: string;
  explanationEs: string;
  /** One short English sentence the coach can say out loud. */
  spokenTip: string;
  severity: 1 | 2 | 3;
  source: "rules" | "llm";
  turnIndex?: number;
}

/** A dictionary tip about a word Spanish speakers often mispronounce. NOT a measurement. */
export interface PronunciationTip {
  word: string;
  ipa: string;
  /** Syllables separated by "·", stressed syllable in UPPERCASE. */
  stress: string;
  category: PronCategory;
  tipEs: string;
}

export type PronCategory =
  | "th-voiceless"
  | "th-voiced"
  | "ed-t"
  | "ed-d"
  | "ed-id"
  | "v-sound"
  | "s-cluster"
  | "stress"
  | "dj-sound"
  | "sh-sound"
  | "short-i"
  | "r-vowel"
  | "schwa"
  | "h-sound"
  | "vowel-a";

export interface Hint {
  es: string;
  starter: string;
}

// ---------------------------------------------------------------------------
// The coach agent: observation -> decision (ordered actions) -> updated memory
// ---------------------------------------------------------------------------

/** What the agent perceives after each learner turn. */
export interface Observation {
  kind: "start" | "answer" | "drill-result" | "silence";
  userText?: string;
  speech?: {
    durationSec: number;
    wordsPerMinute?: number;
    /** Seconds of silence before the learner started talking. */
    latencySec?: number;
  };
  /** Pronunciation evidence. `measured` is false when it only comes from text. */
  pronunciation?: {
    measured: boolean;
    overall?: number;
    fluency?: number;
    prosody?: number;
    problemWords: { word: string; accuracy?: number; phoneme?: string; phonemeAccuracy?: number }[];
  };
  drill?: { word: string; success: boolean; attempts: number; accuracy?: number; measured: boolean };
  /** Signals the client detected: the learner asked for a hint, a repeat, went silent… */
  signals?: ("asked-hint" | "asked-repeat" | "long-silence" | "asked-slower" | "asked-skip")[];
}

/** Working memory the agent keeps about the learner during one session. */
export interface AgentMemory {
  exchange: number;
  levelEstimate: Level;
  pace: "slower" | "normal" | "faster";
  /** Short English notes the agent writes for itself (max 8). */
  notes: string[];
  weakCategories: { category: string; labelEs: string; count: number }[];
  drilledWords: string[];
  lastCorrectionExchange: number;
  lastDrillExchange: number;
  topicsCovered: string[];
}

export type AgentAction =
  | { type: "say"; text: string; purpose: "reaction" | "question" | "followup" | "closing" | "encouragement" }
  | { type: "correct"; correctionId: string }
  | { type: "drill"; word: string; reasonEs: string; measured: boolean }
  | { type: "hint" }
  | { type: "adjust"; level?: Level; pace?: "slower" | "normal" | "faster"; reasonEs: string };

export interface AgentDecision {
  actions: AgentAction[];
  /** Analysis of the latest utterance. Always returned (fluent mode keeps them for the end). */
  corrections: Correction[];
  /** Dictionary tips for risky words in the utterance (not measured). */
  pronunciationTips: PronunciationTip[];
  /** Hint for the question asked in this decision. */
  hint?: Hint;
  memory: AgentMemory;
  done: boolean;
  provider: string;
  model?: string;
  /** true when the AI agent failed and the rule-based backup answered instead. */
  fallbackUsed: boolean;
  /** Opaque state the rule-based backup needs back. */
  engineState?: string;
}

export interface PhonemeScore {
  phoneme: string;
  accuracy: number;
}

export type WordErrorType =
  | "None"
  | "Omission"
  | "Insertion"
  | "Mispronunciation"
  | "UnexpectedBreak"
  | "MissingBreak"
  | "Monotone"
  | "NotRecognized";

export interface WordAssessment {
  word: string;
  accuracy?: number;
  errorType?: WordErrorType;
  phonemes?: PhonemeScore[];
}

export interface ProblemWord {
  word: string;
  accuracy?: number;
  worstPhoneme?: PhonemeScore;
  /** Spanish advice: from the phoneme map (measured) or the dictionary (not measured). */
  adviceEs: string;
  tip: PronunciationTip | null;
  reasonEs: string;
  measured: boolean;
}

export interface PronunciationAssessment {
  /** true only when an acoustic engine scored the audio itself. */
  measured: boolean;
  provider: "azure" | "transcript";
  referenceText: string;
  recognizedText?: string;
  scores?: {
    accuracy?: number;
    fluency?: number;
    completeness?: number;
    prosody?: number;
    overall?: number;
  };
  words: WordAssessment[];
  problemWords: ProblemWord[];
  /** Spanish notes shown to the learner, including honesty disclaimers. */
  notes: string[];
}

export interface SessionLimits {
  maxMinutes: number;
  maxTurns: number;
  maxAssessments: number;
  maxTtsChars: number;
  maxAnswerSeconds: number;
  maxSessionsPerDay: number;
}

export interface PublicConfig {
  /** live=false means no LLM is configured: only the rule-based backup (no AI) is available. */
  agent: { provider: "groq" | "openai" | "anthropic" | "offline"; live: boolean; model?: string };
  stt: { provider: "browser" | "groq" | "openai" };
  tts: { provider: "browser" | "azure" | "openai" };
  pronunciation: { provider: "transcript" | "azure"; measured: boolean };
  limits: SessionLimits;
}

export interface SessionStart {
  token: string;
  expiresAt: number;
  limits: SessionLimits;
}

export interface Exercise {
  kind: "say" | "fix" | "create";
  promptEs: string;
  /** For "fix": the sentence with the mistake. */
  wrong?: string;
  /** English target sentence (answer / model to say). */
  target: string;
}

export interface ErrorGroup {
  category: string;
  labelEs: string;
  type: CorrectionType;
  count: number;
  score: number;
  explanationEs: string;
  examples: { original: string; corrected: string }[];
}

export interface TopError extends ErrorGroup {
  exercises: Exercise[];
}

export interface SummaryPronItem {
  word: string;
  measured: boolean;
  accuracy?: number;
  adviceEs: string;
  tip: PronunciationTip | null;
}

export interface SessionStats {
  turns: number;
  userWords: number;
  speakingSeconds: number;
  wordsPerMinute: number;
  corrections: number;
}

export interface SessionSummary {
  topErrors: TopError[];
  pronunciation: SummaryPronItem[];
  stats: SessionStats;
  closingEs: string;
  provider: string;
}

export interface ApiErrorBody {
  error: string;
  code:
    | "bad_request"
    | "no_session"
    | "session_expired"
    | "limit_turns"
    | "limit_tts"
    | "limit_assessments"
    | "limit_audio"
    | "limit_daily"
    | "not_configured"
    | "provider_error";
  messageEs: string;
}
