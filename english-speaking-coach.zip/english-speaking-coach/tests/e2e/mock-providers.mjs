// Local stand-ins for Groq (OpenAI-compatible chat + Whisper) and Azure Speech,
// so the real provider code paths can be tested end to end without API keys.
// NOT used by the app in normal operation.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const silentMp3 = fs.readFileSync(path.join(here, "fixtures/silence.mp3"));
export const log = [];

const QUESTIONS = [
  "Great to meet you. To start, could you tell me a little about yourself and your background?",
  "Interesting. Tell me about a technical project you're proud of. What was your role?",
  "How would you explain a machine learning model to a client with no technical background?",
  "Tell me about a time you disagreed with a teammate. How did you handle it?",
];

const RULES = [
  [/\bI have (\w+) years working\b/i, (m) => `I have been working for ${m[1]} years`, "present-perfect-duration", "Duración con present perfect", "Para algo que sigue en el presente usa «have been + -ing» con «for»."],
  [/\bis very important\b/i, () => "it is very important", "missing-subject", "Sujeto obligatorio", "En inglés siempre va el sujeto: «it is»."],
  [/\bexplain me\b/i, () => "explain to me", "explain-to-me", "explain to me", "Después de «explain» va «to»."],
  [/\bI realized (\w+) tests\b/i, (m) => `I carried out ${m[1]} tests`, "false-friend-realize", "Falso amigo: realize", "«Realize» es darse cuenta; realizar es «carry out»."],
];

const DRILL_WORDS = ["develop", "three", "python", "engineer", "studied", "algorithm"];

function agentReply(payload) {
  const obs = payload.OBSERVATION;
  const mem = payload.MEMORY;
  if (obs.kind === "start") {
    return {
      corrections: [],
      actions: [
        { type: "say", purpose: "reaction", text: "Hi! I'm Maya, your AI interviewer for the AI Engineer role." },
        { type: "say", purpose: "question", text: "Before we begin, how are you feeling today?" },
      ],
      hint: { es: "Di cómo te sientes y agradece la oportunidad.", starter: "I'm feeling good, thank you for having me." },
      memory: { notes: [], levelEstimate: "B1", topicsCovered: [] },
      done: false,
    };
  }
  const text = obs.userText ?? "";
  const corrections = [];
  for (const [re, fix, category, label, expl] of RULES) {
    const m = text.match(re);
    if (m) corrections.push({ original: m[0], corrected: fix(m), type: "grammar", category, categoryLabelEs: label, explanationEs: expl, spokenTip: `Say "${fix(m)}" instead of "${m[0]}".`, severity: 3 });
  }
  const actions = [{ type: "say", purpose: "reaction", text: text ? `Thanks. I noted what you said about ${text.split(" ").slice(-3).join(" ")}.` : "No worries." }];
  if (corrections.length) actions.push({ type: "correct", index: 0 });
  const measured = obs.pronunciation?.measured ? obs.pronunciation.problemWords.map((p) => p.word) : [];
  const drill = measured[0] ?? DRILL_WORDS.find((w) => text.toLowerCase().includes(w));
  if (drill) actions.push({ type: "drill", word: drill, reasonEs: "Práctica." });
  if ((obs.signals ?? []).includes("long-silence")) actions.push({ type: "adjust", pace: "slower", reasonEs: "Te noté con pausas largas: hablaré más despacio." });
  const done = mem.exchange >= 4;
  actions.push(done ? { type: "say", purpose: "closing", text: "That's all for today. You did great. Let's review your feedback." } : { type: "say", purpose: "question", text: QUESTIONS[(mem.exchange - 1) % QUESTIONS.length] });
  return {
    corrections,
    actions,
    hint: { es: "Responde con un ejemplo concreto.", starter: "For example, in my last job…" },
    memory: { notes: [...mem.notes, `said: ${text.slice(0, 40)}`].slice(-8), levelEstimate: "B1", topicsCovered: [] },
    done,
  };
}

function summaryReply(payload) {
  return {
    groups: payload.errorGroups.map((g) => ({
      category: g.category,
      explanationEs: `Regla explicada por la IA para ${g.label}.`,
      exercises: [
        { kind: "say", promptEs: "Dilo en voz alta.", target: g.examples[0]?.corrected ?? "I have been working here for two years." },
        { kind: "fix", promptEs: "Corrige la frase.", wrong: g.examples[0]?.original ?? "x", target: g.examples[0]?.corrected ?? "y" },
        { kind: "create", promptEs: "Crea tu propia frase.", target: "I have been studying AI for a year." },
      ],
    })),
    closingEs: "Resumen generado por el agente de IA simulado: buen ritmo, cuida la duración con present perfect.",
  };
}

const drillAttempts = new Map();
function azureAssessment(params) {
  const ref = params.ReferenceText;
  const words = ref.split(/\s+/).filter(Boolean);
  const single = words.length === 1;
  let wordScore = (w) => (/^(three|develop|python)$/i.test(w) ? 55 : 93);
  if (single) {
    const n = (drillAttempts.get(ref) ?? 0) + 1;
    drillAttempts.set(ref, n);
    wordScore = () => (n === 1 ? 62 : 88);
  }
  const Words = words.map((w) => {
    const acc = wordScore(w);
    return {
      Word: w.toLowerCase(),
      PronunciationAssessment: { AccuracyScore: acc, ErrorType: acc < 60 ? "Mispronunciation" : "None" },
      Phonemes: [
        { Phoneme: /^th/i.test(w) ? "θ" : "ɪ", PronunciationAssessment: { AccuracyScore: acc < 70 ? 35 : 95 } },
        { Phoneme: "v", PronunciationAssessment: { AccuracyScore: acc < 70 ? 58 : 96 } },
      ],
    };
  });
  const avg = Words.reduce((s, w) => s + w.PronunciationAssessment.AccuracyScore, 0) / Words.length;
  return {
    RecognitionStatus: "Success",
    DisplayText: ref,
    NBest: [
      {
        Lexical: ref.toLowerCase(),
        PronunciationAssessment: { AccuracyScore: avg, FluencyScore: 72, CompletenessScore: 100, ProsodyScore: 66, PronScore: Math.round(avg * 0.95) },
        Words,
      },
    ],
  };
}

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
  });
}

export function startMockProviders(port = 4010) {
  const server = http.createServer(async (req, res) => {
    const body = await readBody(req);
    const url = req.url ?? "";
    const send = (code, obj, type = "application/json") => {
      res.writeHead(code, { "Content-Type": type });
      res.end(type === "application/json" ? JSON.stringify(obj) : obj);
    };
    try {
      if (url.startsWith("/v1/chat/completions")) {
        if (req.headers.authorization !== "Bearer mock-key") return send(401, { error: "bad key" });
        const j = JSON.parse(body.toString());
        log.push({ kind: "chat", json: j.response_format?.type, model: j.model });
        const last = j.messages[j.messages.length - 1].content;
        const payload = JSON.parse(last);
        const out = payload.errorGroups ? summaryReply(payload) : agentReply(payload);
        return send(200, { choices: [{ message: { content: JSON.stringify(out) } }] });
      }
      if (url.startsWith("/v1/audio/transcriptions")) {
        log.push({ kind: "stt", bytes: body.length });
        return send(200, { text: "I have three years working as a technician and I develop tools in Python." });
      }
      if (url.startsWith("/stt/speech/recognition/conversation/cognitiveservices/v1")) {
        if (req.headers["ocp-apim-subscription-key"] !== "mock-azure") return send(401, { error: "bad key" });
        const params = JSON.parse(Buffer.from(String(req.headers["pronunciation-assessment"]), "base64").toString());
        const isWav = body.subarray(0, 4).toString() === "RIFF";
        log.push({ kind: "azure-pa", ref: params.ReferenceText, bytes: body.length, isWav, miscue: params.EnableMiscue });
        if (!isWav) return send(400, { error: "not wav" });
        return send(200, azureAssessment(params));
      }
      if (url.startsWith("/tts/cognitiveservices/v1")) {
        log.push({ kind: "azure-tts", ssml: body.toString().slice(0, 200) });
        return send(200, silentMp3, "audio/mpeg");
      }
      if (url === "/log") return send(200, log);
      send(404, { error: "not found" });
    } catch (e) {
      send(500, { error: String(e) });
    }
  });
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  startMockProviders(Number(process.env.PORT ?? 4010)).then(() => console.log("mock providers on", process.env.PORT ?? 4010));
}
