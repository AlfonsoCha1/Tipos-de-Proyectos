// End-to-end test in a real Chromium with a fake microphone.
// Usage: npm run build && npm run test:e2e
// Runs: (A) offline backup, (B) AI agent + Azure (mocked HTTP), (C) real mic capture + VAD +
// server Whisper (mocked HTTP), (D) barge-in with a real audio signal.
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";
import { startMockProviders, log as mockLog } from "./mock-providers.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const out = path.join(here, "output");
fs.mkdirSync(out, { recursive: true });
const audio = path.join(here, "fixtures/speech-bursts.wav");
const executablePath = process.env.CHROMIUM_PATH ?? (fs.existsSync("/opt/pw-browsers/chromium-1194/chrome-linux/chrome") ? "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" : undefined);

let failures = 0;
let currentPage = null;
function check(cond, msg) {
  if (cond) console.log(`  ✓ ${msg}`);
  else {
    failures++;
    console.log(`  ✗ ${msg}`);
  }
}

function startNext(port, extraEnv) {
  const env = { ...process.env, PORT: String(port), ALLOW_TEST_MODE: "1", LIMIT_SESSIONS_PER_IP_PER_DAY: "100", NEXT_TELEMETRY_DISABLED: "1" };
  for (const k of ["GROQ_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "AZURE_SPEECH_KEY", "AZURE_SPEECH_REGION", "AZURE_SPEECH_ENDPOINT", "STT_PROVIDER", "TTS_PROVIDER"]) delete env[k];
  Object.assign(env, extraEnv);
  const proc = spawn("npx", ["next", "start", "-p", String(port)], { cwd: root, env, stdio: ["ignore", "pipe", "pipe"], detached: true });
  let logs = "";
  proc.stdout.on("data", (d) => (logs += d));
  proc.stderr.on("data", (d) => (logs += d));
  return {
    proc,
    logs: () => logs,
    ready: (async () => {
      for (let i = 0; i < 60; i++) {
        try {
          const r = await fetch(`http://127.0.0.1:${port}/api/config`);
          if (r.ok) return;
        } catch {}
        await new Promise((r) => setTimeout(r, 500));
      }
      throw new Error(`next on ${port} did not start\n${logs}`);
    })(),
  };
}

const hooks = {
  waitListening: (page, timeout = 25000) => page.waitForFunction(() => window.__escTest?.pending != null, null, { timeout }),
  async say(page, text) {
    await hooks.waitListening(page);
    await page.evaluate((t) => window.__escTest.say(t), text);
  },
  async silence(page) {
    await hooks.waitListening(page);
    await page.evaluate(() => window.__escTest.silence());
  },
  spoken: (page) => page.evaluate(() => window.__escTest.spoken),
};

async function newPage(browser, settings) {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, permissions: ["microphone"] });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  // Google Fonts can't be reached from the test sandbox; that's not an app error.
  page.on("console", (m) => m.type() === "error" && !m.text().includes("ERR_TUNNEL_CONNECTION_FAILED") && errors.push(m.text()));
  page.on("response", (r) => r.status() === 404 && errors.push(`404 ${r.url()}`));
  currentPage = page;
  if (settings) await page.addInitScript((s) => localStorage.setItem("esc.settings.v1", JSON.stringify(s)), settings);
  return { page, context, errors };
}

async function startPractice(page) {
  await page.getByRole("button", { name: "Empezar a hablar" }).click();
  await page.getByRole("button", { name: "Permitir micrófono y empezar" }).click();
}

async function answerUntilSummary(page, answers) {
  let i = 0;
  for (let guard = 0; guard < 25; guard++) {
    if (await page.getByTestId("summary").isVisible().catch(() => false)) return true;
    try {
      await hooks.waitListening(page, 8000);
    } catch {
      continue;
    }
    const drillListening = await page.evaluate(() => document.querySelector('[data-testid="drill"] .field-note')?.textContent?.includes("Tu turno"));
    if (drillListening) {
      const word = await page.evaluate(() => document.querySelector('[data-testid="drill"]')?.getAttribute("aria-label")?.split(" ").pop());
      await page.evaluate((w) => window.__escTest.say(w), word);
    } else {
      await page.evaluate((t) => window.__escTest.say(t), answers[i++ % answers.length]);
    }
  }
  return page.getByTestId("summary").isVisible();
}

const BASE = { scenario: "interview", level: "B1", role: "software", length: "short", spokenSpanishTips: true };

async function scenarioA(browser) {
  console.log("\nA) Offline backup (no AI key), teacher mode, full interview flow");
  const { page, context, errors } = await newPage(browser, { ...BASE, correctionMode: "teacher", bargeIn: false });
  await page.goto("http://127.0.0.1:3201/?test=1");
  await page.getByRole("button", { name: "Empezar a hablar" }).waitFor();
  await page.waitForFunction(() => document.body.innerText.includes("Sin IA"));
  await page.screenshot({ path: path.join(out, "A1-home.png") });
  await page.screenshot({ path: path.join(out, "A1-home-full.png"), fullPage: true });
  await page.getByRole("button", { name: "Empezar a hablar" }).click();
  await page.getByRole("button", { name: "Permitir micrófono y empezar" }).waitFor();
  await page.screenshot({ path: path.join(out, "A2-consent.png"), fullPage: true });
  await page.getByRole("button", { name: "Permitir micrófono y empezar" }).click();

  await hooks.waitListening(page);
  let spoken = await hooks.spoken(page);
  check(spoken[0]?.text.includes("interviewer"), "coach greets out loud");
  check((await page.getByTestId("status").textContent()).includes("Te escucho"), "status shows listening");

  await hooks.silence(page);
  await page.getByTestId("hint").first().waitFor();
  await hooks.waitListening(page);
  spoken = await hooks.spoken(page);
  check(spoken.some((s) => s.lang === "es"), "silence → hint spoken in Spanish");
  check(spoken.some((s) => s.text.startsWith("You could start with")), "hint includes an English starter");

  const before = (await hooks.spoken(page)).length;
  await hooks.say(page, "can you repeat please");
  await hooks.waitListening(page);
  spoken = await hooks.spoken(page);
  check(spoken.slice(before).some((s) => s.text.includes("How are you")), "'repeat' command → question repeated");

  await hooks.say(page, "I'm fine thanks, a little nervous");
  await hooks.say(page, "I studied the career of computer systems and I have three years working as a technician");
  await page.getByTestId("correction").first().waitFor();
  const fixes = await page.getByTestId("correction").allTextContents();
  check(fixes.some((f) => f.includes("I have been working for three years")), "correction card: present perfect duration");
  await page.getByTestId("drill").first().waitFor();
  spoken = await hooks.spoken(page);
  check(spoken.some((s) => s.text.startsWith("Instead of")), "teacher mode speaks one correction");
  check(spoken.some((s) => s.slow), "drill plays the word slowly");
  await hooks.waitListening(page);
  await page.screenshot({ path: path.join(out, "A3-correction-drill.png") });
  const word = await page.evaluate(() => document.querySelector('[data-testid="drill"]')?.getAttribute("aria-label")?.split(" ").pop());
  await page.evaluate((w) => window.__escTest.say(w), word);
  await page.waitForFunction(() => document.querySelector('[data-testid="drill"]')?.textContent?.includes("Intento 1"));
  const drillText = await page.getByTestId("drill").first().textContent();
  check(drillText.includes("no medición"), "drill result is labeled as NOT an acoustic measurement");
  check(drillText.includes("Sugerencia, no medido"), "drill badge says 'not measured'");

  // Manual interruption while the coach talks.
  await hooks.waitListening(page);
  await page.evaluate(() => (window.__escTest.ttsMs = 4000));
  await page.evaluate(() => window.__escTest.say("I like to automate tests with Python because is very important for quality"));
  await page.getByRole("button", { name: "Interrumpir" }).waitFor({ timeout: 10000 });
  await page.getByRole("button", { name: "Interrumpir" }).click();
  await hooks.waitListening(page, 6000);
  check(true, "tapping 'Interrumpir' stops the coach and listens");
  await page.evaluate(() => (window.__escTest.ttsMs = 120));
  const unspoken = await page.locator(".msg.coach.unspoken").count();
  check(unspoken >= 1, "the interrupted question is shown on screen");
  await page.screenshot({ path: path.join(out, "A4-interrupted.png") });

  const done = await answerUntilSummary(page, [
    "I am agree with the plan, and my team is very good",
    "In three years I want to be a machine learning engineer",
    "I depend of my manager for the priorities",
  ]);
  check(done, "session ends with a summary");
  await page.screenshot({ path: path.join(out, "A5-summary.png"), fullPage: true });
  const top = await page.getByTestId("top-error").count();
  check(top >= 2 && top <= 3, `summary shows top errors (${top})`);
  await page.getByRole("button", { name: "Grabar mi intento" }).first().click();
  await hooks.waitListening(page);
  const target = await page.locator(".exercise .target").first().textContent();
  await page.evaluate((t) => window.__escTest.say(t), target);
  await page.getByTestId("practice-result").first().waitFor();
  const pr = await page.getByTestId("practice-result").first().textContent();
  check(pr.includes("Bien"), "summary exercise: attempt evaluated");
  check(errors.length === 0, `no page errors (${errors.join(" | ").slice(0, 300)})`);
  await context.close();
}

async function scenarioB(browser) {
  console.log("\nB) AI agent (Groq API shape) + Azure pronunciation (mocked HTTP), teacher mode");
  const { page, context, errors } = await newPage(browser, { ...BASE, role: "ai", correctionMode: "teacher", bargeIn: false });
  await page.goto("http://127.0.0.1:3202/?test=1");
  await page.waitForFunction(() => document.body.innerText.includes("Agente IA (Groq)"));
  await page.screenshot({ path: path.join(out, "B1-home-ai.png"), fullPage: true });
  await startPractice(page);
  await hooks.waitListening(page);
  const spoken = await hooks.spoken(page);
  check(spoken.some((s) => s.text.includes("Maya")), "greeting comes from the AI agent");
  check((await page.locator(".pill").first().textContent()) === "IA", "session shows the AI agent is answering");

  await hooks.say(page, "I'm feeling good");
  await hooks.say(page, "I have three years working in testing and I develop tools in Python");
  await page.getByTestId("drill").first().waitFor({ timeout: 20000 });
  const badge = await page.locator('[data-testid="user-msg"] .badge.measured').last().textContent();
  check(/Pronunciación \d+\/100/.test(badge), `answer scored acoustically (${badge})`);
  const fixes = await page.getByTestId("correction").allTextContents();
  check(fixes.some((f) => f.includes("I have been working for three years")), "AI correction shown");
  const drill = await page.getByTestId("drill").first().textContent();
  check(drill.includes("Medido con audio"), "drill is marked as measured");
  // Two attempts: mock scores 62 then 88.
  const word = await page.evaluate(() => document.querySelector('[data-testid="drill"]')?.getAttribute("aria-label")?.split(" ").pop());
  await hooks.say(page, word);
  await page.waitForFunction(() => document.querySelector('[data-testid="drill"]')?.textContent?.includes("Intento 1: 62/100"));
  await hooks.say(page, word);
  await page.waitForFunction(() => document.querySelector('[data-testid="drill"]')?.textContent?.includes("Intento 2: 88/100"), null, { timeout: 15000 });
  check(true, "drill: first attempt 62/100, retry 88/100");
  await page.screenshot({ path: path.join(out, "B2-measured-drill.png") });
  await page.emulateMedia({ colorScheme: "dark" });
  await page.screenshot({ path: path.join(out, "B2-measured-drill-dark.png") });
  await page.emulateMedia({ colorScheme: "light" });
  const done = await answerUntilSummary(page, ["I realized functional tests every week", "Is very important to explain me the goals", "Thank you"]);
  check(done, "AI session ends with a summary");
  const summaryText = await page.getByTestId("summary").textContent();
  check(summaryText.includes("simulado"), "summary written by the (mocked) AI agent");
  check(summaryText.includes("Medido"), "summary pronunciation list shows measured words");
  await page.screenshot({ path: path.join(out, "B3-summary-ai.png"), fullPage: true });
  const chats = mockLog.filter((l) => l.kind === "chat");
  check(chats.length >= 5 && chats.every((c) => c.json === "json_object"), `LLM called in JSON mode (${chats.length} calls)`);
  const pa = mockLog.filter((l) => l.kind === "azure-pa");
  check(pa.length >= 3 && pa.every((p) => p.isWav), `Azure received WAV audio (${pa.length} assessments)`);
  check(errors.length === 0, `no page errors (${errors.join(" | ").slice(0, 300)})`);
  await context.close();
}

async function scenarioC(browser) {
  console.log("\nC) Real mic capture → VAD end-of-turn → server Whisper (mocked), fluent mode");
  const { page, context, errors } = await newPage(browser, { ...BASE, correctionMode: "fluent", bargeIn: false });
  await page.goto("http://127.0.0.1:3202/?test=1&realmic=1");
  await startPractice(page);
  await page.getByTestId("user-msg").first().waitFor({ timeout: 30000 });
  const msg = await page.getByTestId("user-msg").first().textContent();
  check(msg.includes("I have three years working"), "VAD detected the end of speech and Whisper text arrived");
  check(await page.getByRole("button", { name: "Mi grabación" }).first().isVisible(), "'Mi grabación' button to replay my answer");
  check((await page.getByTestId("correction").count()) === 0, "fluent mode: no corrections during the conversation");
  await page.waitForFunction(() => /correcci(ón|ones) guardadas? para el final/.test(document.body.innerText), null, { timeout: 20000 });
  check(true, "fluent mode keeps corrections for the end");
  await page.screenshot({ path: path.join(out, "C1-fluent-realmic.png") });
  await page.getByRole("button", { name: "Terminar" }).click();
  await page.getByTestId("summary").waitFor({ timeout: 20000 });
  const top = await page.getByTestId("top-error").count();
  check(top >= 1, "summary lists the deferred corrections");
  const stt = mockLog.filter((l) => l.kind === "stt");
  check(stt.length >= 1 && stt[0].bytes > 16000, `WAV uploaded for transcription (${stt[0]?.bytes} bytes)`);
  check(errors.length === 0, `no page errors (${errors.join(" | ").slice(0, 300)})`);
  await context.close();
}

async function scenarioD(browser) {
  console.log("\nD) Barge-in: the learner's voice (real audio signal) interrupts the coach");
  const { page, context, errors } = await newPage(browser, { ...BASE, correctionMode: "teacher", bargeIn: true });
  // The coach "talks" for 12 s; the fake mic plays speech bursts every 7 s.
  await page.goto("http://127.0.0.1:3201/?test=1&ttsms=12000");
  await page.getByRole("button", { name: "Empezar a hablar" }).click();
  const t0 = Date.now();
  await page.getByRole("button", { name: "Permitir micrófono y empezar" }).click();
  await hooks.waitListening(page, 20000);
  const elapsed = Date.now() - t0;
  check(elapsed < 12000, `coach stopped when the learner's voice started (${elapsed} ms; full line = 12000 ms)`);
  check(errors.length === 0, `no page errors (${errors.join(" | ").slice(0, 300)})`);
  await context.close();
}

const mock = await startMockProviders(4010);
const offline = startNext(3201, {});
const live = startNext(3202, {
  GROQ_API_KEY: "mock-key",
  GROQ_BASE_URL: "http://127.0.0.1:4010/v1",
  AZURE_SPEECH_KEY: "mock-azure",
  AZURE_SPEECH_ENDPOINT: "http://127.0.0.1:4010",
  TTS_PROVIDER: "azure",
  STT_PROVIDER: "groq",
});
let browser;
try {
  await Promise.all([offline.ready, live.ready]);
  browser = await chromium.launch({
    executablePath,
    args: [
      "--use-fake-ui-for-media-stream",
      "--use-fake-device-for-media-stream",
      `--use-file-for-fake-audio-capture=${audio}`,
      "--autoplay-policy=no-user-gesture-required",
    ],
  });
  const only = process.argv[2];
  for (const [name, fn] of [["A", scenarioA], ["B", scenarioB], ["C", scenarioC], ["D", scenarioD]]) {
    if (only && !only.includes(name)) continue;
    try {
      await fn(browser);
    } catch (e) {
      failures++;
      console.log(`  ✗ scenario ${name} crashed: ${e.message.split("\n")[0]}`);
      if (currentPage) {
        await currentPage.screenshot({ path: path.join(out, `${name}-crash.png`), fullPage: true }).catch(() => {});
        const dump = await currentPage.evaluate(() => ({ status: document.querySelector('[data-testid="status"]')?.textContent, spoken: window.__escTest?.spoken?.map((s) => s.text), pending: !!window.__escTest?.pending, feed: document.querySelector(".feed")?.innerText })).catch(() => null);
        console.log(JSON.stringify(dump, null, 1).slice(0, 3000));
      }
    }
  }
} finally {
  await browser?.close();
  for (const p of [offline.proc, live.proc]) {
    try {
      process.kill(-p.pid, "SIGTERM");
    } catch {}
  }
  mock.close();
  fs.writeFileSync(path.join(out, "server-offline.log"), offline.logs());
  fs.writeFileSync(path.join(out, "server-live.log"), live.logs());
}
console.log(failures ? `\n${failures} check(s) failed` : "\nAll e2e checks passed");
process.exit(failures ? 1 : 0);
