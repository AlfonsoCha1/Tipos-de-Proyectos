import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { runAgent, summarize } from "@/lib/server/agent";
import { applyPolicy, initialMemory, rawDecisionSchema } from "@/lib/server/agent/policy";
import { DEFAULT_SETTINGS } from "@/lib/shared/scenarios";
import { detectCommand } from "@/lib/shared/text";
import type { AgentDecision, ChatMessage, SessionSettings } from "@/lib/shared/types";

const teacher: SessionSettings = { ...DEFAULT_SETTINGS, correctionMode: "teacher", length: "short" };
const fluent: SessionSettings = { ...teacher, correctionMode: "fluent" };

function clearKeys() {
  for (const k of ["GROQ_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "AGENT_PROVIDER"]) delete process.env[k];
}

describe("voice commands", () => {
  it("detects short control phrases only", () => {
    expect(detectCommand("can you repeat please")).toBe("repeat");
    expect(detectCommand("no sé")).toBe("hint");
    expect(detectCommand("I don't know")).toBe("hint");
    expect(detectCommand("next question")).toBe("skip");
    expect(detectCommand("slower please")).toBe("slower");
    expect(detectCommand("let's end the interview")).toBe("end");
    expect(detectCommand("I don't know exactly how many years but I worked at a bank for a long time")).toBeNull();
  });
});

describe("policy enforces the product rules whatever the LLM says", () => {
  const raw = rawDecisionSchema.parse({
    corrections: [],
    actions: [
      { type: "say", purpose: "question", text: "First question?" },
      { type: "correct", index: 0 },
      { type: "drill", word: "develop", reasonEs: "x" },
      { type: "drill", word: "python", reasonEs: "x" },
      { type: "say", purpose: "reaction", text: "Nice." },
      { type: "say", purpose: "question", text: "Second question?" },
    ],
    done: false,
  });
  const correction = {
    id: "c1-0", category: "x", categoryLabelEs: "x", type: "grammar" as const, original: "I have 3 years working",
    corrected: "I have been working for 3 years", explanationEs: "x", spokenTip: "x", severity: 3 as const, source: "llm" as const,
  };
  const observation = { kind: "answer" as const, userText: "I have 3 years working and I develop apps in python" };

  it("teacher: orders actions, one correction, one drill, one final question", () => {
    const d = applyPolicy({
      settings: teacher, observation, memory: { ...initialMemory(teacher), exchange: 2 }, raw,
      corrections: [correction], riskyWords: [], provider: "test",
    });
    expect(d.actions.map((a) => a.type)).toEqual(["say", "correct", "drill", "say"]);
    expect(d.actions[0]).toMatchObject({ purpose: "reaction" });
    expect(d.actions[3]).toMatchObject({ purpose: "question", text: "Second question?" });
    const drill = d.actions[2];
    expect(drill).toMatchObject({ type: "drill", word: "develop", measured: false });
    expect(d.memory.drilledWords).toContain("develop");
  });

  it("fluent: never corrects or drills mid-conversation but keeps corrections", () => {
    const d = applyPolicy({
      settings: fluent, observation, memory: { ...initialMemory(fluent), exchange: 2 }, raw,
      corrections: [correction], riskyWords: [], provider: "test",
    });
    expect(d.actions.map((a) => a.type)).toEqual(["say", "say"]);
    expect(d.corrections).toHaveLength(1);
  });

  it("does not correct every sentence (cooldown) unless severe", () => {
    const mild = { ...correction, severity: 2 as const };
    const d = applyPolicy({
      settings: teacher, observation, memory: { ...initialMemory(teacher), exchange: 3, lastCorrectionExchange: 2 }, raw,
      corrections: [mild], riskyWords: [], provider: "test",
    });
    expect(d.actions.some((a) => a.type === "correct")).toBe(false);
  });

  it("refuses drills on words the learner never said", () => {
    const r = rawDecisionSchema.parse({ actions: [{ type: "drill", word: "algorithm" }, { type: "say", purpose: "question", text: "Q?" }] });
    const d = applyPolicy({
      settings: teacher, observation, memory: { ...initialMemory(teacher), exchange: 2 }, raw: r,
      corrections: [], riskyWords: [], provider: "test",
    });
    expect(d.actions.some((a) => a.type === "drill")).toBe(false);
  });

  it("marks drills as measured only with acoustic evidence", () => {
    const r = rawDecisionSchema.parse({ actions: [{ type: "drill", word: "three" }, { type: "say", purpose: "question", text: "Q?" }] });
    const d = applyPolicy({
      settings: teacher,
      observation: {
        kind: "answer", userText: "three years",
        pronunciation: { measured: true, problemWords: [{ word: "three", accuracy: 48 }] },
      },
      memory: { ...initialMemory(teacher), exchange: 2 }, raw: r, corrections: [], riskyWords: [], provider: "test",
    });
    expect(d.actions.find((a) => a.type === "drill")).toMatchObject({ measured: true });
  });

  it("adds a question when the model forgets one and closes when done", () => {
    const r = rawDecisionSchema.parse({ actions: [{ type: "say", purpose: "reaction", text: "Ok." }] });
    const d = applyPolicy({ settings: teacher, observation, memory: initialMemory(teacher), raw: r, corrections: [], riskyWords: [], provider: "t" });
    expect(d.actions.at(-1)).toMatchObject({ type: "say", purpose: "followup" });
    const done = applyPolicy({ settings: teacher, observation, memory: initialMemory(teacher), raw: { ...r, done: true }, corrections: [], riskyWords: [], provider: "t" });
    expect(done.done).toBe(true);
    expect(done.actions.at(-1)).toMatchObject({ purpose: "closing" });
  });
});

describe("offline backup (no LLM key)", () => {
  beforeEach(clearKeys);

  it("runs a complete short interview and reports it is not the AI agent", async () => {
    const history: ChatMessage[] = [];
    let memory = null as AgentDecision["memory"] | null;
    let engineState: string | undefined;
    let d = await runAgent({ settings: teacher, history, observation: { kind: "start" }, memory, engineState });
    expect(d.provider).toBe("offline");
    expect(d.fallbackUsed).toBe(false);
    const answers = [
      "I'm fine thanks, a little nervous",
      "I studied the career of computer systems and I have three years working as a technician",
      "I realized functional tests and I developed a small database in Python for my team",
      "Is very important to communicate, so I talked with him and we agreed on a plan",
      "no more questions thank you",
      "thanks",
      "bye",
    ];
    let turns = 0;
    const said: string[] = [];
    for (const a of answers) {
      history.push({ role: "coach", text: d.actions.filter((x) => x.type === "say").map((x) => (x as { text: string }).text).join(" ") });
      history.push({ role: "user", text: a });
      memory = d.memory;
      engineState = d.engineState;
      d = await runAgent({ settings: teacher, history, observation: { kind: "answer", userText: a }, memory, engineState });
      turns++;
      said.push(...d.actions.map((x) => x.type));
      if (d.done) break;
    }
    expect(d.done).toBe(true);
    expect(turns).toBeLessThanOrEqual(7);
    expect(said).toContain("correct");
    expect(said).toContain("drill");
    expect(d.actions.at(-1)).toMatchObject({ purpose: "closing" });
  });
});

describe("AI agent over an OpenAI-compatible API (mocked HTTP)", () => {
  let calls: { url: string; body: Record<string, unknown>; headers: Record<string, string> }[] = [];
  beforeEach(() => {
    clearKeys();
    process.env.GROQ_API_KEY = "test-key";
    calls = [];
    vi.stubGlobal("fetch", async (url: string, init: RequestInit) => {
      calls.push({ url, body: JSON.parse(String(init.body)), headers: init.headers as Record<string, string> });
      return new Response(
        JSON.stringify({
          choices: [
            {
              message: {
                content: JSON.stringify({
                  corrections: [
                    {
                      original: "I have three years working", corrected: "I have been working for three years",
                      type: "grammar", category: "present-perfect-duration", categoryLabelEs: "Duración",
                      explanationEs: "Usa present perfect continuo.", spokenTip: "Say: I have been working for three years.", severity: 3,
                    },
                    { original: "something I never said", corrected: "x", type: "grammar", category: "x", severity: 3 },
                  ],
                  actions: [
                    { type: "say", purpose: "reaction", text: "Three years in testing is solid experience." },
                    { type: "correct", index: 0 },
                    { type: "say", purpose: "question", text: "What kind of boards did you test?" },
                  ],
                  hint: { es: "Describe los equipos.", starter: "I tested boards for…" },
                  memory: { notes: ["Works in electronics testing"], levelEstimate: "B1", topicsCovered: ["background"] },
                  done: false,
                }),
              },
            },
          ],
        }),
        { status: 200 },
      );
    });
  });
  afterEach(() => vi.unstubAllGlobals());

  it("sends a JSON-mode request with the key server-side and applies the policy", async () => {
    const d = await runAgent({
      settings: teacher,
      history: [{ role: "coach", text: "Tell me about yourself." }, { role: "user", text: "I have three years working in testing" }],
      observation: { kind: "answer", userText: "I have three years working in testing" },
      memory: { ...initialMemory(teacher), exchange: 1 },
    });
    expect(calls[0].url).toBe("https://api.groq.com/openai/v1/chat/completions");
    expect(calls[0].headers.Authorization).toBe("Bearer test-key");
    expect(calls[0].body.response_format).toEqual({ type: "json_object" });
    expect(d.provider).toBe("groq");
    expect(d.corrections).toHaveLength(1); // the invented quote was dropped
    expect(d.actions.map((a) => a.type)).toEqual(["say", "correct", "say"]);
    expect(d.memory.notes).toEqual(["Works in electronics testing"]);
    expect(d.memory.weakCategories[0]).toMatchObject({ category: "present-perfect-duration", count: 1 });
    expect(d.hint?.starter).toContain("I tested");
  });

  it("falls back to the offline backup when the LLM errors, and says so", async () => {
    vi.stubGlobal("fetch", async () => new Response("rate limited", { status: 429 }));
    const d = await runAgent({ settings: teacher, history: [], observation: { kind: "start" }, memory: null });
    expect(d.provider).toBe("offline");
    expect(d.fallbackUsed).toBe(true);
    expect(d.actions.at(-1)?.type).toBe("say");
  });

  it("summary ranks real errors and uses rule exercises when the LLM fails", async () => {
    vi.stubGlobal("fetch", async () => new Response("down", { status: 500 }));
    const c = (category: string, severity: 1 | 2 | 3) => ({
      id: Math.random().toString(), category, categoryLabelEs: category, type: "grammar" as const,
      original: `o-${category}`, corrected: `c-${category}`, explanationEs: "e", spokenTip: "s", severity, source: "rules" as const,
    });
    const s = await summarize({
      settings: teacher,
      corrections: [c("age-have-years", 3), c("i-agree", 2), c("i-agree", 2), c("depend-on", 1), c("people-are", 2)],
      pronunciation: [],
      stats: { turns: 4, userWords: 120, speakingSeconds: 60, wordsPerMinute: 120, corrections: 5 },
      memory: null,
    });
    expect(s.topErrors.map((t) => t.category)).toEqual(["i-agree", "age-have-years", "people-are"]);
    expect(s.topErrors[0].exercises).toHaveLength(3);
  });
});
