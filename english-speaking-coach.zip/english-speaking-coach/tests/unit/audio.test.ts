import { describe, expect, it } from "vitest";
import { BargeInDetector, Vad } from "@/lib/client/audio/vad";
import { encodeWav, resample, toWav16k } from "@/lib/client/audio/wav";
import { wavDurationSec } from "@/lib/server/http";

const FRAME = 20;

function feed(vad: Vad, db: number, ms: number) {
  const events: string[] = [];
  for (let t = 0; t < ms; t += FRAME) {
    const e = vad.push(db, FRAME);
    if (e) events.push(e);
  }
  return events;
}

describe("VAD end-of-turn detection", () => {
  const opts = { silenceMs: 1200, minSpeechMs: 160, thresholdDb: 12, absoluteMinDb: -55 };

  it("detects start and end of speech with a pause tolerance", () => {
    const vad = new Vad(opts);
    expect(feed(vad, -65, 1000)).toEqual([]); // room noise
    expect(feed(vad, -30, 1500)).toEqual(["speech-start"]);
    expect(feed(vad, -64, 600)).toEqual([]); // short pause mid-sentence: not the end
    expect(feed(vad, -32, 800)).toEqual([]);
    expect(feed(vad, -64, 1300)).toEqual(["speech-end"]);
  });

  it("ignores clicks shorter than minSpeechMs", () => {
    const vad = new Vad(opts);
    feed(vad, -65, 500);
    expect(feed(vad, -20, 60)).toEqual([]);
    expect(feed(vad, -65, 500)).toEqual([]);
    expect(vad.hasSpoken).toBe(false);
  });

  it("adapts to a noisy room", () => {
    const vad = new Vad(opts);
    feed(vad, -40, 3000); // noisy background (fan, street)
    expect(vad.noiseFloorDb).toBeGreaterThan(-45);
    expect(feed(vad, -36, 1000)).toEqual([]); // a bit louder than noise is not speech
    expect(feed(vad, -20, 400)).toEqual(["speech-start"]);
  });
});

describe("barge-in detector", () => {
  it("ignores the coach's own echo but triggers on a louder learner", () => {
    const b = new BargeInDetector(-60);
    let fired = false;
    for (let t = 0; t < 2000; t += FRAME) fired ||= b.push(-38 + Math.sin(t / 50) * 2, FRAME); // echo
    expect(fired).toBe(false);
    for (let t = 0; t < 400; t += FRAME) fired ||= b.push(-18, FRAME); // learner talks
    expect(fired).toBe(true);
  });
});

describe("WAV encoding", () => {
  it("resamples 48k to 16k and writes a valid header", () => {
    const s = new Float32Array(48000).map((_, i) => Math.sin(i / 10));
    expect(resample(s, 48000, 16000).length).toBe(16000);
    const wav = Buffer.from(toWav16k(s, 48000));
    expect(wav.toString("ascii", 0, 4)).toBe("RIFF");
    expect(wav.readUInt32LE(24)).toBe(16000);
    expect(wavDurationSec(wav)).toBeCloseTo(1, 2);
    expect(wavDurationSec(Buffer.from(encodeWav(new Float32Array(8000), 16000)))).toBeCloseTo(0.5, 2);
  });
});
