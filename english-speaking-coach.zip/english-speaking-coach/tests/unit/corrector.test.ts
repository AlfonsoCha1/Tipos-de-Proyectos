import { describe, expect, it } from "vitest";
import { correctText } from "@/lib/server/offline/corrector";

function fix(text: string) {
  return correctText(text).map((c) => [c.original, c.corrected, c.category]);
}

describe("rule-based corrector (offline backup)", () => {
  it("catches classic Spanish-speaker errors", () => {
    expect(fix("I have 28 years and I live in Mexico")[0]).toEqual(["I have 28 years", "I am 28 years old", "age-have-years"]);
    expect(fix("I have three years working as a technician")[0]).toEqual([
      "I have three years working",
      "I have been working for three years",
      "present-perfect-duration",
    ]);
    expect(fix("i am agree with you")[0][1]).toBe("I agree");
    expect(fix("can you explain me the process")[0][1]).toBe("explain to me");
    expect(fix("the people is very nice")[0][1]).toBe("people are");
    expect(fix("I worked there since two years")[0][1]).toBe("for two years");
    expect(fix("I didn't went to the office")[0][1]).toBe("didn't go");
    expect(fix("we didn't finished on time")[0][1]).toBe("didn't finish");
    expect(fix("I'm interesting in machine learning")[0][1]).toBe("I'm interested in");
    expect(fix("actually I work at Marelli")[0][1]).toBe("currently I work");
    expect(fix("because is very important to test")[0][1]).toBe("it is very important");
    expect(fix("is important to learn")[0][1]).toBe("it is important");
    expect(fix("I realized functional tests every day")[0][1]).toBe("carried out functional tests");
    expect(fix("I studied the career of computer systems")[0][1]).toBe("studied");
    expect(fix("I can to start next month")[0][1]).toBe("can start");
    expect(fix("my boss wants that I travel")[0][1]).toBe("wants me to travel");
    expect(fix("I look forward to work with you")[0][1]).toBe("look forward to working");
    expect(fix("he said me the results")[0][1]).toBe("told me");
    expect(fix("I received many feedbacks")[0][1]).toBe("feedback");
    expect(fix("I assisted to a conference")[0][1]).toBe("attended a conference");
    expect(fix("I won a lot of experience")).toEqual([]); // "a lot of" in between: not matched on purpose
    expect(fix("I won experience in support")[0][1]).toBe("gained experience");
  });

  it("does not flag correct sentences", () => {
    const correct = [
      "I have 3 years of experience in Python",
      "I have been working here since 2020",
      "I agree with you",
      "It depends on the project",
      "In the last year I learned a lot",
      "People are friendly",
      "I want to grow my career in AI",
      "The job is interesting and I'm interested in it",
      "I didn't know that",
      "It is very important",
      "I actually enjoyed it",
    ];
    for (const s of correct) expect(fix(s), s).toEqual([]);
  });

  it("returns at most three corrections, most severe first", () => {
    const out = correctText("I have 30 years, i am agree, people is nice, explain me, depend of it");
    expect(out.length).toBe(3);
    expect(out[0].severity).toBeGreaterThanOrEqual(out[2].severity);
  });
});
