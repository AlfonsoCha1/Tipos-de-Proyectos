import { describe, expect, it } from "vitest";
import { findRiskyWords, lookupTip, phonemeAdviceEs } from "@/lib/shared/pronunciation";
import {
  azureAssessmentHeader,
  createPronunciationProvider,
  parseAzureResponse,
  trimWav,
} from "@/lib/server/providers/pronunciation";
import { encodeWav } from "@/lib/client/audio/wav";

describe("pronunciation dictionary (not a measurement)", () => {
  it("finds words that are often hard for Spanish speakers", () => {
    const words = findRiskyWords("I develop software with Python and I worked three years").map((t) => t.word);
    expect(words).toEqual(["develop", "with", "python"]);
    expect(lookupTip("develop")?.stress).toBe("de·VEL·op");
    expect(lookupTip("engineer")?.tipEs).toContain("neer");
  });

  it("classifies -ed endings of unknown regular verbs", () => {
    expect(lookupTip("stopped")?.category).toBe("ed-t");
    expect(lookupTip("deployed")?.category).toBe("ed-d");
    expect(lookupTip("migrated")?.category).toBe("ed-id");
    expect(lookupTip("hundred")).toBeNull();
  });

  it("maps IPA and SAPI phonemes to mouth advice", () => {
    expect(phonemeAdviceEs("θ")).toContain("lengua entre los dientes");
    expect(phonemeAdviceEs("th")).toContain("lengua entre los dientes");
    expect(phonemeAdviceEs("v")).toContain("labio");
  });
});

describe("Azure pronunciation assessment", () => {
  it("builds the base64 Pronunciation-Assessment header", () => {
    const json = JSON.parse(Buffer.from(azureAssessmentHeader("develop", true), "base64").toString());
    expect(json).toMatchObject({
      ReferenceText: "develop",
      GradingSystem: "HundredMark",
      Granularity: "Phoneme",
      EnableMiscue: "True",
      EnableProsodyAssessment: "True",
    });
  });

  it("parses the nested response shape and picks the worst phoneme", () => {
    const out = parseAzureResponse(
      {
        RecognitionStatus: "Success",
        NBest: [
          {
            Lexical: "three developers",
            PronunciationAssessment: { AccuracyScore: 71, FluencyScore: 88, CompletenessScore: 100, ProsodyScore: 64, PronScore: 76 },
            Words: [
              {
                Word: "three",
                PronunciationAssessment: { AccuracyScore: 52, ErrorType: "Mispronunciation" },
                Phonemes: [
                  { Phoneme: "θ", PronunciationAssessment: { AccuracyScore: 31 } },
                  { Phoneme: "r", PronunciationAssessment: { AccuracyScore: 80 } },
                  { Phoneme: "i", PronunciationAssessment: { AccuracyScore: 90 } },
                ],
              },
              { Word: "developers", PronunciationAssessment: { AccuracyScore: 95, ErrorType: "None" }, Phonemes: [] },
            ],
          },
        ],
      },
      "three developers",
    );
    expect(out.measured).toBe(true);
    expect(out.scores?.prosody).toBe(64);
    expect(out.problemWords).toHaveLength(1);
    expect(out.problemWords[0].word).toBe("three");
    expect(out.problemWords[0].worstPhoneme).toEqual({ phoneme: "θ", accuracy: 31 });
    expect(out.problemWords[0].adviceEs).toContain("lengua entre los dientes");
    expect(out.notes.some((n) => n.includes("entonación"))).toBe(true);
  });

  it("parses the flat response shape", () => {
    const out = parseAzureResponse(
      {
        RecognitionStatus: "Success",
        NBest: [
          {
            AccuracyScore: 100,
            FluencyScore: 100,
            PronScore: 95,
            Words: [{ Word: "good", AccuracyScore: 100, ErrorType: "None" }],
          },
        ],
      },
      "good",
    );
    expect(out.scores?.overall).toBe(95);
    expect(out.problemWords).toEqual([]);
  });

  it("explains no-speech results", () => {
    const out = parseAzureResponse({ RecognitionStatus: "InitialSilenceTimeout" }, "develop");
    expect(out.notes[0]).toContain("No se detectó voz");
  });

  it("trims WAV audio to the 30 s REST limit", () => {
    const samples = new Float32Array(16000 * 40);
    const wav = Buffer.from(encodeWav(samples, 16000));
    const trimmed = trimWav(wav, 29.5);
    expect(trimmed.readUInt32LE(40)).toBe(16000 * 2 * 29.5);
    expect(trimmed.length).toBe(44 + 16000 * 2 * 29.5);
  });
});

describe("transcript-only provider is honest", () => {
  it("never claims to measure", async () => {
    const p = createPronunciationProvider("transcript");
    const out = await p.assess({ referenceText: "develop", recognizedText: "the velop", mode: "scripted" });
    expect(out.measured).toBe(false);
    expect(out.problemWords[0].reasonEs).toContain("no es una medición");
    expect(out.notes[0]).toContain("Sin evaluación acústica");
  });
});
